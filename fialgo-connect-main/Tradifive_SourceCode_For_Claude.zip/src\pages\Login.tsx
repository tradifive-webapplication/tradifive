import { useState, useEffect } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, EyeOff, Mail, Lock, User, ArrowRight, Github, ShieldCheck, RefreshCw } from "lucide-react";
import { 
  InputOTP, 
  InputOTPGroup, 
  InputOTPSlot, 
  InputOTPSeparator 
} from "@/components/ui/input-otp";
import tradifiveLogo from "@/assets/tradifive-login-logo.png";
import { supabase } from "@/lib/supabase";
import { PushableButton } from "@/components/PushableButton";
import { toast } from "sonner";
import { recordUserActivity } from "@/lib/activity";

export default function Login() {
  const location = useLocation();
  const [isLogin, setIsLogin] = useState(location.state?.mode !== 'signup');
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState<'auth' | 'otp'>('auth');
  const [otpCode, setOtpCode] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [tempUser, setTempUser] = useState<any>(null);
  const navigate = useNavigate();

  // Force white mode only on the login/register pages
  useEffect(() => {
    document.documentElement.classList.remove("dark");
  }, []);

  useEffect(() => {
    if (location.state?.mode) {
      setIsLogin(location.state.mode !== 'signup');
    }

    // Handle authentication state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      // Only redirect automatically if they JUST signed in or registered
      if (session && (event === 'SIGNED_IN' || event === 'USER_UPDATED')) {
        // We check if this was a programmatic redirect or a fresh login
        // If they just arrived at the page and were already logged in, we let them stay
        const isFreshLogin = sessionStorage.getItem('fresh_login') === 'true';
        if (isFreshLogin) {
          sessionStorage.removeItem('fresh_login');
          navigate("/home");
        }
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [location.state, navigate]);

  const finalizeLogin = async (user: any) => {
    // Clear old cached profile to prevent session pollution
    localStorage.removeItem("tradifive_cached_display_name");
    localStorage.removeItem("tradifive_cached_username");
    localStorage.removeItem("tradifive_cached_avatar_url");
    localStorage.removeItem("tradifive_cached_mt5_acc");
    
    // Clear any stale mock profile overrides from localStorage
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('tradifive_mock_profile_') || key.startsWith('tradifive_privacy_user_'))) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach(key => localStorage.removeItem(key));

    // Set marker for fresh login so the listener knows to redirect
    sessionStorage.setItem('fresh_login', 'true');
    
    // Update last_login_at timestamp
    await supabase
      .from('profiles')
      .update({ last_login_at: new Date().toISOString() })
      .eq('id', user.id);

    // Record activity
    await recordUserActivity('LOGIN', `User logged in from ${window.location.hostname}`);

    toast.success("Welcome back!");
    navigate("/home");
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (otpCode === generatedOtp) {
      await finalizeLogin(tempUser);
    } else {
      toast.error("Invalid verification code. Please try again.");
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (!isLogin) {
        // Sign Up
        if (password !== confirmPassword) {
          toast.error("Passwords do not match");
          setIsLoading(false);
          return;
        }

        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              first_name: firstName,
              last_name: lastName,
            },
          },
        });

        if (error) {
          toast.error(error.message);
        } else if (data.user) {
          const generatedUsername = email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '') + Math.floor(100 + Math.random() * 900);
          
          // Explicitly create a profile row for the new user
          await supabase.from('profiles').upsert({
            id: data.user.id,
            email: email,
            first_name: firstName,
            last_name: lastName,
            full_name: `${firstName} ${lastName}`.trim(),
            username: generatedUsername,
            xp_total: 0,
            xp_level: 1,
            streak_days: 0,
            created_at: new Date().toISOString(),
          }, { onConflict: 'id' });

          if (data.session) {
            localStorage.removeItem("tradifive_cached_display_name");
            localStorage.removeItem("tradifive_cached_username");
            localStorage.removeItem("tradifive_cached_avatar_url");
            localStorage.removeItem("tradifive_cached_mt5_acc");
            toast.success("Account created successfully!");
            navigate("/home");
          } else {
            toast.success("Verification email sent!");
            navigate("/verify-email", { state: { email } });
          }
        }
      } else {
        // Sign In
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (error) {
          toast.error(error.message);
        } else {
          // Check if 2FA is enabled
          const { data: profile } = await supabase
            .from('profiles')
            .select('two_factor_enabled')
            .eq('id', data.user.id)
            .single();

          if (profile?.two_factor_enabled) {
            // Generate a random 6-digit code for mock implementation
            const code = Math.floor(100000 + Math.random() * 900000).toString();
            setGeneratedOtp(code);
            setTempUser(data.user);
            setStep('otp');
            
            toast.info("Institutional 2FA Required", {
              description: `For security, we've sent a code to your terminal. (MOCK: ${code})`,
              duration: 10000,
            });
            setIsLoading(false);
            return;
          }

          // If no 2FA, proceed as normal
          await finalizeLogin(data.user);
        }
      }
    } catch (err: any) {
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      if (step !== 'otp') setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    console.log("Attempting Google login...");
    const toastId = toast.loading("Initializing Google login...");
    
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/home`,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          }
        }
      });
      
      if (error) {
        console.error("Google OAuth Error:", error);
        toast.error(`Login failed: ${error.message}`, { id: toastId });
        return;
      }

      if (data?.url) {
        sessionStorage.setItem('fresh_login', 'true');
        console.log("Redirecting to:", data.url);
        toast.success("Redirecting to Google...", { id: toastId });
      } else {
        console.log("Login initialized, waiting for redirect...");
        toast.dismiss(toastId);
      }
    } catch (err: any) {
      console.error("Unexpected login error:", err);
      toast.error("Failed to initialize Google login. Check console for details.", { id: toastId });
    }
  };

  const handleGithubLogin = async () => {
    console.log("Attempting GitHub login...");
    const toastId = toast.loading("Initializing GitHub login...");
    
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'github',
        options: {
          redirectTo: `${window.location.origin}/home`,
        }
      });
      
      if (error) {
        console.error("GitHub OAuth Error:", error);
        toast.error(`Login failed: ${error.message}`, { id: toastId });
        return;
      }

      if (data?.url) {
        console.log("Redirecting to GitHub:", data.url);
        toast.success("Redirecting to GitHub...", { id: toastId });
      } else {
        toast.dismiss(toastId);
      }
    } catch (err: any) {
      console.error("Unexpected GitHub login error:", err);
      toast.error("Failed to initialize GitHub login.", { id: toastId });
    }
  };

  return (
    <div 
      style={{ fontFamily: "'Inter', sans-serif" }}
      className="flex min-h-screen bg-transparent font-sans selection:bg-primary/10 relative overflow-hidden"
    >
      {/* All fonts loaded globally via index.html (Inter) */}

      {/* Dynamic Background */}
      <div className="login-bg" />

      {/* Left Side - Sidebar with floating black card */}
      <div className="hidden lg:flex lg:w-1/2 p-6 bg-transparent shrink-0 items-center justify-center">
        <div className="w-full h-full bg-[#000000] rounded-[2rem] flex flex-col items-start justify-start p-12 relative overflow-hidden shadow-2xl border border-white/5">

          {/* Main 3D Nexbot Integration */}
          <div className="absolute inset-0 z-0">
            <iframe src='https://my.spline.design/nexbotrobotcharacterconcept-YRlAYft8uwy5vwEuFSt45xvp/' frameBorder='0' width='100%' height='100%' loading="eager"></iframe>
          </div>

          {/* Top-Left Branding Overlay */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.15 }}
            className="relative z-10 flex flex-col items-start pointer-events-none"
          >
            <img src={tradifiveLogo} alt="Tradifive" className="w-[180px] h-auto mb-3" />
            <div className="space-y-0">
              <p className="text-white/60 text-[10px] font-black uppercase tracking-[0.3em] leading-tight">AI-Powered Trading, Unleashed.</p>
            </div>
          </motion.div>

          {/* Mask to hide SPLINE watermark (Bottom Right) */}
          <div className="absolute bottom-0 right-0 w-40 h-12 bg-black z-20 pointer-events-none shadow-[-20px_-10px_40px_rgba(0,0,0,0.8)]" />

          {/* Footer - Restored to 'Built by a Trader, for Traders' */}
          <div className="absolute bottom-10 left-12 z-10">
            <p className="text-white/40 text-[10px] tracking-[0.2em] font-bold uppercase whitespace-nowrap">
              Built by a <span className="text-white font-black cursor-default">Trader</span>, for <span className="text-white font-black cursor-default">Traders</span>
            </p>
          </div>

          {/* Subtle Mask to blend the iframe edges */}
          <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none z-0" />
        </div>
      </div>

      {/* Right Side - Form area */}
      <div className="flex w-full lg:w-1/2 items-center justify-center px-8 lg:px-20 bg-transparent relative">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.15 }}
          className="w-full max-w-[420px]"
        >
          {/* Mobile logo display */}
          <div className="lg:hidden flex flex-col items-center mb-10">
            <img src={tradifiveLogo} alt="Tradifive" className="w-36 h-auto invert brightness-0" />
            <p className="text-slate-400 mt-3 text-[10px] font-bold tracking-widest uppercase">AI-Powered Trading, Unleashed.</p>
          </div>

          <div className="mb-10 text-left">
            <h2 className="text-4xl font-black tracking-tighter text-slate-900 dark:text-white mb-2">
              {step === 'otp' ? "Verify" : isLogin ? "Welcome" : "Get"} <span className="text-primary">{step === 'otp' ? "Identity" : isLogin ? "Back" : "Started"}</span>
            </h2>
            <p className="text-slate-400 text-sm font-semibold">
              {step === 'otp' ? "Enter the institutional 2FA code to continue." : isLogin ? "Please enter your details to sign in." : "Fill in the information to get started."}
            </p>
          </div>

          <AnimatePresence mode="wait">
            {step === 'auth' ? (
              <motion.div
                key="auth-form"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
              >
                <div className="grid grid-cols-2 gap-4 mb-8">
            <button
              onClick={handleGoogleLogin}
              className="flex items-center justify-center gap-2 bg-white dark:bg-[#1A1A1A] border border-slate-100 dark:border-[#333333] hover:bg-slate-50 dark:bg-[#141414] py-3 rounded-xl text-[12px] font-bold uppercase text-slate-700 transition-all shadow-sm"
            >
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-4 h-4" />
              Google
            </button>
            <button 
              onClick={handleGithubLogin}
              className="flex items-center justify-center gap-2 bg-white dark:bg-[#1A1A1A] border border-slate-100 dark:border-[#333333] hover:bg-slate-50 dark:bg-[#141414] py-3 rounded-xl text-[12px] font-bold uppercase text-slate-700 transition-all shadow-sm"
            >
              <Github size={18} className="text-slate-900 dark:text-white" />
              GitHub
            </button>
          </div>

          <div className="flex items-center gap-4 mb-8">
            <div className="h-px flex-1 bg-slate-100 dark:bg-[#1A1A1A]" />
            <span className="text-[10px] text-slate-300 uppercase tracking-widest font-black">Or</span>
            <div className="h-px flex-1 bg-slate-100 dark:bg-[#1A1A1A]" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <AnimatePresence mode="wait">
              {!isLogin && (
                <motion.div
                  key="signup-names"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="grid grid-cols-2 gap-4 overflow-hidden"
                >
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 ml-1">First Name</label>
                    <div className="relative group">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-primary transition-colors">
                        <User size={16} />
                      </div>
                      <input
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-[#141414] border border-slate-100 dark:border-[#333333] rounded-xl py-3 pl-10 pr-4 text-slate-900 dark:text-white placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary/20 transition-all text-sm font-medium"
                        placeholder="John"
                        required={!isLogin}
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 ml-1">Last Name</label>
                    <div className="relative group">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-primary transition-colors">
                        <User size={16} />
                      </div>
                      <input
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-[#141414] border border-slate-100 dark:border-[#333333] rounded-xl py-3 pl-10 pr-4 text-slate-900 dark:text-white placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary/20 transition-all text-sm font-medium"
                        placeholder="Doe"
                        required={!isLogin}
                      />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-1.5">
              <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 ml-1">Email Address</label>
              <div className="relative group">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-primary transition-colors">
                  <Mail size={16} />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-[#141414] border border-slate-100 dark:border-[#333333] rounded-xl py-3 pl-10 pr-4 text-slate-900 dark:text-white placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary/20 transition-all text-sm font-medium"
                  placeholder="name@example.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between items-center px-1">
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Password</label>
                {isLogin && (
                  <Link
                    to="/forgot-password"
                    className="text-[10px] font-extrabold uppercase tracking-wider text-primary hover:text-primary/70 transition-colors"
                  >
                    Forgot password?
                  </Link>
                )}
              </div>
              <div className="relative group">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-primary transition-colors">
                  <Lock size={16} />
                </div>
                <input
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-[#141414] border border-slate-100 dark:border-[#333333] rounded-xl py-3 pl-10 pr-10 text-slate-900 dark:text-white placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary/20 transition-all text-sm font-medium"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500 transition-colors"
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <AnimatePresence>
              {!isLogin && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-1.5 overflow-hidden"
                >
                  <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 ml-1">Confirm Password</label>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-primary transition-colors">
                      <Lock size={16} />
                    </div>
                    <input
                      type={showPw ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-[#141414] border border-slate-100 dark:border-[#333333] rounded-xl py-3 pl-10 pr-4 text-slate-900 dark:text-white placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary/20 transition-all text-sm font-medium"
                      placeholder="••••••••"
                      required={!isLogin}
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="pt-6">
              <PushableButton
                type="submit"
                disabled={isLoading}
                className="w-full"
              >
                {isLoading ? "Processing..." : (
                  <span className="flex items-center justify-center font-bold uppercase tracking-[0.2em] text-[12px] py-1">
                    {isLogin ? "Sign In" : "Create Account"}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </span>
                )}
              </PushableButton>
            </div>
          </form>

              <p className="mt-12 text-center text-[11px] font-bold text-slate-400 tracking-wide uppercase">
                {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
                <button
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-primary hover:text-primary/70 transition-colors ml-1 font-bold"
                >
                  {isLogin ? "Create one" : "Sign in here"}
                </button>
              </p>
            </motion.div>
          ) : (
            <motion.div
              key="otp-form"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="flex flex-col items-center"
            >
              <div className="w-16 h-16 bg-blue-50 dark:bg-blue-600/10 rounded-2xl flex items-center justify-center mb-8 border border-blue-100 dark:border-blue-600/20">
                <ShieldCheck className="text-blue-600" size={32} />
              </div>

              <form onSubmit={handleVerifyOTP} className="w-full space-y-8 flex flex-col items-center">
                <InputOTP
                  maxLength={6}
                  value={otpCode}
                  onChange={(val) => setOtpCode(val)}
                >
                  <InputOTPGroup className="gap-2">
                    {[0, 1, 2, 3, 4, 5].map((index) => (
                      <InputOTPSlot
                        key={index}
                        index={index}
                        className="w-12 h-14 text-xl font-black border-slate-200 dark:border-[#333333] rounded-xl bg-white dark:bg-[#1A1A1A] text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/20"
                      />
                    ))}
                  </InputOTPGroup>
                </InputOTP>

                <div className="w-full space-y-4">
                  <PushableButton
                    type="submit"
                    disabled={isLoading || otpCode.length !== 6}
                    className="w-full"
                  >
                    {isLoading ? "Verifying..." : (
                      <span className="flex items-center justify-center font-bold uppercase tracking-[0.2em] text-[12px] py-1">
                        Authorize Access
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </span>
                    )}
                  </PushableButton>

                  <button
                    type="button"
                    onClick={() => {
                      setStep('auth');
                      setOtpCode("");
                    }}
                    className="w-full py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-600 transition-colors flex items-center justify-center gap-2"
                  >
                    <RefreshCw size={12} />
                    Back to Login
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  </div>
);
}





