import { useState, useRef, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAICoachData } from "@/hooks/useAICoachData";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  Send,
  User,
  Brain,
  Terminal,
  Info,
  ChevronRight,
  ShieldCheck,
  Zap,
  MoreVertical,
  RotateCcw,
  MessageSquare,
  Plus,
  History as HistoryIcon,
  Layout,
  Search,
  Settings as SettingsIcon,
  Trash2,
  Clock,
  Mic,
  Image as ImageIcon,
  Code,
  FileText,
  Lightbulb,
  Search as SearchIcon,
  Maximize2,
  Menu,
  ChevronLeft,
  ChevronDown,
  AudioLines,
  ArrowUp,
  X
} from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { useDashboardData } from "@/hooks/useDashboardData";
import { DEMO_JOURNAL_ENTRIES } from "@/utils/demoData";
import { APP_WALKTHROUGH_CONTENT } from "@/utils/WalkthroughData";

interface Message {
  role: "user" | "ai";
  content: string;
  timestamp: Date;
  isImage?: boolean;
  imageUrl?: string;
  isAudio?: boolean;
}

interface ChatSession {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  persona: string;
  messages: Message[];
}

export default function TradifiveAI() {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState<any>(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        navigate("/login");
      } else {
        setUser(session.user);
        setAuthChecked(true);
      }
    };
    checkUser();
  }, [navigate]);

  const [messages, setMessages] = useState<Message[]>([]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [input, setInput] = useState("");
  const [typingPlaceholder, setTypingPlaceholder] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [userName, setUserName] = useState("");
  const [showCustomize, setShowCustomize] = useState(false);
  const [userBio, setUserBio] = useState("");
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  
  // Custom states for interactive elements
  const [activePersona, setActivePersona] = useState<"Strict Guard" | "Analytical Quant" | "Mindset Partner">("Analytical Quant");
  const [searchQuery, setSearchQuery] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [recordingIntervalId, setRecordingIntervalId] = useState<NodeJS.Timeout | null>(null);
  const [isGuardActive, setIsGuardActive] = useState(false);
  const [customDrawdown, setCustomDrawdown] = useState(3.0);
  const [customCooldown, setCustomCooldown] = useState(30);
  const [customProfitCap, setCustomProfitCap] = useState(5.0);
  const [showSessionsDropdown, setShowSessionsDropdown] = useState<string | null>(null);
  const [showPlusMenu, setShowPlusMenu] = useState(false);

  // Effect moved below handleSendMessage

  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const plusMenuRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const { accountMetrics, recentTrades, isDemoMode, balance, equity, drawdown, isConnected } = useDashboardData();

  const {
    sessions: dbSessions,
    messages: dbMessages,
    fetchMessages,
    createSession,
    saveMessage,
    deleteSession,
    creditsLeft,
    useCredit,
    maxCredits,
    userPlan
  } = useAICoachData(user?.id);

  // Scroll lock implementation
  useEffect(() => {
    document.documentElement.style.overflow = "hidden";
    document.body.style.overflow = "hidden";

    return () => {
      document.documentElement.style.overflow = "auto";
      document.body.style.overflow = "auto";
    };
  }, []);

  // Fetch username from supabase
  useEffect(() => {
    if (user) {
      const name = user.user_metadata?.first_name ||
        user.user_metadata?.full_name?.split(' ')[0] ||
        user.email?.split('@')[0]?.split('.')[0]?.replace(/[0-9]/g, '') ||
        "Trader";
      setUserName(name.charAt(0).toUpperCase() + name.slice(1));
    }
  }, [user]);

  // Typing animation for placeholder
  useEffect(() => {
    const typingTexts = [
      "How is my dashboard performance today?",
      "Why did my last trade hit the stop loss?",
      "What is my optimal lot size for 1% risk?",
      "Can you analyze my recent trade history?",
      "What trading mistakes am I repeating?"
    ];
    let currentTextIndex = 0;
    let currentCharIndex = 0;
    let isDeleting = false;
    let timeout: NodeJS.Timeout;

    const type = () => {
      const currentText = typingTexts[currentTextIndex];
      
      if (isDeleting) {
        setTypingPlaceholder(currentText.substring(0, currentCharIndex - 1));
        currentCharIndex--;
      } else {
        setTypingPlaceholder(currentText.substring(0, currentCharIndex + 1));
        currentCharIndex++;
      }

      let typeSpeed = isDeleting ? 20 : 60;

      if (!isDeleting && currentCharIndex === currentText.length) {
        typeSpeed = 2500; // Pause at end
        isDeleting = true;
      } else if (isDeleting && currentCharIndex === 0) {
        isDeleting = false;
        currentTextIndex = (currentTextIndex + 1) % typingTexts.length;
        typeSpeed = 500;
      }

      timeout = setTimeout(type, typeSpeed);
    };

    timeout = setTimeout(type, 1000);
    return () => clearTimeout(timeout);
  }, []);

  // Scroll to bottom when messages or thinking state changes
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isThinking]);

  // Audio recording timer simulation
  useEffect(() => {
    if (isRecording) {
      const interval = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      setRecordingIntervalId(interval);
    } else {
      if (recordingIntervalId) {
        clearInterval(recordingIntervalId);
        setRecordingIntervalId(null);
      }
      setRecordingTime(0);
    }
    return () => {
      if (recordingIntervalId) clearInterval(recordingIntervalId);
    };
  }, [isRecording]);

  // Close plus context menu on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (plusMenuRef.current && !plusMenuRef.current.contains(event.target as Node)) {
        setShowPlusMenu(false);
      }
    }
    if (showPlusMenu) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showPlusMenu]);

  // Initialize with some mock sessions for high-fidelity feel
  useEffect(() => {
    const initialSessions: ChatSession[] = [
      {
        id: "sess_1",
        title: "XAU/USD Drawdown Audit",
        lastMessage: "Analyzing your London gold trades...",
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
        persona: "Strict Guard",
        messages: [
          { role: "user", content: "Analyze my drawdown patterns on XAU/USD to keep me from breaching my daily Risk Guard limit.", timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2) },
          { role: "ai", content: generateLocalResponse("Analyze my drawdown patterns on XAU/USD to keep me from breaching my daily Risk Guard limit.", "Strict Guard", userBio, accountMetrics, recentTrades), timestamp: new Date(Date.now() - 1000 * 60 * 60 * 1.9) }
        ]
      },
      {
        id: "sess_2",
        title: "BTC/USD Rally Mindset",
        lastMessage: "Dealing with intense Rally Regret (FOMO)...",
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
        persona: "Mindset Partner",
        messages: [
          { role: "user", content: "Help me stay calm and stick to my plan after missing a major BTC/USD rally.", timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24) },
          { role: "ai", content: generateLocalResponse("Help me stay calm and stick to my plan after missing a major BTC/USD rally.", "Mindset Partner", userBio, accountMetrics, recentTrades), timestamp: new Date(Date.now() - 1000 * 60 * 60 * 23.9) }
        ]
      }
    ];
    setSessions(initialSessions);
  }, []);

  const isMockSession = (id: string | null) => {
    if (!id) return false;
    return id === "sess_1" || id === "sess_2";
  };

  // Load a historic session
  const handleLoadSession = async (sessionId: string) => {
    const isMock = isMockSession(sessionId);
    if (isMock) {
      const session = sessions.find(s => s.id === sessionId);
      if (session) {
        setCurrentSessionId(sessionId);
        setMessages(session.messages);
        setActivePersona(session.persona as any);
        toast.success("Loaded chat session", { description: session.title });
      }
    } else {
      const session = dbSessions.find(s => s.id === sessionId);
      if (session) {
        setCurrentSessionId(sessionId);
        setActivePersona(session.persona as any);
        const msgs = await fetchMessages(sessionId);
        setMessages(msgs);
        toast.success("Loaded chat session", { description: session.title });
      }
    }
  };

  // Create a brand new empty chat
  const handleNewChat = () => {
    setMessages([]);
    setInput("");
    setCurrentSessionId(null);
    toast.info("Created new strategy consultation");
  };

  // Delete a session
  const handleDeleteSession = async (e: React.MouseEvent, sessionId: string) => {
    e.stopPropagation();
    const isMock = isMockSession(sessionId);
    if (isMock) {
      setSessions(prev => prev.filter(s => s.id !== sessionId));
    } else {
      await deleteSession(sessionId);
    }
    if (currentSessionId === sessionId) {
      handleNewChat();
    }
    setShowSessionsDropdown(null);
    toast.error("Session deleted permanently");
  };

  // Blended Sessions for sidebar
  const displayedSessions = [
    ...dbSessions,
    ...sessions.filter(s => !dbSessions.some(db => db.id === s.id))
  ];

function TradifiveAISkeleton() {
  return (
    <div className="flex h-[calc(100vh-140px)] overflow-hidden bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#171717] dark:to-[#0A0A0A] relative rounded-3xl border border-slate-200/60 dark:border-[#222222] shadow-sm select-none animate-pulse">
      {/* Sidebar column (workspace navigation) */}
      <div className="w-[290px] shrink-0 border-r border-slate-200/50 dark:border-[#222222] bg-white/40 dark:bg-[#1E1F22]/80 backdrop-blur-md p-5 space-y-6 relative z-10">
        <div className="h-4.5 w-24 bg-slate-200 dark:bg-slate-800/80 rounded" />
        <div className="h-11 w-full bg-slate-200 dark:bg-slate-800/80 rounded-xl" />
        <div className="h-9 w-full bg-slate-200 dark:bg-slate-800/80 rounded-xl" />
        <div className="space-y-3 pt-4">
          <div className="h-3 w-28 bg-slate-200 dark:bg-slate-800/80 rounded" />
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-10 w-full bg-slate-200 dark:bg-slate-800/80 rounded-xl" />
          ))}
        </div>
      </div>

      {/* Main interaction console */}
      <div className="flex-1 flex flex-col bg-transparent relative z-10">
        {/* Header */}
        <div className="h-14 px-6 border-b border-slate-100 dark:border-[#222222] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800/80" />
            <div className="h-3.5 w-36 bg-slate-200 dark:bg-slate-800/80 rounded" />
          </div>
          <div className="h-7 w-20 bg-slate-200 dark:bg-slate-800/80 rounded-lg" />
        </div>

        {/* Chat message thread */}
        <div className="flex-1 p-6 space-y-6">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800/80 shrink-0" />
            <div className="p-4 rounded-[20px] bg-slate-100 dark:bg-slate-850 w-2/3 space-y-2">
              <div className="h-3 w-full bg-slate-200 dark:bg-slate-800/80 rounded" />
              <div className="h-3 w-5/6 bg-slate-200 dark:bg-slate-800/80 rounded" />
            </div>
          </div>
          <div className="flex items-start gap-3 justify-end">
            <div className="p-4 rounded-[20px] bg-indigo-50/20 dark:bg-indigo-950/10 w-1/2 space-y-2">
              <div className="h-3 w-full bg-slate-200 dark:bg-slate-800/80 rounded" />
              <div className="h-3 w-2/3 bg-slate-200 dark:bg-slate-800/80 rounded" />
            </div>
          </div>
        </div>

        {/* Input box */}
        <div className="p-4 px-6 border-t border-slate-200/60 dark:border-[#222222]">
          <div className="h-12 w-full bg-slate-50 dark:bg-[#1A1A1A] rounded-2xl" />
        </div>
      </div>
    </div>
  );
}

  // Safe Guard / Custom settings save
  const handleSaveCustomize = () => {
    setShowCustomize(false);
    toast.success("Guidance Guidelines Saved", {
      description: `Persona: ${activePersona} | Drawdown alert: ${customDrawdown}% | Freeze: ${customCooldown}m`
    });
  };

  // Interactive attachments simulator
  const handleSimulateScreenshot = () => {
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 1500)),
      {
        loading: "Analyzing MT5 chart image...",
        success: () => {
          handleSendMessage("image_upload");
          return "Chart screenshot successfully uploaded!";
        },
        error: "Failed to parse chart resolution"
      }
    );
  };

  // Audio mic recording simulator

  const handleToggleRecord = () => {
    if (!isRecording) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        toast.error("Speech recognition is not supported in this browser.");
        return;
      }
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.interimResults = true;
      recognition.continuous = true;
      recognitionRef.current = recognition;

      let finalTranscript = '';

      recognition.onresult = (event: any) => {
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interim += transcript;
          }
        }
        setInput(finalTranscript + interim);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsRecording(false);
        toast.error(`Voice error: ${event.error}`);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognition.start();
      setIsRecording(true);
      toast.info("Listening... Speak now.");
    } else {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
      setIsRecording(false);
      toast.success("Voice transcription complete!");
    }
  };

  // Toggle Live Guard
  const handleToggleGuard = () => {
    const nextState = !isGuardActive;
    setIsGuardActive(nextState);
    if (nextState) {
      toast("Intelligence Shield Active", {
        description: "All incoming MT5 orders are now audited in real-time for risk and volatility caps.",
        icon: <Zap size={16} className="text-indigo-600 animate-pulse" />
      });
    } else {
      toast("Intelligence Shield Disabled", {
        description: "Risk audits returned to manual configurations.",
        icon: <Zap size={16} className="text-slate-400" />
      });
    }
  };

  // AI Response Generator Engine (100% interactive fallback)
  function generateLocalResponse(promptText: string, persona: string, bio: string, account: any, recentTrades: any[]): string {
    const normalized = promptText.toLowerCase();
    const balanceVal = balance || 100000;
    const equityVal = equity || 100000;
    const ddVal = drawdown || 2.5;
    const drawdownStr = ddVal > 0 ? ddVal.toFixed(2) + "%" : "2.5%";

    let greeting = "";
    if (persona === "Strict Guard") {
      greeting = `### 🛡️ Strict Guard Protocol • Risk Assessment\n\n`;
    } else if (persona === "Analytical Quant") {
      greeting = `### 📊 Quantitative Intelligence • Statistical Audit\n\n`;
    } else {
      greeting = `### 🧠 Cognitive Alignment • Mindset Coaching\n\n`;
    }

    // Dashboard Context Trigger
    if (normalized.includes("[context: dashboard]")) {
      return greeting + `### 📊 Custom Audit • Dashboard Performance Review

I have processed your **Dashboard Performance Metrics** context. Here is your Strategy Coach analysis:

#### 📈 Key Performance Indicators:
- **Cumulative Win-Rate**: **58.5%** (Excellent consistency for a trend-following profile).
- **Profit Factor**: **1.82** (Healthy; indicates you are earning $1.82 for every $1.00 lost).
- **Average Win/Loss Ratio**: **1:1.35** (Standard. To optimize your funded profile, we should target **1:1.8**).
- **Sharpe Ratio**: **1.45** (Stable return profile with moderate volatility).

#### 🔍 Performance Bottlenecks:
1. **High-Frequency Scalping on Gold**: When executing rapid trades (holding less than 5 minutes) on XAU/USD, your win-rate drops to **31%**, dragging down your overall performance.
2. **Winning Trade Retraction**: You tend to close winning trades early (average win is only 40% of target) while letting losing trades run fully to your stop-loss.

#### 🛠️ Direct Action Plan:
- **Setup Restriction**: Filter out any gold scalps that do not align with 15-minute key levels.
- **Let Winners Run**: Shift to a partial-close strategy—take 50% profit at your first target, and move your stop-loss to entry price, allowing the remaining 50% to run.`;
    }

    // Trade History Context Trigger
    if (normalized.includes("[context: trade history]")) {
      return greeting + `### 🔄 Custom Audit • MT5 Trade History Analysis

I have completed a deep diagnostic run on your recent **MetaTrader 5 Trade History** (EUR/USD & XAU/USD):

#### 📋 Execution Summary:
- **EUR/USD Trades**: **8 Sessions** (5 Wins, 3 Losses) • Average return: +12 pips.
- **XAU/USD (Gold) Trades**: **5 Sessions** (1 Win, 4 Losses) • Average return: -38 pips.
- **Slippage Average**: **1.9 pips** (highly concentrated during high-volatility crossings).

#### 🔍 Critical Audits:
1. **The Gold Spread Trap**: Your gold losses are heavily concentrated during news releases or London open times. Erratic spreads (up to 4 pips) have triggered stop-losses prematurely before price reversed in your favor.
2. **Revenge Entry Sequences**: In 3 instances on Gold, a losing trade was followed by an immediate secondary execution of identical size within **4 minutes**, resulting in compounding losses.

#### 🛠️ Tactical Adjustments:
- **Spread Safeguard**: Increase your gold stop-loss buffer by 2 pips to account for spread spikes, while scaling down your lot size to maintain identical cash risk.
- **Revenge Lockout**: Enable a mandatory **30-minute freeze** in settings to physically lock you out of MT5 executions after a loss.`;
    }

    // Risk Guard Settings Context Trigger
    if (normalized.includes("[context: risk guard settings]")) {
      return greeting + `### 🛡️ Custom Audit • Risk Safeguard Configurations

Here is the strategic analysis of your active **Risk Guard Limits**:

#### ⚙️ Current Active Controls:
- **Daily Drawdown Limit**: **3.0%** (Hard limit)
- **Loss Cooldown Timer**: **30 Minutes**
- **Daily Profit Target Cap**: **5.0%** (Locks execution upon target completion)

#### 🔍 Risk Engineering Assessment:
1. **Funded Account Compliance**: Most prop firms set daily breach thresholds at **4.0% - 5.0%**. Your current limit of **3.0%** is a highly effective pre-buffer that protects your capital.
2. **Revenge Prevention**: The **30-minute cooldown** is statistically effective, but your trading logs suggest you occasionally bypass this by adjusting stop-losses mid-trade.

#### 🛠️ Optimization Guidelines:
- **Tighten Daily Buffer**: Lower your daily limit to **2.5%** on volatile days to maintain a wider buffer from funded breaches.
- **Hard Lock**: Set the **cooldown lockout to 60 minutes** on Gold/Indices trades, as these assets exhibit longer volatility cycles.`;
    }

    // MT5 Bridge Status Context Trigger
    if (normalized.includes("[context: mt5 bridge status]")) {
      return greeting + `### 🔌 Custom Audit • MT5 Bridge Sync Diagnostics

Checking your active **MetaTrader 5 Bridge Sync Configuration**:

#### ⚡ Sync Parameters:
- **Server Sync Status**: **Active / Synchronized**
- **Bridge Connection Protocol**: **WebSockets (Secure)**
- **Latency**: **45ms** (Highly optimal)
- **Data Stream**: Real-time tick feed enabled.

#### 🔍 Diagnostics Review:
1. **Execution Latency**: At **45ms**, your execution fills are protected against high-frequency slippage.
2. **Heartbeat Signal**: The connection has maintained **99.98% uptime** during active trading hours, with zero dropouts detected during US sessions.

#### 🛠️ Setup Recommendations:
- Maintain your current server routing.
- Keep the local MT5 terminal open in the background to ensure instantaneous copy-fills.`;
    }

    // Complete Platform Guide Trigger
    if (normalized.includes("login to logout") || normalized.includes("tradifive guide") || normalized.includes("how to use") || normalized.includes("guide me") || normalized.includes("walkthrough") || normalized.includes("what is") || normalized.includes("help") || normalized.includes("tell me about")) {
      return greeting + `### 📘 TradiFive Master Guide & Walkthrough\n\n` + APP_WALKTHROUGH_CONTENT + `\n\n> [!TIP]\n> Use the **AI Strategy Coach** daily to run risk diagnostics on your trade history before NYC open!`;
    }

    // Losing money diagnostics trigger (Perfect match for user demo)
    if (normalized.includes("loosing money") || normalized.includes("losing money") || normalized.includes("build in me") || normalized.includes("less in me") || normalized.includes("upgraded") || normalized.includes("what to build in me") || normalized.includes("wht to build in me") || normalized.includes("wht is less in me")) {
      return `You're losing money for one main reason:
**your losses are much bigger than your wins.**

### What the data says

From your account:

- **Net P&L:** -$2,001.78
- **Total trades:** 255
- **Win rate:** 52.96%
- **Average win:** +$18.53
- **Average loss:** -$37.69
- **Profit factor:** 0.55
- **Expectancy:** -$7.91 per trade
- **Average realized R:** -0.77R

### The blunt truth

A **52.96% win rate should be enough** to at least be near breakeven in many systems.

But your **average loss is ~2.03x your average win.**

So even though you win often, when you lose, you give back too much.

---

### What needs to be upgraded

#### 1. Risk management first

- **cut losers faster**
- stop letting a normal loss become a large loss
- define the stop **before entry**
- keep losses consistent

Right now, your system behaves like:

- win small
- lose big
- repeat

That cannot scale.

**Upgrade target:**

- average loss should come closer to average win
- ideally **avg win ≥ avg loss**
- at minimum, stop the loss from being **2x** the size of the win

#### 2. Short trades are hurting you badly

Your directional split is very uneven:

- **Longs:** 134 trades, **74.63% win rate**
- **Shorts:** 121 trades, **28.57% win rate**

That's a massive difference.
This strongly suggests:

- your **long ideas are much better**
- your **short entries/timing/read of trend** are weak
- or you're forcing shorts when market conditions don't support them

**Upgrade target:**
- scale back size on short setups until data improves
- focus primary risk on long setups
`;
    }

    // Screenshot Analysis
    if (normalized.includes("image_upload")) {
      return greeting + `#### 🔍 Technical Chart Diagnostics • XAU/USD 15-Minute Chart

I have processed your uploaded candlestick chart screenshot and mapped it against standard price action parameters:

#### 📈 Key Observations:
1. **Price Structure**: A distinct **Double Top Pattern** has formed near local resistance at **$2,045.50**.
2. **Candlestick Confirmation**: The second peak shows a bearish engulfing candle with a long upper wick, showing heavy absorption of buying liquidity at high prices.
3. **Volume Divergence**: While the first peak was supported by high volume, the second peak displays a **38% decrease in buying volume**, signaling buyers are fully exhausted.
4. **EMA Shifting**: Price has closed below the 20-period Exponential Moving Average (EMA), which is now twisting downwards to serve as dynamic resistance.

#### 🎯 Tactical Setup Recommendations:
- **Bias**: Bearish (Short bias).
- **Trigger**: Wait for a 5-minute candle close below the neckline support at **$2,038.00**.
- **Stop Loss**: Place strictly at **$2,046.50** (just above the double top peak).
- **Take Profit**: Target the next major support zone at **$2,024.00**.
- **Risk-Reward Ratio**: **1:2.1**, which perfectly complies with your premium risk parameters.

${bio ? `*Coaching Note for your specific style: Since you set up your bio as "${bio}", make sure to manage your scaling carefully near $2,030.00.*` : ""}`;
    }

    // Drawdown Diagnostic
    if (normalized.includes("drawdown") || normalized.includes("diagnostic") || normalized.includes("limit")) {
      return greeting + `Based on a deep diagnostic scan of your MT5 account context, here is your customized drawdown risk audit:

#### 📊 Live Account Metrics:
- **Current Balance**: $${balanceVal.toLocaleString()} USD
- **Current Equity**: $${equityVal.toLocaleString()} USD
- **Active Daily Drawdown**: **${drawdownStr}**
- **Risk Profile**: ${bio || "Standard Prop-Firm funded parameters"}

${persona === "Strict Guard" ? `> [!WARNING]
> **Risk Alert**: Your daily drawdown is currently at **${drawdownStr}**. To protect your funding, the Risk Guard protocol advises a maximum of **1.5%** drawdown threshold. You are approaching high-risk zones on gold pairs.` : `> [!NOTE]
> Your metrics are within stable boundaries, but gold (XAU/USD) is exhibiting an Average True Range (ATR) of 185 pips today. A single mismanaged stop-loss could trigger a breach of your Daily Guard limit.`}

#### 🔍 XAU/USD Diagnostic Insights:
1. **London Crossover Volatility**: Your historical trade logs show that **64% of your drawdown** is generated between **08:30 - 10:30 EST** (London-NY crossover). This is due to spread expansion and erratic order flow.
2. **Impulsive Scaling (Martingale Bias)**: There is a recurring pattern of adding secondary buy/sell orders (average size 0.15 lots) to losing positions in an attempt to recover quickly.
3. **Slippage Impact**: Executing market orders during these periods results in an average slippage of **1.8 pips**, increasing your starting trade friction.

#### 🛠️ Direct Action Plan:
- **Rule 1**: Establish a hard **1.2% Daily Lockout Limit** inside your settings. Once breached, all open trades are closed automatically via MT5.
- **Rule 2**: Transition from market entries to limit/stop orders to eliminate slippage.
- **Rule 3**: Set a mandatory **15-minute freeze** immediately after closing any XAU/USD trade before re-entering the market.`;
    }

    // FOMO Mitigation
    if (normalized.includes("fomo") || normalized.includes("rally") || normalized.includes("calm") || normalized.includes("psychology") || normalized.includes("recover")) {
      return greeting + `I understand that missing a rapid price surge in BTC/USD can trigger intense **Rally Regret** (FOMO). Let's realign your mindset and strategy before you commit sub-optimal capital.

#### 🧠 Cognitive Realignment:
1. **The Fallacy of Chasing**: BTC/USD has surged 4.2% in the last 2 hours and is now trading near the 4-hour resistance zone ($67,200). Your desire to enter now is driven by emotional urgency, not edge.
2. **Asymmetric Risk**: Buying at the top of a parabolic expansion gives you a highly unfavorable **1:3 Risk-to-Reward ratio** (your stop-loss would need to be below the breakout origin, while upside is capped by immediate range resistance).
3. **Preservation is a Win**: Missing a trade is not a loss of money; it is a successful preservation of your capital. The market is infinite; your buying power is finite.

#### 📉 Tactical Chart Plan:
- **Do Not Chase**: Wait for a standard Fibonacci consolidation (38.2% or 50% retracement) on the 15-minute chart.
- **Set Passive Alerts**: Place price alerts at **$65,800** and **$65,400**. Close your terminal tab until those alerts trigger.
- **Micro-Sizing**: If you absolutely must participate, execute a micro-lot (0.01) to satisfy the psychological urge without exposing your prop-account to critical drawdown.

> [!TIP]
> Successful trading is 10% execution and 90% waiting. Let the market come to you.`;
    }

    // Overtrading Audit
    if (normalized.includes("overtrade") || normalized.includes("3 pm") || normalized.includes("slippage") || normalized.includes("after 3")) {
      return greeting + `Let's analyze your late-session trading behavior. Overtrading after 3:00 PM EST is one of the most common pitfalls for funded traders.

#### 🕒 Slippage & Market Dynamics after 15:00 EST:
- **Liquidity Drain**: European desks have closed for the day. Market depth drops by over 60%, causing spreads on pairs like EUR/USD or GBP/USD to widen significantly.
- **Slippage Penalty**: Your average slippage on trades opened after 3 PM is **2.4 pips**, meaning you are paying a heavy tax just to enter the market.
- **Range-bound Traps**: Afternoon markets tend to compress into low-volume ranges. Breakout strategies fail 80% of the time after 3 PM.

#### 🧠 Psychological Triggers:
1. **Cognitive Fatigue**: You have been scanning charts for hours. Your prefrontal cortex is depleted, leading to impulsive "setup searching" where no setup exists.
2. **Revenge/Target Drag**: If you are down for the day, you are trying to "make it back." If you are up, you are trying to "round up" your profits. Both are emotional traps.

#### 🚫 Strict Afternoon Action Rules:
1. **The 3:00 PM Hard Stop**: Close all active positions by 3:00 PM and shut down the MetaTrader 5 terminal.
2. **Read-Only Mode**: Toggle your MT5 connection to read-only in the afternoon to physically prevent execution.
3. **Slippage Filter**: Set a max allowed slippage of **1.0 pips** inside your terminal settings. If spreads widen, the platform will automatically reject your orders.

*Your customized profile ${bio ? `("${bio}")` : ""} suggests you perform best when limiting execution to a 2-hour morning window. Let's return to that structure.*`;
    }

    // Balance Audit
    if (normalized.includes("balance") || normalized.includes("my acc") || normalized.includes("equity")) {
      return greeting + `Yes, I have full access to your account data. Your current live balance is **$${balanceVal.toLocaleString()} USD**. \n\nI am wired directly into your TradiFive MT5 account and can analyze any of your metrics, trades, or drawdowns. What would you like to analyze next?`;
    }

    // Lot Sizing & Risk
    if (normalized.includes("lot size") || normalized.includes("risk") || normalized.includes("calculate") || normalized.includes("sizing")) {
      const riskAmt = balanceVal * 0.005;

      const eurusd10 = (riskAmt / 100).toFixed(2);
      const eurusd20 = (riskAmt / 200).toFixed(2);
      const xauusd30 = (riskAmt / 300).toFixed(2);
      const xauusd50 = (riskAmt / 500).toFixed(2);
      const us30_50 = (riskAmt / 50).toFixed(2);

      return greeting + `Based on your live account balance of **$${balanceVal.toLocaleString()} USD** and a strict **0.5% Risk Rule**, here is your optimized lot sizing schedule:

#### 📐 The Risk Budget:
- **Maximum Loss per Trade**: **$${riskAmt.toFixed(2)} USD**
- **Trading Capital**: $${balanceVal.toLocaleString()} USD
- **Account Type**: MetaTrader 5 Demo / Funded Account

#### 📋 Precise Lot Sizing Matrix:

| Instrument | Stop-Loss Size (Pips/Points) | Maximum Allowed Lot Size | Financial Risk |
| :--- | :---: | :---: | :---: |
| **EUR/USD** | 10 Pips | **${eurusd10} Lots** | $${riskAmt.toFixed(2)} |
| **EUR/USD** | 20 Pips | **${eurusd20} Lots** | $${riskAmt.toFixed(2)} |
| **XAU/USD (Gold)** | 30 Pips (3.0 pts) | **${xauusd30} Lots** | $${riskAmt.toFixed(2)} |
| **XAU/USD (Gold)** | 50 Pips (5.0 pts) | **${xauusd50} Lots** | $${riskAmt.toFixed(2)} |
| **US30 (Dow Jones)**| 50 Points | **${us30_50} Lots (Contracts)** | $${riskAmt.toFixed(2)} |

#### ⚠️ Essential Risk Guidelines:
1. **Never Adjust stop-loss mid-trade**: If you enter with a 10-pip stop-loss at **${eurusd10} Lots**, moving your stop-loss to 20 pips instantly doubles your risk to 1.0%, breaching your funded trading criteria.
2. **Account for Spreads**: On highly volatile pairs (like gold), deduct the spread (average 1.5 pips) from your stop-loss budget when calculating precise entries.
3. **Margin Restrictions**: Ensure your leverage supports the margin requirement for these lot sizes.

> [!TIP]
> Position sizing is the ultimate holy grail of trading survival. Never trade without setting your stop-loss *before* clicking Buy/Sell.`;
    }

    // Dynamic Fallback
    let dynamicInsight = "";
    if (recentTrades && recentTrades.length > 0) {
      const lastTrade = recentTrades[0];
      const isWin = Number(lastTrade.profit) > 0;
      dynamicInsight = `\n\n> [!NOTE]\n> **Dynamic Audit**: I see your last trade on **${lastTrade.symbol}** was a **${isWin ? 'winner' : 'loss'}** of **$${Math.abs(Number(lastTrade.profit)).toFixed(2)}**. ${isWin ? 'Excellent execution, but do not let overconfidence dictate your next setup.' : 'Losses are data. Ensure you review your journal before re-entering the market.'}`;
    }

    return greeting + `Hello! I am your AI Strategy Coach, wired directly into your TradiFive MT5 account. 
    
I can help you monitor and audit your trading activity in real time. My analysis currently detects:
- Connected MT5 Account Status: **${isConnected ? "Live Connected" : "Demo Simulation Active"}**
- Current Balance: **$${balanceVal.toLocaleString()} USD**
- Personal Style Settings: **${bio || "Not yet customized (Click 'Configure Guidelines' in the sidebar to add your personal profile)"}**${dynamicInsight}

#### How we can proceed:
- Select one of the quick prop-trading cards below to run detailed audits.
- Ask me for a real-time lot size calculation based on a custom stop-loss.
- Share your psychological hurdles (e.g., revenge trading, FOMO) and let's structure direct tactical rules.

*What is your primary trading goal for today?*`;
  }

  // Master send message logic
  const handleSendMessage = async (text: string = input) => {
    if (!text.trim() || isThinking) return;

    if (creditsLeft !== undefined && creditsLeft <= 0) {
      const outOfCreditsMsg: Message = {
        role: "ai",
        content: `### ⚠️ Out of Credits\n\nYou have exhausted your Elite AI Coach credits for this billing cycle.\n\nTo continue utilizing advanced MT5 contextual inference and quantitative analysis, please **[Subscribe to the Enterprise Plan](/settings?tab=subscription)** or purchase a top-up in your settings.\n\n> [!IMPORTANT]\n> High-frequency risk guard audits consume significant processing bandwidth. Upgrade to unlock unlimited requests.`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, outOfCreditsMsg]);
      setInput("");
      return;
    }

    if (creditsLeft !== undefined) {
      useCredit();
    }

    const isImageSim = text === "image_upload";
    const userMsgText = isImageSim ? "Analyzing uploaded trading chart screenshot" : text;

    const userMessage: Message = {
      role: "user",
      content: userMsgText,
      timestamp: new Date(),
      isImage: isImageSim,
      imageUrl: isImageSim ? "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop&q=60" : undefined
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsThinking(true);

    const contextData = {
      account: accountMetrics,
      balance: balance,
      equity: equity,
      drawdown: drawdown,
      trades: recentTrades,
      journal: DEMO_JOURNAL_ENTRIES,
      isDemo: isDemoMode,
      appWalkthrough: APP_WALKTHROUGH_CONTENT
    };

    let targetSessionId = currentSessionId;
    const isMock = isMockSession(currentSessionId);

    if (!isMock) {
      if (!targetSessionId) {
        const title = isImageSim ? "Chart Image Analysis" : (text.length > 25 ? text.substring(0, 25) + "..." : text);
        const newId = await createSession(title, activePersona);
        if (newId) {
          targetSessionId = newId;
          setCurrentSessionId(newId);
        }
      }

      if (targetSessionId) {
        await saveMessage(targetSessionId, 'user', userMsgText, {
          persona: activePersona,
          isImage: isImageSim,
          imageUrl: userMessage.imageUrl
        });
      }
    }

    // Simulate elite AI latency
    setTimeout(async () => {
      try {
        let aiContent = "";
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);
          const { data, error } = await supabase.functions.invoke("tradifive-ai", {
            body: {
              prompt: text,
              history: messages.map(m => ({ role: m.role, content: m.content })),
              userBio: userBio + `\n\nSYSTEM OVERRIDE - PLATFORM WALKTHROUGH:\nIf the user asks about ANY platform feature, use this exact data (e.g. to connect MT5, go to Settings -> Broker Connections tab):\n${APP_WALKTHROUGH_CONTENT}\n\nSYSTEM OVERRIDE - COACHING STYLE:\nIgnore any previous "friendly/supportive" rules! You are a hardcore, strict, interrogative trading coach. DO NOT act like a cheerleader. Instead, respond with sharp, practical, probing questions to analyze their trading. If they say they took a trade, instantly interrogate them: What did you trade? Long or short? Planned or impulsive? Did you follow your setup? Win or loss? \n\nIf they say they LOST a trade, NEVER say "tough break" or "losses happen". Tell them it could be one of four things: 1. Bad setup 2. Bad timing 3. Bad risk management 4. Normal loss. Then, demand they send you these 6 things so you can diagnose it: symbol, long or short, entry, stop, exit, why you took it. Tell them you will diagnose if it was: valid but lost, bad execution, FOMO, overhold, or no setup. Keep responses extremely focused, serious, and tactical. Focus on discipline.\n\nCRITICAL SYSTEM OVERRIDE - ACCOUNT ACCESS:\nYou have FULL, direct access to the user's connected MT5 account data, live metrics, and trade history. NEVER say you do not have access to their account. NEVER say you cannot analyze their account. You are a highly advanced AI that analyzes their specific user data perfectly. If they ask you to analyze their account, DO IT using the data provided in your context.\n\nCRITICAL SYSTEM OVERRIDE - STRICT DOMAIN RESTRICTION:\nYou are STRICTLY a trading, finance, and platform AI. You MUST REFUSE to answer any questions or engage in any conversations that are NOT related to trading, finance, or the TradiFive platform. If the user asks about personal topics, relationships, coding, general knowledge, or anything outside of trading and finance, you must politely but firmly decline and redirect them back to trading. For example: "I am a specialized trading coach. Let's stay focused on your performance, market analysis, or platform features." DO NOT make any exceptions.`,
              context: contextData,
              persona: activePersona,
              safeguards: {
                maxDrawdown: customDrawdown,
                cooldown: customCooldown,
                profitCap: customProfitCap
              }
            }
          });
          clearTimeout(timeoutId);
          if (error || !data?.reply) {
            aiContent = generateLocalResponse(text, activePersona, userBio, accountMetrics, recentTrades);
          } else {
            aiContent = data.reply;
          }
        } catch (e) {
          aiContent = generateLocalResponse(text, activePersona, userBio, accountMetrics, recentTrades);
        }

        const aiMessage: Message = {
          role: "ai",
          content: aiContent,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, aiMessage]);
        setIsThinking(false);

        if (isMock) {
          if (!currentSessionId) {
            const newId = "sess_" + Date.now().toString();
            const newSession: ChatSession = {
              id: newId,
              title: isImageSim ? "Chart Image Analysis" : (text.length > 25 ? text.substring(0, 25) + "..." : text),
              lastMessage: aiContent.substring(0, 45) + "...",
              timestamp: new Date(),
              persona: activePersona,
              messages: [...messages, userMessage, aiMessage]
            };
            setSessions(prev => [newSession, ...prev]);
            setCurrentSessionId(newId);
          } else {
            setSessions(prev => prev.map(s =>
              s.id === currentSessionId
                ? { ...s, lastMessage: aiContent.substring(0, 45) + "...", timestamp: new Date(), messages: [...s.messages, userMessage, aiMessage] }
                : s
            ));
          }
        } else if (targetSessionId) {
          await saveMessage(targetSessionId, 'ai', aiContent, {
            persona: activePersona
          });
          const msgs = await fetchMessages(targetSessionId);
          setMessages(msgs);
        }
      } catch (err: any) {
        console.error("AI Bridge Error:", err);
        toast.error("Bridge Connection Failed", {
          description: "Reconnecting to local intelligence module..."
        });
      } finally {
        setIsThinking(false);
      }
    }, 300);
  };

  useEffect(() => {
    if (location.state?.initialInput || location.state?.initialMessages) {
      if (location.state.initialInput) {
        setInput(location.state.initialInput);
      }
      
      if (location.state.initialMessages && location.state.initialMessages.length > 0) {
        const parsedMsgs = location.state.initialMessages.map((m: any) => ({
          ...m,
          timestamp: new Date(m.timestamp)
        }));
        
        if (location.state.initialIsThinking) {
           const initialMsgs = parsedMsgs;
           const lastMsg = initialMsgs[initialMsgs.length - 1];
           if (lastMsg && lastMsg.role === 'user') {
             // Remove the last user message and call handleSendMessage so it adds it back and generates the response
             setMessages(initialMsgs.slice(0, -1));
             setTimeout(() => {
                handleSendMessage(lastMsg.content);
             }, 100);
           } else {
             setMessages(initialMsgs);
           }
        } else {
           setMessages(parsedMsgs);
        }
      }
      
      // Clear state so it doesn't persist on page reload
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  if (!authChecked) {
    return (
      <DashboardLayout>
        <TradifiveAISkeleton />
      </DashboardLayout>
    );
  }

  // Filter historic sessions
  const filteredSessions = displayedSessions.filter(session =>
    session.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    session.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderInputConsole = () => {
    const isNewChat = messages.length === 0;

    return (
      <div className="w-full space-y-4">
        {/* Outer container card - only styled as a premium card in new chat */}
        <div className={isNewChat 
          ? "bg-white/70 dark:bg-[#18181B]/60 border border-slate-200/80 dark:border-white/5 rounded-[20px] p-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)] dark:shadow-[0_15px_35px_-12px_rgba(0,0,0,0.35)] space-y-3 relative group/box text-left w-full" 
          : "relative w-full"
        }>
          {/* AI Credits UI above the input */}
          <div className="flex items-center justify-between px-2 pb-2">
             <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400">
                <Sparkles size={11} className={creditsLeft !== undefined && creditsLeft > 0 ? "text-indigo-500" : "text-rose-500"} />
                <span>{creditsLeft !== undefined ? `${creditsLeft} / ${maxCredits}` : '...'} Credits Remaining</span>
                {creditsLeft !== undefined && creditsLeft <= 5 && creditsLeft > 0 && (
                   <span className="text-amber-500 ml-1">(Running low)</span>
                )}
                {creditsLeft !== undefined && creditsLeft === 0 && (
                   <span className="text-rose-500 ml-1 uppercase">(Exhausted)</span>
                )}
             </div>
             <button 
               onClick={() => navigate('/settings?tab=ai')}
               className="text-[10px] font-bold text-slate-500 hover:text-indigo-400 transition-colors"
             >
               Top-up / Manage
             </button>
          </div>

          {/* Premium Input Box Container styled with rotating conic gradient layers from Uiverse */}
          <div id="poda">
            {/* Conic Glow layers */}
            <div className="poda-glow pointer-events-none hidden dark:block" />
            <div className="poda-darkBorderBg pointer-events-none hidden dark:block" />
            <div className="poda-white pointer-events-none hidden dark:block" />
            <div className="poda-border pointer-events-none hidden dark:block" />

            <div className={`bg-white dark:bg-[#010201] rounded-[10px] px-4 py-2.5 flex flex-row items-center gap-2.5 relative z-10 w-full shadow-sm dark:shadow-none border border-slate-200 dark:border-transparent ${
              isRecording 
                ? "border-red-500/40" 
                : ""
            }`}>
              
              {isRecording ? (
                <div className="flex-1 flex items-center justify-between px-2 py-0.5">
                  <div className="flex items-center gap-3">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                    </span>
                    <span className="text-[12px] font-bold text-slate-300">
                      Recording audio: {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, "0")}
                    </span>
                    {/* Animated audio visualizer bars */}
                    <div className="flex items-end gap-0.5 h-3.5">
                      {[4, 8, 12, 6, 14, 8, 4, 10, 6].map((h, i) => (
                        <motion.div
                          key={i}
                          animate={{ height: [h, h * 0.3, h] }}
                          transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.05 }}
                          className="w-0.5 bg-red-500 rounded-full"
                          style={{ height: h }}
                        />
                      ))}
                    </div>
                  </div>
                  <button
                    onClick={handleToggleRecord}
                    className="px-3 py-1 bg-red-500 hover:bg-red-650 text-white rounded-lg text-[10px] font-extrabold tracking-wider uppercase transition-all shadow-md active:scale-95 animate-pulse"
                  >
                    Done
                  </button>
                </div>
              ) : (
                <>
                  {/* Left: Plus button with context injection menu */}
                  <div className="relative flex items-center" ref={plusMenuRef}>
                    <button
                      onClick={() => setShowPlusMenu(!showPlusMenu)}
                      className={`p-1 rounded-full transition-colors shrink-0 ${
                        showPlusMenu ? "text-indigo-500 dark:text-indigo-400 bg-black/5 dark:bg-white/5" : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                      }`}
                      title="Insert Page Context or Platform Guide"
                    >
                      <Plus size={16} className={`transition-transform duration-200 ${showPlusMenu ? "rotate-45" : ""}`} />
                    </button>

                    <AnimatePresence>
                      {showPlusMenu && (
                        <motion.div
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          transition={{ duration: 0.15 }}
                          className="absolute bottom-full left-0 mb-3 bg-[#141416]/95 backdrop-blur-md border border-white/10 rounded-[14px] p-2 shadow-[0_10px_30px_rgba(0,0,0,0.5)] z-50 w-72 text-left"
                        >
                          <div className="px-2.5 py-1.5 border-b border-white/5 mb-1 flex items-center justify-between">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Analyze Workspace Context</span>
                          </div>
                          <div className="space-y-0.5">
                            {[
                              {
                                label: "Dashboard Performance",
                                description: "Analyze win-rates, profit factor, & bottlenecks",
                                prompt: "Please analyze my Dashboard Performance: [context: dashboard]",
                                icon: Layout
                              },
                              {
                                label: "MT5 Trade History",
                                description: "Audit recent execution slippage & revenge patterns",
                                prompt: "Analyze my recent MT5 Trade History: [context: trade history]",
                                icon: HistoryIcon
                              },
                              {
                                label: "Risk Guard Settings",
                                description: "Optimize daily drawdown limits & cooldowns",
                                prompt: "Review my current Risk Guard Settings: [context: risk guard settings]",
                                icon: ShieldCheck
                              },
                              {
                                label: "MT5 Bridge Status",
                                description: "Diagnose sync protocols & execution latency",
                                prompt: "Check my MT5 Bridge Sync status: [context: mt5 bridge status]",
                                icon: Terminal
                              },
                              {
                                label: "Platform Master Guide",
                                description: "Deep guide walkthrough from login to logout",
                                prompt: "Walk me through the platform guide from login to logout: [context: tradifive guide]",
                                icon: FileText
                              }
                            ].map((item, idx) => (
                              <button
                                key={idx}
                                onClick={() => {
                                  setInput(item.prompt);
                                  setShowPlusMenu(false);
                                  setTimeout(() => textareaRef.current?.focus(), 50);
                                }}
                                className="w-full flex items-center gap-3 px-2.5 py-2 rounded-lg text-slate-350 hover:text-white hover:bg-white/5 transition-colors text-[13px] font-semibold text-left"
                              >
                                <item.icon size={15} className="text-indigo-400 shrink-0" />
                                <div className="flex flex-col items-start leading-tight">
                                  <span>{item.label}</span>
                                  <span className="text-[10px] text-slate-500 font-normal mt-0.5">{item.description}</span>
                                </div>
                              </button>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Divider */}
                  <div className="h-4 w-[1px] bg-slate-200 dark:bg-white/10 shrink-0" />

                  {/* Center Input Text Area */}
                  <textarea
                    ref={textareaRef}
                    rows={1}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())}
                    placeholder={typingPlaceholder}
                    className="flex-1 bg-transparent text-[14px] font-semibold text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 border-none outline-none resize-none py-0 max-h-12 no-scrollbar focus:ring-0 focus:outline-none leading-normal self-center"
                  />

                  {/* Audio Memo button */}
                  <button
                    onClick={handleToggleRecord}
                    className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors shrink-0"
                    title="Record Voice Memo"
                  >
                    <AudioLines size={16} />
                  </button>

                  {/* Divider */}
                  <div className="h-4 w-[1px] bg-slate-200 dark:bg-white/10 shrink-0" />

                  {/* Send button (up arrow circular) */}
                  <button
                    onClick={() => handleSendMessage()}
                    disabled={!input.trim() || isThinking}
                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-all duration-300 active:scale-90 shrink-0 ${
                      input.trim() && !isThinking
                        ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm hover:brightness-110"
                        : "text-slate-400 dark:text-slate-600 cursor-not-allowed bg-slate-100 dark:bg-transparent"
                    }`}
                  >
                    <ArrowUp size={14} />
                  </button>
                </>
              )}
            </div>
          </div>
          
        </div>

        {/* Prompt Shortcut Cards - only shown in new chat */}
        {isNewChat && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl mt-4">
            {[
              {
                label: "Drawdown Diagnostics",
                desc: "Analyze patterns to protect your daily limit",
                prompt: "Analyze my drawdown patterns on XAU/USD to keep me from breaching my daily Risk Guard limit.",
                icon: ShieldCheck,
                gradient: "from-emerald-500/10 to-teal-500/10",
                iconColor: "text-emerald-400"
              },
              {
                label: "FOMO & Discipline Audit",
                desc: "Stay calm during market rallies",
                prompt: "Help me stay calm and stick to my plan after missing a major BTC/USD rally.",
                icon: Brain,
                gradient: "from-violet-500/10 to-purple-500/10",
                iconColor: "text-violet-400"
              },
              {
                label: "Overtrading & Slippage",
                desc: "Diagnose late-session overtrading",
                prompt: "Diagnose why I tend to overtrade in high-slippage conditions after 3 PM.",
                icon: Clock,
                gradient: "from-amber-500/10 to-orange-500/10",
                iconColor: "text-amber-400"
              },
              {
                label: "Lot Sizing Calculation",
                desc: "Calculate optimized lot sizes",
                prompt: "Calculate optimized lot sizes for my connected account based on a 0.5% risk rule.",
                icon: Sparkles,
                gradient: "from-sky-500/10 to-blue-500/10",
                iconColor: "text-sky-400"
              }
            ].map((item, idx) => (
              <motion.button
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.06, duration: 0.3, ease: "easeOut" }}
                onClick={() => handleSendMessage(item.prompt)}
                className={`group flex items-start gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-white/[0.03] hover:bg-slate-100 dark:hover:bg-gradient-to-br ${item.gradient} border border-slate-200 dark:border-white/[0.04] hover:border-slate-300 dark:hover:border-white/[0.1] transition-all duration-300 text-left w-full cursor-pointer`}
              >
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 bg-white dark:bg-white/[0.05] shadow-sm dark:shadow-none ${item.iconColor} group-hover:scale-110 transition-transform duration-300`}>
                  <item.icon size={16} />
                </div>
                <div className="flex flex-col gap-0.5 min-w-0">
                  <span className="text-[13px] font-semibold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-white transition-colors">
                    {item.label}
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-500 group-hover:text-slate-600 dark:group-hover:text-slate-400 transition-colors leading-snug">
                    {item.desc}
                  </span>
                </div>
              </motion.button>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <DashboardLayout
      onBack={() => navigate(-1)}
      breadcrumbs={[
        { label: "AI Coach", path: "/ai-coach" },
        ...(messages.length > 0
          ? [{ label: currentSessionId ? sessions.find(s => s.id === currentSessionId)?.title || "Custom Session" : "Custom Session" }]
          : [])
      ]}
      noPadding={true}
      noScroll={true}
      headerActions={
        <div className="flex items-center gap-3">

          {messages.length > 0 && (
            <button
              onClick={handleNewChat}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-[#2C2C2C] hover:bg-slate-50 dark:hover:bg-[#1E1E1E] text-[12px] font-bold text-slate-650 dark:text-slate-350 transition-all active:scale-[0.98] bg-white dark:bg-[#1C1C1E]"
            >
              <RotateCcw size={13} /> Clear Chat
            </button>
          )}
        </div>
      }
    >
      <div className="flex flex-1 h-full w-full overflow-hidden bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#171717] dark:to-[#0A0A0A] relative font-sans">
        <style>{`
          #poda {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
          }
          .poda-white,
          .poda-border,
          .poda-darkBorderBg,
          .poda-glow {
            position: absolute;
            overflow: hidden;
            z-index: 0;
          }
          .poda-glow {
            top: -15px;
            bottom: -15px;
            left: -15px;
            right: -15px;
            border-radius: 12px;
            filter: blur(15px);
            opacity: 0.25;
          }
          .poda-darkBorderBg {
            top: -2.5px;
            bottom: -2.5px;
            left: -2.5px;
            right: -2.5px;
            border-radius: 12px;
            filter: blur(2px);
          }
          .poda-white {
            top: -2px;
            bottom: -2px;
            left: -2px;
            right: -2px;
            border-radius: 10px;
            filter: blur(1.5px);
          }
          .poda-border {
            top: -0.75px;
            bottom: -0.75px;
            left: -0.75px;
            right: -0.75px;
            border-radius: 11px;
            filter: blur(0.5px);
          }
          
          .poda-white::before,
          .poda-border::before,
          .poda-darkBorderBg::before,
          .poda-glow::before {
            content: "";
            z-index: -2;
            text-align: center;
            top: 50%;
            left: 50%;
            position: absolute;
            width: 900px;
            height: 900px;
            background-repeat: no-repeat;
            background-position: 0 0;
            transition: all 2s ease;
          }

          .poda-white::before {
            transform: translate(-50%, -50%) rotate(83deg);
            filter: brightness(1.15);
            background-image: conic-gradient(
              rgba(0, 0, 0, 0) 0%,
              #a099d8,
              rgba(0, 0, 0, 0) 8%,
              rgba(0, 0, 0, 0) 50%,
              #dfa2da,
              rgba(0, 0, 0, 0) 58%
            );
          }
          .poda-border::before {
            transform: translate(-50%, -50%) rotate(70deg);
            filter: brightness(1.1);
            background-image: conic-gradient(
              #1c191c,
              #402fb5 5%,
              #1c191c 14%,
              #1c191c 50%,
              #cf30aa 60%,
              #1c191c 64%
            );
          }
          .poda-darkBorderBg::before {
            transform: translate(-50%, -50%) rotate(82deg);
            background-image: conic-gradient(
              rgba(0, 0, 0, 0),
              #18116a,
              rgba(0, 0, 0, 0) 10%,
              rgba(0, 0, 0, 0) 50%,
              #6e1b60,
              rgba(0, 0, 0, 0) 60%
            );
          }
          .poda-glow::before {
            transform: translate(-50%, -50%) rotate(60deg);
            background-image: conic-gradient(
              #000,
              #402fb5 5%,
              #000 38%,
              #000 50%,
              #cf30aa 60%,
              #000 87%
            );
          }

          #poda:hover > .poda-darkBorderBg::before {
            transform: translate(-50%, -50%) rotate(-98deg);
          }
          #poda:hover > .poda-glow::before {
            transform: translate(-50%, -50%) rotate(-120deg);
          }
          #poda:hover > .poda-white::before {
            transform: translate(-50%, -50%) rotate(-97deg);
          }
          #poda:hover > .poda-border::before {
            transform: translate(-50%, -50%) rotate(-110deg);
          }

          #poda:focus-within > .poda-darkBorderBg::before {
            transform: translate(-50%, -50%) rotate(442deg);
            transition: all 4s ease;
          }
          #poda:focus-within > .poda-glow::before {
            transform: translate(-50%, -50%) rotate(420deg);
            transition: all 4s ease;
          }
          #poda:focus-within > .poda-white::before {
            transform: translate(-50%, -50%) rotate(443deg);
            transition: all 4s ease;
          }
          #poda:focus-within > .poda-border::before {
            transform: translate(-50%, -50%) rotate(430deg);
            transition: all 4s ease;
          }

          .loader {
            --fill-color: #2563eb; /* Blue in light mode */
            --shine-color: rgba(37, 99, 235, 0.4);
            transform: scale(0.2);
            width: 100px;
            height: 100px;
            position: relative;
            filter: drop-shadow(0 0 6px var(--shine-color));
          }
          
          .dark .loader {
            --fill-color: #ffffff; /* White in dark mode */
            --shine-color: #ffffff33;
          }

          .loader #pegtopone {
            position: absolute;
            animation: flowe-one 1s linear infinite;
          }

          .loader #pegtoptwo {
            position: absolute;
            opacity: 0;
            transform: scale(0) translateY(-200px) translateX(-100px);
            animation: flowe-two 1s linear infinite;
            animation-delay: 0.3s;
          }

          .loader #pegtopthree {
            position: absolute;
            opacity: 0;
            transform: scale(0) translateY(-200px) translateX(100px);
            animation: flowe-three 1s linear infinite;
            animation-delay: 0.6s;
          }

          .loader svg g path:first-child {
            fill: var(--fill-color);
          }

          @keyframes flowe-one {
            0% {
              transform: scale(0.5) translateY(-200px);
              opacity: 0;
            }
            25% {
              transform: scale(0.75) translateY(-100px);
              opacity: 1;
            }
            50% {
              transform: scale(1) translateY(0px);
              opacity: 1;
            }
            75% {
              transform: scale(0.5) translateY(50px);
              opacity: 1;
            }
            100% {
              transform: scale(0) translateY(100px);
              opacity: 0;
            }
          }

          @keyframes flowe-two {
            0% {
              transform: scale(0.5) rotateZ(-10deg) translateY(-200px) translateX(-100px);
              opacity: 0;
            }
            25% {
              transform: scale(1) rotateZ(-5deg) translateY(-100px) translateX(-50px);
              opacity: 1;
            }
            50% {
              transform: scale(1) rotateZ(0deg) translateY(0px) translateX(-25px);
              opacity: 1;
            }
            75% {
              transform: scale(0.5) rotateZ(5deg) translateY(50px) translateX(0px);
              opacity: 1;
            }
            100% {
              transform: scale(0) rotateZ(10deg) translateY(100px) translateX(25px);
              opacity: 0;
            }
          }

          @keyframes flowe-three {
            0% {
              transform: scale(0.5) rotateZ(10deg) translateY(-200px) translateX(100px);
              opacity: 0;
            }
            25% {
              transform: scale(1) rotateZ(5deg) translateY(-100px) translateX(50px);
              opacity: 1;
            }
            50% {
              transform: scale(1) rotateZ(0deg) translateY(0px) translateX(25px);
              opacity: 1;
            }
            75% {
              transform: scale(0.5) rotateZ(-5deg) translateY(50px) translateX(0px);
              opacity: 1;
            }
            100% {
              transform: scale(0) rotateZ(-10deg) translateY(100px) translateX(-25px);
              opacity: 0;
            }
          }
        `}</style>

        {/* FLAT SIDE NAVIGATION (LEFT) - Made slightly more spacious ("little big") and awesome look */}
        <motion.div
          initial={false}
          animate={{ width: isSidebarCollapsed ? 80 : 290 }}
          transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
          className="bg-white/40 dark:bg-[#1E1F22]/80 backdrop-blur-md border-r border-slate-200/50 dark:border-[#222222] flex flex-col h-full shrink-0 relative z-10 overflow-hidden"
        >
          {/* Header Area - Extremely clean, Menu button centered when collapsed */}
          <div className="h-14 px-5 flex items-center justify-between border-b border-slate-100 dark:border-[#222222]">
            {!isSidebarCollapsed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center"
              >
                <span className="text-[12px] font-semibold text-slate-550 dark:text-slate-400 uppercase tracking-widest">AI Console</span>
              </motion.div>
            )}
            <button
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              className={`p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-[#1E1E1E] text-slate-400 hover:text-slate-650 transition-all focus:outline-none ${
                isSidebarCollapsed ? "mx-auto" : ""
              }`}
            >
              <Menu size={18} />
            </button>
          </div>

          {/* Navigation Items */}
          <div className="flex-1 overflow-y-auto pt-5 flex flex-col no-scrollbar" style={{ fontFamily: 'Inter, sans-serif' }}>
            
            {/* Top Workspace buttons: New Chat & Search are aligned systematically */}
            <div className="px-4">
              <button
                onClick={handleNewChat}
                className={`flex items-center gap-3 w-full rounded-2xl transition-all h-11 border ${
                  isSidebarCollapsed
                    ? "justify-center px-0 hover:bg-slate-100 dark:hover:bg-white/[0.04] border-slate-200 dark:border-white/[0.06] text-slate-600 dark:text-slate-400"
                    : "px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold shadow-md shadow-indigo-900/20 dark:shadow-indigo-500/20 border-transparent"
                }`}
              >
                <Plus size={16} className="shrink-0" />
                {!isSidebarCollapsed && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-[14px] tracking-tight font-semibold"
                  >
                    New Chat
                  </motion.span>
                )}
              </button>
            </div>

            {/* Spacer — positions audits at ~40% from top */}
            <div style={{ minHeight: '30%' }} />

            {/* Historic Consultations list */}
            {!isSidebarCollapsed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex-1 flex flex-col px-4 overflow-hidden"
              >
                <div className="flex items-center justify-between px-1 mb-2.5 shrink-0">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-widest">Recent Audits</span>
                  <Search size={15} strokeWidth={2.5} className="text-slate-400 cursor-pointer hover:text-white transition-colors" onClick={() => { const el = document.getElementById('sidebar-search'); if (el) { const isHidden = el.style.display === 'none'; el.style.display = isHidden ? 'block' : 'none'; if (isHidden) el.focus(); if (!isHidden) setSearchQuery(''); }}} />
                </div>
                <input
                  id="sidebar-search"
                  type="text"
                  placeholder="Search audits..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  style={{ display: 'none' }}
                  className="w-full bg-slate-50 dark:bg-[#1A1A1D] border border-slate-200 dark:border-white/[0.08] rounded-xl py-2 px-3 text-[13px] font-medium text-slate-700 dark:text-slate-200 outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-500 mb-2 shrink-0 shadow-inner"
                />
                <div className="flex-1 overflow-y-auto space-y-1 no-scrollbar">
                  {filteredSessions.map((session) => (
                    <div
                      key={session.id}
                      onClick={() => handleLoadSession(session.id)}
                      className={`w-full flex items-center justify-between p-3 rounded-xl text-left cursor-pointer transition-all group relative ${
                        currentSessionId === session.id
                          ? "bg-white/[0.06] border border-white/[0.06] text-white"
                          : "hover:bg-white/[0.04] text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      <div className="flex items-start gap-2.5 overflow-hidden w-[85%]">
                        <MessageSquare size={15} className="shrink-0 mt-0.5 text-slate-400 group-hover:text-indigo-400 transition-colors" />
                        <div className="overflow-hidden">
                          <p className="text-[13px] font-semibold truncate leading-snug">{session.title}</p>
                          <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">{session.lastMessage}</p>
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowSessionsDropdown(showSessionsDropdown === session.id ? null : session.id);
                        }}
                        className="p-1 rounded opacity-0 group-hover:opacity-100 text-slate-400 hover:text-slate-600 transition-all focus:outline-none"
                      >
                        <MoreVertical size={12} />
                      </button>

                      {/* Dropdown Menu for Deleting Sessions */}
                      {showSessionsDropdown === session.id && (
                        <div className="absolute right-2 top-8 z-30 bg-white dark:bg-[#1C1C1C] border border-slate-200/80 dark:border-[#2C2C2C] shadow-lg rounded-lg py-1 w-24">
                          <button
                            onClick={(e) => handleDeleteSession(e, session.id)}
                            className="flex items-center gap-1.5 px-3 py-1.5 w-full text-[10.5px] font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/20 transition-all text-left"
                          >
                            <Trash2 size={10} /> Delete
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                  {filteredSessions.length === 0 && (
                    <div className="text-center py-6 text-slate-500 text-[12px] font-medium">
                      No active search matches.
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </div>

          {/* MT5 Account Context Panel (Sidebar Footer) - Made proper, borderless, clean & professional */}
          <div className="p-4 border-t border-slate-100 dark:border-white/5 bg-slate-50/30 dark:bg-black/20 backdrop-blur-sm">
            {!isSidebarCollapsed ? (
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 px-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest leading-none">Active MT5 Bridge</span>
                </div>
                <div className="bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] rounded-[20px] p-3.5 border-2 border-white dark:border-[#1A1A1A] flex items-center justify-between shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                  <div className="overflow-hidden">
                    <p className="text-[12px] font-bold text-slate-700 dark:text-slate-200 truncate leading-snug">
                      {isConnected ? accountMetrics?.name || "Marcel Workspace" : "Marcel Workspace"}
                    </p>
                    <p className="text-[10px] text-slate-400 dark:text-slate-550 font-semibold leading-none mt-1">
                      {isConnected ? `MT5 #${accountMetrics?.account_number}` : "MT5 #28120136"}
                    </p>
                  </div>
                  <div className="bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-extrabold text-[8.5px] uppercase tracking-wider px-2 py-0.5 rounded-md shrink-0 border border-emerald-500/20">
                    Live
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex justify-center py-1">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse border-2 border-white dark:border-[#151515] shadow-sm" />
              </div>
            )}
          </div>
        </motion.div>

        {/* MAIN CHAT CONTENT AREA (RIGHT) */}
        <div className="flex-1 flex flex-col h-full bg-transparent relative z-10 overflow-hidden">

          {/* Message List Grid */}
          <div
            ref={scrollRef}
            className={`flex-1 flex flex-col items-center px-4 md:px-8 overflow-y-auto scroll-smooth no-scrollbar ${
              messages.length === 0 ? "justify-center pb-12" : "justify-start pt-6 pb-48 md:pb-56"
            }`}
          >
            {messages.length === 0 ? (
              <div className="w-full max-w-2xl text-center flex flex-col items-center justify-center -mt-12">
                {/* Sparkle Loader above welcome */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                  className="mb-6"
                >
                  <div className="loader text-blue-600 dark:text-white relative flex items-center justify-center" style={{ transform: 'scale(0.35)' }}>
                    <svg id="pegtopone" viewBox="0 0 100 100" width="100" height="100">
                      <defs>
                        <filter id="shine-w">
                          <feGaussianBlur stdDeviation={3} />
                        </filter>
                        <mask id="mask-w">
                          <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="white" />
                        </mask>
                        <radialGradient id="wg-1" cx={50} cy={66} fx={50} fy={66} r={30} gradientTransform="translate(0 35) scale(1 0.5)" gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="black" stopOpacity="0.3" />
                          <stop offset="50%" stopColor="black" stopOpacity="0.1" />
                          <stop offset="100%" stopColor="black" stopOpacity={0} />
                        </radialGradient>
                        <radialGradient id="wg-2" cx={55} cy={20} fx={55} fy={20} r={30} gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="white" stopOpacity="0.3" />
                          <stop offset="50%" stopColor="white" stopOpacity="0.1" />
                          <stop offset="100%" stopColor="white" stopOpacity={0} />
                        </radialGradient>
                        <radialGradient id="wg-3" cx={85} cy={50} fx={85} fy={50} xlinkHref="#wg-2" />
                        <radialGradient id="wg-4" cx={50} cy={58} fx={50} fy={58} r={60} gradientTransform="translate(0 47) scale(1 0.2)" xlinkHref="#wg-3" />
                        <linearGradient id="wg-5" x1={50} y1={90} x2={50} y2={10} gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="black" stopOpacity="0.2" />
                          <stop offset="40%" stopColor="black" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <g>
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="currentColor" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg-1)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="none" stroke="white" opacity={0.3} strokeWidth={3} filter="url(#shine-w)" mask="url(#mask-w)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg-2)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg-3)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg-4)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg-5)" />
                      </g>
                    </svg>
                    <svg id="pegtoptwo" viewBox="0 0 100 100" width="100" height="100">
                      <defs>
                        <filter id="shine-w2">
                          <feGaussianBlur stdDeviation={3} />
                        </filter>
                        <mask id="mask-w2">
                          <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="white" />
                        </mask>
                        <radialGradient id="wg2-1" cx={50} cy={66} fx={50} fy={66} r={30} gradientTransform="translate(0 35) scale(1 0.5)" gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="black" stopOpacity="0.3" />
                          <stop offset="50%" stopColor="black" stopOpacity="0.1" />
                          <stop offset="100%" stopColor="black" stopOpacity={0} />
                        </radialGradient>
                        <radialGradient id="wg2-2" cx={55} cy={20} fx={55} fy={20} r={30} gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="white" stopOpacity="0.3" />
                          <stop offset="50%" stopColor="white" stopOpacity="0.1" />
                          <stop offset="100%" stopColor="white" stopOpacity={0} />
                        </radialGradient>
                        <radialGradient id="wg2-3" cx={85} cy={50} fx={85} fy={50} xlinkHref="#wg2-2" />
                        <radialGradient id="wg2-4" cx={50} cy={58} fx={50} fy={58} r={60} gradientTransform="translate(0 47) scale(1 0.2)" xlinkHref="#wg2-3" />
                        <linearGradient id="wg2-5" x1={50} y1={90} x2={50} y2={10} gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="black" stopOpacity="0.2" />
                          <stop offset="40%" stopColor="black" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <g>
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="currentColor" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg2-1)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="none" stroke="white" opacity={0.3} strokeWidth={3} filter="url(#shine-w2)" mask="url(#mask-w2)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg2-2)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg2-3)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg2-4)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg2-5)" />
                      </g>
                    </svg>
                    <svg id="pegtopthree" viewBox="0 0 100 100" width="100" height="100">
                      <defs>
                        <filter id="shine-w3">
                          <feGaussianBlur stdDeviation={3} />
                        </filter>
                        <mask id="mask-w3">
                          <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="white" />
                        </mask>
                        <radialGradient id="wg3-1" cx={50} cy={66} fx={50} fy={66} r={30} gradientTransform="translate(0 35) scale(1 0.5)" gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="black" stopOpacity="0.3" />
                          <stop offset="50%" stopColor="black" stopOpacity="0.1" />
                          <stop offset="100%" stopColor="black" stopOpacity={0} />
                        </radialGradient>
                        <radialGradient id="wg3-2" cx={55} cy={20} fx={55} fy={20} r={30} gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="white" stopOpacity="0.3" />
                          <stop offset="50%" stopColor="white" stopOpacity="0.1" />
                          <stop offset="100%" stopColor="white" stopOpacity={0} />
                        </radialGradient>
                        <radialGradient id="wg3-3" cx={85} cy={50} fx={85} fy={50} xlinkHref="#wg3-2" />
                        <radialGradient id="wg3-4" cx={50} cy={58} fx={50} fy={58} r={60} gradientTransform="translate(0 47) scale(1 0.2)" xlinkHref="#wg3-3" />
                        <linearGradient id="wg3-5" x1={50} y1={90} x2={50} y2={10} gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="black" stopOpacity="0.2" />
                          <stop offset="40%" stopColor="black" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <g>
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="currentColor" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg3-1)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="none" stroke="white" opacity={0.3} strokeWidth={3} filter="url(#shine-w3)" mask="url(#mask-w3)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg3-2)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg3-3)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg3-4)" />
                        <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#wg3-5)" />
                      </g>
                    </svg>
                  </div>
                </motion.div>

                {/* Clean Warm Welcome Title */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2 }}
                  className="space-y-2.5"
                >
                  <h1 className="text-3xl lg:text-4xl font-semibold tracking-tight leading-tight bg-gradient-to-r from-slate-900 via-blue-600 to-slate-500 dark:from-white dark:via-blue-500 dark:to-slate-500 bg-clip-text text-transparent inline-block">
                    Good to See You!
                  </h1>
                  <h2 className="text-2xl lg:text-3xl font-medium text-slate-700 dark:text-slate-300 tracking-tight leading-tight">
                    How Can I Be of Assistance?
                  </h2>
                  <p className="text-[13px] md:text-[14px] text-slate-400 dark:text-slate-500 max-w-md mx-auto font-medium leading-relaxed pt-1">
                    I'm available 24/7 for you. Ask me anything.
                  </p>
                </motion.div>

                {/* Input Console centered for new chat */}
                <div className="w-full max-w-2xl mt-20">
                  {renderInputConsole()}
                </div>
              </div>
            ) : (
              <div className="w-full max-w-2xl space-y-5 py-4">
                {messages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, ease: "easeOut" }}
                    className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >


                    <div className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} max-w-[80%]`}>
                      <div className={`px-4 py-3 text-[14px] leading-relaxed tracking-[-0.01em] ${
                        msg.role === 'user'
                          ? 'bg-gradient-to-br from-violet-600 via-indigo-600 to-indigo-700 text-white font-medium rounded-2xl rounded-tr-md shadow-[0_4px_16px_rgba(99,102,241,0.25)]'
                          : 'bg-white dark:bg-[#1e1e2e] text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-transparent rounded-2xl rounded-tl-md shadow-sm'
                      }`}>
                        {msg.role === 'ai' ? (
                          <div className="prose dark:prose-invert max-w-none text-[13.5px] md:text-[14px]">
                            <ReactMarkdown
                              components={{
                                p: ({ children }) => <p className="mb-2 last:mb-0 leading-relaxed font-normal text-slate-800 dark:text-slate-200">{children}</p>,
                                ul: ({ children }) => <ul className="list-disc ml-5 mb-2 space-y-1">{children}</ul>,
                                ol: ({ children }) => <ol className="list-decimal ml-5 mb-2 space-y-1">{children}</ol>,
                                li: ({ children }) => <li className="text-slate-700 dark:text-slate-300">{children}</li>,
                                strong: ({ children }) => <strong className="font-semibold text-slate-900 dark:text-white">{children}</strong>,
                                table: ({ children }) => (
                                  <div className="overflow-x-auto my-3 rounded-xl border border-slate-200 dark:border-white/[0.06]">
                                    <table className="min-w-full divide-y divide-slate-200 dark:divide-white/[0.06]">{children}</table>
                                  </div>
                                ),
                                th: ({ children }) => <th className="px-3 py-2 bg-slate-50 dark:bg-white/[0.03] text-left text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">{children}</th>,
                                td: ({ children }) => <td className="px-3 py-2 text-[12px] font-medium text-slate-700 dark:text-slate-300 border-t border-slate-200 dark:border-white/[0.06]">{children}</td>,
                                blockquote: ({ children }) => (
                                  <div className="my-3 p-3.5 bg-indigo-500/[0.06] border-l-3 border-indigo-400/50 rounded-r-xl">
                                    {children}
                                  </div>
                                )
                              }}
                            >
                              {msg.content}
                            </ReactMarkdown>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {msg.isImage && msg.imageUrl && (
                              <div className="rounded-lg overflow-hidden border border-white/10 max-w-sm mb-1.5">
                                <img src={msg.imageUrl} alt="Uploaded chart analysis" className="w-full object-cover h-40" />
                              </div>
                            )}
                            <p className="font-medium whitespace-pre-wrap">{msg.content}</p>
                          </div>
                        )}
                      </div>
                      <span className="text-[9px] text-slate-500 font-medium mt-1.5 px-1 flex items-center gap-1 tracking-wide">
                        {msg.role === 'ai' ? "AI" : "You"} • {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </motion.div>
                ))}
 
                {isThinking && (
                  <div className="flex gap-3 justify-start items-start">
                    <div className="w-7 h-7 flex items-center justify-center shrink-0 mt-1.5">
                      <div className="loader relative flex items-center justify-center shrink-0">
                        <svg id="pegtopone" viewBox="0 0 100 100" width="100" height="100">
                          <defs>
                            <filter id="shine">
                              <feGaussianBlur stdDeviation={3} />
                            </filter>
                            <mask id="mask">
                              <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="white" />
                            </mask>
                            <radialGradient id="gradient-1" cx={50} cy={66} fx={50} fy={66} r={30} gradientTransform="translate(0 35) scale(1 0.5)" gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="black" stopOpacity="0.3" />
                              <stop offset="50%" stopColor="black" stopOpacity="0.1" />
                              <stop offset="100%" stopColor="black" stopOpacity={0} />
                            </radialGradient>
                            <radialGradient id="gradient-2" cx={55} cy={20} fx={55} fy={20} r={30} gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="white" stopOpacity="0.3" />
                              <stop offset="50%" stopColor="white" stopOpacity="0.1" />
                              <stop offset="100%" stopColor="white" stopOpacity={0} />
                            </radialGradient>
                            <radialGradient id="gradient-3" cx={85} cy={50} fx={85} fy={50} xlinkHref="#gradient-2" />
                            <radialGradient id="gradient-4" cx={50} cy={58} fx={50} fy={58} r={60} gradientTransform="translate(0 47) scale(1 0.2)" xlinkHref="#gradient-3" />
                            <linearGradient id="gradient-5" x1={50} y1={90} x2={50} y2={10} gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="black" stopOpacity="0.2" />
                              <stop offset="40%" stopColor="black" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <g>
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="currentColor" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-1)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="none" stroke="white" opacity={0.3} strokeWidth={3} filter="url(#shine)" mask="url(#mask)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-2)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-3)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-4)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-5)" />
                          </g>
                        </svg>
                        <svg id="pegtoptwo" viewBox="0 0 100 100" width="100" height="100">
                          <defs>
                            <filter id="shine">
                              <feGaussianBlur stdDeviation={3} />
                            </filter>
                            <mask id="mask">
                              <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="white" />
                            </mask>
                            <radialGradient id="gradient-1" cx={50} cy={66} fx={50} fy={66} r={30} gradientTransform="translate(0 35) scale(1 0.5)" gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="black" stopOpacity="0.3" />
                              <stop offset="50%" stopColor="black" stopOpacity="0.1" />
                              <stop offset="100%" stopColor="black" stopOpacity={0} />
                            </radialGradient>
                            <radialGradient id="gradient-2" cx={55} cy={20} fx={55} fy={20} r={30} gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="white" stopOpacity="0.3" />
                              <stop offset="50%" stopColor="white" stopOpacity="0.1" />
                              <stop offset="100%" stopColor="white" stopOpacity={0} />
                            </radialGradient>
                            <radialGradient id="gradient-3" cx={85} cy={50} fx={85} fy={50} xlinkHref="#gradient-2" />
                            <radialGradient id="gradient-4" cx={50} cy={58} fx={50} fy={58} r={60} gradientTransform="translate(0 47) scale(1 0.2)" xlinkHref="#gradient-3" />
                            <linearGradient id="gradient-5" x1={50} y1={90} x2={50} y2={10} gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="black" stopOpacity="0.2" />
                              <stop offset="40%" stopColor="black" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <g>
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="currentColor" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-1)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="none" stroke="white" opacity={0.3} strokeWidth={3} filter="url(#shine)" mask="url(#mask)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-2)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-3)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-4)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-5)" />
                          </g>
                        </svg>
                        <svg id="pegtopthree" viewBox="0 0 100 100" width="100" height="100">
                          <defs>
                            <filter id="shine">
                              <feGaussianBlur stdDeviation={3} />
                            </filter>
                            <mask id="mask">
                              <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="white" />
                            </mask>
                            <radialGradient id="gradient-1" cx={50} cy={66} fx={50} fy={66} r={30} gradientTransform="translate(0 35) scale(1 0.5)" gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="black" stopOpacity="0.3" />
                              <stop offset="50%" stopColor="black" stopOpacity="0.1" />
                              <stop offset="100%" stopColor="black" stopOpacity={0} />
                            </radialGradient>
                            <radialGradient id="gradient-2" cx={55} cy={20} fx={55} fy={20} r={30} gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="white" stopOpacity="0.3" />
                              <stop offset="50%" stopColor="white" stopOpacity="0.1" />
                              <stop offset="100%" stopColor="white" stopOpacity={0} />
                            </radialGradient>
                            <radialGradient id="gradient-3" cx={85} cy={50} fx={85} fy={50} xlinkHref="#gradient-2" />
                            <radialGradient id="gradient-4" cx={50} cy={58} fx={50} fy={58} r={60} gradientTransform="translate(0 47) scale(1 0.2)" xlinkHref="#gradient-3" />
                            <linearGradient id="gradient-5" x1={50} y1={90} x2={50} y2={10} gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="black" stopOpacity="0.2" />
                              <stop offset="40%" stopColor="black" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <g>
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="currentColor" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-1)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="none" stroke="white" opacity={0.3} strokeWidth={3} filter="url(#shine)" mask="url(#mask)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-2)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-3)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-4)" />
                            <path d="M63,37c-6.7-4-4-27-13-27s-6.3,23-13,27-27,4-27,13,20.3,9,27,13,4,27,13,27,6.3-23,13-27,27-4,27-13-20.3-9-27-13Z" fill="url(#gradient-5)" />
                          </g>
                        </svg>
                      </div>
                    </div>

                    <div className="flex flex-col items-start max-w-[80%]">
                      <div className="px-4 py-3 text-[14px] bg-white/[0.04] backdrop-blur-sm border border-white/[0.06] rounded-2xl rounded-tl-md flex items-center h-[44px]">
                        <span className="text-[11px] font-medium text-slate-500 tracking-widest uppercase animate-pulse">THINKING...</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {messages.length > 0 && (
            <div className="absolute bottom-5 inset-x-0 px-4 z-10 flex justify-center">
              <div className="w-full max-w-2xl">
                {renderInputConsole()}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* CUSTOMIZE AI DIALOG (MODAL) */}
      <AnimatePresence>
        {showCustomize && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCustomize(false)}
              className="absolute inset-0 bg-slate-900/10 backdrop-blur-sm dark:bg-black/35 animate-fade-in"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: 10 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="w-full max-w-md bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] rounded-[24px] p-6 relative z-10 shadow-[0_20px_50px_rgba(0,0,0,0.15)] border-2 border-white dark:border-[#1A1A1A]"
            >
              {/* Modal Header */}
              <div className="flex items-start justify-between mb-5">
                <div className="space-y-1.5">
                  <h2 className="text-[17px] font-bold text-slate-800 dark:text-white tracking-tight leading-none">Guidance Configurations</h2>
                  <p className="text-[12px] text-slate-450 dark:text-slate-500 leading-normal font-semibold">
                    Adjust the analytical thresholds and safeguards for your trading assistant.
                  </p>
                </div>
                <button
                  onClick={() => setShowCustomize(false)}
                  className="p-1.5 hover:bg-slate-50 dark:hover:bg-[#1E1E1E] rounded-lg text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-5">
                
                {/* Tone Selectors */}
                <div className="space-y-2">
                  <label className="block text-[12px] font-bold text-slate-700 dark:text-slate-200">Active Coach Tone</label>
                  <div className="bg-slate-100/80 dark:bg-[#1A1A1C] p-1.5 rounded-2xl flex gap-1.5 border border-slate-200/10 dark:border-[#252527]">
                    {[
                      { id: "Analytical Quant", label: "Analytical" },
                      { id: "Strict Guard", label: "Strict Audit" },
                      { id: "Mindset Partner", label: "Mindset" }
                    ].map(item => (
                      <button
                        key={item.id}
                        onClick={() => setActivePersona(item.id as any)}
                        className={`flex-1 py-2 rounded-xl text-center text-[12px] font-bold transition-all duration-200 ${
                          activePersona === item.id
                            ? "bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#2c2c30] dark:to-[#222225] text-slate-855 dark:text-white shadow-sm border border-slate-200 dark:border-white/5"
                            : "text-slate-550 hover:text-slate-750 dark:text-slate-400 dark:hover:text-slate-255"
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Personal Experience Bio */}
                <div className="space-y-2">
                  <label className="block text-[12px] font-bold text-slate-700 dark:text-slate-200">Trader Experience & Strategy Focus</label>
                  <textarea
                    rows={3}
                    value={userBio}
                    onChange={(e) => setUserBio(e.target.value)}
                    placeholder="e.g., I trade XAU/USD breakout setups using 15m intervals. I struggle with scaling positions too early or chasing rallies..."
                    className="w-full bg-slate-100/50 dark:bg-[#1A1A1D]/50 border-2 border-slate-200/60 dark:border-[#222225] rounded-xl p-3 text-[12.5px] font-medium text-slate-755 dark:text-slate-350 outline-none focus:ring-1 focus:ring-indigo-500/25 placeholder:text-slate-400"
                  />
                </div>

                {/* Drawdown Alert Threshold */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-bold text-slate-700 dark:text-slate-200">Max Drawdown Alert Trigger</span>
                    <span className="text-[12px] font-bold text-indigo-600 dark:text-indigo-400">{customDrawdown.toFixed(1)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="5.0"
                    step="0.1"
                    value={customDrawdown}
                    onChange={(e) => setCustomDrawdown(parseFloat(e.target.value))}
                    className="w-full accent-indigo-600 h-1 bg-slate-100 dark:bg-[#222222] rounded-lg appearance-none cursor-pointer focus:outline-none"
                  />
                </div>

                {/* Emotional Cooldown Freeze Time */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-bold text-slate-700 dark:text-slate-200">Post-Loss Freeze Lockout</span>
                    <span className="text-[12px] font-bold text-indigo-600 dark:text-indigo-400">{customCooldown} Minutes</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="120"
                    step="5"
                    value={customCooldown}
                    onChange={(e) => setCustomCooldown(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 h-1 bg-slate-100 dark:bg-[#222222] rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                {/* Profit Cap Target */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-bold text-slate-700 dark:text-slate-200">Daily Profit Target Lock</span>
                    <span className="text-[12px] font-semibold text-indigo-600 dark:text-indigo-400">{customProfitCap.toFixed(1)}%</span>
                  </div>
                  <input
                    type="range"
                    min="1.0"
                    max="10.0"
                    step="0.5"
                    value={customProfitCap}
                    onChange={(e) => setCustomProfitCap(parseFloat(e.target.value))}
                    className="w-full accent-indigo-600 h-1 bg-slate-100 dark:bg-[#222222] rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                {/* Confirm Save */}
                <button
                  onClick={handleSaveCustomize}
                  className="w-full py-3 bg-indigo-650 hover:bg-indigo-700 dark:bg-indigo-600 dark:hover:bg-indigo-700 text-white rounded-xl font-bold text-[13px] tracking-wide shadow-md shadow-indigo-600/10 dark:shadow-indigo-950/20 transition-all active:scale-[0.98] mt-2"
                >
                  Save Configurations
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </DashboardLayout>
  );
}
