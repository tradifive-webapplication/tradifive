import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Bell, Clock, ChevronLeft, Sparkles, AlertTriangle, XCircle, ShieldAlert, Timer, X, Bot } from "lucide-react";
import AppSidebar from "./AppSidebar";
import FloatingAICoach from "./FloatingAICoach";
import { useLocation, useNavigate } from "react-router-dom";
import { useTrading } from "@/contexts/TradingContext";
import { useDashboardData } from "@/hooks/useDashboardData";
import { toast } from "sonner";

interface Breadcrumb {
  label: string;
  path?: string;
}

interface DashboardLayoutProps {
  children: React.ReactNode;
  breadcrumbs?: Breadcrumb[];
  onBack?: () => void;
  headerActions?: React.ReactNode;
  noPadding?: boolean;
  noScroll?: boolean;
}

export default function DashboardLayout({ children, breadcrumbs, onBack, headerActions, noPadding = false, noScroll = false }: DashboardLayoutProps) {
  const [emergencyHaltActive, setEmergencyHaltActive] = useState(false);
  const [showFlash, setShowFlash] = useState(false);
  const [alertKey, setAlertKey] = useState(0);
  const [isAIOpen, setIsAIOpen] = useState(false);
  const constraintsRef = useRef(null);

  // Revenge trade cooldown violation detection
  const [cooldownActive, setCooldownActive] = useState(false);
  const [cooldownEndsAt, setCooldownEndsAt] = useState(0);
  const [showRevengeFlash, setShowRevengeFlash] = useState(false);
  const [lastKnownTradeCount, setLastKnownTradeCount] = useState<number | null>(null);
  const { recentTrades } = useDashboardData();

  // Monitor cooldown state from localStorage
  useEffect(() => {
    const checkCooldown = () => {
      try {
        const saved = localStorage.getItem('fialgo_cooldown');
        if (saved) {
          const cd = JSON.parse(saved);
          if (cd.active && cd.endsAt > Date.now()) {
            setCooldownActive(true);
            setCooldownEndsAt(cd.endsAt);
          } else {
            setCooldownActive(false);
            setCooldownEndsAt(0);
          }
        } else {
          setCooldownActive(false);
          setCooldownEndsAt(0);
        }
      } catch (e) { console.error(e); }
    };

    checkCooldown();
    window.addEventListener('fialgo_cooldown_changed', checkCooldown);
    window.addEventListener('storage', checkCooldown);
    // Also check periodically to catch expiry
    const interval = setInterval(checkCooldown, 5000);

    return () => {
      window.removeEventListener('fialgo_cooldown_changed', checkCooldown);
      window.removeEventListener('storage', checkCooldown);
      clearInterval(interval);
    };
  }, []);

  // Detect new trades during cooldown → trigger violation flash
  useEffect(() => {
    if (!recentTrades || recentTrades.length === 0) return;
    
    // Initialize trade count on first load
    if (lastKnownTradeCount === null) {
      setLastKnownTradeCount(recentTrades.length);
      return;
    }

    // Check if a new trade appeared while cooldown is active
    if (recentTrades.length > lastKnownTradeCount && cooldownActive) {
      setShowRevengeFlash(true);
      toast.error("⚠️ REVENGE TRADE DETECTED", {
        description: "Cooldown shield is active. Wait for the timer to expire before trading.",
        duration: 8000
      });
    }

    setLastKnownTradeCount(recentTrades.length);
  }, [recentTrades, cooldownActive, lastKnownTradeCount]);

  useEffect(() => {
    if (emergencyHaltActive) {
      setAlertKey(prev => prev + 1);
    }
  }, [emergencyHaltActive]);

  useEffect(() => {
    const checkHalt = () => {
      const saved = localStorage.getItem('fialgo_risk_config');
      if (saved) {
        try {
          const config = JSON.parse(saved);
          const active = config.autoTrading === true;
          setEmergencyHaltActive(active);

          if (active) {
            const triggerFlash = sessionStorage.getItem('fialgo_trigger_flash');
            if (triggerFlash === 'true') {
              setShowFlash(true);
              sessionStorage.removeItem('fialgo_trigger_flash');
            }
          } else {
            setShowFlash(false);
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        setEmergencyHaltActive(false);
        setShowFlash(false);
      }
    };

    checkHalt();

    window.addEventListener('fialgo_config_changed', checkHalt);
    window.addEventListener('storage', checkHalt);

    return () => {
      window.removeEventListener('fialgo_config_changed', checkHalt);
      window.removeEventListener('storage', checkHalt);
    };
  }, []);
  const location = useLocation();
  const navigate = useNavigate();
  const [isMounted, setIsMounted] = useState(false);
  useEffect(() => {
    setIsMounted(true);
  }, []);
  const [isCollapsed, setIsCollapsed] = useState(() => {
    try {
      return localStorage.getItem("fialgo_sidebar_collapsed") === "true";
    } catch (e) {
      return false;
    }
  });
  
  const handleToggleCollapse = () => {
    setIsCollapsed(prev => {
      const next = !prev;
      try {
        localStorage.setItem("fialgo_sidebar_collapsed", String(next));
      } catch (e) {
        console.error(e);
      }
      return next;
    });
  };

  const [impersonatingUser, setImpersonatingUser] = useState<string | null>(null);

  useEffect(() => {
    const impersonated = localStorage.getItem("fialgo_impersonating_user");
    if (impersonated) {
      setImpersonatingUser(impersonated);
    }
  }, []);

  const handleExitGodMode = () => {
    localStorage.removeItem("fialgo_impersonating_user");
    window.location.href = "/admin";
  };
  
  const pathSegments = location.pathname.split("/").filter(Boolean);
  
  // Clean up display segments to match sidebar labels
  let displaySegments = [...pathSegments];
  if (displaySegments[0] === 'competitions') {
    if (displaySegments[1] === 'dashboard') {
      displaySegments = ['competitions'];
    } else if (displaySegments[1] === 'rewards') {
      displaySegments = ['rewards'];
    }
  }

  const lastSegment = displaySegments[displaySegments.length - 1] || "dashboard";
  
  // Format string utility: capitalize and replace hyphens with spaces
  const formatSegment = (str: string) => {
    if (str.toLowerCase() === 'ai-coach') return 'AI Coach';
    return str.charAt(0).toUpperCase() + str.slice(1).replace(/-/g, " ");
  };
  
  const title = formatSegment(lastSegment);

  const getCategoryName = (pathname: string) => {
    if (pathname.startsWith('/inbox') || pathname.startsWith('/notifications')) return 'Communication';
    if (pathname.startsWith('/competitions') || pathname.startsWith('/rewards')) return 'Engagement';
    if (pathname.startsWith('/admin')) return 'Admin';
    if (pathname.startsWith('/settings') || pathname.startsWith('/profile') || pathname.startsWith('/support') || pathname.startsWith('/feedback')) return 'Settings & Support';
    return 'Main Menu';
  };
  
  const categoryName = getCategoryName(location.pathname);

  const { } = useTrading();

  return (
    <div ref={constraintsRef} className="min-h-screen bg-gradient-to-br from-[#F5F7FF] via-[#FFFFFF] to-[#F0F4FF] dark:from-[#000000] dark:via-[#000000] dark:to-[#000000] flex relative overflow-hidden">

      {/* Decorative Blobs */}
      <div className="absolute top-[-20%] left-[-10%] w-[40%] h-[40%] rounded-full bg-black/[0.1] dark:hidden blur-[100px] -z-10 pointer-events-none" />
      <div className="absolute top-[-10%] left-[-5%] w-[40%] h-[40%] rounded-full bg-primary/5 dark:hidden blur-[120px] -z-10 animate-float" />
      <div className="absolute bottom-[10%] right-[-5%] w-[30%] h-[40%] rounded-full bg-purple-400/5 dark:hidden blur-[100px] -z-10 animate-pulse" />

      <AppSidebar isCollapsed={isCollapsed} toggleCollapse={handleToggleCollapse} />

      <div className={`flex-1 flex flex-col h-screen overflow-hidden ${isMounted ? 'transition-[margin-left] duration-300' : ''} ${isCollapsed ? 'ml-[80px]' : 'ml-[280px]'}`}>
        
        {impersonatingUser && (
          <div className="bg-rose-500 text-white px-4 py-2 flex items-center justify-center gap-3 shrink-0 shadow-lg z-50">
            <AlertTriangle size={16} className="animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-widest">
              God Mode Active: Viewing data as user ID ({impersonatingUser.slice(0, 8)}...)
            </span>
            <button 
              onClick={handleExitGodMode}
              className="ml-4 flex items-center gap-1 bg-black/20 hover:bg-black/40 px-3 py-1 rounded-md text-xs font-bold transition-colors"
            >
              <XCircle size={14} /> Exit God Mode
            </button>
          </div>
        )}

        {/* Main Content Area - Housed in the 'Big Box' Card */}
        <div className={`flex-1 px-5 ${impersonatingUser ? 'pt-3' : 'pt-5'} pb-5 ${noScroll ? 'overflow-hidden h-full flex flex-col' : 'overflow-y-auto scrollbar-hide'}`}>
          <main
            className={`${
              noScroll ? 'flex-1 h-full flex flex-col overflow-hidden' : 'min-h-full'
            } rounded-[2.5rem] bg-white dark:bg-[#121212] shadow-[0_8px_30_rgb(0,0,0,0.04)] border border-slate-100 dark:border-white/5 overflow-hidden font-sans`}
          >
            {/* Header (Moved Inside to Scroll) */}
            <header className="h-[70px] flex items-center justify-between px-10 border-b border-slate-100 dark:border-white/5 shrink-0">
              <div className="flex items-center gap-1 sm:gap-3">
                <button 
                  onClick={onBack ? onBack : () => navigate(-1)} 
                  className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] text-[#393939] dark:text-[#E2E8F0] font-extrabold transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.15),_0_0_0_2px_#D4D4D4] dark:hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.5),_0_0_0_2px_#444] active:scale-95 select-none mr-2"
                  title="Go Back"
                >
                  <ChevronLeft size={16} />
                </button>
                {breadcrumbs && breadcrumbs.length > 0 ? (
                  <div className="flex items-center gap-2 text-[14px] font-semibold text-slate-500 dark:text-slate-400">
                    <button onClick={() => navigate('/dashboard')} className="hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors">{categoryName}</button>
                    <span className="text-slate-300 dark:text-slate-600">/</span>
                    {breadcrumbs.map((bc, idx) => (
                      <span key={idx} className="flex items-center gap-2">
                        <span className={idx === breadcrumbs.length - 1 ? "text-[15px] font-semibold text-slate-900 dark:text-white capitalize" : "capitalize hover:text-indigo-500 transition-colors cursor-pointer"}>{bc.label}</span>
                        {idx < breadcrumbs.length - 1 && <span className="text-slate-300 dark:text-slate-600">/</span>}
                      </span>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-[14px] font-semibold text-slate-500 dark:text-slate-400">
                    <button onClick={() => navigate('/dashboard')} className="hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors">{categoryName}</button>
                    {displaySegments.length > 0 ? displaySegments.map((segment, idx) => (
                      <span key={idx} className="flex items-center gap-2">
                        <span className="text-slate-300 dark:text-slate-600">/</span>
                        <span className={idx === displaySegments.length - 1 ? "text-[15px] font-semibold text-slate-900 dark:text-white capitalize" : "capitalize text-slate-500"}>
                          {formatSegment(segment)}
                        </span>
                      </span>
                    )) : (
                      <span className="flex items-center gap-2">
                        <span className="text-slate-300 dark:text-slate-600">/</span>
                        <span className="text-[15px] font-semibold text-slate-900 dark:text-white capitalize">Dashboard</span>
                      </span>
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-4">
                {headerActions}
                <button
                  onClick={() => setIsAIOpen(!isAIOpen)}
                  className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] text-[#393939] dark:text-[#E2E8F0] font-extrabold text-[11px] uppercase tracking-wider transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.15),_0_0_0_2px_#D4D4D4] dark:hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.5),_0_0_0_2px_#444] active:scale-95 select-none"
                  title="Toggle AI Coach"
                >
                  <Bot size={14} /> <span>AI Coach</span>
                </button>
              </div>
            </header>

            {/* Premium Global Emergency Halt Banner - Crimson red warning card with physics-based gravity drop & free drag */}
            <AnimatePresence>
              {showFlash && (
                <motion.div
                  key="halt-flash"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 0.25, 0, 0.25, 0] }}
                  transition={{ 
                    duration: 1.2, 
                    times: [0, 0.25, 0.5, 0.75, 1], 
                    ease: "easeInOut" 
                  }}
                  onAnimationComplete={() => setShowFlash(false)}
                  className="fixed inset-0 bg-red-500 z-[9998] pointer-events-none"
                />
              )}
              {emergencyHaltActive && (
                <div key="halt-banner" className="fixed inset-x-0 top-24 flex justify-center z-[9999] pointer-events-none">
                  <motion.div
                    key={`halt-card-motion-${alertKey}`}
                    drag
                    dragConstraints={constraintsRef}
                    dragElastic={0.05}
                    dragMomentum={true}
                    initial={{ opacity: 0, y: -450, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -450, scale: 0.95 }}
                    transition={{ 
                       type: "spring", 
                       stiffness: 240, 
                       damping: 13, 
                       mass: 1.1
                    }}
                    className="w-fit max-w-[90%] sm:max-w-[480px] pointer-events-auto select-none cursor-grab active:cursor-grabbing"
                  >
                    <div className="p-5 rounded-[22px] bg-gradient-to-b from-[#FFF0F0] to-[#FFFFFF] dark:from-[#2D1B1B] dark:to-[#1C1C1E] border-2 border-white dark:border-[#2C2C2E] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#FCD1D1] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#4C2626] flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-[#F06363]/10 flex items-center justify-center text-[#F06363] shrink-0 border border-[#F06363]/20">
                        <AlertTriangle size={18} />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-[13px] font-semibold text-slate-800 dark:text-white leading-tight">Emergency Halt Active</h3>
                        <p className="text-[11px] text-slate-400 dark:text-zinc-500 font-medium mt-1">
                          All open positions have been forced closed. Fialgo MT5 Bridge is ignoring new order commands.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              )}
            </AnimatePresence>

            {/* Revenge Trade Violation Flash — 3x intense red screen flash */}
            <AnimatePresence>
              {showRevengeFlash && (
                <motion.div
                  key="revenge-flash"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 0.35, 0, 0.35, 0, 0.35, 0] }}
                  transition={{ 
                    duration: 1.8, 
                    times: [0, 0.14, 0.28, 0.42, 0.56, 0.70, 1], 
                    ease: "easeInOut" 
                  }}
                  onAnimationComplete={() => setShowRevengeFlash(false)}
                  className="fixed inset-0 bg-red-600 z-[9998] pointer-events-none"
                />
              )}
            </AnimatePresence>

            {/* Internal Content Padding - stretch flex dynamically if noScroll is active */}
            <div className={`${noPadding || noScroll ? "p-0" : "p-10 pb-20"} ${noScroll ? "flex-1 min-h-0 flex flex-col overflow-hidden" : ""}`}>
              {children}
            </div>
            
            {/* Global Floating AI Coach Widget */}
            <FloatingAICoach isOpen={isAIOpen} onClose={() => setIsAIOpen(false)} />
          </main>
        </div>
      </div>
    </div>
  );
}
