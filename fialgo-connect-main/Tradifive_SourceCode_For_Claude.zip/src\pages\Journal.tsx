import { useState } from "react";
import { GripVertical } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import DashboardLayout from "@/components/DashboardLayout";
import JournalMetrics from "@/components/journal/JournalMetrics";
import JournalGrid from "@/components/journal/JournalGrid";
import JournalTradesTable from "@/components/journal/JournalTradesTable";
import TradeSlideOver from "@/components/journal/TradeSlideOver";
import JournalSettingsBar from "@/components/journal/JournalSettingsBar";
import { JournalSettingsProvider } from "@/contexts/JournalSettingsContext";
import { formatUTCDate, formatHoldDuration } from "@/utils/tradeUtils";

export default function Journal() {
  const [selectedTrade, setSelectedTrade] = useState<any>(null);
  const [isSlideOverOpen, setIsSlideOverOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);


  return (
    <JournalSettingsProvider>
      <DashboardLayout>
        <div className="max-w-[1600px] mx-auto space-y-6 pb-12">

          {/* Metrics Row — always fixed at top */}
          <JournalMetrics
            isEditMode={isEditMode}
            onEditToggle={() => setIsEditMode(v => !v)}
          />

          {/* Edit mode hint banner */}
          <AnimatePresence>
            {isEditMode && (
              <motion.div
                initial={{ opacity: 0, height: 0, marginBottom: 0 }}
                animate={{ opacity: 1, height: "auto", marginBottom: 24 }}
                exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                className="overflow-hidden"
              >
                <div className="flex items-center gap-2 px-4 py-2.5 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800/50 rounded-xl text-[12px] font-semibold text-blue-700 dark:text-slate-300">
                  <GripVertical size={14} />
                  Drag any box or the calendar to reorder your journal layout. Click <strong className="text-blue-800 dark:text-blue-400">Done</strong> when finished.
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Draggable Grid */}
          <JournalGrid isEditMode={isEditMode} />

          {/* 📊 Premium Live Trades & Positions Table */}
          <JournalTradesTable onTradeClick={(trade) => {
            const mapped = {
              id: Number(trade.ticket || 0) || trade.id,
              asset: trade.symbol,
              direction: trade.trade_type === 0 || String(trade.trade_type).toUpperCase().includes("BUY") ? "BUY" as const : "SELL" as const,
              pnl: Number(trade.profit),
              entryTime: formatUTCDate(trade.opened_at || trade.created_at),
              exitTime: trade.closed_at ? formatUTCDate(trade.closed_at) : "Open",
              entryPrice: Number(trade.open_price || trade.entry_price || 0),
              exitPrice: Number(trade.close_price || trade.exit_price || 0),
              stopLoss: trade.stop_loss ? Number(trade.stop_loss) : undefined,
              takeProfit: trade.take_profit ? Number(trade.take_profit) : undefined,
              setups: trade.tags || (trade.setup ? [trade.setup] : []),
              mistakes: [],
              notes: trade.notes || "",
              holdDuration: formatHoldDuration(trade.opened_at || trade.created_at, trade.closed_at),
              rawTrade: trade
            };
            setSelectedTrade(mapped);
            setIsSlideOverOpen(true);
          }} />

        </div>

        {/* Trade Slide-Over */}
        <TradeSlideOver
          trade={selectedTrade}
          isOpen={isSlideOverOpen}
          onClose={() => setIsSlideOverOpen(false)}
        />
      </DashboardLayout>
    </JournalSettingsProvider>
  );
}
