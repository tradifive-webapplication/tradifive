import React, { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import DashboardLayout from "@/components/DashboardLayout";
import { Link, useNavigate } from "react-router-dom";
import { 
  CheckCircle2, MapPin, Calendar, MoreHorizontal, X,
  Search, Heart, MessageCircle, Bookmark, Share2, 
  TrendingUp, Globe, Flame, ShieldCheck, Trophy,
  Star, BarChart2, FileText, Shield, Info, Target, Scale,
  Crown, ArrowRight, ChevronDown, Radio, Play, Pencil, Settings, Camera
} from "lucide-react";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";
import CreatePostModal from "@/components/CreatePostModal";
import CommentModal from "@/components/CommentModal";
import JournalTradesTable from "@/components/journal/JournalTradesTable";
import { JournalSettingsProvider } from "@/contexts/JournalSettingsContext";
import { getGamificationState } from "@/utils/gamification";

// Placeholder display names to filter out from suggestions
const PLACEHOLDER_NAMES = ["new trader", "guest trader", "demo trader", "trader", "guest"];

function PollBlock({ 
  post, 
  currentUserId, 
  onVoteSuccess 
}: { 
  post: any; 
  currentUserId: string; 
  onVoteSuccess: () => void;
}) {
  const votedOptionKey = `tradifive_voted_poll_${post.id}`;
  const [votedOption, setVotedOption] = useState<number | null>(() => {
    const val = localStorage.getItem(votedOptionKey);
    return val !== null ? Number(val) : null;
  });

  let pollData: { options: string[]; votes: number[] } | null = null;
  if (post.post_type === "poll" && post.media_url) {
    try {
      pollData = JSON.parse(post.media_url);
    } catch (e) {}
  }

  if (!pollData) return null;

  const handleVoteOption = async (index: number) => {
    if (!pollData || votedOption !== null || post.user_id === currentUserId) return;
    const updatedVotes = [...pollData.votes];
    updatedVotes[index]++;
    const updatedPoll = { ...pollData, votes: updatedVotes };
    
    localStorage.setItem(votedOptionKey, String(index));
    setVotedOption(index);
    
    try {
      const { error } = await supabase
        .from('social_posts')
        .update({ media_url: JSON.stringify(updatedPoll) })
        .eq('id', post.id);
      if (error) throw error;
      onVoteSuccess();
    } catch (err) {
      console.error("Error voting:", err);
    }
  };

  const totalPollVotes = pollData.votes.reduce((a, b) => a + b, 0);
  const hasVotedOrOwns = votedOption !== null || post.user_id === currentUserId;

  return (
    <div className="mb-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/30 dark:bg-[#1A1A1A]/10 space-y-3">
      {pollData.options.map((opt, idx) => {
        const votes = pollData!.votes[idx] || 0;
        const percentage = totalPollVotes > 0 ? Math.round((votes / totalPollVotes) * 100) : 0;
        
        return hasVotedOrOwns ? (
          <div key={idx} className="relative w-full p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-[#111111] overflow-hidden select-none font-semibold text-xs text-slate-800 dark:text-white flex items-center justify-between">
            <div 
              className="absolute left-0 top-0 bottom-0 bg-blue-500/10 dark:bg-blue-500/15 transition-all duration-500" 
              style={{ width: `${percentage}%` }}
            />
            <span className="relative z-10 flex items-center gap-2 font-bold">
              {opt} {votedOption === idx && <span className="text-[10px] text-blue-500 font-extrabold">(Your Vote)</span>}
            </span>
            <span className="relative z-10 font-extrabold text-slate-700 dark:text-slate-355">
              {percentage}% ({votes})
            </span>
          </div>
        ) : (
          <button
            key={idx}
            onClick={() => handleVoteOption(idx)}
            className="w-full text-left p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-600 hover:bg-blue-50/10 dark:hover:bg-blue-500/5 transition-all font-semibold text-xs text-slate-700 dark:text-slate-300 hover:text-blue-500 select-none cursor-pointer"
          >
            {opt}
          </button>
        );
      })}
      <div className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500 px-1 pt-1 flex justify-between">
        <span>Total: {totalPollVotes} vote{totalPollVotes !== 1 ? 's' : ''}</span>
        {post.user_id === currentUserId && <span className="text-blue-500">Your Poll</span>}
      </div>
    </div>
  );
}

const getActiveUserId = () => {
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('sb-') && key.endsWith('-auth-token')) {
        const session = JSON.parse(localStorage.getItem(key) || '{}');
        if (session && session.user && session.user.id) {
          return session.user.id;
        }
      }
    }
  } catch (e) {}
  return 'guest';
};

export default function Profile() {
  const navigate = useNavigate();
  const userIdSync = getActiveUserId();

  const [profile, setProfile] = useState<any>(() => {
    const cached = localStorage.getItem(`prof_cache_data_${userIdSync}`);
    return cached ? JSON.parse(cached) : null;
  });
  const [posts, setPosts] = useState<any[]>(() => {
    const cached = localStorage.getItem(`prof_cache_posts_${userIdSync}`);
    return cached ? JSON.parse(cached) : [];
  });
  const [loading, setLoading] = useState(() => {
    return localStorage.getItem(`prof_cache_data_${userIdSync}`) === null;
  });
  const [activeTab, setActiveTab] = useState<string>("Posts");
  const avatarUploadRef = useRef<HTMLInputElement>(null);
  const bannerUploadRef = useRef<HTMLInputElement>(null);
  
  // Follow/Profile Stats
  const [followerCount, setFollowerCount] = useState(() => {
    const cached = localStorage.getItem(`prof_cache_followers_${userIdSync}`);
    return cached ? Number(cached) : 0;
  });
  const [followingCount, setFollowingCount] = useState(() => {
    const cached = localStorage.getItem(`prof_cache_following_${userIdSync}`);
    return cached ? Number(cached) : 0;
  });
  const [ownPostsCount, setOwnPostsCount] = useState(() => {
    const cached = localStorage.getItem(`prof_cache_posts_count_${userIdSync}`);
    return cached ? Number(cached) : 0;
  });

  // Real-time calculated metrics with mockup fallbacks
  const [totalTradesCount, setTotalTradesCount] = useState<number>(() => {
    const cached = localStorage.getItem(`prof_cache_stats_${userIdSync}`);
    return cached ? JSON.parse(cached).totalTradesCount : 0;
  });
  const [winRateVal, setWinRateVal] = useState<string>(() => {
    const cached = localStorage.getItem(`prof_cache_stats_${userIdSync}`);
    return cached ? JSON.parse(cached).winRateVal : "0%";
  });
  const [roiVal, setRoiVal] = useState<string>(() => {
    const cached = localStorage.getItem(`prof_cache_stats_${userIdSync}`);
    return cached ? JSON.parse(cached).roiVal : "0.00%";
  });
  const [avgRRVal, setAvgRRVal] = useState<string>("1 : 0.0");
  const [streakVal, setStreakVal] = useState<string>(() => {
    const cached = localStorage.getItem(`prof_cache_stats_${userIdSync}`);
    return cached ? JSON.parse(cached).streakVal : "0 Days";
  });
  const [bestStreak, setBestStreak] = useState<number>(() => {
    const cached = localStorage.getItem(`prof_cache_stats_${userIdSync}`);
    return cached ? JSON.parse(cached).bestStreak : 0;
  });
  const [streakDots, setStreakDots] = useState<{date: string; status: 'green'|'red'|'gray'}[]>([]);
  const [calendarDayMap, setCalendarDayMap] = useState<Record<string, 'green'|'red'|'gray'>>({});
  const [calendarMonth, setCalendarMonth] = useState(() => new Date());

  // Interaction States
  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});
  const [likesOffsets, setLikesOffsets] = useState<Record<string, number>>({});
  const [followedUsers, setFollowedUsers] = useState<Record<string, boolean>>({});
  const [suggestedTraders, setSuggestedTraders] = useState<any[]>([]);
  const [editPost, setEditPost] = useState<any>(null);
  const [openDropdownId, setOpenDropdownId] = useState<string | null>(null);
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});
  const [commentsCounts, setCommentsCounts] = useState<Record<string, number>>({});
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const handleDeletePost = async (postId: string) => {
    if (!confirm("Are you sure you want to delete this post?")) return;
    try {
      const { error } = await supabase
        .from('social_posts')
        .delete()
        .eq('id', postId);
      if (error) throw error;
      toast.success("Post deleted successfully!");
      fetchProfileAndData();
    } catch (err: any) {
      console.error("Error deleting post:", err);
      toast.error("Failed to delete post.");
    }
  };

  // Edit Profile and Privacy States
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [gamState, setGamState] = useState(() => getGamificationState());

  useEffect(() => {
    const handleXPUpdate = () => {
      setGamState(getGamificationState());
    };
    window.addEventListener("tradifive_xp_update", handleXPUpdate);
    return () => window.removeEventListener("tradifive_xp_update", handleXPUpdate);
  }, []);

  const [privacySettings, setPrivacySettings] = useState({
    show_location: true,
    show_winrate: true,
    show_roi: true,
    show_streak: true,
    show_trades: true,
    is_private: false,
    account_type: 'personal' as 'personal' | 'creator' | 'business'
  });

  const [editDisplayName, setEditDisplayName] = useState("");
  const [editUsername, setEditUsername] = useState("");
  const [editBio, setEditBio] = useState("");
  const [editLocation, setEditLocation] = useState("");
  const [editCountry, setEditCountry] = useState("");
  const [editCountryEmoji, setEditCountryEmoji] = useState("");
  const [editAvatarUrl, setEditAvatarUrl] = useState("");
  const [editBannerUrl, setEditBannerUrl] = useState("");

  useEffect(() => {
    if (profile?.id) {
      const stored = localStorage.getItem(`tradifive_privacy_${profile.id}`);
      if (stored) {
        setPrivacySettings(JSON.parse(stored));
      }
    }
  }, [profile?.id]);

  const openEditModal = () => {
    navigate('/settings?tab=profiles');
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile?.id) return;

    const updatedProfile = {
      ...profile,
      display_name: editDisplayName,
      username: editUsername,
      bio: editBio,
      location: editLocation,
      country: editCountry,
      country_emoji: editCountryEmoji,
      avatar_url: editAvatarUrl,
      banner_url: editBannerUrl
    };

    setProfile(updatedProfile);

    // Save privacy settings locally
    localStorage.setItem(`tradifive_privacy_${profile.id}`, JSON.stringify(privacySettings));
    
    // Also save privacy settings globally by username for public view lookups
    localStorage.setItem(`tradifive_privacy_user_${editUsername.toLowerCase()}`, JSON.stringify(privacySettings));
    
    // Also store the updated mock profiles in localStorage for public user profile page to look up!
    localStorage.setItem(`tradifive_mock_profile_${editUsername.toLowerCase()}`, JSON.stringify(updatedProfile));

    // Update tradifive cache keys for sidebar
    localStorage.setItem("tradifive_cached_display_name", editDisplayName);
    localStorage.setItem("tradifive_cached_username", editUsername);
    localStorage.setItem("tradifive_cached_avatar_url", editAvatarUrl);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user && !user.id.startsWith('mock-user-id')) {
        await supabase
          .from('profiles')
          .update({
            display_name: editDisplayName,
            username: editUsername,
            bio: editBio,
            avatar_url: editAvatarUrl,
            banner_url: editBannerUrl
          })
          .eq('id', user.id);
      }
      window.dispatchEvent(new Event("tradifive_profile_update"));
      toast.success("Profile updated successfully!");
    } catch (err) {
      console.error("Error updating database profile:", err);
      toast.error("Failed to save changes in database, but saved locally.");
    } finally {
      setIsEditModalOpen(false);
    }
  };

  useEffect(() => {
    fetchProfileAndData();
  }, []);

  const fetchProfileAndData = async () => {
    // Check local cache for immediate render
    const cacheProf = localStorage.getItem(`prof_cache_data_${userIdSync}`);
    if (cacheProf) {
      setProfile(JSON.parse(cacheProf));
    }
    const cachePosts = localStorage.getItem(`prof_cache_posts_${userIdSync}`);
    if (cachePosts) {
      setPosts(JSON.parse(cachePosts));
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        // Parallelize all independent DB fetches!
        const [
          profRes,
          followersRes,
          followingRes,
          sugRes,
          postsRes,
          likesRes,
          tradesRes,
          mt5Res
        ] = await Promise.all([
          supabase.from('profiles').select('*').eq('id', user.id).maybeSingle(),
          supabase.from('social_follows').select('*', { count: 'exact', head: true }).eq('following_id', user.id),
          supabase.from('social_follows').select('following_id').eq('follower_id', user.id),
          supabase.from('profiles').select('id, display_name, username, avatar_url, win_rate, bio').neq('id', user.id).limit(10),
          supabase.from('social_posts').select('*, profiles:user_id (id, first_name, last_name, avatar_url, username, display_name, bio, banner_url)').order('created_at', { ascending: false }),
          supabase.from('social_post_likes').select('post_id').eq('user_id', user.id),
          supabase.from('trades').select('*').eq('user_id', user.id),
          supabase.from('mt5_accounts').select('balance').eq('user_id', user.id).maybeSingle()
        ]);

        const profileData = profRes.data;
        if (profileData) {
          const emailUsername = user.email?.split('@')[0]?.toLowerCase().replace(/[^a-z0-9]/g, '') || "trader";
          if (profileData.display_name === "Guest Trader" || !profileData.display_name || profileData.username === "guest_trader" || !profileData.username) {
            const meta = user.user_metadata || {};
            const resolvedDisplayName = meta.full_name || meta.name || `${meta.first_name || ''} ${meta.last_name || ''}`.trim() || emailUsername;
            const resolvedUsername = profileData.username && profileData.username !== "guest_trader" ? profileData.username : emailUsername;
            const resolvedAvatarUrl = profileData.avatar_url || meta.avatar_url || meta.picture || `https://api.dicebear.com/7.x/initials/svg?seed=${resolvedDisplayName}`;

            const updatedProfile = {
              ...profileData,
              display_name: profileData.display_name && profileData.display_name !== "Guest Trader" ? profileData.display_name : resolvedDisplayName,
              username: resolvedUsername,
              bio: profileData.bio || "",
              avatar_url: resolvedAvatarUrl,
              banner_url: profileData.banner_url || "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1200&fit=crop&q=80",
            };
            supabase.from('profiles').update({
                display_name: updatedProfile.display_name,
                username: updatedProfile.username,
                avatar_url: updatedProfile.avatar_url,
                banner_url: updatedProfile.banner_url
              }).eq('id', user.id).then();
            setProfile(updatedProfile);
            localStorage.setItem(`prof_cache_data_${userIdSync}`, JSON.stringify(updatedProfile));
          } else {
            setProfile(profileData);
            localStorage.setItem(`prof_cache_data_${userIdSync}`, JSON.stringify(profileData));
          }
        }

        if (followersRes.count !== null) {
          setFollowerCount(followersRes.count);
          localStorage.setItem(`prof_cache_followers_${userIdSync}`, String(followersRes.count));
        }
        if (followingRes.data) {
          setFollowingCount(followingRes.data.length);
          localStorage.setItem(`prof_cache_following_${userIdSync}`, String(followingRes.data.length));
          const map: Record<string, boolean> = {};
          followingRes.data.forEach((f: any) => { map[f.following_id] = true; });
          setFollowedUsers(map);
        }

        if (sugRes.data) {
          const realTraders = sugRes.data.filter((p: any) => {
            const name = (p.display_name || '').trim().toLowerCase();
            return name.length > 0 && !PLACEHOLDER_NAMES.includes(name);
          }).slice(0, 5);
          setSuggestedTraders(realTraders);
        }

        if (!postsRes.error && postsRes.data) {
          const localPosts = JSON.parse(localStorage.getItem('fialgo_local_posts') || '[]');
          const combinedPosts = [...localPosts, ...(postsRes.data ?? [])];
          combinedPosts.sort((a: any, b: any) => {
            const timeA = a && a.created_at ? new Date(a.created_at).getTime() : 0;
            const timeB = b && b.created_at ? new Date(b.created_at).getTime() : 0;
            return isNaN(timeB) || isNaN(timeA) ? 0 : timeB - timeA;
          });
          setPosts(combinedPosts);
          localStorage.setItem(`prof_cache_posts_${userIdSync}`, JSON.stringify(combinedPosts));
          const ownCount = combinedPosts.filter((p: any) => p.user_id === user.id || p.id.startsWith('local-')).length;
          setOwnPostsCount(ownCount);
          localStorage.setItem(`prof_cache_posts_count_${userIdSync}`, String(ownCount));
        } else {
          const localPosts = JSON.parse(localStorage.getItem('fialgo_local_posts') || '[]');
          setPosts(localPosts);
          setOwnPostsCount(localPosts.length);
          localStorage.setItem(`prof_cache_posts_count_${userIdSync}`, String(localPosts.length));
        }

        if (likesRes.data) {
          const likedMap: Record<string, boolean> = {};
          likesRes.data.forEach((l: any) => { likedMap[l.post_id] = true; });
          setLikedPosts(likedMap);
        }

        const tradesData = tradesRes.data;
        if (tradesData && tradesData.length > 0) {
          const total = tradesData.length;
          const wins = tradesData.filter((t: any) => Number(t.profit) > 0).length;
          const wr = total > 0 ? Math.round((wins / total) * 100) : 0;
          const pnlSum = tradesData.reduce((acc: number, t: any) => acc + Number(t.profit || 0), 0);
          
          setTotalTradesCount(total);
          setWinRateVal(`${wr}%`);
          
          let currentStreak = 0;
          const sortedTrades = [...tradesData].sort((a: any, b: any) => new Date(b.closed_at || b.created_at).getTime() - new Date(a.closed_at || a.created_at).getTime());
          for (const t of sortedTrades) {
            if (Number(t.profit) > 0) { currentStreak++; } else { break; }
          }
          setStreakVal(`${currentStreak} Day${currentStreak !== 1 ? 's' : ''}`);

          let best = 0;
          let runLen = 0;
          const chronoTrades = [...tradesData].sort((a: any, b: any) => new Date(a.closed_at || a.created_at).getTime() - new Date(b.closed_at || b.created_at).getTime());
          for (const t of chronoTrades) {
            if (Number(t.profit) > 0) { runLen++; if (runLen > best) best = runLen; } else { runLen = 0; }
          }
          setBestStreak(best);

          const today = new Date();
          const dots: {date: string; status: 'green'|'red'|'gray'}[] = [];
          const dailyPnl: Record<string, number> = {};
          for (const t of tradesData) {
            const d = new Date(t.closed_at || t.created_at);
            const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
            dailyPnl[key] = (dailyPnl[key] || 0) + Number(t.profit || 0);
          }
          for (let i = 14; i >= 0; i--) {
            const d = new Date(today);
            d.setDate(d.getDate() - i);
            const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
            if (dailyPnl[key] !== undefined) {
              dots.push({ date: key, status: dailyPnl[key] > 0 ? 'green' : 'red' });
            } else {
              dots.push({ date: key, status: 'gray' });
            }
          }
          setStreakDots(dots);

          const calMap: Record<string, 'green'|'red'|'gray'> = {};
          for (const [key, pnl] of Object.entries(dailyPnl)) {
            calMap[key] = pnl > 0 ? 'green' : 'red';
          }
          setCalendarDayMap(calMap);

          const balance = mt5Res.data?.balance || 10000;
          const roiPercent = balance > 0 ? (pnlSum / balance) * 100 : 0;
          const calculatedRoi = (pnlSum >= 0 ? "+" : "") + roiPercent.toFixed(2) + "%";
          setRoiVal(calculatedRoi);

          localStorage.setItem(`prof_cache_stats_${userIdSync}`, JSON.stringify({
            totalTradesCount: total,
            winRateVal: `${wr}%`,
            roiVal: calculatedRoi,
            streakVal: `${currentStreak} Day${currentStreak !== 1 ? 's' : ''}`,
            bestStreak: best
          }));
        } else {
          setTotalTradesCount(0);
          setWinRateVal("0%");
          setStreakVal("0 Days");
          setRoiVal("0.00%");
          setBestStreak(0);
          setStreakDots([]);
          setCalendarDayMap({});
        }
      } else {
        setProfile({
          id: "guest",
          display_name: "Guest Trader",
          username: "guest",
          bio: "",
          avatar_url: "",
          banner_url: "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1200&fit=crop&q=80",
        });
        setPosts([]);
        setOwnPostsCount(0);
      }
    } catch (err) {
      console.error("Error loading profile data:", err);
      setPosts([]);
    } finally {
      setLoading(false);
    }
  };
  const toggleFollowUser = async (targetUserId: string, targetName: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    if (targetUserId === user.id) return;
    
    const isFollowing = followedUsers[targetUserId] || false;
    setFollowedUsers(prev => ({ ...prev, [targetUserId]: !isFollowing }));
    
    try {
      if (isFollowing) {
        const { error } = await supabase
          .from('social_follows')
          .delete()
          .eq('follower_id', user.id)
          .eq('following_id', targetUserId);
        if (error) throw error;
        toast.info(`Unfollowed ${targetName}`);
      } else {
        const { error } = await supabase
          .from('social_follows')
          .insert([{ follower_id: user.id, following_id: targetUserId }]);
        if (error) throw error;
        toast.success(`Followed ${targetName}`);
      }
    } catch (err) {
      console.error("Error toggling follow:", err);
      toast.error("Failed to update follow status.");
      setFollowedUsers(prev => ({ ...prev, [targetUserId]: isFollowing }));
    }
  };

  const handleLikePost = async (postId: string) => {
    const isCurrentlyLiked = likedPosts[postId] || false;
    const nextLiked = !isCurrentlyLiked;
    
    // Optimistic UI updates
    setLikedPosts(prev => ({ ...prev, [postId]: nextLiked }));
    setLikesOffsets(prev => ({
      ...prev,
      [postId]: (prev[postId] || 0) + (nextLiked ? 1 : -1)
    }));

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user && !user.id.startsWith('mock-user-id')) {
        if (nextLiked) {
          await supabase.from('social_post_likes').insert([{ post_id: postId, user_id: user.id }]);
        } else {
          await supabase.from('social_post_likes').delete().eq('post_id', postId).eq('user_id', user.id);
        }
      }
    } catch (err) {
      console.error("Error toggling like:", err);
    }
  };

  const formatCount = (baseVal: number, offset: number) => {
    const total = Math.max(0, baseVal + offset);
    if (total >= 1000) {
      return (total / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
    }
    return total.toString();
  };

  // Filtering posts based on mobile app rules
  const filteredPosts = posts.filter((p: any) => {
    const isOwnPost = profile ? (p.user_id === profile.id || p.id.startsWith('local-')) : false;
    const isTagged = (profile && profile.username && p.content) 
      ? p.content.toLowerCase().includes('@' + profile.username.toLowerCase())
      : false;

    if (activeTab === "Activity") {
      return isOwnPost || isTagged;
    } else if (activeTab === "Posts") {
      return isOwnPost && p.media_type !== 'video';
    } else if (activeTab === "Mentions") {
      return isTagged;
    } else if (activeTab === "Videos") {
      return isOwnPost && p.media_type === 'video';
    }
    return false;
  });

  const headerActions = (
    <div className="flex items-center gap-4">
      {/* Action buttons (e.g., share) could go here */}
    </div>
  );

  if (loading) {
    return (
      <DashboardLayout breadcrumbs={[{ label: "Home", path: "/home" }, { label: "My Profile", path: "/profile" }]} headerActions={headerActions} noPadding={true}>
        <div className="w-full h-full flex flex-col px-4 lg:px-10 pt-6 pb-6 bg-[#F8FAFC] dark:bg-[#000000]">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-7xl mx-auto w-full animate-pulse">
            <div className="lg:col-span-9 space-y-6">
              <div className="h-64 sm:h-80 bg-slate-200 dark:bg-[#141414] rounded-[32px] w-full" />
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                 <div className="h-28 bg-slate-200 dark:bg-[#141414] rounded-2xl" />
                 <div className="h-28 bg-slate-200 dark:bg-[#141414] rounded-2xl" />
                 <div className="h-28 bg-slate-200 dark:bg-[#141414] rounded-2xl" />
                 <div className="h-28 bg-slate-200 dark:bg-[#141414] rounded-2xl" />
                 <div className="h-28 bg-slate-200 dark:bg-[#141414] rounded-2xl" />
              </div>
              <div className="h-96 bg-slate-200 dark:bg-[#141414] rounded-[32px] w-full mt-6" />
            </div>
            <div className="lg:col-span-3 space-y-6">
              <div className="h-80 bg-slate-200 dark:bg-[#141414] rounded-3xl" />
            </div>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <>
      <DashboardLayout breadcrumbs={[{ label: "Home", path: "/home" }, { label: "My Profile", path: "/profile" }]} headerActions={headerActions} noPadding={true}>
      <div className="w-full min-h-screen flex flex-col px-4 lg:px-10 pt-6 pb-6 select-none font-sans text-slate-800 dark:text-slate-100 bg-[#F8FAFC] dark:bg-[#000000]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0 relative max-w-7xl mx-auto w-full">
          
          {/* --- LEFT & MIDDLE MAIN CONTENT (col-span-9) --- */}
          <div className="lg:col-span-9 space-y-6">
            
            {/* Header Card (Consistent Tactile Neumorphic / Claymorphic Outer container with dual-border & soft shadow specs) */}
            <div className="bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] rounded-[32px] overflow-hidden border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] relative">
              
              {/* Cover Banner */}
              <div className="h-44 sm:h-52 w-full relative bg-[#1A1A1A] overflow-hidden border-b border-white/10 dark:border-[#1A1A1A]">
                {loading ? (
                  <div className="w-full h-full animate-pulse bg-slate-350 dark:bg-[#141414]" />
                ) : (
                  <div className="w-full h-full relative group">
                    <img 
                      src={profile?.banner_url || "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1200&fit=crop&q=80"} 
                      alt="Cover" 
                      className="w-full h-full object-cover opacity-90 scale-105"
                    />
                    {/* Blue/Cyberpunk gradient overlays to match image banner */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/20" />
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-900/30 to-purple-950/40 mix-blend-multiply" />
                    
                    {/* Upload Banner Button */}
                    <button 
                      onClick={() => bannerUploadRef.current?.click()}
                      className="absolute top-4 right-4 bg-black/40 hover:bg-black/60 backdrop-blur-md p-2 rounded-full text-white transition-all opacity-0 group-hover:opacity-100 shadow-lg border border-white/20 z-10"
                      title="Update Cover Photo"
                    >
                      <Camera size={18} />
                    </button>
                    
                    <input 
                      type="file"
                      ref={bannerUploadRef}
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                         const file = e.target.files?.[0];
                         if (file) {
                            if (file.size > 5 * 1024 * 1024) {
                               toast.error("File is too large! Please select an image under 5MB.");
                               return;
                            }
                            const reader = new FileReader();
                            reader.onloadend = async () => {
                               const base64Str = reader.result as string;
                               setProfile(p => ({...p, banner_url: base64Str}));
                               if (user) {
                                  try {
                                     await supabase.from('profiles').update({ banner_url: base64Str }).eq('id', user.id);
                                     toast.success("Cover photo updated!");
                                  } catch (err) {
                                     toast.error("Failed to save cover photo");
                                  }
                               }
                            };
                            reader.readAsDataURL(file);
                         }
                      }}
                    />
                  </div>
                )}

                {/* Cover Banner Crown pill status */}
                <div className="absolute bottom-4 right-6 bg-[#000000]/45 backdrop-blur-md text-white text-[11px] font-extrabold px-3.5 py-2 rounded-full flex items-center gap-1.5 border border-white/10 shadow-lg">
                  <Crown size={12} className="text-yellow-400 fill-yellow-400" />
                  <span>Elite Trader</span>
                </div>
              </div>

              {/* Profile Details Area */}
              <div className="px-8 pb-5 relative pt-4">
                
                {/* Horizontal Layout containing Avatar & Stats top-level row */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                  
                  {/* Left: Avatar container overlapping covers */}
                  <div className="relative -mt-16 sm:-mt-20 shrink-0">
                    <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-white dark:border-[#1A1A1C] overflow-hidden bg-white dark:bg-[#1A1A1C] relative">
                      {loading ? (
                        <div className="w-full h-full animate-pulse bg-slate-200 dark:bg-slate-700" />
                      ) : (
                        <div className="relative w-full h-full group">
                          <img 
                            src={profile?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${profile?.display_name || 'T'}`} 
                            alt="Avatar" 
                            className="w-full h-full object-cover"
                          />
                          <button 
                            onClick={() => avatarUploadRef.current?.click()}
                            className="absolute inset-0 bg-black/40 hover:bg-black/50 backdrop-blur-[2px] flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                            title="Update Avatar"
                          >
                            <Camera size={24} className="drop-shadow-md" />
                          </button>
                          
                          <input 
                            type="file"
                            ref={avatarUploadRef}
                            accept="image/*"
                            className="hidden"
                            onChange={async (e) => {
                               const file = e.target.files?.[0];
                               if (file) {
                                  if (file.size > 5 * 1024 * 1024) {
                                     toast.error("File is too large! Please select an image under 5MB.");
                                     return;
                                  }
                                  const reader = new FileReader();
                                  reader.onloadend = async () => {
                                     const base64Str = reader.result as string;
                                     setProfile(p => ({...p, avatar_url: base64Str}));
                                     if (user) {
                                        try {
                                           await supabase.from('profiles').update({ avatar_url: base64Str }).eq('id', user.id);
                                           toast.success("Avatar updated!");
                                        } catch (err) {
                                           toast.error("Failed to save avatar");
                                        }
                                     }
                                  };
                                  reader.readAsDataURL(file);
                               }
                            }}
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right: Stats display horizontally positioned next to the avatar (Using Inter font weights) */}
                  <div className="flex flex-1 justify-around sm:justify-end gap-6 sm:gap-14 w-full sm:w-auto py-2 sm:py-0 text-center sm:text-right">
                    <div className="min-w-[65px] text-center">
                      <p className="text-xl sm:text-[23px] font-extrabold text-slate-900 dark:text-white leading-none tracking-tight font-sans">{ownPostsCount}</p>
                      <p className="text-[10px] font-bold text-slate-455 dark:text-slate-500 uppercase tracking-wider mt-2 leading-none">posts</p>
                    </div>
                    <div className="border-r border-slate-200 dark:border-slate-800/80 h-8 self-center hidden sm:block" />
                    <div className="min-w-[75px] text-center">
                      <p className="text-xl sm:text-[23px] font-extrabold text-slate-900 dark:text-white leading-none tracking-tight font-sans">{followerCount}</p>
                      <p className="text-[10px] font-bold text-slate-455 dark:text-slate-500 uppercase tracking-wider mt-2 leading-none">followers</p>
                    </div>
                    <div className="border-r border-slate-200 dark:border-slate-800/80 h-8 self-center hidden sm:block" />
                    <div className="min-w-[75px] text-center">
                      <p className="text-xl sm:text-[23px] font-extrabold text-slate-900 dark:text-white leading-none tracking-tight font-sans">{followingCount}</p>
                      <p className="text-[10px] font-bold text-slate-455 dark:text-slate-500 uppercase tracking-wider mt-2 leading-none">following</p>
                    </div>
                  </div>

                </div>

                {/* Info and buttons layout below the avatar level */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-6 items-end">
                  
                  {/* Left columns: Profile identity labels & pills */}
                  <div className="md:col-span-8 text-center sm:text-left">
                    <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white flex items-center justify-center sm:justify-start gap-2 leading-tight">
                      {profile?.display_name || "Guest Trader"}
                      <CheckCircle2 size={20} className="text-blue-500 fill-blue-500 text-white dark:text-[#1A1A1C] shrink-0" />
                    </h1>
                    <p className="text-[13px] font-semibold text-slate-455 dark:text-slate-500 mt-1">
                      @{profile?.username || "guest_trader"}
                    </p>
                    <div className="flex items-center justify-center sm:justify-start gap-4 mt-2.5 mb-1.5 select-none">
                      <span className="bg-gradient-to-r from-blue-500/20 to-indigo-500/20 text-blue-655 dark:text-blue-400 text-[10.5px] font-black px-2.5 py-1 rounded-lg border border-blue-500/25 flex items-center gap-1 shadow-sm shrink-0">
                        <Crown size={12} className="text-blue-500" /> Lvl {gamState.level}
                      </span>
                      <div className="flex items-center gap-2 flex-1 max-w-[180px] min-w-[120px]">
                        <div className="flex-1 h-1.5 bg-slate-200 dark:bg-[#141414] rounded-full overflow-hidden relative">
                          <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full" style={{ width: `${Math.min(100, (gamState.xp / gamState.xp_required) * 100)}%` }} />
                        </div>
                        <span className="text-[9.5px] text-slate-450 dark:text-slate-500 font-bold shrink-0">{gamState.xp}/{gamState.xp_required} XP</span>
                      </div>
                    </div>
                    <p className="text-[14px] text-slate-700 dark:text-slate-300 font-semibold leading-relaxed mt-3.5 max-w-xl">
                      {profile?.bio || "No bio yet. Update your profile to tell others about your trading style."}
                    </p>

                    {/* Badges row */}
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-500/10 text-purple-655 dark:text-purple-400 text-[11px] font-bold border border-purple-500/10 shadow-sm">
                        <Crown size={11} className="fill-purple-500/20 text-purple-500" /> Elite Trader
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-500/10 text-blue-655 dark:text-blue-400 text-[11px] font-bold border border-blue-500/10 shadow-sm">
                        <Star size={11} className="fill-blue-500/20 text-blue-500" /> Swing Master
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-655 dark:text-emerald-450 text-[11px] font-bold border border-emerald-500/10 shadow-sm">
                        <Shield size={11} className="fill-emerald-500/20 text-emerald-500" /> AI Disciplined
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-500/10 text-orange-655 dark:text-orange-400 text-[11px] font-bold border border-orange-500/10 shadow-sm">
                        <Star size={11} className="fill-orange-500/20 text-orange-500" /> Top Mentor
                      </span>
                    </div>

                    {/* Geographic and join info */}
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-5 gap-y-2 text-slate-500 dark:text-slate-400 text-xs font-bold mt-5 pt-4 border-t border-slate-200/50 dark:border-slate-800/40">
                      <span className="flex items-center gap-1.5">
                        {profile?.country_emoji || "🌍"} <span>{profile?.country || "Not set"}</span>
                      </span>
                      <span className="flex items-center gap-1.5">
                        <MapPin size={13.5} className="text-slate-400" /> <span>{profile?.location || "Not set"}</span>
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Calendar size={13.5} className="text-slate-400" /> <span>Joined Jan 2024</span>
                      </span>
                    </div>
                  </div>

                  {/* Right columns: Claymorphic Action Buttons to match mockup exactly */}
                  <div className="md:col-span-4 flex items-center justify-center sm:justify-end gap-2.5 w-full pb-2.5">
                    {/* Edit Button */}
                    <button 
                      onClick={openEditModal}
                      className="flex items-center justify-center gap-1.5 px-5 py-2 rounded-full text-[12px] font-bold whitespace-nowrap transition-all duration-300 border-2 active:scale-95 bg-gradient-to-b from-[#60A5FA] to-[#3B82F6] dark:from-[#3B82F6] dark:to-[#1D4ED8] text-white border-[#93C5FD] dark:border-[#3B82F6] shadow-[0_4px_7px_-5px_rgba(59,130,246,0.25),_0_0_0_2px_#3B82F6] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1D4ED8]"
                    >
                      <Pencil size={13} /> Edit
                    </button>

                    {/* Share Button */}
                    <button 
                      onClick={() => {
                        const profileUrl = `${window.location.origin}/user/${profile?.username || "guest_trader"}`;
                        navigator.clipboard.writeText(profileUrl);
                        toast.success("Profile link copied to clipboard!");
                      }}
                      className="flex items-center justify-center gap-1.5 px-5 py-2 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] text-[#393939] dark:text-[#E2E8F0] text-[12px] font-bold whitespace-nowrap transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] active:scale-95"
                    >
                      <Share2 size={13} /> Share
                    </button>
                  </div>

                </div>

              </div>
            </div>

            {/* --- QUICK STATS GRID CARDS (5 Cards) --- */}
            {/* Redesigned to have 100% Tactile claymorphic styling matching mockup box shadow specs */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
              {[
                { title: "Trades", value: totalTradesCount.toLocaleString(), icon: <BarChart2 size={16} className="text-blue-500" />, color: "bg-blue-500/10 text-blue-600" },
                { title: "Win Rate", value: winRateVal, icon: <CheckCircle2 size={16} className="text-emerald-500" />, color: "bg-emerald-500/10 text-emerald-600" },
                { title: "ROI (All Time)", value: roiVal, icon: <TrendingUp size={16} className="text-emerald-500 animate-pulse" />, color: "bg-emerald-500/10 text-emerald-600", highlighted: true },
                { title: "Avg RR", value: avgRRVal, icon: <Target size={16} className="text-purple-500" />, color: "bg-purple-500/10 text-purple-600" },
                { title: "Streak", value: streakVal, icon: <Flame size={16} className="text-orange-500 animate-pulse" />, color: "bg-orange-500/10 text-orange-600" }
              ].map((card, idx) => (
                <div key={idx} className="py-3.5 px-5 rounded-2xl bg-gradient-to-b from-[#F4F4F4]/70 to-[#FFFFFF] dark:from-[#252528]/65 dark:to-[#1A1A1C] border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.35),_0_0_0_2px_#333336] hover:-translate-y-0.5 transition-all duration-350 flex flex-col gap-2.5 group">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-455 dark:text-slate-500 uppercase tracking-wider">{card.title}</span>
                    <div className={`p-2 rounded-xl ${card.color} transition-transform group-hover:scale-105 duration-300`}>
                      {card.icon}
                    </div>
                  </div>
                  <p className={`text-xl sm:text-[22px] font-extrabold leading-none font-sans tracking-tight ${card.highlighted ? 'text-emerald-500' : 'text-slate-900 dark:text-white'}`}>
                    {card.value}
                  </p>
                </div>
              ))}
            </div>

            {/* --- TWO COLUMN MIDDLE SECTION: PERFORMANCE vs AI ANALYSIS --- */}
            {/* Both styled as tactile rounded-3xl containers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Card A: Trading Performance */}
              <div className="bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] flex flex-col gap-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider">Trading Performance</h3>
                  
                  {/* Select dropdown style tactile clone */}
                  <span className="text-[11px] font-bold text-[#393939] dark:text-[#E2E8F0] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] px-3.5 py-1.5 rounded-full border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#333336] cursor-pointer flex items-center gap-1.5 select-none active:scale-95 transition-all">
                    All Time <ArrowRight size={10} className="rotate-90 text-slate-500" />
                  </span>
                </div>

                <div className="grid grid-cols-12 gap-5 items-center">
                  
                  {/* Left part: Total PnL Label & glowing Line Chart */}
                  <div className="col-span-6 flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider leading-none">Total PnL</span>
                    <span className="text-2xl font-extrabold text-emerald-500 tracking-tight leading-none mt-2.5 font-sans">+212.45%</span>
                    
                    <div className="h-24 w-full mt-5 relative">
                      <svg className="w-full h-full filter drop-shadow-[0_4px_8px_rgba(59,130,246,0.2)]" viewBox="0 0 100 40" preserveAspectRatio="none">
                        <defs>
                          <linearGradient id="pnlGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                        <path 
                          d="M0,35 Q12,32 25,24 T55,27 T75,10 T100,3" 
                          fill="none" 
                          stroke="#3b82f6" 
                          strokeWidth="2.5" 
                          strokeLinecap="round"
                        />
                        <path 
                          d="M0,35 Q12,32 25,24 T55,27 T75,10 T100,3 L100,40 L0,40 Z" 
                          fill="url(#pnlGrad)"
                        />
                        {/* Glowing terminal node */}
                        <circle cx="100" cy="3" r="3.5" fill="#3b82f6" className="animate-ping" />
                        <circle cx="100" cy="3" r="2" fill="#3b82f6" />
                      </svg>
                    </div>
                  </div>

                  {/* Right part: stats list styled with Inter weights */}
                  <div className="col-span-6 space-y-3.5 pl-6 border-l border-slate-200 dark:border-slate-800/80">
                    {[
                      { label: "Profit Factor", value: "2.31", color: "text-blue-500", icon: <BarChart2 size={13} className="text-blue-500" /> },
                      { label: "Expectancy", value: "+1.42R", color: "text-emerald-500", icon: <TrendingUp size={13} className="text-emerald-500" /> },
                      { label: "Max Drawdown", value: "-8.72%", color: "text-rose-500", highlighted: true, icon: <Scale size={13} className="text-rose-500" /> },
                      { label: "Consistency Score", value: "82%", color: "text-blue-500", icon: <CheckCircle2 size={13} className="text-blue-500" />, showInfo: true }
                    ].map((stat, i) => (
                      <div key={i} className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-455 dark:text-slate-400 flex items-center gap-2">
                          {/* Inner icon consistency boxes */}
                          <div className="p-1 rounded-lg bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] border border-white dark:border-[#1A1A1A] shadow-sm">
                            {stat.icon}
                          </div>
                          <span className="flex items-center gap-1 font-semibold">
                            {stat.label}
                            {stat.showInfo && <Info size={11} className="text-slate-400 hover:text-slate-655 cursor-pointer" />}
                          </span>
                        </span>
                        <span className={`font-bold tracking-tight font-sans ${stat.highlighted ? 'text-rose-500' : 'text-slate-855 dark:text-slate-200'}`}>{stat.value}</span>
                      </div>
                    ))}
                  </div>

                </div>
              </div>

              {/* Card B: Tradifive AI Analysis (Tactile rounded-3xl container) */}
              <div className="bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] flex flex-col gap-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider">Tradifive AI Analysis</h3>
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Updated 2h ago</span>
                </div>

                <div className="space-y-4">
                  {/* Emotional Discipline bar */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-2">
                      <span className="text-slate-555 dark:text-slate-400">Emotional Discipline</span>
                      <span className="font-bold text-emerald-500">82%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 dark:bg-[#141414] rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-850">
                      <div className="h-full bg-[#10b981] rounded-full transition-all duration-1000" style={{ width: '82%' }} />
                    </div>
                  </div>

                  {/* Revenge Trading Risk */}
                  <div className="flex justify-between items-center text-xs py-2.5 border-y border-slate-200/60 dark:border-slate-800/80">
                    <span className="font-semibold text-slate-555 dark:text-slate-400">Revenge Trading Risk</span>
                    <span className="font-bold text-[#10b981] flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] shadow-sm" /> Low
                    </span>
                  </div>

                  {/* Confidence Score bar */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-2">
                      <span className="text-slate-555 dark:text-slate-400">Confidence Score</span>
                      <span className="font-bold text-blue-500">74%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 dark:bg-[#141414] rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-850">
                      <div className="h-full bg-blue-500 rounded-full transition-all duration-1000" style={{ width: '74%' }} />
                    </div>
                  </div>

                  {/* Two detailed info cells */}
                  <div className="grid grid-cols-2 gap-4 text-xs pt-2.5 border-t border-slate-200/60 dark:border-slate-800/80">
                    <div>
                      <span className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-[9px] block">Best Trading Session</span>
                      <span className="font-bold text-slate-900 dark:text-white mt-1 block font-sans">London (1PM - 5PM)</span>
                    </div>
                    <div>
                      <span className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-[9px] block">Suggested Improvement</span>
                      <span className="font-bold text-slate-900 dark:text-white mt-1 block font-sans">Work on RR consistency</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Pill Tabs Bar Selector */}
            {/* Styled with skeuomorphic outline frame */}
            <div className="bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] p-1.5 rounded-full flex items-center border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] select-none overflow-x-auto scrollbar-hide">
              {["Posts", "Trades", "Videos", "Mentions", "Achievements"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 text-center py-2.5 px-5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 shrink-0 ${
                    activeTab === tab 
                      ? "bg-gradient-to-b from-[#60A5FA] to-[#3B82F6] dark:from-[#3B82F6] dark:to-[#1D4ED8] text-white border-2 border-[#93C5FD] dark:border-[#3B82F6] shadow-[0_4px_7px_-5px_rgba(59,130,246,0.2),_0_0_0_2px_#3B82F6] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1D4ED8]" 
                      : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* --- BOTTOM GRID: POSTS FEED vs PINNED LIVE STREAM --- */}
            {/* Outer boxes fully adjusted to tactile rounded-3xl outer cards for absolute layout symmetry */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Feed Posts List */}
              <div className="md:col-span-12 max-w-4xl mx-auto w-full space-y-6">
                {activeTab === "Trades" ? (
                  <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336]">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Synchronized Execution Ledger</h3>
                    </div>
                    <JournalSettingsProvider>
                      <JournalTradesTable />
                    </JournalSettingsProvider>
                  </div>
                ) : activeTab === "Achievements" ? (
                  <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] space-y-6">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60">
                      <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                        <Trophy size={16} className="text-blue-500" />
                        <span>Trader Badges & Level Progress</span>
                      </h3>
                      <span className="bg-gradient-to-r from-blue-500/15 to-indigo-500/15 text-blue-600 dark:text-blue-400 text-[10px] font-extrabold px-3 py-1.5 rounded-full border border-blue-500/20 shadow-sm uppercase tracking-wider">
                        Rank: Vanguard
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Active Level Widget */}
                      <div className="p-5 rounded-2xl bg-white dark:bg-[#1E2335]/40 border border-slate-150 dark:border-[#1A1A1A] shadow-sm flex flex-col justify-between h-[120px]">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Progression Level</span>
                            <span className="text-2xl font-extrabold text-slate-900 dark:text-white mt-1 block">Level {gamState.level}</span>
                          </div>
                          <Crown size={22} className="text-amber-500 fill-amber-500/20" />
                        </div>
                        <div className="space-y-1.5">
                          <div className="flex justify-between text-[10px] font-bold text-slate-455">
                            <span>XP: {gamState.xp} / {gamState.xp_required}</span>
                            <span>{Math.round((gamState.xp / gamState.xp_required) * 100)}%</span>
                          </div>
                          <div className="w-full h-2 bg-slate-100 dark:bg-[#141414] rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-850">
                            <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full" style={{ width: `${(gamState.xp / gamState.xp_required) * 100}%` }} />
                          </div>
                        </div>
                      </div>

                      {/* Discipline Level Modifier */}
                      <div className="p-5 rounded-2xl bg-white dark:bg-[#1E2335]/40 border border-slate-150 dark:border-[#1A1A1A] shadow-sm flex flex-col justify-between h-[120px]">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Discipline Score</span>
                            <span className="text-2xl font-extrabold text-emerald-500 mt-1 block">82%</span>
                          </div>
                          <ShieldCheck size={22} className="text-emerald-500" />
                        </div>
                        <div className="text-[10.5px] text-slate-500 dark:text-slate-400 font-semibold leading-relaxed">
                          Your rank is stable. Maintain &gt;75% score to preserve premium badge benefits.
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4 pt-2">
                      <h4 className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Achievements Ledger ({[1,2,3,6].length} Unlocked)</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {[
                          { id: 1, name: "100 Winning Trades", desc: "Executed 100 profitable trades with verified parameters.", status: "unlocked", progress: "100/100" },
                          { id: 2, name: "Discipline Master", desc: "Maintained > 80% discipline score for 10 consecutive days.", status: "unlocked", progress: "10/10" },
                          { id: 3, name: "Drawdown Survivor", desc: "Zero days exceeding 2% drawdown limit this month.", status: "unlocked", progress: "30/30" },
                          { id: 4, name: "Risk Maestro", desc: "All executed positions had defined stop-losses and take-profits.", status: "locked", progress: "80/100" },
                          { id: 5, name: "Streak Legend", desc: "Reached a 15-day trading streak on the platform.", status: "locked", progress: `${gamState.streak}/15` },
                          { id: 6, name: "AI Coach Approved", desc: "Cleared 5 personal challenges proposed by the AI Coach.", status: "unlocked", progress: "5/5" }
                        ].map((badge) => (
                          <div 
                            key={badge.id}
                            className={`p-4 rounded-2xl border transition-all duration-300 flex items-start gap-3.5 ${
                              badge.status === "unlocked"
                                ? "bg-white dark:bg-[#1E2335]/30 border-slate-150 dark:border-[#1A1A1A] hover:border-blue-500/20"
                                : "bg-slate-50/50 dark:bg-[#1A1A1A]/40 border-transparent opacity-65"
                            }`}
                          >
                            <div className={`p-2.5 rounded-xl shrink-0 ${
                              badge.status === "unlocked" ? "bg-blue-500/10 text-blue-500" : "bg-slate-200 dark:bg-[#141414] text-slate-400"
                            }`}>
                              {badge.id === 1 ? <Trophy size={18} /> : 
                               badge.id === 2 ? <ShieldCheck size={18} /> : 
                               badge.id === 3 ? <TrendingUp size={18} /> : 
                               badge.id === 4 ? <Target size={18} /> : 
                               badge.id === 5 ? <Flame size={18} /> : <Star size={18} />}
                            </div>
                            <div className="space-y-1 min-w-0">
                              <div className="flex justify-between items-center gap-2">
                                <h5 className="text-[12.5px] font-bold text-slate-900 dark:text-white truncate">{badge.name}</h5>
                                <span className={`text-[9px] font-black px-1.5 py-0.5 rounded ${
                                  badge.status === "unlocked" ? "bg-emerald-500/10 text-emerald-500" : "bg-slate-100 dark:bg-[#141414] text-slate-400"
                                }`}>
                                  {badge.status === "unlocked" ? "COMPLETED" : badge.progress}
                                </span>
                              </div>
                              <p className="text-[10.5px] text-slate-500 dark:text-slate-400 leading-snug font-medium">{badge.desc}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : filteredPosts.length === 0 ? (
                  <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] text-center py-12 flex flex-col items-center justify-center">
                    <p className="text-slate-500 dark:text-slate-400 text-sm font-bold">No Posts Available</p>
                  </div>
                ) : (
                  filteredPosts.map((post: any) => {
                    const author = getPostUser(post);
                    const isLiked = likedPosts[post.id] || false;
                    const isCommentsOpen = expandedComments[post.id] || false;
                    const currentCommentsCount = (() => {
                      if (commentsCounts[post.id] !== undefined) {
                        return commentsCounts[post.id];
                      }
                      const localCommentCounts = JSON.parse(localStorage.getItem("fialgo_local_comment_counts") || "{}");
                      const storedOverride = localCommentCounts[post.id];
                      return storedOverride !== undefined ? storedOverride : (post.comment_count ?? post.comments_count ?? 0);
                    })();
                    
                    return (
                      <div 
                        key={post.id} 
                        className="p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] flex flex-col gap-5"
                      >
                        {/* Post Header */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <img 
                              src={author.avatar} 
                              alt={author.name} 
                              className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-750 shadow-sm" 
                            />
                            <div>
                              <p className="text-[14px] font-bold text-slate-900 dark:text-white flex items-center gap-1.5 leading-none">
                                {author.name}
                                <CheckCircle2 size={14} className="text-blue-500 fill-blue-500 text-white dark:text-[#1A1A1C] shrink-0" />
                              </p>
                              <p className="text-[12px] text-slate-500 mt-0.5">@{author.username}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {post.user_id !== profile?.id && (
                              <button 
                                onClick={() => toggleFollowUser(post.user_id, author.name)}
                                className="text-[12px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-500/10 px-3 py-1.5 rounded-[10px] hover:bg-blue-100 dark:hover:bg-blue-500/20 transition-colors"
                              >
                                {followedUsers[post.user_id] ? "Following" : "Follow"}
                              </button>
                            )}
                            <button className="text-[12px] font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-[#222] px-3 py-1.5 rounded-[10px] hover:bg-slate-200 dark:hover:bg-[#333] transition-colors">
                              Channel
                            </button>
                            {/* Three-dots dropdown */}
                            <div className="relative">
                              <button 
                                onClick={() => setOpenDropdownId(openDropdownId === post.id ? null : post.id)}
                                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors ml-1 p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800/60"
                              >
                                <MoreHorizontal size={18} />
                              </button>
                              {openDropdownId === post.id && (
                                <>
                                  <div className="fixed inset-0 z-10" onClick={() => setOpenDropdownId(null)} />
                                  <div className="absolute right-0 mt-2 w-36 rounded-2xl bg-white dark:bg-[#1C2031] border border-slate-250 dark:border-slate-850 shadow-xl z-20 py-1.5 text-left font-sans animate-in fade-in slide-in-from-top-1 duration-150">
                                    {post.user_id === profile?.id ? (
                                      <>
                                        <button 
                                          onClick={() => {
                                            setOpenDropdownId(null);
                                            setEditPost(post);
                                          }}
                                          className="w-full px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#252C42] hover:text-blue-500 text-left transition-colors"
                                        >
                                          Edit Post
                                        </button>
                                        <button 
                                          onClick={() => {
                                            setOpenDropdownId(null);
                                            handleDeletePost(post.id);
                                          }}
                                          className="w-full px-4 py-2 text-xs font-bold text-rose-500 hover:bg-slate-50 dark:hover:bg-[#252C42] text-left transition-colors"
                                        >
                                          Delete Post
                                        </button>
                                      </>
                                    ) : (
                                      <button 
                                        onClick={() => {
                                          setOpenDropdownId(null);
                                          toast.success("Post reported successfully!");
                                        }}
                                        className="w-full px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#252C42] hover:text-rose-500 text-left transition-colors"
                                      >
                                        Report Post
                                      </button>
                                    )}
                                    <button 
                                      onClick={() => {
                                        setOpenDropdownId(null);
                                        navigator.clipboard.writeText(window.location.origin + "/user/" + (post.profiles?.username || ""));
                                        toast.success("Profile link copied!");
                                      }}
                                      className="w-full px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#252C42] text-left transition-colors"
                                    >
                                      Copy Link
                                    </button>
                                  </div>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Post Media (Images Collage / Single Image / Video) */}
                        {post.media_type === 'video' ? (
                          <div className="relative rounded-xl overflow-hidden bg-[#1A1A1A] border border-slate-100 dark:border-slate-850 aspect-video flex items-center justify-center group/video">
                            <video
                              src={post.media_url}
                              controls
                              className="w-full h-full object-cover"
                              poster="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop"
                            />
                          </div>
                        ) : post.images && post.images.length >= 4 ? (
                          <div className="rounded-xl overflow-hidden border border-slate-100 dark:border-[#1A1A1A] shadow-sm">
                            <div className="grid grid-cols-2 gap-1 h-[300px]">
                               <div className="col-span-1 h-full cursor-pointer hover:opacity-95 transition-opacity" onClick={() => setLightboxImage(post.images[0])}>
                                   <img src={post.images[0]} className="w-full h-full object-cover" alt="Gold Chart" />
                               </div>
                               <div className="col-span-1 flex flex-col gap-1 h-full">
                                   <img src={post.images[1]} className="w-full h-[148px] object-cover cursor-pointer hover:opacity-95 transition-opacity" onClick={() => setLightboxImage(post.images[1])} alt="Chart close up" />
                                   <div className="flex gap-1 flex-1">
                                       <img src={post.images[2]} className="w-1/2 h-full object-cover cursor-pointer hover:opacity-95 transition-opacity" onClick={() => setLightboxImage(post.images[2])} alt="Stock Numbers" />
                                       <div className="w-1/2 relative cursor-pointer hover:opacity-95 transition-opacity" onClick={() => setLightboxImage(post.images[3])}>
                                            <img src={post.images[3]} className="w-full h-full object-cover" alt="Chart zoom" />
                                            {post.images.length > 4 && (
                                                <div className="absolute inset-0 bg-black/45 flex items-center justify-center text-white font-bold text-lg backdrop-blur-[1.5px]">
                                                    +{post.images.length - 4}
                                                </div>
                                            )}
                                       </div>
                                   </div>
                               </div>
                            </div>
                          </div>
                        ) : (
                          post.media_url && post.post_type !== 'poll' && post.media_type !== 'poll' && (
                            <div className="rounded-xl overflow-hidden border border-slate-100 dark:border-slate-855 bg-slate-50 dark:bg-[#1A1A1A]/30 flex items-center justify-center">
                              <img 
                                src={post.media_url} 
                                alt="Post media" 
                                className="w-full h-auto max-h-[480px] object-contain cursor-pointer hover:opacity-98 transition-all" 
                                onClick={() => setLightboxImage(post.media_url)}
                              />
                            </div>
                          )
                        )}

                        {/* Poll Rendering */}
                        {post.post_type === 'poll' && (
                          <PollBlock 
                            post={post} 
                            currentUserId={profile?.id ?? ""} 
                            onVoteSuccess={fetchProfileAndData} 
                          />
                        )}

                        {/* Content */}
                        <p className="text-[13px] text-slate-600 dark:text-slate-355 leading-relaxed font-medium">
                          {post.content}
                          <button className="font-bold text-slate-900 dark:text-white ml-1.5 hover:underline">read more</button>
                        </p>

                        {/* Post Tags */}
                        {post.tags && post.tags.length > 0 && (
                          <div className="flex flex-wrap gap-2.5 mt-0.5">
                            {post.tags.map((tag: string) => (
                              <span key={tag} className="text-[12px] font-bold text-blue-500 cursor-pointer hover:underline">#{tag}</span>
                            ))}
                          </div>
                        )}

                        {/* Actions Footer */}
                        <div className="flex items-center justify-between pt-4 border-t border-slate-200/60 dark:border-slate-800/80 select-none text-slate-455 dark:text-slate-500 text-xs">
                          <div className="flex items-center gap-6">
                            <button onClick={() => handleLikePost(post.id)} className="flex items-center gap-2 group hover:text-rose-500 transition-colors">
                              <Heart size={18} className={`group-hover:scale-110 transition-transform duration-300 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                              <span className="font-extrabold text-slate-700 dark:text-slate-300">{formatCount(post.likes_count || 0, likesOffsets[post.id] || 0)}</span>
                            </button>
                            <button 
                              onClick={() => setExpandedComments(prev => ({ ...prev, [post.id]: !prev[post.id] }))}
                              className={`flex items-center gap-2 transition-colors group ${isCommentsOpen ? 'text-blue-500' : 'hover:text-blue-500'}`}
                            >
                              <MessageCircle size={18} className="group-hover:scale-110 transition-transform duration-300" />
                              <span className="font-extrabold text-slate-700 dark:text-slate-300">{currentCommentsCount}</span>
                            </button>
                          </div>
                          <button className="text-blue-555 hover:text-blue-600 transition-colors group">
                            <Bookmark size={18} className={`group-hover:scale-110 transition-transform duration-300 ${post.bookmarked ? 'fill-blue-500 text-blue-500' : ''}`} />
                          </button>
                        </div>

                        {/* Real-time centered Comment Modal Dialog */}
                        <CommentModal 
                          isOpen={isCommentsOpen}
                          onClose={() => setExpandedComments(prev => ({ ...prev, [post.id]: false }))}
                          postId={post.id}
                          currentUserId={profile?.id ?? ""}
                          post={post}
                          onCommentsCountChange={(newCount) => {
                            setCommentsCounts(prev => ({ ...prev, [post.id]: newCount }));
                          }}
                        />
                      </div>
                    );
                  })
                )}
              </div>

            </div>

          </div>
          
          {/* --- COLUMN 3: RIGHT SIDEBAR (col-span-3) --- */}
          {/* All outer sidebar panels aligned to rounded-3xl outer cards with clean borders */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* A. Suggested Traders Widget */}
            <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336]">
              <div className="flex items-center justify-between mb-5">
                <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck size={16} className="text-emerald-500 shrink-0" />
                  <span>Suggested Traders</span>
                </h3>
                <span className="text-[11px] font-bold text-blue-500 hover:underline cursor-pointer">View all</span>
              </div>

              <div className="flex flex-col gap-5">
                {suggestedTraders.length === 0 ? (
                  <p className="text-[11px] font-semibold text-slate-400 text-center py-2">No suggested traders available</p>
                ) : (
                  suggestedTraders.map((person) => {
                    const isFollowing = followedUsers[person.id] || false;
                    const displayName = person.display_name || person.username || "Trader";
                    const displayAvatar = person.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${displayName}`;
                    const displayWinrate = person.win_rate ? `${person.win_rate}% Win Rate` : "Active Trader";
                    const displayRole = person.bio ? (person.bio.length > 30 ? person.bio.substring(0, 30) + "..." : person.bio) : "Tradifive Member";

                    return (
                      <div key={person.id} className="flex items-center justify-between gap-3 group">
                        <div className="flex items-center gap-3 min-w-0">
                          <Link to={`/user/${person.username || ""}`} className="shrink-0 hover:opacity-85 transition-opacity duration-300">
                            <img src={displayAvatar} alt={displayName} className="w-10 h-10 rounded-full border border-slate-200/50 dark:border-slate-700 object-cover bg-slate-100" />
                          </Link>
                          <div className="min-w-0">
                            <Link to={`/user/${person.username || ""}`}>
                              <h4 className="font-bold text-slate-900 dark:text-white text-[13px] leading-tight hover:text-blue-600 cursor-pointer truncate transition-colors">{displayName}</h4>
                            </Link>
                            <p className="text-slate-455 dark:text-slate-455 text-[10.5px] leading-none mt-1 truncate font-semibold">{displayWinrate}</p>
                            <p className="text-slate-400 dark:text-slate-500 text-[10.5px] leading-none mt-1.5 truncate font-semibold">{displayRole}</p>
                          </div>
                        </div>

                        {/* Follow Button */}
                        <button 
                          onClick={() => toggleFollowUser(person.id, displayName)}
                          className={`shrink-0 flex items-center justify-center px-4 py-2.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider transition-all duration-300 border-2 active:scale-95 ${
                            isFollowing 
                              ? 'bg-gradient-to-b from-[#F4F4F4]/50 to-[#FFFFFF]/60 dark:from-[#252528]/40 dark:to-[#1A1A1C]/50 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700' 
                              : 'bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] text-[#393939] dark:text-[#E2E8F0] border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336]'
                          }`}
                        >
                          {isFollowing ? 'Following' : 'Follow'}
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* B. Trading Streak Widget — Real Data */}
            <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] flex flex-col gap-4.5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60 mb-1">
                <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Flame size={16} className="text-orange-500 fill-orange-500/10" />
                  <span>Trading Streak</span>
                </h3>
                <span className="text-[14px] font-bold text-orange-500 leading-none">{streakVal}</span>
              </div>

              <div className="flex justify-between text-xs font-semibold text-slate-455">
                <span>Current Streak</span>
                <span>Best: <strong className="text-slate-900 dark:text-white font-extrabold">{bestStreak} Day{bestStreak !== 1 ? 's' : ''}</strong></span>
              </div>

              {/* Day Dot indicators from real trade data (last 15 days) */}
              <div className="flex items-center justify-between gap-1.5 py-1">
                {(streakDots.length > 0 ? streakDots : Array.from({length: 15}, () => ({date: '', status: 'gray' as const}))).map((dot, idx) => (
                  <span 
                    key={idx}
                    title={dot.date}
                    className={`w-2.5 h-2.5 rounded-full block border border-white/5 shadow-sm ${
                      dot.status === 'green' ? 'bg-[#10b981]' : (dot.status === 'red' ? 'bg-[#ef4444]' : 'bg-slate-200 dark:bg-[#141414]')
                    }`} 
                  />
                ))}
              </div>

              <div className="flex justify-between text-[9px] text-slate-455 font-bold uppercase tracking-widest leading-none">
                <span>{streakDots.length > 0 ? (() => { const d = new Date(streakDots[0].date); return isNaN(d.getTime()) ? '' : d.toLocaleDateString('en-US', {day: 'numeric', month: 'short'}); })() : ''}</span>
                <span>Today</span>
              </div>
            </div>

            {/* C. Performance Calendar Widget — Real Data */}
            <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] flex flex-col gap-4.5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60 mb-1">
                <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Calendar size={15} className="text-blue-500" />
                  <span>Calendar</span>
                </h3>
                {/* Month Navigation */}
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setCalendarMonth(prev => { const d = new Date(prev); d.setMonth(d.getMonth() - 1); return d; })}
                    className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-400 hover:text-slate-700 dark:hover:text-white"
                  >
                    <ChevronDown size={13} className="rotate-90" />
                  </button>
                  <span className="flex items-center justify-between gap-2 px-4 py-2 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] text-[#393939] dark:text-[#E2E8F0] text-[11px] font-extrabold uppercase tracking-wider transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] cursor-default select-none min-w-[105px]">
                    <span>{calendarMonth.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</span>
                  </span>
                  <button 
                    onClick={() => setCalendarMonth(prev => { const d = new Date(prev); d.setMonth(d.getMonth() + 1); return d; })}
                    className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-400 hover:text-slate-700 dark:hover:text-white"
                  >
                    <ChevronDown size={13} className="-rotate-90" />
                  </button>
                </div>
              </div>

              {/* Dynamic Heatmap Grid Calendar */}
              <div className="space-y-2">
                <div className="grid grid-cols-7 gap-1.5 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(d => <span key={d}>{d.substring(0,1)}</span>)}
                </div>

                <div className="grid grid-cols-7 gap-1.5">
                  {(() => {
                    const year = calendarMonth.getFullYear();
                    const month = calendarMonth.getMonth();
                    const firstDay = new Date(year, month, 1);
                    const lastDay = new Date(year, month + 1, 0);
                    const startOffset = (firstDay.getDay() + 6) % 7; // Monday=0
                    const cells: React.ReactNode[] = [];
                    
                    // Empty cells for days before the 1st
                    for (let i = 0; i < startOffset; i++) {
                      cells.push(<span key={`empty-${i}`} className="h-6" />);
                    }
                    
                    const todayStr = (() => { const t = new Date(); return `${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,'0')}-${String(t.getDate()).padStart(2,'0')}`; })();
                    
                    for (let day = 1; day <= lastDay.getDate(); day++) {
                      const key = `${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
                      const status = calendarDayMap[key]; // 'green' | 'red' | undefined
                      const isToday = key === todayStr;
                      
                      let cellClass = "aspect-square w-full rounded-[4px] transition-all ";
                      if (status === 'green') {
                        cellClass += "bg-[#10b981]/50 dark:bg-[#10b981]/80 shadow-sm";
                      } else if (status === 'red') {
                        cellClass += "bg-[#ef4444]/30 dark:bg-[#ef4444]/15 border-[#ef4444]/20 shadow-sm";
                      } else {
                        cellClass += "bg-slate-100 dark:bg-[#1A1A1A] border-slate-200/40 dark:border-slate-800";
                      }
                      if (isToday) {
                        cellClass += " ring-2 ring-blue-500/50 ring-offset-1 dark:ring-offset-[#1A1A1C]";
                      }
                      
                      cells.push(
                        <span 
                          key={key} 
                          className={cellClass}
                          title={`${key}${status === 'green' ? ' — Profitable' : status === 'red' ? ' — Loss' : ' — No Trade'}`}
                        />
                      );
                    }
                    
                    return cells;
                  })()}
                </div>
              </div>

              {/* Legend details row */}
              <div className="flex items-center justify-between text-[9px] text-slate-455 dark:text-slate-500 font-extrabold uppercase tracking-wider pt-2.5 border-t border-slate-200/60 dark:border-slate-850">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-[#10b981]" /> Profitable
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-[#ef4444]" /> Loss
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-slate-200 dark:bg-[#141414]" /> No Trade
                </span>
              </div>
            </div>

            {/* D. Achievements Widget with gorgeous premium inline SVG medals */}
            <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#141414] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#333336] flex flex-col gap-4.5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60 mb-1">
                <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Star size={15} className="text-blue-500" />
                  <span>Achievements</span>
                </h3>
                <span className="text-[11px] font-bold text-blue-500 hover:underline cursor-pointer">View all</span>
              </div>

              <div className="grid grid-cols-3 gap-2.5 text-center text-[9px] font-bold text-slate-500 dark:text-slate-400 select-none">
                
                {/* 1. 100 Winning Trades Medallion */}
                <div className="flex flex-col items-center justify-center gap-2.5 py-4 px-3 rounded-2xl bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] border-2 border-white dark:border-[#1A1A1A] shadow-[0_2px_4px_rgba(0,0,0,0.03),_0_0_0_1px_#E7E7E7] dark:shadow-[0_2px_4px_rgba(0,0,0,0.2),_0_0_0_1px_#333336] hover:scale-103 transition-transform duration-350">
                  <svg className="w-12 h-12 shrink-0 select-none" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="45" r="30" fill="url(#goldGlow)" opacity="0.15" />
                    <path d="M35 50 L25 85 L50 72 L75 85 L65 50 Z" fill="url(#goldRibbon)" stroke="#F59E0B" strokeWidth="1.5" />
                    <polygon points="50,15 80,25 80,55 50,80 20,55 20,25" fill="url(#goldShield)" stroke="#D97706" strokeWidth="2.5" strokeLinejoin="round" />
                    <polygon points="50,20 74,28 74,52 50,72 26,52 26,28" fill="none" stroke="#FBBF24" strokeWidth="1" strokeLinejoin="round" />
                    <polygon points="50,28 54,38 65,38 56,44 59,55 50,48 41,55 44,44 35,38 46,38" fill="#FBBF24" />
                    <circle cx="50" cy="52" r="14" fill="#78350F" stroke="#FBBF24" strokeWidth="1.5" />
                    <text x="50" y="56" fill="#FBBF24" fontSize="11" fontWeight="900" textAnchor="middle" fontFamily="sans-serif">100</text>
                    <defs>
                      <radialGradient id="goldGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#F59E0B" />
                        <stop offset="100%" stopColor="#F59E0B" stopOpacity="0" />
                      </radialGradient>
                      <linearGradient id="goldShield" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#FBBF24" />
                        <stop offset="50%" stopColor="#F59E0B" />
                        <stop offset="100%" stopColor="#D97706" />
                      </linearGradient>
                      <linearGradient id="goldRibbon" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#EF4444" />
                        <stop offset="100%" stopColor="#B91C1C" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <span className="leading-tight block uppercase tracking-wider text-[8px] font-bold text-amber-600 dark:text-amber-500 text-center">
                    100<br />Winning<br />Trades
                  </span>
                </div>

                {/* 2. 10 Days Streak Medallion */}
                <div className="flex flex-col items-center justify-center gap-2.5 py-4 px-3 rounded-2xl bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] border-2 border-white dark:border-[#1A1A1A] shadow-[0_2px_4px_rgba(0,0,0,0.03),_0_0_0_1px_#E7E7E7] dark:shadow-[0_2px_4px_rgba(0,0,0,0.2),_0_0_0_1px_#333336] hover:scale-103 transition-transform duration-350">
                  <svg className="w-12 h-12 shrink-0 select-none" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="45" r="30" fill="url(#purpleGlow)" opacity="0.15" />
                    <path d="M35 50 L25 85 L50 72 L75 85 L65 50 Z" fill="url(#purpleRibbon)" stroke="#A855F7" strokeWidth="1.5" />
                    <polygon points="50,15 80,25 80,55 50,80 20,55 20,25" fill="url(#purpleShield)" stroke="#7E22CE" strokeWidth="2.5" strokeLinejoin="round" />
                    <polygon points="50,20 74,28 74,52 50,72 26,52 26,28" fill="none" stroke="#C084FC" strokeWidth="1" strokeLinejoin="round" />
                    <path d="M50,28 C54,34 52,38 54,42 C51,44 48,42 46,40 C44,45 47,48 50,48 C53,48 56,44 54,37" fill="#F59E0B" />
                    <circle cx="50" cy="52" r="14" fill="#4C1D95" stroke="#C084FC" strokeWidth="1.5" />
                    <text x="50" y="56" fill="#C084FC" fontSize="11" fontWeight="900" textAnchor="middle" fontFamily="sans-serif">10</text>
                    <defs>
                      <radialGradient id="purpleGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#8B5CF6" />
                        <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" />
                      </radialGradient>
                      <linearGradient id="purpleShield" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#C084FC" />
                        <stop offset="50%" stopColor="#8B5CF6" />
                        <stop offset="100%" stopColor="#6D28D9" />
                      </linearGradient>
                      <linearGradient id="purpleRibbon" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#EC4899" />
                        <stop offset="100%" stopColor="#BE185D" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <span className="leading-tight block uppercase tracking-wider text-[8px] font-bold text-purple-655 dark:text-purple-400 text-center">
                    10 Days<br />Streak
                  </span>
                </div>

                {/* 3. 2K Trades Executed Medallion */}
                <div className="flex flex-col items-center justify-center gap-2.5 py-4 px-3 rounded-2xl bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] border-2 border-white dark:border-[#1A1A1A] shadow-[0_2px_4px_rgba(0,0,0,0.03),_0_0_0_1px_#E7E7E7] dark:shadow-[0_2px_4px_rgba(0,0,0,0.2),_0_0_0_1px_#333336] hover:scale-103 transition-transform duration-350">
                  <svg className="w-12 h-12 shrink-0 select-none" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="45" r="30" fill="url(#blueGlow)" opacity="0.15" />
                    <path d="M35 50 L25 85 L50 72 L75 85 L65 50 Z" fill="url(#blueRibbon)" stroke="#3B82F6" strokeWidth="1.5" />
                    <polygon points="50,15 80,25 80,55 50,80 20,55 20,25" fill="url(#blueShield)" stroke="#1D4ED8" strokeWidth="2.5" strokeLinejoin="round" />
                    <polygon points="50,20 74,28 74,52 50,72 26,52 26,28" fill="none" stroke="#60A5FA" strokeWidth="1" strokeLinejoin="round" />
                    <circle cx="50" cy="38" r="8" fill="#FBBF24" />
                    <path d="M42,48 L58,48 L55,42 L45,42 Z" fill="#FBBF24" />
                    <circle cx="50" cy="52" r="14" fill="#1E3A8A" stroke="#60A5FA" strokeWidth="1.5" />
                    <text x="50" y="55" fill="#60A5FA" fontSize="9" fontWeight="900" textAnchor="middle" fontFamily="sans-serif">2K</text>
                    <defs>
                      <radialGradient id="blueGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#3B82F6" />
                        <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
                      </radialGradient>
                      <linearGradient id="blueShield" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#60A5FA" />
                        <stop offset="50%" stopColor="#3B82F6" />
                        <stop offset="100%" stopColor="#1D4ED8" />
                      </linearGradient>
                      <linearGradient id="blueRibbon" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#10B981" />
                        <stop offset="100%" stopColor="#047857" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <span className="leading-tight block uppercase tracking-wider text-[8px] font-bold text-blue-600 dark:text-blue-400 text-center">
                    2K<br />Trades<br />Executed
                  </span>
                </div>

              </div>
            </div>

          </div>

        </div>
      </div>

      <CreatePostModal 
        isOpen={editPost !== null} 
        onClose={() => setEditPost(null)} 
        onSuccess={() => { setEditPost(null); fetchProfileAndData(); }} 
        userId={profile?.id ?? ""} 
        mode="edit"
        postId={editPost?.id}
        initialContent={editPost?.content}
        initialTags={editPost?.tags || []}
        initialMediaUrl={editPost?.media_url}
        initialMediaType={editPost?.media_type as any}
      />
      {/* Real-time Image Zoom Lightbox Overlay */}
      {lightboxImage && createPortal(
        <div 
          className="fixed inset-0 z-[99999] bg-slate-955/95 backdrop-blur-md flex items-center justify-center p-4 cursor-zoom-out animate-in fade-in duration-200"
          onClick={() => setLightboxImage(null)}
        >
          <button 
            onClick={() => setLightboxImage(null)}
            className="absolute top-6 right-6 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center border border-white/10 transition-colors shadow-lg z-50 cursor-pointer"
          >
            <X size={20} />
          </button>
          <motion.img 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.2 }}
            src={lightboxImage} 
            alt="Full size setup chart" 
            onClick={(e) => e.stopPropagation()}
            className="max-w-full max-h-[90vh] object-contain rounded-2xl shadow-2xl border border-white/10 select-none cursor-default"
          />
        </div>,
        document.body
      )}
    </DashboardLayout>
    </>
  );
}

// Get post user helper function
function getPostUser(post: any) {
  if (post.profiles) {
    return {
      name: post.profiles.display_name || post.profiles.username || "User",
      username: post.profiles.username || "user",
      avatar: post.profiles.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(post.profiles.display_name || 'User')}`
    };
  }
  return {
    name: "Guest Trader",
    username: "guest_trader",
    avatar: "https://api.dicebear.com/7.x/adventurer/svg?seed=guest"
  };
}
