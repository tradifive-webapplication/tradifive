import React, { useState, useRef } from "react";
import { Search, Plus, X, MoreHorizontal, Heart, MessageCircle, Bookmark, UserPlus, UserCheck, Flame, ShieldCheck, TrendingUp, Layers, Eye, Calendar, Globe, Sliders, PlayCircle, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import CommentModal from "@/components/CommentModal";
import { FeedPost } from "@/hooks/useHomeData";


export default function FeedCard({ 
    feed, 
    currentUserId, 
    followedUsers, 
    onToggleFollow,
    isLiked,
    likes,
    onLike,
    onEdit,
    onDelete,
    onVote,
    onImageClick
}: { 
    feed: FeedPost; 
    currentUserId: string; 
    followedUsers: Record<string, boolean>; 
    onToggleFollow: (id: string, name: string) => void;
    isLiked: boolean;
    likes: number;
    onLike: () => void;
    onEdit?: (feed: FeedPost) => void;
    onDelete?: (postId: string) => void;
    onVote?: (postId: string, updatedMediaUrl: string) => void;
    onImageClick?: (url: string) => void;
}) {
    const authorName = feed.profiles?.full_name || "Anonymous Trader";
    const authorHandle = feed.profiles?.username ? `@${feed.profiles.username}` : "@anonymous";
    const authorAvatar = feed.profiles?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${authorName}`;
    const images = feed.media_urls || [];
    const tags = feed.tags || [];
    const comments = feed.comment_count ?? feed.comments_count ?? 0;
    const bookmarked = feed.bookmark_count ? feed.bookmark_count > 0 : false;

    const [showDropdown, setShowDropdown] = useState(false);
    const [showComments, setShowComments] = useState(false);
    const [focusedImageUrl, setFocusedImageUrl] = useState<string | null>(null);
    const [showHeartAnimation, setShowHeartAnimation] = useState(false);
    const clickTimerRef = useRef<NodeJS.Timeout | null>(null);
    const heartTimeoutRef = useRef<NodeJS.Timeout | null>(null);

    const handleImageInteraction = (url: string, e: React.MouseEvent) => {
        if (e.detail === 1) {
            clickTimerRef.current = setTimeout(() => {
                setFocusedImageUrl(url);
            }, 250);
        } else if (e.detail === 2) {
            if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
            // Trigger heart animation
            if (heartTimeoutRef.current) clearTimeout(heartTimeoutRef.current);
            setShowHeartAnimation(true);
            heartTimeoutRef.current = setTimeout(() => setShowHeartAnimation(false), 900);
            if (!isLiked) {
                onLike();
            }
        }
    };
    const [localCommentsCount, setLocalCommentsCount] = useState<number>(() => {
        const localCommentCounts = JSON.parse(localStorage.getItem("fialgo_local_comment_counts") || "{}");
        const storedOverride = localCommentCounts[feed.id];
        return storedOverride !== undefined ? storedOverride : comments;
    });

    // Vote state
    const votedOptionKey = `tradifive_voted_poll_${feed.id}`;
    const [votedOption, setVotedOption] = useState<number | null>(() => {
        const val = localStorage.getItem(votedOptionKey);
        return val !== null ? Number(val) : null;
    });

    // Parse poll details if applicable
    let pollData: { options: string[]; votes: number[] } | null = null;
    if (feed.post_type === "poll" && feed.media_url) {
        try {
            pollData = JSON.parse(feed.media_url);
        } catch (e) {}
    }

    const handleVoteOption = (index: number) => {
        if (!pollData || votedOption !== null || feed.user_id === currentUserId) return;
        const updatedVotes = [...pollData.votes];
        updatedVotes[index]++;
        const updatedPoll = { ...pollData, votes: updatedVotes };
        
        localStorage.setItem(votedOptionKey, String(index));
        setVotedOption(index);
        
        if (onVote) {
            onVote(feed.id, JSON.stringify(updatedPoll));
        }
    };

    const totalPollVotes = pollData ? pollData.votes.reduce((a, b) => a + b, 0) : 0;
    const hasVotedOrOwns = votedOption !== null || feed.user_id === currentUserId;

    return (
        <div className="p-6 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
                <Link to={`/user/${authorHandle.replace('@', '')}`} className="flex items-center gap-3 hover:opacity-85 transition-opacity group/feedcard">
                    <img src={authorAvatar} alt={authorName} className="w-10 h-10 rounded-full bg-slate-200 object-cover" />
                    <div>
                        <p className="text-[14px] font-bold text-slate-900 dark:text-white leading-tight group-hover/feedcard:text-blue-500 transition-colors">{authorName}</p>
                        <p className="text-[12px] text-slate-500">{authorHandle}</p>
                    </div>
                </Link>
                <div className="flex items-center gap-2">
                    {feed.user_id !== currentUserId && (
                        <button 
                            onClick={() => onToggleFollow(feed.user_id || "", authorName)}
                            className={`text-[12px] font-bold px-3 py-1.5 rounded-[10px] transition-colors ${
                                followedUsers[feed.user_id || ""]
                                    ? "text-slate-655 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700"
                                    : "text-blue-600 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-100 dark:hover:bg-blue-500/20"
                            }`}
                        >
                            {followedUsers[feed.user_id || ""] ? "Following" : "Follow"}
                        </button>
                    )}
                    <button className="text-[12px] font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-[#222] px-3 py-1.5 rounded-[10px] hover:bg-slate-200 dark:hover:bg-[#333] transition-colors">
                        Channel
                    </button>
                    
                    {/* Floating Actions Menu Dropdown */}
                    <div className="relative">
                        <button 
                            onClick={() => setShowDropdown(!showDropdown)}
                            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors ml-2 p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800/60"
                        >
                            <MoreHorizontal size={20} />
                        </button>
                        {showDropdown && (
                            <>
                                <div className="fixed inset-0 z-10" onClick={() => setShowDropdown(false)} />
                                <div className="absolute right-0 mt-2 w-36 rounded-2xl bg-white dark:bg-[#1C2031] border border-slate-250 dark:border-slate-850 shadow-xl z-20 py-1.5 text-left font-sans animate-in fade-in slide-in-from-top-1 duration-150">
                                    {feed.user_id !== currentUserId && (
                                        <button 
                                            onClick={() => {
                                                setShowDropdown(false);
                                                toast.success("Post reported successfully!");
                                            }}
                                            className="w-full px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#252C42] hover:text-rose-500 text-left transition-colors"
                                        >
                                            Report Post
                                        </button>
                                    )}
                                    <button 
                                        onClick={() => {
                                            setShowDropdown(false);
                                            navigator.clipboard.writeText(window.location.origin + "/user/" + (feed.profiles?.username || ""));
                                            toast.success("Profile link copied!");
                                        }}
                                        className="w-full px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#252C42] text-left transition-colors"
                                    >
                                        Copy Profile Link
                                    </button>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>
            
            {/* Media Rendering */}
            {images.length > 0 ? (
                <div className="mb-4 rounded-xl overflow-hidden border border-slate-100 dark:border-[#333] relative select-none">
                    {images.length >= 4 ? (
                        <div className="grid grid-cols-2 gap-1 h-[300px]">
                           <div className="col-span-1 h-full cursor-pointer hover:opacity-95 transition-opacity" onClick={(e) => handleImageInteraction(images[0], e)}>
                               <img src={images[0]} className="w-full h-full object-cover" draggable={false} />
                           </div>
                           <div className="col-span-1 flex flex-col gap-1 h-full">
                               <img src={images[1]} className="w-full h-[148px] object-cover cursor-pointer hover:opacity-95 transition-opacity" onClick={(e) => handleImageInteraction(images[1], e)} draggable={false} />
                               <div className="flex gap-1 flex-1">
                                   <img src={images[2]} className="w-1/2 h-full object-cover cursor-pointer hover:opacity-95 transition-opacity" onClick={(e) => handleImageInteraction(images[2], e)} draggable={false} />
                                   <div className="w-1/2 relative cursor-pointer hover:opacity-95 transition-opacity" onClick={(e) => handleImageInteraction(images[3], e)}>
                                        <img src={images[3]} className="w-full h-full object-cover" draggable={false} />
                                        {images.length > 4 && (
                                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-white font-bold text-xl backdrop-blur-[2px]">
                                                +{images.length - 4}
                                            </div>
                                        )}
                                   </div>
                               </div>
                           </div>
                        </div>
                    ) : (
                        <img 
                            src={images[0]} 
                            className="w-full h-auto max-h-[480px] object-contain bg-slate-50 dark:bg-slate-900/30 flex items-center justify-center cursor-pointer hover:opacity-95 transition-opacity" 
                            onClick={(e) => handleImageInteraction(images[0], e)}
                            alt="Feed Attachment"
                            draggable={false}
                        />
                    )}
                    {/* Instagram-style double-tap heart animation */}
                    <AnimatePresence>
                        {showHeartAnimation && (
                            <motion.div
                                className="absolute inset-0 flex items-center justify-center pointer-events-none z-10"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                transition={{ duration: 0.15 }}
                            >
                                <motion.div
                                    initial={{ scale: 0, opacity: 0 }}
                                    animate={{ scale: [0, 1.3, 1, 1], opacity: [0, 1, 1, 0] }}
                                    transition={{ duration: 0.85, times: [0, 0.25, 0.6, 1], ease: "easeOut" }}
                                >
                                    <Heart size={80} className="text-white fill-white drop-shadow-[0_4px_24px_rgba(239,68,68,0.7)]" style={{ filter: 'drop-shadow(0 0 30px rgba(239,68,68,0.6))' }} />
                                </motion.div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            ) : feed.media_url && feed.media_type !== "poll" ? (
                <div className="mb-4 rounded-xl overflow-hidden border border-slate-100 dark:border-[#333] bg-slate-50 dark:bg-slate-900/30 flex items-center justify-center relative select-none">
                    {feed.media_type === 'video' ? (
                        <video src={feed.media_url} controls className="w-full max-h-[480px] object-contain" />
                    ) : (
                        <img 
                            src={feed.media_url} 
                            className="w-full h-auto max-h-[480px] object-contain cursor-pointer hover:opacity-98 transition-all" 
                            onClick={(e) => handleImageInteraction(feed.media_url!, e)}
                            alt="Feed Attachment"
                            draggable={false}
                        />
                    )}
                    {/* Instagram-style double-tap heart animation */}
                    <AnimatePresence>
                        {showHeartAnimation && (
                            <motion.div
                                className="absolute inset-0 flex items-center justify-center pointer-events-none z-10"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                transition={{ duration: 0.15 }}
                            >
                                <motion.div
                                    initial={{ scale: 0, opacity: 0 }}
                                    animate={{ scale: [0, 1.3, 1, 1], opacity: [0, 1, 1, 0] }}
                                    transition={{ duration: 0.85, times: [0, 0.25, 0.6, 1], ease: "easeOut" }}
                                >
                                    <Heart size={80} className="text-white fill-white drop-shadow-[0_4px_24px_rgba(239,68,68,0.7)]" style={{ filter: 'drop-shadow(0 0 30px rgba(239,68,68,0.6))' }} />
                                </motion.div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            ) : null}

            {/* Poll Rendering */}
            {pollData && (
                <div className="mb-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/30 dark:bg-slate-900/10 space-y-3">
                    {pollData.options.map((opt, idx) => {
                        const votes = pollData!.votes[idx] || 0;
                        const percentage = totalPollVotes > 0 ? Math.round((votes / totalPollVotes) * 100) : 0;
                        
                        return hasVotedOrOwns ? (
                            <div key={idx} className="relative w-full p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-[#0B0D18] overflow-hidden select-none font-semibold text-xs text-slate-800 dark:text-white flex items-center justify-between">
                                <div 
                                    className="absolute left-0 top-0 bottom-0 bg-blue-500/10 dark:bg-blue-500/15 transition-all duration-500" 
                                    style={{ width: `${percentage}%` }}
                                />
                                <span className="relative z-10 flex items-center gap-2 font-bold">
                                    {opt} {votedOption === idx && <span className="text-[10px] text-blue-500 font-extrabold">(Your Vote)</span>}
                                </span>
                                <span className="relative z-10 font-extrabold text-slate-700 dark:text-slate-350">
                                    {percentage}% ({votes})
                                </span>
                            </div>
                        ) : (
                            <button
                                key={idx}
                                onClick={() => handleVoteOption(idx)}
                                className="w-full text-left p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-600 hover:bg-blue-50/10 dark:hover:bg-blue-500/5 transition-all font-semibold text-xs text-slate-700 dark:text-slate-300 hover:text-blue-500 select-none cursor-pointer"
                            >
                                {opt}
                            </button>
                        );
                    })}
                    <div className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500 px-1 pt-1 flex justify-between">
                        <span>Total: {totalPollVotes} vote{totalPollVotes !== 1 ? 's' : ''}</span>
                        {feed.user_id === currentUserId && <span className="text-blue-500">Your Poll</span>}
                    </div>
                </div>
            )}

            {/* Content & Tags */}
            <p className="text-[13px] text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
                {feed.content} <button className="font-bold text-slate-900 dark:text-white ml-1 hover:underline">read more</button>
            </p>
            {tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-5">
                    {tags.map((tag: string) => (
                        <span key={tag} className="text-[12px] font-bold text-blue-500">#{tag}</span>
                    ))}
                </div>
            )}

            {/* Actions Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-[#222]">
                <div className="flex items-center gap-6">
                    <button 
                        onClick={onLike}
                        className={`flex items-center gap-2 transition-colors group ${
                            isLiked ? "text-red-500" : "text-slate-400 hover:text-red-500"
                        }`}
                    >
                        <Heart size={18} className={`group-hover:scale-110 transition-transform ${isLiked ? "fill-current" : ""}`} />
                        <span className="text-[13px] font-bold text-slate-600 dark:text-slate-300">{likes}</span>
                    </button>
                    <button 
                        onClick={() => setShowComments(!showComments)}
                        className={`flex items-center gap-2 transition-colors group ${
                            showComments ? "text-blue-500" : "text-slate-400 hover:text-blue-500"
                        }`}
                    >
                        <MessageCircle size={18} className="group-hover:scale-110 transition-transform" />
                        <span className="text-[13px] font-bold text-slate-600 dark:text-slate-300">{localCommentsCount}</span>
                    </button>
                </div>
                <button className="text-slate-400 hover:text-blue-500 transition-colors group">
                    <Bookmark size={18} className={`group-hover:scale-110 transition-transform ${bookmarked ? 'text-blue-500 fill-current' : ''}`} />
                </button>
            </div>

            {/* Real-time centered Comment Modal Dialog or Full Screen Media Viewer */}
            <CommentModal 
                isOpen={showComments || !!focusedImageUrl}
                onClose={() => { setShowComments(false); setFocusedImageUrl(null); }}
                postId={feed.id}
                currentUserId={currentUserId}
                post={feed}
                onCommentsCountChange={(newCount) => setLocalCommentsCount(newCount)}
                focusedImageUrl={focusedImageUrl}
            />
        </div>
    );
}
