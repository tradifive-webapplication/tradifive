import React from "react";
import { useNavigate } from "react-router-dom";
import tradifiveLogo from "@/assets/tradifive-login-logo.png";
import { Ic } from "./Ic";

export default function PublicFooter() {
  const navigate = useNavigate();
  return (
    <footer style={{ padding: "100px 28px 60px", background: "#000", position: "relative", overflow: "hidden" }}>
      {/* Waycode-style Atmospheric Fade */}
      <div style={{ position: "absolute", top: 0, left: 0, width: "100%", height: 300, background: "linear-gradient(to bottom, rgba(255, 255, 255, 0.05) 0%, transparent 100%)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: 0, left: "50%", transform: "translateX(-50%)", width: "80%", height: 1, background: "linear-gradient(to right, transparent, rgba(255, 255, 255, 0.2), transparent)" }} />

      <div style={{ maxWidth: 1100, margin: "0 auto", position: "relative" }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr repeat(4, 1fr)", gap: 40 }} className="footer-grid-mobile">
          {/* Brand Column */}
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <img src={tradifiveLogo} style={{ height: 34, width: "auto" }} alt="TradiFive" />
            </div>
            <p style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", lineHeight: 1.6, fontWeight: 500, maxWidth: 220 }}>
              Where institutional-grade technical work lives. Built for the modern trader.
            </p>
            <a href="mailto:hello@tradifive.com" style={{ fontSize: 13, color: "#cccccc", textDecoration: "none", fontWeight: 600 }}>hello@tradifive.com</a>
          </div>

          {/* Link Columns */}
          {[
            { title: "Platform", links: ["Algorithms", "Risk Guard", "Auto-Journal", "MT5 Bridge", "Discover", "Channels"] },
            { title: "Community", links: ["Pulse Feeds", "Signal Channels", "Competitions", "Wall of Fame"] },
            { title: "Resources", links: ["Documentation", "API Docs", "Download App", "Support"] },
            { title: "Legal", links: ["Privacy Policy", "Terms of Service", "Risk Disclosure"] }
          ].map((col, i) => (
            <div key={i}>
              <h4 style={{ fontSize: 12, fontWeight: 800, color: "rgba(255,255,255,0.3)", marginBottom: 20, textTransform: "uppercase", letterSpacing: "1px" }}>{col.title}</h4>
              <ul style={{ listStyle: "none", padding: 0, display: "flex", flexDirection: "column", gap: 12 }}>
                {col.links.map(l => (
                  <li key={l}><a href="#" style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", textDecoration: "none", transition: "color 0.3s" }} className="hover:text-white">{l}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 60, paddingTop: 32, borderTop: "1px solid rgba(255,255,255,0.05)", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 20 }}>
          <div style={{ display: "flex", gap: 20 }}>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.2)", fontWeight: 600 }}>© 2025 TradiFive. Built for traders, by traders tired of learning alone.</p>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.2)", fontWeight: 600 }}>Made with <span style={{ color: "rgba(255,255,255,0.4)" }}>♥</span> for the world by TradiFive</p>
            <div style={{ display: "flex", gap: 16 }}>
              {["twitter", "github", "linkedin"].map(icon => (
                <a key={icon} href="#" style={{ transition: "opacity 0.3s" }} className="hover:opacity-100">
                  <Ic n={icon} s={16} c="rgba(255,255,255,0.3)" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
