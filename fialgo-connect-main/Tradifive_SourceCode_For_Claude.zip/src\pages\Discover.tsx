import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import DashboardLayout from "@/components/DashboardLayout";
import { Search, Lock, UserPlus, Compass } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useDiscoverData } from "@/hooks/useDiscoverData";
import { motion, AnimatePresence } from "framer-motion";

// --- STATIC CONSTANTS ---
const CATEGORIES = ["All", "Mentors", "Channels", "Traders", "People", "Competitions"];
const PLACEHOLDER_NAMES = ['new trader', 'guest trader', 'demo trader', 'trader', 'guest'];

// Curated high-fidelity cover image assets to simulate Discord's layout
const CARD_COVERS = [
    "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800", // colorful wave (like Midjourney)
    "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&q=80&w=800", // neon graphic (like Marvel Rivals)
    "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=800", // anime vibe (like Star Rail)
    "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800", // gaming zone (like Valorant)
    "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800", // network grids (like Helldivers)
    "https://images.unsplash.com/photo-1642543492481-44e81e3914a7?auto=format&fit=crop&q=80&w=800", // abstract 3d (like Wuthering Waves)
    "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=800", // futuristic dashboard
    "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&q=80&w=800"  // cool blue charts
];

// Verified Badge matching Discord's green badge exactly
const VerifiedBadge = () => (
    <span className="inline-flex items-center justify-center bg-[#23A55A] text-white rounded-full w-4 h-4 shrink-0 select-none">
        <svg viewBox="0 0 12 12" className="w-2.5 h-2.5 fill-current">
            <path d="M4.5 9L1.5 6l1.2-1.2L4.5 6.6l4.8-4.8L10.5 3z" />
        </svg>
    </span>
);

export default function Discover() {
    const navigate = useNavigate();
    const [user, setUser] = useState<any>(null);
    const [authChecked, setAuthChecked] = useState(false);
    const [activeTab, setActiveTab] = useState("All");
    const [searchQuery, setSearchQuery] = useState("");

    useEffect(() => {
        const checkUser = async () => {
            const { data: { session } } = await supabase.auth.getSession();
            if (!session?.user) {
                navigate("/login");
            } else {
                setUser(session.user);
                setAuthChecked(true);
            }
        };
        checkUser();
    }, [navigate]);

    const { mentors, channels, traders, people, searchResults, loading, searching } = useDiscoverData(user?.id ?? "", searchQuery);

    function DiscoverSkeleton() {
        return (
            <div className="w-full space-y-8 select-none animate-pulse">
                {/* Top Nav skeleton */}
                <div className="h-16 w-full border-b border-slate-200/50 dark:border-white/5 bg-slate-500/10 flex items-center justify-between px-6">
                    <div className="h-6 w-32 bg-slate-800 rounded-md" />
                    <div className="h-8 w-64 bg-slate-800 rounded-md" />
                </div>
                {/* Hero skeleton */}
                <div className="w-full h-56 bg-slate-200 dark:bg-slate-800/40" />
                {/* Cards skeleton */}
                <div className="w-full max-w-7xl mx-auto px-8 md:px-16 lg:px-20 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="h-80 bg-slate-200 dark:bg-slate-800/40 rounded-xl" />
                    ))}
                </div>
            </div>
        );
    }

    if (!authChecked || loading) {
        return (
            <DashboardLayout breadcrumbs={[{ label: "Discover", path: "/discover" }]} noPadding={true} noScroll={true}>
                <div className="h-full overflow-y-auto w-full scrollbar-hide">
                    <DiscoverSkeleton />
                </div>
            </DashboardLayout>
        );
    }

    const finalMentors = mentors.map(m => ({
        id: m.id,
        name: m.full_name || m.username || "Active Mentor",
        title: m.trading_style || "Professional Mentor",
        avatar: m.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${m.full_name || 'M'}`,
        onlineCount: m.total_trades ? Math.floor(m.total_trades * 4.2 * 100) : 1240,
        memberCount: m.total_trades ? Math.floor(m.total_trades * 12.5 * 100) : 4850,
        verified: m.is_verified || false,
        tags: [m.preferred_market, m.trading_style].filter(Boolean) as string[]
    }));

    const finalChannels = channels.map(c => ({
        id: c.id,
        name: c.name,
        onlineCount: c.member_count !== null ? Math.floor(c.member_count * 0.28) : 850,
        memberCount: c.member_count !== null ? c.member_count : 2400,
        description: c.description || "Official Tradifive communication channel.",
        icon: c.icon || "📢",
        locked: c.channel_type === "private" || c.channel_type === "premium"
    }));

    const finalTraders = traders
        .filter(t => {
            const name = (t.full_name || t.username || '').trim().toLowerCase();
            return name.length > 0 && !PLACEHOLDER_NAMES.includes(name);
        })
        .map((t, idx) => ({
            id: t.id,
            name: t.full_name || t.username || "Active Trader",
            avatar: t.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${t.full_name || 'T'}`,
            winRate: t.win_rate ? `${t.win_rate}%` : "—",
            profit: t.roi_all_time ? `${t.roi_all_time >= 0 ? '+' : ''}${t.roi_all_time}%` : "—",
            onlineCount: Math.floor(Math.random() * 500) + 120,
            memberCount: Math.floor(Math.random() * 2000) + 1500,
            rank: idx + 1
        }));

    const finalPeople = people
        .filter(p => {
            const name = (p.full_name || p.username || '').trim().toLowerCase();
            return name.length > 0 && !PLACEHOLDER_NAMES.includes(name);
        })
        .map((p) => ({
            id: p.id,
            name: p.full_name || p.username || "Active User",
            handle: p.username ? `@${p.username}` : "@user",
            avatar: p.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${p.full_name || 'U'}`,
            onlineCount: Math.floor(Math.random() * 300) + 50,
            memberCount: Math.floor(Math.random() * 1500) + 1000,
            mutual: Math.floor(Math.random() * 20)
        }));

    return (
        <DashboardLayout breadcrumbs={[{ label: "Discover", path: "/discover" }]} noPadding={true} noScroll={true}>
            <div className="w-full font-sans pb-32 bg-white dark:bg-[#313338] text-slate-800 dark:text-slate-100 h-full overflow-y-auto relative scrollbar-hide">
                
                {/* Unified Gradient Wrapper for Nav & Hero */}
                <div className="w-full bg-gradient-to-br from-[#ECEDF2] to-[#E2E4FB] dark:from-[#2B2D31] dark:to-[#2A2B3E] relative overflow-hidden">
                    {/* Faded Discord Blurple Blobs (Unified) */}
                    <div className="absolute inset-0 pointer-events-none z-0">
                        {/* Adjusted left blob to match right blob's awesome positioning */}
                        <div className="absolute top-[20%] -left-[10%] w-[50%] h-[120%] bg-[#5865F2]/10 dark:bg-[#5865F2]/15 blur-[100px] rounded-full"></div>
                        <div className="absolute top-[20%] -right-[10%] w-[50%] h-[120%] bg-[#5865F2]/10 dark:bg-[#5865F2]/15 blur-[100px] rounded-full"></div>
                    </div>

                    {/* 1. DISCORD TOP BAR NAVIGATION */}
                    <div className="w-full flex justify-center relative z-10 border-b border-slate-100 dark:border-white/5">
                        <div className="w-full max-w-[1400px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col md:flex-row md:items-stretch justify-between gap-4">
                        {/* Left side category tabs */}
                        <div className="flex items-stretch gap-6 overflow-x-auto scrollbar-hide">
                            <div className="flex items-center gap-2 text-[#313338] dark:text-slate-200 font-extrabold text-base shrink-0 select-none py-3 pr-1">
                                <Compass className="text-[#313338] dark:text-slate-200" size={20} />
                            </div>
                            <div className="flex items-stretch gap-1 select-none pt-2">
                                {CATEGORIES.map(category => {
                                    const isAll = category === "All";
                                    const label = isAll ? "Home" : category;
                                    const isActive = activeTab === category;
                                    
                                    return (
                                        <button
                                            key={category}
                                            onClick={() => setActiveTab(category)}
                                            className={`relative px-3 flex items-center text-sm font-semibold transition-all shrink-0 ${
                                                isActive 
                                                    ? "text-slate-900 dark:text-white font-bold"
                                                    : "text-[#5C5E66] hover:text-slate-900 dark:text-[#B5BAC1] dark:hover:text-white"
                                            }`}
                                        >
                                            {label}
                                            {isActive && (
                                                <div className="absolute bottom-[-1px] left-3 right-3 h-[3px] bg-slate-900 dark:bg-white rounded-t-md z-10" />
                                            )}
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                        
                        {/* Right side search bar */}
                        <div className="relative w-full md:w-60 shrink-0 py-2 flex items-center">
                            <div className="relative flex w-full items-center bg-[#E3E5EB] dark:bg-[#1E1F22] border border-slate-300 dark:border-slate-800 rounded-md px-3 py-1 group transition-all">
                                <input 
                                    type="text" 
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    placeholder="Search" 
                                    className="w-full bg-transparent text-slate-900 dark:text-white placeholder-[#949BA4] text-xs font-semibold outline-none py-1.5"
                                />
                                <Search className="text-[#949BA4] ml-2" size={16} />
                                {searchQuery && (
                                    <button onClick={() => setSearchQuery('')} className="ml-1 text-xs font-bold text-slate-400 hover:text-slate-600 dark:hover:text-white">
                                        ×
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Search Bar & Hero */}
                {!searchQuery && (
                    <div className="w-full flex justify-center relative select-none">
                        <div className="w-full max-w-[1400px] mx-auto px-4 md:px-8 lg:px-12 py-8 md:py-12 relative z-10">
                            <style>
                                {`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');`}
                            </style>
                            <h1 className="capitalize text-[32px] md:text-[48px] text-[#060607] dark:text-[#F2F3F5] leading-[1.05] mb-4 tracking-[-0.03em]" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 900 }}>
                                Find your community <br/>on Tradifive
                            </h1>
                            <p className="text-base md:text-[17px] text-[#4E5058] dark:text-[#B5BAC1] max-w-xl leading-relaxed font-medium">
                                Discover top trading circles. Share alpha, debate market trends, and level up your financial journey together.
                            </p>
                        </div>
                    </div>
                )}
                </div>

                {/* Main Content Area */}
                <div className="w-full max-w-[1400px] mx-auto px-4 md:px-8 lg:px-12 mt-4 space-y-8">
                    
                    {/* Search Results Drawer */}
                    <AnimatePresence>
                        {searchQuery.trim() && (
                            <motion.div 
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                className="overflow-hidden"
                            >
                                <div className="bg-white dark:bg-[#2B2D31] p-6 rounded-xl border border-slate-200 dark:border-slate-800">
                                    <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
                                        Search Results ({searching ? "Searching..." : `${searchResults.length} found`})
                                    </h2>
                                    {searchResults.length === 0 && !searching ? (
                                        <p className="text-sm text-slate-500 py-6 text-center">No results found.</p>
                                    ) : (
                                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                                            {searchResults.map(profile => {
                                                const displayName = profile.full_name || profile.username || "Active User";
                                                const displaySlug = profile.username || "user";
                                                return (
                                                    <Link key={profile.id} to={`/user/${displaySlug}`} className="bg-white dark:bg-[#1E1F22] p-4 rounded-xl border border-slate-200 dark:border-slate-850 hover:shadow-md transition-all flex items-center gap-3 group">
                                                        <img src={profile.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${displayName}`} alt={displayName} className="w-12 h-12 rounded-full object-cover" />
                                                        <div>
                                                            <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-500 transition-colors">{displayName}</h3>
                                                            <p className="text-xs text-slate-500">@{displaySlug}</p>
                                                        </div>
                                                    </Link>
                                                );
                                            })}
                                        </div>
                                    )}
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>

                    {/* Featured Channels heading / Mentors */}
                    {(activeTab === "All" || activeTab === "Mentors") && !searchQuery && (
                        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
                            <h2 className="text-xl font-bold text-[#060607] dark:text-[#F2F3F5]">
                                {activeTab === "All" ? "Featured Channels" : "Featured Mentors"}
                            </h2>
                            
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                                {finalMentors.slice(0, 8).map((mentor, index) => {
                                    const userSlug = mentor.name.replace(/\s+/g, '').toLowerCase();
                                    return (
                                        <div 
                                            key={mentor.id} 
                                            className="relative group bg-[#FFFFFF] dark:bg-[#2B2D31] rounded-lg overflow-hidden border border-slate-200/60 dark:border-transparent shadow-[0_2px_4px_rgba(0,0,0,0.04)] hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 flex flex-col h-[340px]"
                                        >
                                            {/* Cover Banner */}
                                            <div className="h-[143px] w-full relative shrink-0">
                                                <img src={CARD_COVERS[index % CARD_COVERS.length]} alt="" className="w-full h-full object-cover" />
                                            </div>
                                            
                                            {/* Circular Overlapping Avatar */}
                                            <div className="absolute left-4 top-[115px] w-12 h-12 rounded-full overflow-hidden bg-white border-[4px] border-white dark:border-[#2B2D31] shadow-sm z-20">
                                                <img src={mentor.avatar} alt={mentor.name} className="w-full h-full object-cover" />
                                            </div>
                                            
                                            {/* Card Content body */}
                                            <div className="pt-8 px-4 pb-4 flex flex-col flex-grow justify-between relative z-10">
                                                <div>
                                                    <div className="flex items-center gap-1.5 mb-1.5">
                                                        <span className="text-sm font-extrabold text-[#060607] dark:text-[#F2F3F5] leading-tight line-clamp-1 group-hover:text-blue-500 transition-colors">
                                                            {mentor.name}
                                                        </span>
                                                        {mentor.verified && <VerifiedBadge />}
                                                    </div>
                                                    <p className="text-xs font-semibold text-[#4E5058] dark:text-[#B5BAC1] line-clamp-2 leading-relaxed">
                                                        {mentor.title}
                                                    </p>
                                                </div>
                                                
                                                {/* Stats Footer Row */}
                                                <div className="flex items-center gap-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                                                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#949BA4]">
                                                        <span className="w-2.5 h-2.5 rounded-full bg-[#23A55A]" />
                                                        <span>{mentor.onlineCount.toLocaleString()} Online</span>
                                                    </div>
                                                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#949BA4]">
                                                        <span className="w-2.5 h-2.5 rounded-full bg-[#80848E]" />
                                                        <span>{mentor.memberCount.toLocaleString()} Members</span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <Link to={`/user/${userSlug}`} className="absolute inset-0 z-0" />
                                        </div>
                                    );
                                })}
                            </div>
                        </motion.div>
                    )}

                    {/* Channels */}
                    {(activeTab === "All" || activeTab === "Channels") && !searchQuery && (
                        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
                            {activeTab !== "All" && (
                                <h2 className="text-xl font-bold text-[#060607] dark:text-[#F2F3F5]">Channels</h2>
                            )}
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                                {finalChannels.map((channel, index) => (
                                    <div 
                                        key={channel.id} 
                                        className="relative group bg-[#FFFFFF] dark:bg-[#2B2D31] rounded-lg overflow-hidden border border-slate-200/60 dark:border-transparent shadow-[0_2px_4px_rgba(0,0,0,0.04)] hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 flex flex-col h-[340px]"
                                    >
                                        {/* Cover Banner */}
                                        <div className="h-[143px] w-full relative shrink-0">
                                            <img src={CARD_COVERS[(index + 2) % CARD_COVERS.length]} alt="" className="w-full h-full object-cover" />
                                        </div>
                                        
                                        {/* Overlapping Avatar */}
                                        <div className="absolute left-4 top-[115px] w-12 h-12 rounded-full bg-white border-[4px] border-white dark:border-[#2B2D31] shadow-sm z-20 flex items-center justify-center text-xl select-none">
                                            {channel.icon}
                                        </div>
                                        
                                        {/* Card body */}
                                        <div className="pt-8 px-4 pb-4 flex flex-col flex-grow justify-between relative z-10">
                                            <div>
                                                <div className="flex items-center justify-between gap-1.5 mb-1.5">
                                                    <span className="text-sm font-extrabold text-[#060607] dark:text-[#F2F3F5] leading-tight line-clamp-1 group-hover:text-blue-500 transition-colors">
                                                        {channel.name}
                                                    </span>
                                                    {channel.locked && <Lock size={14} className="text-slate-400 shrink-0" />}
                                                </div>
                                                <p className="text-xs font-semibold text-[#4E5058] dark:text-[#B5BAC1] line-clamp-2 leading-relaxed">
                                                    {channel.description}
                                                </p>
                                            </div>
                                            
                                            {/* Stats Footer Row */}
                                            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                                                <div className="flex items-center gap-4">
                                                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#949BA4]">
                                                        <span className="w-2.5 h-2.5 rounded-full bg-[#23A55A]" />
                                                        <span>{channel.onlineCount.toLocaleString()} Online</span>
                                                    </div>
                                                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#949BA4]">
                                                        <span className="w-2.5 h-2.5 rounded-full bg-[#80848E]" />
                                                        <span>{channel.memberCount.toLocaleString()} Members</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </motion.div>
                    )}

                    {/* Traders */}
                    {(activeTab === "All" || activeTab === "Traders") && !searchQuery && (
                        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
                            {activeTab !== "All" && (
                                <h2 className="text-xl font-bold text-[#060607] dark:text-[#F2F3F5]">Top Traders</h2>
                            )}
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                                {finalTraders.slice(0, 8).map((trader, index) => {
                                    const userSlug = trader.name.replace(/\s+/g, '').toLowerCase();
                                    return (
                                        <div 
                                            key={trader.id} 
                                            className="relative group bg-[#FFFFFF] dark:bg-[#2B2D31] rounded-lg overflow-hidden border border-slate-200/60 dark:border-transparent shadow-[0_2px_4px_rgba(0,0,0,0.04)] hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 flex flex-col h-[340px]"
                                        >
                                            {/* Cover Banner */}
                                            <div className="h-[143px] w-full relative shrink-0">
                                                <img src={CARD_COVERS[(index + 4) % CARD_COVERS.length]} alt="" className="w-full h-full object-cover" />
                                            </div>
                                            
                                            {/* Overlapping Avatar */}
                                            <div className="absolute left-4 top-[115px] w-12 h-12 rounded-full overflow-hidden bg-white border-[4px] border-white dark:border-[#2B2D31] shadow-sm z-20">
                                                <img src={trader.avatar} alt={trader.name} className="w-full h-full object-cover" />
                                            </div>
                                            
                                            {/* Content body */}
                                            <div className="pt-8 px-4 pb-4 flex flex-col flex-grow justify-between relative z-10">
                                                <div>
                                                    <div className="flex items-center gap-1.5 mb-1.5">
                                                        <span className="text-sm font-extrabold text-[#060607] dark:text-[#F2F3F5] leading-tight line-clamp-1 group-hover:text-blue-500 transition-colors">
                                                            {trader.name}
                                                        </span>
                                                    </div>
                                                    <div className="space-y-1 mt-1 text-xs font-semibold text-[#4E5058] dark:text-[#B5BAC1]">
                                                        <div>Win Rate: {trader.winRate}</div>
                                                        <div>Est. ROI: {trader.profit}</div>
                                                    </div>
                                                </div>
                                                
                                                {/* Stats Footer Row */}
                                                <div className="flex items-center gap-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                                                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#949BA4]">
                                                        <span className="w-2.5 h-2.5 rounded-full bg-[#23A55A]" />
                                                        <span>{trader.onlineCount.toLocaleString()} Online</span>
                                                    </div>
                                                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#949BA4]">
                                                        <span className="w-2.5 h-2.5 rounded-full bg-[#80848E]" />
                                                        <span>{trader.memberCount.toLocaleString()} Members</span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <Link to={`/user/${userSlug}`} className="absolute inset-0 z-0" />
                                        </div>
                                    );
                                })}
                            </div>
                        </motion.div>
                    )}

                    {/* People */}
                    {(activeTab === "All" || activeTab === "People") && !searchQuery && (
                        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
                            {activeTab !== "All" && (
                                <h2 className="text-xl font-bold text-[#060607] dark:text-[#F2F3F5]">People</h2>
                            )}
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                                {finalPeople.map((person, index) => {
                                    const userSlug = person.handle.replace('@', '');
                                    return (
                                        <div 
                                            key={person.id} 
                                            className="relative group bg-[#FFFFFF] dark:bg-[#2B2D31] rounded-lg overflow-hidden border border-slate-200/60 dark:border-transparent shadow-[0_2px_4px_rgba(0,0,0,0.04)] hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 flex flex-col h-[340px]"
                                        >
                                            {/* Cover Banner */}
                                            <div className="h-[143px] w-full relative shrink-0">
                                                <img src={CARD_COVERS[(index + 1) % CARD_COVERS.length]} alt="" className="w-full h-full object-cover" />
                                            </div>
                                            
                                            {/* Overlapping Avatar */}
                                            <div className="absolute left-4 top-[115px] w-12 h-12 rounded-full overflow-hidden bg-white border-[4px] border-white dark:border-[#2B2D31] shadow-sm z-20">
                                                <img src={person.avatar} alt={person.name} className="w-full h-full object-cover" />
                                            </div>
                                            
                                            {/* Content body */}
                                            <div className="pt-8 px-4 pb-4 flex flex-col flex-grow justify-between relative z-10">
                                                <div>
                                                    <div className="flex items-center gap-1.5 mb-1.5">
                                                        <span className="text-sm font-extrabold text-[#060607] dark:text-[#F2F3F5] leading-tight line-clamp-1 group-hover:text-blue-500 transition-colors">
                                                            {person.name}
                                                        </span>
                                                    </div>
                                                    <p className="text-xs font-semibold text-[#4E5058] dark:text-[#B5BAC1]">
                                                        {person.handle}
                                                    </p>
                                                    <p className="text-[11px] font-bold text-slate-400 mt-1">
                                                        {person.mutual} mutual servers
                                                    </p>
                                                </div>
                                                
                                                {/* Stats Footer Row */}
                                                <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                                                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#949BA4]">
                                                        <span className="w-2.5 h-2.5 rounded-full bg-[#80848E]" />
                                                        <span>{person.onlineCount.toLocaleString()} Online</span>
                                                    </div>
                                                    <button className="relative z-30 bg-gradient-to-b from-[#60A5FA] to-[#3B82F6] dark:from-[#3B82F6] dark:to-[#1D4ED8] text-white border border-[#93C5FD] dark:border-[#3B82F6] text-[10px] font-black uppercase tracking-wider px-2.5 py-1.5 rounded hover:scale-[1.03] transition-transform shrink-0 flex items-center gap-1">
                                                        <UserPlus size={11} /> Add
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            <Link to={`/user/${userSlug}`} className="absolute inset-0 z-0" />
                                        </div>
                                    );
                                })}
                            </div>
                        </motion.div>
                    )}

                    {/* Competitions */}
                    {(activeTab === "All" || activeTab === "Competitions") && !searchQuery && (
                        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
                            {activeTab !== "All" && (
                                <h2 className="text-xl font-bold text-[#060607] dark:text-[#F2F3F5]">Competitions</h2>
                            )}
                            <div className="relative w-full h-[280px] rounded-lg overflow-hidden bg-slate-900 border border-slate-700 dark:border-slate-800 shadow-sm flex items-center justify-center group">
                                <div className="absolute inset-0 opacity-40 bg-[url('https://images.unsplash.com/photo-1518186285589-2f7649de83e0?auto=format&fit=crop&q=80&w=1200')] bg-cover bg-center group-hover:scale-[1.02] transition-transform duration-700"></div>
                                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent"></div>
                                
                                <div className="relative z-10 flex flex-col items-center text-center p-8">
                                    <div className="w-14 h-14 rounded-xl bg-white/10 backdrop-blur-xl border border-white/20 flex items-center justify-center mb-5 text-white shadow-2xl">
                                        <Lock size={24} />
                                    </div>
                                    <h3 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight mb-2">Funded Account Battles</h3>
                                    <p className="text-slate-300 font-semibold text-xs md:text-sm max-w-lg">Compete against thousands globally for six-figure funded accounts and massive cash prizes.</p>
                                    
                                    <div className="mt-6 flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl">
                                        <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse"></span>
                                        <span className="text-[10px] font-black text-white uppercase tracking-widest">Launching Soon</span>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    )}
                </div>
            </div>
            
            <style dangerouslySetInnerHTML={{__html: `
                .scrollbar-hide::-webkit-scrollbar { display: none; }
                .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
            `}} />
        </DashboardLayout>
    )
}
