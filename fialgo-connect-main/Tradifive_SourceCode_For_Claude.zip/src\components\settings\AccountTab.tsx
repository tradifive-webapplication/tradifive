import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Key, Smartphone, ShieldCheck, CheckCircle2, Users } from 'lucide-react';

export default function AccountTab({ 
   setActiveSubTab, 
   onEditProfile,
   onEditPhone 
}: { 
   setActiveSubTab: (id: string) => void,
   onEditProfile?: () => void,
   onEditPhone?: () => void
}) {
   const [revealEmail, setRevealEmail] = useState(false);
   const [revealPhone, setRevealPhone] = useState(false);

   useEffect(() => {
      const handleScroll = (e: Event) => {
         const container = e.target as HTMLElement;
         const sections = ['account-info', 'password-security', 'account-standing', 'family-center'];
         let currentActive = sections[0];
         
         // Check if scrolled to the bottom
         const isAtBottom = container.scrollHeight - container.scrollTop <= container.clientHeight + 10;
         
         if (isAtBottom) {
            currentActive = sections[sections.length - 1];
         } else {
            for (const section of sections) {
               const el = document.getElementById(section);
               if (el && container.scrollTop >= (el.offsetTop - 150)) {
                  currentActive = section;
               }
            }
         }
         
         setActiveSubTab(currentActive);
      };
      const scrollContainer = document.getElementById('settings-scroll-container');
      if (scrollContainer) {
         scrollContainer.addEventListener('scroll', handleScroll);
         return () => scrollContainer.removeEventListener('scroll', handleScroll);
      }
   }, [setActiveSubTab]);

   return (
      <div className="space-y-6 pb-24 font-sans">
         
         {/* SECTION 1: MY ACCOUNT */}
         <section id="account-info">
            <div className="bg-slate-50 dark:bg-[#151515] p-6 rounded-2xl border border-slate-200 dark:border-[#333333] shadow-sm space-y-6">
               <h2 className="text-xs font-bold text-slate-500 dark:text-neutral-500 uppercase tracking-widest mb-2">My Account</h2>
               
               {/* Banner with Avatar */}
               <div className="h-28 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 relative rounded-xl border border-slate-200 dark:border-transparent">
                  {/* Avatar */}
                  <div className="absolute -bottom-10 left-6">
                     <div className="w-24 h-24 rounded-full border-[6px] border-white dark:border-[#151515] bg-slate-200 dark:bg-[#1C1C1E] flex items-center justify-center overflow-hidden relative group cursor-pointer shadow-sm">
                        <img src="https://api.dicebear.com/7.x/initials/svg?seed=JD" alt="Avatar" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                           <span className="text-white text-[10px] font-bold uppercase tracking-wider">Change</span>
                        </div>
                     </div>
                  </div>
               </div>

               {/* Profile Info Header & Controls */}
               <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pt-6">
                  <div>
                     <h3 className="text-xl font-bold text-slate-900 dark:text-white">John Doe</h3>
                     <p className="text-sm font-medium text-slate-500 dark:text-[#949ba4]">@johndoe</p>
                  </div>
                  <button onClick={onEditProfile} className="px-4 py-2 bg-[#3b82f6] hover:bg-blue-600 text-white text-[13px] font-semibold rounded-md shadow-sm transition-colors">
                     Edit User Profile
                  </button>
               </div>

               <div className="h-[1px] bg-slate-200/60 dark:bg-[#333333]" />

               {/* Email */}
               <div className="flex justify-between items-center">
                  <div>
                     <p className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-1">Email</p>
                     <div className="flex items-center gap-2">
                        <p className="text-[14px] text-slate-800 dark:text-white font-medium">
                           {revealEmail ? "johndoe@example.com" : "j*******@example.com"}
                        </p>
                        <button onClick={() => setRevealEmail(!revealEmail)} className="text-[13px] text-blue-500 hover:underline">
                           {revealEmail ? "Hide" : "Reveal"}
                        </button>
                     </div>
                  </div>
                  <button onClick={onEditProfile} className="px-3 py-1.5 bg-white dark:bg-[#202022] hover:bg-slate-50 dark:hover:bg-[#2c2c2f] border border-slate-200 dark:border-[#333333] text-slate-800 dark:text-white text-[13px] font-semibold rounded transition-colors shadow-sm">
                     Edit
                  </button>
               </div>

               <div className="h-[1px] bg-slate-200/60 dark:bg-[#333333]" />

               {/* Phone */}
               <div className="flex justify-between items-center">
                  <div>
                     <p className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-1">Phone Number</p>
                     <div className="flex items-center gap-2">
                        <p className="text-[14px] text-slate-800 dark:text-white font-medium">
                           {revealPhone ? "+1 (555) 123-4567" : "********567"}
                        </p>
                        <button onClick={() => setRevealPhone(!revealPhone)} className="text-[13px] text-blue-500 hover:underline">
                           {revealPhone ? "Hide" : "Reveal"}
                        </button>
                     </div>
                  </div>
                  <button onClick={onEditPhone} className="px-3 py-1.5 bg-white dark:bg-[#202022] hover:bg-slate-50 dark:hover:bg-[#2c2c2f] border border-slate-200 dark:border-[#333333] text-slate-800 dark:text-white text-[13px] font-semibold rounded transition-colors shadow-sm">
                     Edit
                  </button>
               </div>
            </div>
         </section>

         {/* SECTION 2: PASSWORD & SECURITY */}
         <section id="password-security">
            <div className="bg-slate-50 dark:bg-[#151515] p-6 rounded-2xl border border-slate-200 dark:border-[#333333] shadow-sm space-y-6">
               <h2 className="text-xs font-bold text-slate-500 dark:text-neutral-500 uppercase tracking-widest">Password & Security</h2>
               
               {/* Change Password Card Row */}
               <div className="flex justify-between items-center gap-4">
                  <div>
                     <h3 className="text-[15px] font-bold text-slate-900 dark:text-white">Change Password</h3>
                     <p className="text-[13px] text-slate-500 dark:text-[#949ba4] mt-1">Update your password to keep your account secure.</p>
                  </div>
                  <button className="px-4 py-2 bg-[#3b82f6] hover:bg-blue-600 text-white text-[13px] font-semibold rounded-md shadow-sm transition-colors shrink-0">
                     Change Password
                  </button>
               </div>

               <div className="h-[1px] bg-slate-200/60 dark:bg-[#333333]" />

               {/* MFA Details */}
               <div className="space-y-5">
                  <div className="flex items-center gap-3">
                     <ShieldCheck size={24} className="text-green-500" />
                     <div>
                        <h3 className="text-[15px] font-bold text-slate-900 dark:text-white uppercase tracking-wide">Two-Factor Authentication</h3>
                        <p className="text-[13px] text-slate-500 dark:text-[#949ba4] mt-0.5">Add an extra layer of security to your Tradifive account.</p>
                     </div>
                  </div>

                  <div className="space-y-3">
                     <div className="flex justify-between items-center p-4 rounded-xl bg-white dark:bg-[#121212] border border-slate-200/50 dark:border-[#333333] shadow-sm">
                        <div className="flex items-center gap-4">
                           <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-[#3b82f6]">
                              <Smartphone size={20} />
                           </div>
                           <div>
                              <h4 className="text-[14px] font-bold text-slate-900 dark:text-white">Authenticator App</h4>
                              <p className="text-[12px] text-slate-500 dark:text-[#949ba4]">Use an app like Google Authenticator or Authy.</p>
                           </div>
                        </div>
                        <button className="px-4 py-2 bg-slate-100 dark:bg-[#202022] hover:bg-slate-200 dark:hover:bg-[#2c2c2f] border border-slate-200 dark:border-transparent text-slate-800 dark:text-white text-[13px] font-semibold rounded transition-colors shadow-sm">
                           Enable
                        </button>
                     </div>
                     
                     <div className="flex justify-between items-center p-4 rounded-xl bg-white dark:bg-[#121212] border border-slate-200/50 dark:border-[#333333] shadow-sm">
                        <div className="flex items-center gap-4">
                           <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-500">
                              <Key size={20} />
                           </div>
                           <div>
                              <h4 className="text-[14px] font-bold text-slate-900 dark:text-white">Security Keys</h4>
                              <p className="text-[12px] text-slate-500 dark:text-[#949ba4]">Use a hardware security key (like YubiKey) for maximum security.</p>
                           </div>
                        </div>
                        <button className="px-4 py-2 bg-slate-100 dark:bg-[#202022] hover:bg-slate-200 dark:hover:bg-[#2c2c2f] border border-slate-200 dark:border-transparent text-slate-800 dark:text-white text-[13px] font-semibold rounded transition-colors shadow-sm">
                           Register Key
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </section>

         {/* SECTION 3: ACCOUNT STANDING */}
         <section id="account-standing">
            <div className="bg-slate-50 dark:bg-[#151515] p-6 md:p-8 rounded-2xl border border-slate-200 dark:border-[#333333] shadow-sm flex flex-col items-center justify-center text-center space-y-4 py-10">
               <h2 className="text-xs font-bold text-slate-500 dark:text-neutral-500 uppercase tracking-widest self-start mb-2">Account Standing</h2>
               <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mt-2">
                  <CheckCircle2 size={32} className="text-green-500" />
               </div>
               <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Your account is in good standing</h3>
                  <p className="text-[13px] text-slate-500 dark:text-[#949ba4] max-w-md mx-auto leading-relaxed">
                     You have no active warnings, restrictions, or bans. Thank you for following the community guidelines and keeping Tradifive a safe environment for all traders.
                  </p>
               </div>
            </div>
         </section>

         {/* SECTION 4: FAMILY CENTER */}
         <section id="family-center">
            <div className="bg-slate-50 dark:bg-[#151515] p-6 md:p-8 rounded-2xl border border-slate-200 dark:border-[#333333] shadow-sm flex flex-col items-center justify-center text-center space-y-6">
               <h2 className="text-xs font-bold text-slate-500 dark:text-neutral-500 uppercase tracking-widest self-start mb-2">Family Center</h2>
               <div className="w-20 h-20 rounded-full bg-blue-500/10 flex items-center justify-center mt-2">
                  <Users size={40} className="text-[#3b82f6]" />
               </div>
               <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">Welcome to Family Center</h3>
                  <p className="text-[14px] text-slate-500 dark:text-[#949ba4] max-w-lg mx-auto leading-relaxed">
                     Family Center is a new tool that helps you manage connected teen accounts. Monitor their trading activity safely, set guardrails, and stay informed without intruding on their space.
                  </p>
               </div>
               <div className="flex gap-4 mt-2">
                  <button className="px-5 py-2.5 bg-[#3b82f6] hover:bg-blue-600 text-white text-[14px] font-semibold rounded-md shadow-sm transition-colors">
                     Enable Family Center
                  </button>
                  <button className="px-5 py-2.5 bg-white dark:bg-[#1e1e21] hover:bg-slate-100 dark:hover:bg-[#2b2b2b] border border-slate-200 dark:border-[#333333] text-slate-800 dark:text-white text-[14px] font-semibold rounded-md transition-colors shadow-sm">
                     Learn More
                  </button>
               </div>
            </div>
         </section>
      </div>
   );
}
