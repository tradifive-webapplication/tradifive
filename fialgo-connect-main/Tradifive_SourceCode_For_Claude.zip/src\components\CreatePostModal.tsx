import React, { useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import {
  X, Image, Video, Hash, Globe, Crown, Loader2, BarChart2, Smile, Gift, Plus, Trash2,
  Calendar, Clock, Heart, MessageCircle, Send, Bookmark, MapPin, ChevronDown, Check,
  MoreHorizontal, Share2, Youtube, Music, MessageSquare
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  userId: string;
  mode?: "create" | "edit";
  postId?: string;
  initialContent?: string;
  initialTags?: string[];
  initialMediaUrl?: string | null;
  initialMediaType?: "image" | "video" | "poll" | null;
  variant?: "modal" | "dropdown";
}

const CURATED_GIFS = [
  { name: "Stonks Up", url: "https://media.giphy.com/media/YnkMcHgNIMW4YcX2Xs/giphy.gif" },
  { name: "Bull Charge", url: "https://media.giphy.com/media/Vz8cxO1p6ytS8/giphy.gif" },
  { name: "Bear Roar", url: "https://media.giphy.com/media/H5qyL9DSW0vZTJvBH0/giphy.gif" },
  { name: "Money Rain", url: "https://media.giphy.com/media/LCdPNT81vde3CGKjEC/giphy.gif" },
  { name: "Panic Selling", url: "https://media.giphy.com/media/1EghTrigJJFBEXRQVq/giphy.gif" },
  { name: "HODL Crypto", url: "https://media.giphy.com/media/d0DdMUREKWZQmqZlD8/giphy.gif" },
  { name: "Buy The Dip", url: "https://media.giphy.com/media/tXL4FHPSnVJ0A/giphy.gif" },
  { name: "To The Moon", url: "https://media.giphy.com/media/5wBoP56UsdHGTKGMcS/giphy.gif" }
];

const COMMON_EMOJIS = ["📈", "📉", "🚀", "💎", "🙌", "🐂", "🐻", "💰", "📊", "🔥", "👍", "👏", "🚨", "🎯", "🤔", "😂"];

const PRESET_LOCATIONS = [
  "Seebensee, Austria",
  "New York, USA",
  "Tokyo, Japan",
  "London, United Kingdom",
  "Paris, France",
  "Dubai, UAE",
  "Sydney, Australia",
  "Singapore"
];

const POPULAR_TRADERS = [
  { name: "Alex Algo", username: "alex_algo", avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80" },
  { name: "Amber Trades", username: "amber_trades", avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=80" },
  { name: "Andrew Quant", username: "andrew_quant", avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=80" },
  { name: "Mark Travels", username: "markstravels", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80" },
  { name: "Lucy Explores", username: "lucyexplores", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80" },
  { name: "Jenny Wanderlust", username: "wanderlust.jenny", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80" },
  { name: "Arjun FX", username: "arjun_fx", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80" },
  { name: "Aisha Crypto", username: "aisha_crypto", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80" }
];

export default function CreatePostModal({
  isOpen,
  onClose,
  onSuccess,
  userId,
  mode = "create",
  postId,
  initialContent = "",
  initialTags = [],
  initialMediaUrl = null,
  initialMediaType = null,
  variant = "modal"
}: CreatePostModalProps) {
  // Base states
  const [content, setContent] = useState("");
  const [mediaBase64, setMediaBase64] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<"image" | "video" | "poll" | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Selector for Attachment Type: text/none, image, video, gif, poll
  const [attachmentType, setAttachmentType] = useState<"none" | "image" | "video" | "gif" | "poll" | null>("image");

  // Premium details state
  const [locationName, setLocationName] = useState("Seebensee, Austria");
  const [showLocationDropdown, setShowLocationDropdown] = useState(false);
  const [tagsList, setTagsList] = useState<string[]>(["@wanderlust.jenny", "@markstravels", "@lucyexplores"]);
  const [tagInputText, setTagInputText] = useState("");
  
  // Scheduler ON/OFF states
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");
  const [showScheduleErrors, setShowScheduleErrors] = useState(false);
  const [allowComments, setAllowComments] = useState(true);

  // Poll states
  const [showPollCreator, setShowPollCreator] = useState(false);
  const [pollOptions, setPollOptions] = useState<string[]>(["", ""]);

  // Picker toggles
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // Reset/Initialize state
  useEffect(() => {
    if (isOpen) {
      if (mode === "edit") {
        let parsedLocation = "Seebensee, Austria";
        let parsedContent = initialContent;

        const locMatch = initialContent.match(/^📍\s+(.+)\n/);
        if (locMatch) {
          parsedLocation = locMatch[1];
          parsedContent = parsedContent.replace(/^📍\s+.+\n/, "");
        }

        setLocationName(parsedLocation);
        setContent(parsedContent.trim());
        setTagsList(initialTags.length > 0 ? initialTags : ["@wanderlust.jenny", "@markstravels", "@lucyexplores"]);

        if (initialMediaType === "poll" && initialMediaUrl) {
          try {
            const parsed = JSON.parse(initialMediaUrl);
            setPollOptions(parsed.options || ["", ""]);
            setShowPollCreator(true);
            setMediaType("poll");
            setMediaBase64(initialMediaUrl);
            setAttachmentType("poll");
          } catch (e) {
            setMediaBase64(initialMediaUrl);
            setMediaType(initialMediaType);
            setAttachmentType("none");
          }
        } else if (initialMediaUrl) {
          setMediaBase64(initialMediaUrl);
          setMediaType(initialMediaType);
          setShowPollCreator(false);
          setAttachmentType(initialMediaType === "video" ? "video" : "image");
        } else {
          setMediaBase64(null);
          setMediaType(null);
          setShowPollCreator(false);
          setAttachmentType("none");
        }
        setIsScheduled(false);
        setScheduleDate("");
        setScheduleTime("");
      } else {
        // Defaults
        setLocationName("Seebensee, Austria");
        setContent(
          "A canvas painted by nature, framed by the Alps. 🏔️✨\nWhich destination is on your 2025 bucket list? Let us know below! 👇 #TravelGoals #WanderlustViews #AdventureAwaits"
        );
        setTagsList(["@wanderlust.jenny", "@markstravels", "@lucyexplores"]);
        setMediaBase64(null);
        setMediaType(null);
        setShowPollCreator(false);
        setPollOptions(["", ""]);
        setAttachmentType("image");
        setIsScheduled(false);
        setScheduleDate("");
        setScheduleTime("");
        setShowScheduleErrors(false);
      }
      setShowEmojiPicker(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, mode, postId]);

  const handleAttachmentTypeChange = (type: "none" | "image" | "video" | "gif" | "poll") => {
    setAttachmentType(type);
    
    if (type === "none") {
      setMediaBase64(null);
      setMediaType(null);
      setShowPollCreator(false);
    } else if (type === "image") {
      setMediaBase64(null);
      setMediaType("image");
      setShowPollCreator(false);
    } else if (type === "video") {
      setMediaBase64(null);
      setMediaType("video");
      setShowPollCreator(false);
    } else if (type === "gif") {
      setMediaBase64(CURATED_GIFS[0].url);
      setMediaType("image");
      setShowPollCreator(false);
    } else if (type === "poll") {
      setMediaBase64(null);
      setMediaType("poll");
      setShowPollCreator(true);
      if (pollOptions.length < 2) {
        setPollOptions(["", ""]);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast.error("File is too large! Please upload a file smaller than 10MB.");
      return;
    }

    const type = file.type.startsWith("video/") ? "video" : "image";
    const reader = new FileReader();

    reader.onloadstart = () => {
      setIsSubmitting(true);
    };

    reader.onloadend = () => {
      setMediaBase64(reader.result as string);
      setMediaType(type);
      setIsSubmitting(false);
    };

    reader.onerror = () => {
      toast.error("Error reading file");
      setIsSubmitting(false);
    };

    reader.readAsDataURL(file);
  };

  const selectPresetGif = (gifUrl: string) => {
    setMediaBase64(gifUrl);
    setMediaType("image");
    toast.success("Meme GIF attached!");
  };

  const insertEmoji = (emoji: string) => {
    setContent(prev => prev + emoji);
    setShowEmojiPicker(false);
  };

  const addPollOption = () => {
    if (pollOptions.length >= 4) {
      toast.warning("Maximum of 4 options allowed.");
      return;
    }
    setPollOptions([...pollOptions, ""]);
  };

  const removePollOption = (index: number) => {
    if (pollOptions.length <= 2) {
      toast.warning("Minimum of 2 options required.");
      return;
    }
    setPollOptions(pollOptions.filter((_, i) => i !== index));
  };

  const handlePollOptionChange = (index: number, val: string) => {
    const updated = [...pollOptions];
    updated[index] = val;
    setPollOptions(updated);
  };

  const removeMedia = () => {
    setMediaBase64(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      const val = tagInputText.trim().replace(/^@/, "");
      if (!val) return;
      
      const formatted = `@${val}`;
      if (!tagsList.includes(formatted)) {
        setTagsList([...tagsList, formatted]);
      }
      setTagInputText("");
    }
  };

  const removeTag = (tag: string) => {
    setTagsList(prev => prev.filter(t => t !== tag));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isScheduled && (!scheduleDate || !scheduleTime)) {
      setShowScheduleErrors(true);
      toast.error("Please pick a valid Date and Time to schedule your post!");
      return;
    }

    if (!content.trim() && !mediaBase64 && attachmentType !== "poll") {
      toast.error("Please add some text or media to your post!");
      return;
    }

    let finalPostType = "text";
    let finalMediaUrlVal = mediaBase64;
    let finalMediaTypeVal = mediaType;

    if (attachmentType === "poll") {
      const validOptions = pollOptions.filter(o => o.trim() !== "");
      if (validOptions.length < 2) {
        toast.error("Please enter at least 2 non-empty poll options!");
        return;
      }
      finalPostType = "poll";
      finalMediaTypeVal = "poll";

      let finalVotes = new Array(validOptions.length).fill(0);
      if (mode === "edit" && initialMediaType === "poll" && initialMediaUrl) {
        try {
          const parsed = JSON.parse(initialMediaUrl);
          if (parsed.votes && parsed.votes.length === validOptions.length) {
            finalVotes = parsed.votes;
          }
        } catch (err) {}
      }

      finalMediaUrlVal = JSON.stringify({
        options: validOptions,
        votes: finalVotes
      });
    }

    setIsSubmitting(true);

    try {
      const manualTags = tagsList.map(t => t.replace(/^@/, ""));
      const hashtagRegex = /#(\w+)/g;
      const autoTags: string[] = [];
      let match;
      while ((match = hashtagRegex.exec(content)) !== null) {
        if (!autoTags.includes(match[1])) {
          autoTags.push(match[1]);
        }
      }
      const combinedTags = Array.from(new Set([...manualTags, ...autoTags]));

      let finalContent = "";
      if (locationName.trim()) {
        finalContent += `📍 ${locationName.trim()}\n`;
      }
      finalContent += `${content.trim()}`;

      const createdTime = isScheduled && scheduleDate && scheduleTime
        ? new Date(`${scheduleDate}T${scheduleTime}`).toISOString()
        : new Date().toISOString();

      const newPostObject = {
        user_id: userId || "mock-user-id",
        content: finalContent,
        media_url: finalMediaUrlVal,
        media_type: finalMediaTypeVal,
        post_type: finalPostType,
        tags: combinedTags.length > 0 ? combinedTags : null,
        created_at: createdTime,
        likes_count: 0,
        comments_count: 0,
        bookmark_count: 0,
        like_count: 0,
        comment_count: 0,
        share_count: 0,
        view_count: 0,
        is_public: true
      };

      if (mode === "create") {
        try {
          const { error } = await supabase.from("social_posts").insert([newPostObject]);
          if (error) {
            console.warn("Supabase insert failed, using fallback:", error);
            throw error;
          }
          if (isScheduled) {
            toast.success(`Post scheduled successfully for ${scheduleDate} at ${scheduleTime}!`);
          } else {
            toast.success("Post published successfully!");
          }
        } catch (dbErr) {
          // Robust Local fallback!
          const localPosts = JSON.parse(localStorage.getItem('fialgo_local_posts') || '[]');
          localPosts.unshift({
            id: `local-${Date.now()}`,
            ...newPostObject,
            profiles: {
              id: userId || "mock-user-id",
              first_name: "Isabella",
              last_name: "Nilsson",
              display_name: "Isabella Nilsson",
              full_name: "Isabella Nilsson",
              username: "IsabellaN",
              avatar_url: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
              bio: "Algo Trading enthusiast & Developer. Building quantitative strategies and custom indicator sets for systematic market execution.",
              banner_url: "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1200&fit=crop&q=80"
            }
          });
          localStorage.setItem('fialgo_local_posts', JSON.stringify(localPosts));
          
          if (isScheduled) {
            toast.success(`Post scheduled successfully for ${scheduleDate} at ${scheduleTime} (Offline Workspace Backup)!`);
          } else {
            toast.success("Post published successfully (Offline Workspace Backup)!");
          }
        }
      } else {
        if (!postId) throw new Error("Missing postId in Edit Mode");
        try {
          const { error } = await supabase
            .from("social_posts")
            .update({
              content: finalContent,
              media_url: finalMediaUrlVal,
              media_type: finalMediaTypeVal,
              post_type: finalPostType,
              tags: combinedTags.length > 0 ? combinedTags : null,
              created_at: createdTime,
              updated_at: new Date().toISOString()
            })
            .eq("id", postId);
          if (error) {
            console.warn("Supabase update failed, using fallback:", error);
            throw error;
          }
          if (isScheduled) {
            toast.success("Scheduled post details updated successfully!");
          } else {
            toast.success("Post details updated successfully!");
          }
        } catch (dbErr) {
          // Local fallback for Edit!
          const localPosts = JSON.parse(localStorage.getItem('fialgo_local_posts') || '[]');
          const idx = localPosts.findIndex((p: any) => p.id === postId);
          if (idx !== -1) {
            localPosts[idx] = {
              ...localPosts[idx],
              content: finalContent,
              media_url: finalMediaUrlVal,
              media_type: finalMediaTypeVal,
              post_type: finalPostType,
              tags: combinedTags.length > 0 ? combinedTags : null,
              created_at: createdTime,
              updated_at: new Date().toISOString()
            };
            localStorage.setItem('fialgo_local_posts', JSON.stringify(localPosts));
            if (isScheduled) {
              toast.success("Scheduled post updated (Offline Workspace Backup)!");
            } else {
              toast.success("Post details updated (Offline Workspace Backup)!");
            }
          } else {
            // Override editing backup for database mock posts
            localPosts.unshift({
              id: postId,
              user_id: userId || "mock-user-id",
              content: finalContent,
              media_url: finalMediaUrlVal,
              media_type: finalMediaTypeVal,
              post_type: finalPostType,
              tags: combinedTags.length > 0 ? combinedTags : null,
              created_at: createdTime,
              updated_at: new Date().toISOString(),
              likes_count: 0,
              comments_count: 0,
              bookmark_count: 0,
              like_count: 0,
              comment_count: 0,
              share_count: 0,
              view_count: 0,
              is_public: true,
              profiles: {
                id: userId || "mock-user-id",
                first_name: "Isabella",
                last_name: "Nilsson",
                display_name: "Isabella Nilsson",
                full_name: "Isabella Nilsson",
                username: "IsabellaN",
                avatar_url: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
                bio: "Algo Trading enthusiast & Developer. Building quantitative strategies.",
                banner_url: "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1200&fit=crop&q=80"
              }
            });
            localStorage.setItem('fialgo_local_posts', JSON.stringify(localPosts));
            if (isScheduled) {
              toast.success("Scheduled post updated successfully (Offline Workspace Backup)!");
            } else {
              toast.success("Post details updated successfully (Offline Workspace Backup)!");
            }
          }
        }
      }

      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      console.error("Error submitting post:", err);
      toast.error(err.message || "Failed to submit post.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderFormattedPreview = (text: string) => {
    if (!text) return "";
    const parts = text.split(/(\s+)/);
    return parts.map((part, i) => {
      if (part.startsWith("#") || part.startsWith("@")) {
        return (
          <span key={i} className="text-[#3B82F6] dark:text-[#60A5FA] font-semibold cursor-pointer hover:underline">
            {part}
          </span>
        );
      }
      return part;
    });
  };

  if (!isOpen) return null;

  return createPortal(
    <AnimatePresence>
      <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
        {/* Backdrop Blur Overlay */}
        <div 
          className="fixed inset-0 bg-slate-950/75 backdrop-blur-md cursor-pointer" 
          onClick={onClose} 
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, y: 35, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 35, scale: 0.96 }}
          transition={{ duration: 0.22, ease: "easeOut" }}
          onClick={(e) => e.stopPropagation()}
          className="bg-[#FFFFFF] dark:bg-[#121214] border-2 border-white dark:border-[#1A1A1A] shadow-2xl flex text-slate-800 dark:text-slate-100 relative z-50 w-[98vw] md:w-[94vw] lg:w-[88vw] xl:w-[82vw] max-w-7xl h-[94vh] md:h-[88vh] rounded-[32px] overflow-hidden flex-col lg:flex-row font-sans"
        >
          {/* Left Pane: Create Post Workspace */}
          <div className="flex-1 flex flex-col min-w-0 bg-white dark:bg-[#121214] overflow-y-auto amazing-scrollbar">
            {/* Top Header */}
            <div className="p-5 md:p-6 pb-3 flex items-center justify-between border-b border-slate-150 dark:border-slate-800/60 shrink-0">
              <div>
                <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white tracking-tight leading-none font-sans">
                  Create Post
                </h2>
                <p className="text-xs text-slate-400 dark:text-slate-500 font-medium mt-2">
                  Craft and schedule your next social post effortlessly.
                </p>
              </div>
              <button
                onClick={onClose}
                disabled={isSubmitting}
                className="w-10 h-10 rounded-full flex items-center justify-center bg-slate-50 dark:bg-slate-800/40 border border-slate-200/40 dark:border-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-450 hover:text-slate-600 dark:hover:text-white transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Workspace Form */}
            <form onSubmit={handleSubmit} className="p-5 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 flex-grow min-h-0">
              
              {/* Media Asset Manager Column */}
              <div className="lg:col-span-5 space-y-5">
                
                {/* Tactical Attachment Type Selector Bar styled like Fialgo's Profile timeline tabs */}
                <div className="flex flex-col gap-2 select-none font-sans">
                  <label className="text-[11px] font-black uppercase text-slate-400 dark:text-slate-500 tracking-wider">
                    Attach to Post
                  </label>
                  <div className="bg-slate-100 dark:bg-[#1C1C1E] p-1 rounded-full flex items-center border border-slate-200 dark:border-[#2B2B2F] overflow-x-auto scrollbar-hide">
                    <button
                      type="button"
                      onClick={() => handleAttachmentTypeChange("none")}
                      className={`flex-1 text-center py-1.5 px-2.5 rounded-full text-[9px] sm:text-[10.5px] font-black uppercase tracking-wider transition-all duration-300 shrink-0 ${
                        attachmentType === "none"
                          ? "bg-gradient-to-b from-[#3A3A3C] to-[#1C1C1E] dark:from-[#2C2C2E] dark:to-[#1C1C1E] text-white border border-[#48484A] dark:border-[#2B2B2F] shadow-sm"
                          : "text-slate-555 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                      }`}
                    >
                      Text
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAttachmentTypeChange("image")}
                      className={`flex-1 text-center py-1.5 px-2.5 rounded-full text-[9px] sm:text-[10.5px] font-black uppercase tracking-wider transition-all duration-300 shrink-0 ${
                        attachmentType === "image"
                          ? "bg-gradient-to-b from-[#3A3A3C] to-[#1C1C1E] dark:from-[#2C2C2E] dark:to-[#1C1C1E] text-white border border-[#48484A] dark:border-[#2B2B2F] shadow-sm"
                          : "text-slate-555 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                      }`}
                    >
                      Image
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAttachmentTypeChange("video")}
                      className={`flex-1 text-center py-1.5 px-2.5 rounded-full text-[9px] sm:text-[10.5px] font-black uppercase tracking-wider transition-all duration-300 shrink-0 ${
                        attachmentType === "video"
                          ? "bg-gradient-to-b from-[#3A3A3C] to-[#1C1C1E] dark:from-[#2C2C2E] dark:to-[#1C1C1E] text-white border border-[#48484A] dark:border-[#2B2B2F] shadow-sm"
                          : "text-slate-555 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                      }`}
                    >
                      Video
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAttachmentTypeChange("gif")}
                      className={`flex-1 text-center py-1.5 px-2.5 rounded-full text-[9px] sm:text-[10.5px] font-black uppercase tracking-wider transition-all duration-300 shrink-0 ${
                        attachmentType === "gif"
                          ? "bg-gradient-to-b from-[#3A3A3C] to-[#1C1C1E] dark:from-[#2C2C2E] dark:to-[#1C1C1E] text-white border border-[#48484A] dark:border-[#2B2B2F] shadow-sm"
                          : "text-slate-555 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                      }`}
                    >
                      GIF
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAttachmentTypeChange("poll")}
                      className={`flex-1 text-center py-1.5 px-2.5 rounded-full text-[9px] sm:text-[10.5px] font-black uppercase tracking-wider transition-all duration-300 shrink-0 ${
                        attachmentType === "poll"
                          ? "bg-gradient-to-b from-[#3A3A3C] to-[#1C1C1E] dark:from-[#2C2C2E] dark:to-[#1C1C1E] text-white border border-[#48484A] dark:border-[#2B2B2F] shadow-sm"
                          : "text-slate-555 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                      }`}
                    >
                      Poll
                    </button>
                  </div>
                </div>

                {/* Conditional Upload Box or Preset Lists */}
                {attachmentType === "image" && (
                  <div className="flex flex-col gap-2">
                    <label className="text-[11px] font-black uppercase text-slate-400 dark:text-slate-500 tracking-wider">
                      Upload Image
                    </label>
                    {mediaBase64 && mediaType === "image" ? (
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="relative rounded-3xl overflow-hidden border border-slate-200 dark:border-[#1A1A1A] bg-slate-955 h-44 flex items-center justify-center shadow-sm cursor-pointer group"
                        title="Click image to change"
                      >
                        <img src={mediaBase64} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-xs font-bold gap-1">
                          <Plus size={18} />
                          <span>Change Image</span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); removeMedia(); }}
                          className="absolute top-3 right-3 bg-black/60 hover:bg-black/90 text-white rounded-full p-1.5 transition-colors z-10 shadow-lg"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-slate-200 dark:border-[#1A1A1A] rounded-3xl p-6 bg-slate-50/50 dark:bg-[#1C1C1E]/20 hover:bg-slate-50 dark:hover:bg-[#1C1C1E]/40 cursor-pointer flex flex-col items-center justify-center text-center transition-all group relative h-44"
                      >
                        <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800/80 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-3 group-hover:scale-110 transition-transform">
                          <Image size={20} />
                        </div>
                        <p className="text-xs font-bold text-slate-700 dark:text-slate-350">
                          Click to upload or drag image
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {attachmentType === "video" && (
                  <div className="flex flex-col gap-2">
                    <label className="text-[11px] font-black uppercase text-slate-400 dark:text-slate-500 tracking-wider">
                      Upload Video
                    </label>
                    {mediaBase64 && mediaType === "video" ? (
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="relative rounded-3xl overflow-hidden border border-slate-200 dark:border-[#1A1A1A] bg-slate-955 h-44 flex items-center justify-center shadow-sm cursor-pointer group"
                        title="Click to change video"
                      >
                        <video src={mediaBase64} className="w-full h-full object-cover" controls={false} />
                        <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-xs font-bold gap-1">
                          <Plus size={18} />
                          <span>Change Video</span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); removeMedia(); }}
                          className="absolute top-3 right-3 bg-black/60 hover:bg-black/90 text-white rounded-full p-1.5 transition-colors z-10 shadow-lg"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-slate-200 dark:border-[#1A1A1A] rounded-3xl p-6 bg-slate-50/50 dark:bg-[#1C1C1E]/20 hover:bg-slate-50 dark:hover:bg-[#1C1C1E]/40 cursor-pointer flex flex-col items-center justify-center text-center transition-all group relative h-44"
                      >
                        <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800/80 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-3 group-hover:scale-110 transition-transform">
                          <Video size={20} />
                        </div>
                        <p className="text-xs font-bold text-slate-700 dark:text-slate-350">
                          Click to upload or drag video
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {attachmentType === "gif" && (
                  <div className="flex flex-col gap-2">
                    <label className="text-[11px] font-black uppercase text-slate-400 dark:text-slate-500 tracking-wider">
                      Select Meme GIF
                    </label>
                    <div className="grid grid-cols-4 gap-2 bg-slate-50/50 dark:bg-slate-900/10 p-3 rounded-2xl border border-slate-100 dark:border-slate-800/40">
                      {CURATED_GIFS.map((gif) => (
                        <div
                          key={gif.name}
                          onClick={() => selectPresetGif(gif.url)}
                          className={`aspect-square rounded-xl overflow-hidden border cursor-pointer hover:scale-105 transition-all relative group bg-slate-900 ${
                            mediaBase64 === gif.url 
                              ? "border-zinc-500 shadow-[0_0_0_2px_#71717A]" 
                              : "border-slate-200/40 dark:border-slate-800"
                          }`}
                          title={gif.name}
                        >
                          <img src={gif.url} alt={gif.name} className="w-full h-full object-cover" />
                          {mediaBase64 === gif.url && (
                            <div className="absolute top-1 right-1 w-5 h-5 rounded-full bg-zinc-700 text-white flex items-center justify-center text-[8px] font-black">
                              ✓
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {attachmentType === "poll" && (
                  <div className="p-4 rounded-2xl border border-slate-200 dark:border-[#1A1A1A] bg-slate-50/50 dark:bg-[#121214] space-y-3 shadow-3xs">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide flex items-center gap-1">
                        <BarChart2 size={13} className="text-zinc-500" /> Create Poll
                      </span>
                      <button
                        type="button"
                        onClick={() => handleAttachmentTypeChange("none")}
                        className="text-xs text-rose-500 hover:underline font-bold"
                      >
                        Remove Poll
                      </button>
                    </div>
                    <div className="space-y-2.5">
                      {pollOptions.map((opt, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <input
                            type="text"
                            value={opt}
                            onChange={(e) => handlePollOptionChange(i, e.target.value)}
                            placeholder={`Choice ${i + 1}`}
                            disabled={isSubmitting}
                            maxLength={30}
                            className="flex-1 px-4 py-2 rounded-xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-zinc-800 text-xs font-semibold outline-none focus:border-zinc-500 dark:focus:border-zinc-500 transition-colors text-slate-850 dark:text-slate-200"
                          />
                          {pollOptions.length > 2 && (
                            <button
                              type="button"
                              onClick={() => removePollOption(i)}
                              className="text-slate-400 hover:text-rose-500 p-1 transition-colors"
                            >
                              <Trash2 size={15} />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                    {pollOptions.length < 4 && (
                      <button
                        type="button"
                        onClick={addPollOption}
                        className="flex items-center gap-1.5 text-xs text-zinc-550 hover:text-zinc-650 font-bold mt-1.5 transition-colors"
                      >
                        <Plus size={13} /> Add choice
                      </button>
                    )}
                  </div>
                )}

                {/* AI Post Optimizer & Insights Card - Utilizing empty space down with premium analytics */}
                <div className="bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] p-4 rounded-2xl border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#2B2B2F] mt-3 flex flex-col gap-3">
                  <div className="flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/40 pb-2">
                    <div className="w-5 h-5 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-500 shadow-sm shrink-0">
                      <span className="text-[10px] font-black">★</span>
                    </div>
                    <span className="text-[10px] font-black uppercase text-slate-500 dark:text-slate-400 tracking-wider">
                      AI Post Optimizer
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-[11px] font-bold">
                    <div>
                      <span className="text-slate-400 uppercase tracking-wider text-[8px] block">Engagement Rating</span>
                      <span className={`mt-0.5 block font-sans font-black ${
                        attachmentType === "poll" ? "text-emerald-500" : (attachmentType === "image" || attachmentType === "video" ? "text-amber-500" : "text-slate-600 dark:text-slate-350")
                      }`}>
                        {attachmentType === "poll" ? "92% (Maximum)" : (attachmentType === "image" || attachmentType === "video" ? "85% (Very High)" : "55% (Moderate)")}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 uppercase tracking-wider text-[8px] block">Best Time Frame</span>
                      <span className="text-slate-700 dark:text-slate-300 mt-0.5 block font-sans">
                        {isScheduled ? "Custom Scheduled" : "1:30 PM (London Open)"}
                      </span>
                    </div>
                  </div>

                  <div className="text-[10.5px] font-semibold text-slate-500 dark:text-slate-400 bg-slate-50/50 dark:bg-slate-900/15 p-2 rounded-xl border border-slate-100 dark:border-slate-800/20 leading-relaxed italic">
                    {attachmentType === "none" && (
                      "💡 Tip: Attaching an image or interactive poll yields up to 140% higher clicks from Fialgo funded traders."
                    )}
                    {attachmentType === "image" && (
                      "💡 Tip: High-contrast chart setups and PnL metrics screenshots receive the highest bookmarks from quantitative traders."
                    )}
                    {attachmentType === "video" && (
                      "💡 Tip: Video walkthroughs of systematic setups have a 3.2x higher watch-retention rate."
                    )}
                    {attachmentType === "gif" && (
                      "💡 Tip: Humorous market memes generate highly active discussion threads and positive emoji comments!"
                    )}
                    {attachmentType === "poll" && (
                      "💡 Tip: Active polls stimulate trader interaction! Fialgo members love sharing systematic risk preferences."
                    )}
                  </div>
                </div>

                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept={attachmentType === "video" ? "video/*" : "image/*"}
                  className="hidden"
                />
              </div>

              {/* Details Column */}
              <div className="lg:col-span-7 space-y-4">
                
                {/* Caption Description */}
                <div className="flex flex-col gap-1.5 relative">
                  <label className="text-[11px] font-black uppercase text-slate-455 dark:text-slate-500 tracking-wider">
                    Caption
                  </label>
                  <textarea
                    rows={5}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="A canvas painted by nature, framed by the Alps..."
                    className="w-full px-4 py-3 rounded-2xl bg-white dark:bg-[#1C1C1E] border-2 border-slate-105 dark:border-[#1A1A1A] font-semibold text-xs outline-none focus:border-zinc-500 dark:focus:border-zinc-500 transition-colors shadow-sm resize-none text-slate-700 dark:text-slate-200 leading-relaxed"
                  />
                  <div className="absolute right-3.5 bottom-3.5 flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                      className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-zinc-500 transition-colors"
                    >
                      <Smile size={15} />
                    </button>
                  </div>

                  {/* Popover Emojis */}
                  <AnimatePresence>
                    {showEmojiPicker && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 bottom-full mb-2 p-3 bg-white dark:bg-[#121214] border border-slate-200 dark:border-[#1A1A1A] rounded-2xl shadow-xl z-50 w-48 grid grid-cols-5 gap-1 text-center"
                      >
                        {COMMON_EMOJIS.map((emoji) => (
                          <button
                            key={emoji}
                            type="button"
                            onClick={() => insertEmoji(emoji)}
                            className="w-7 h-7 rounded-lg text-md flex items-center justify-center hover:bg-slate-150 dark:hover:bg-slate-800 transition-colors"
                          >
                            {emoji}
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Location Preset Dropdown */}
                <div className="flex flex-col gap-1.5 relative">
                  <label className="text-[11px] font-black uppercase text-slate-455 dark:text-slate-500 tracking-wider">
                    Location
                  </label>
                  <div
                    onClick={() => setShowLocationDropdown(!showLocationDropdown)}
                    className="w-full px-4 py-3 rounded-2xl bg-white dark:bg-[#1C1C1E] border-2 border-slate-100 dark:border-[#1A1A1A] font-bold text-xs outline-none cursor-pointer flex items-center justify-between text-slate-700 dark:text-slate-200"
                  >
                    <div className="flex items-center gap-2">
                      <MapPin size={14} className="text-slate-400" />
                      <span>{locationName}</span>
                    </div>
                    <ChevronDown size={14} className="text-slate-400" />
                  </div>
                  <AnimatePresence>
                    {showLocationDropdown && (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 5 }}
                        className="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-[#121214] border border-slate-200 dark:border-[#1A1A1A] rounded-2xl shadow-xl z-50 overflow-hidden max-h-[160px] overflow-y-auto amazing-scrollbar"
                      >
                        {PRESET_LOCATIONS.map((loc) => (
                          <div
                            key={loc}
                            onClick={() => {
                              setLocationName(loc);
                              setShowLocationDropdown(false);
                            }}
                            className="px-4 py-2.5 text-xs font-semibold cursor-pointer hover:bg-slate-55/40 dark:hover:bg-slate-800 transition-colors flex items-center justify-between"
                          >
                            <span>{loc}</span>
                            {locationName === loc && <Check size={12} className="text-zinc-500" />}
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* User Tag Chips Input */}
                <div className="flex flex-col gap-1.5 relative">
                  <label className="text-[11px] font-black uppercase text-slate-455 dark:text-slate-500 tracking-wider">
                    Tag
                  </label>
                  <input
                    type="text"
                    value={tagInputText}
                    onChange={(e) => setTagInputText(e.target.value)}
                    onKeyDown={handleAddTag}
                    placeholder="Add people by name or username (Press Enter)"
                    className="w-full px-4 py-3 rounded-2xl bg-white dark:bg-[#1C1C1E] border-2 border-slate-100 dark:border-[#1A1A1A] font-semibold text-xs outline-none focus:border-zinc-500 dark:focus:border-zinc-500 transition-colors shadow-sm text-slate-800 dark:text-white"
                  />
                  
                  {/* User Tag Autocomplete Dropdown - Matches Fialgo's style */}
                  {tagInputText.trim() !== "" && (
                    <div className="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-[#121214] border border-slate-200 dark:border-[#1A1A1A] rounded-2xl shadow-xl z-50 overflow-hidden max-h-[160px] overflow-y-auto amazing-scrollbar">
                      {POPULAR_TRADERS.filter(trader => {
                        const query = tagInputText.replace(/^@/, "").toLowerCase();
                        return trader.username.toLowerCase().includes(query) || trader.name.toLowerCase().includes(query);
                      }).map((trader) => (
                        <div
                          key={trader.username}
                          onClick={() => {
                            const formatted = `@${trader.username}`;
                            if (!tagsList.includes(formatted)) {
                              setTagsList([...tagsList, formatted]);
                            }
                            setTagInputText("");
                          }}
                          className="px-4 py-2.5 hover:bg-slate-55/40 dark:hover:bg-slate-800/80 cursor-pointer transition-colors flex items-center gap-3 border-b border-slate-100/50 dark:border-slate-800/40 last:border-b-0"
                        >
                          <div className="w-7 h-7 rounded-full overflow-hidden shrink-0 border border-slate-200/50 dark:border-slate-700 bg-slate-100">
                            <img src={trader.avatar} alt={trader.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="flex-grow min-w-0">
                            <p className="text-xs font-bold text-slate-800 dark:text-white truncate">{trader.name}</p>
                            <p className="text-[10px] text-slate-450 dark:text-slate-550 font-semibold mt-0.5 truncate">@{trader.username}</p>
                          </div>
                          <Plus size={12} className="text-slate-400 hover:text-zinc-500" />
                        </div>
                      ))}
                    </div>
                  )}

                  {tagsList.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-1.5">
                      {tagsList.map((tag) => (
                        <span
                          key={tag}
                          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-50 dark:bg-zinc-800/30 text-zinc-600 dark:text-zinc-400 text-[10px] font-bold border border-zinc-100 dark:border-zinc-800/30"
                        >
                          <span>{tag}</span>
                          <button
                            type="button"
                            onClick={() => removeTag(tag)}
                            className="w-3.5 h-3.5 rounded-full flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                          >
                            <X size={8} />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Conditional Schedule Post (Spacious aligned iOS switches) */}
                <div className="flex flex-col gap-3 bg-slate-50/50 dark:bg-slate-900/10 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800/40">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-750 dark:text-slate-350">
                      Schedule Post
                    </span>
                    {/* Perfect Tactile iOS switch */}
                    <div
                      onClick={() => setIsScheduled(!isScheduled)}
                      className={`w-11 h-6 rounded-full cursor-pointer transition-colors duration-200 relative shrink-0 ${
                        isScheduled ? "bg-zinc-900 dark:bg-zinc-100" : "bg-slate-200 dark:bg-slate-805"
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full shadow absolute top-0.5 transition-all duration-200 ${
                          isScheduled 
                            ? "left-[22px] bg-white dark:bg-zinc-900" 
                            : "left-[2px] bg-white dark:bg-zinc-400"
                        }`}
                      />
                    </div>
                  </div>

                  {isScheduled && (
                    <motion.div 
                      initial={{ opacity: 0, h: 0 }}
                      animate={{ opacity: 1, h: "auto" }}
                      className="grid grid-cols-2 gap-4 pt-2"
                    >
                      <div className="flex flex-col gap-1 relative">
                        <div className="relative">
                          <Calendar size={13} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                          <input
                            type="date"
                            value={scheduleDate}
                            onChange={(e) => {
                              setScheduleDate(e.target.value);
                              setShowScheduleErrors(false);
                            }}
                            className={`w-full pl-10 pr-4 py-3 rounded-2xl bg-white dark:bg-[#1C1C1E] border-2 font-bold text-xs outline-none transition-colors shadow-sm text-slate-700 dark:text-slate-200 ${
                              showScheduleErrors && !scheduleDate
                                ? "border-rose-500 focus:border-rose-500"
                                : "border-slate-100 dark:border-[#1A1A1A] focus:border-zinc-500 dark:focus:border-zinc-500"
                            }`}
                          />
                        </div>
                        {showScheduleErrors && !scheduleDate && (
                          <span className="text-[10px] text-rose-500 font-bold ml-1.5 mt-0.5">
                            Please choose a date.
                          </span>
                        )}
                      </div>
                      <div className="flex flex-col gap-1 relative">
                        <div className="relative">
                          <Clock size={13} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                          <input
                            type="time"
                            value={scheduleTime}
                            onChange={(e) => {
                              setScheduleTime(e.target.value);
                              setShowScheduleErrors(false);
                            }}
                            className={`w-full pl-10 pr-4 py-3 rounded-2xl bg-white dark:bg-[#1C1C1E] border-2 font-bold text-xs outline-none transition-colors shadow-sm text-slate-700 dark:text-slate-200 ${
                              showScheduleErrors && !scheduleTime
                                ? "border-rose-500 focus:border-rose-500"
                                : "border-slate-100 dark:border-[#1A1A1A] focus:border-zinc-500 dark:focus:border-zinc-500"
                            }`}
                          />
                        </div>
                        {showScheduleErrors && !scheduleTime && (
                          <span className="text-[10px] text-rose-500 font-bold ml-1.5 mt-0.5">
                            Time is required.
                          </span>
                        )}
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Allow comments switch (Perfect Tactile iOS switch) */}
                <div className="flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/10 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800/40">
                  <span className="text-xs font-bold text-slate-750 dark:text-slate-350">
                    Allow comments
                  </span>
                  <div
                    onClick={() => setAllowComments(!allowComments)}
                    className={`w-11 h-6 rounded-full cursor-pointer transition-colors duration-200 relative shrink-0 ${
                      allowComments ? "bg-zinc-900 dark:bg-zinc-100" : "bg-slate-200 dark:bg-slate-805"
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full shadow absolute top-0.5 transition-all duration-200 ${
                        allowComments 
                          ? "left-[22px] bg-white dark:bg-zinc-900" 
                          : "left-[2px] bg-white dark:bg-zinc-400"
                      }`}
                    />
                  </div>
                </div>

                {/* Action Buttons Footer (Clean professional alignment) */}
                <div className="flex items-center justify-end gap-3.5 pt-4 border-t border-slate-100 dark:border-slate-800/60 shrink-0">
                  <button
                    type="button"
                    onClick={onClose}
                    disabled={isSubmitting}
                    className="px-6 py-2.5 rounded-full bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/60 dark:hover:bg-slate-800 text-slate-650 dark:text-slate-300 text-xs font-extrabold transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-8 py-2.5 rounded-full font-extrabold text-xs transition-all active:scale-95 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-100 dark:hover:bg-zinc-200 text-white dark:text-black shadow-[0_4px_12px_-5px_rgba(0,0,0,0.3)] disabled:opacity-75 flex items-center justify-center gap-1.5"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 size={13} className="animate-spin text-white dark:text-black" />
                        Saving...
                      </>
                    ) : (
                      isScheduled 
                        ? (mode === "edit" ? "Update Schedule" : "Schedule Post")
                        : (mode === "edit" ? "Update Post" : "Publish Post")
                    )}
                  </button>
                </div>

              </div>
            </form>
          </div>

          {/* Right Pane: High-Fidelity FIALGO FEED POST Mockup Preview */}
          <div className="w-full lg:w-[420px] bg-[#F4F4F5] dark:bg-[#121214] p-5 md:p-6 flex flex-col justify-between overflow-y-auto amazing-scrollbar shrink-0 border-t lg:border-t-0 border-slate-250 dark:border-slate-800 select-none">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200/50 dark:border-slate-850/30 mb-6">
              <h3 className="text-sm font-black text-slate-850 dark:text-slate-300 tracking-tight">
                Content Preview
              </h3>
              <MoreHorizontal size={16} className="text-slate-400" />
            </div>

            {/* High Fidelity Dynamic Fialgo Feed Post Render */}
            <div className="flex-grow flex items-center justify-center py-6">
              
              <div className="w-[320px] rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#1C1C1E] dark:to-[#121214] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#262626] p-5 flex flex-col gap-4">
                
                {/* Fialgo Post Header */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden shrink-0 border border-slate-250 dark:border-slate-805 object-cover">
                    <img
                      src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80"
                      alt="Avatar"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[13px] font-black text-slate-850 dark:text-slate-200 leading-none">
                        Isabella Nilsson
                      </span>
                      <span className="text-[10px] text-slate-400 font-semibold leading-none">
                        @IsabellaN
                      </span>
                      <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-bold leading-none truncate max-w-[140px]" title={isScheduled && scheduleDate && scheduleTime ? `Scheduled: ${scheduleDate} ${scheduleTime}` : undefined}>
                        · {isScheduled && scheduleDate && scheduleTime ? `Scheduled: ${scheduleDate} ${scheduleTime}` : "Just now"}
                      </span>
                    </div>
                    {locationName && (
                      <div className="flex items-center gap-1 text-[9px] text-slate-400 font-bold mt-1 tracking-wide">
                        <MapPin size={9} className="text-zinc-500" />
                        <span>{locationName}</span>
                      </div>
                    )}
                  </div>
                  <MoreHorizontal size={14} className="text-slate-400" />
                </div>

                {/* Attached media asset (if selected and not a poll or none) - Renders FIRST */}
                {mediaBase64 && attachmentType !== "poll" && attachmentType !== "none" && (
                  <div className="rounded-2xl overflow-hidden border border-slate-200/50 dark:border-slate-800 max-h-[190px] bg-black shadow-sm shrink-0">
                    {mediaType === "video" ? (
                      <video src={mediaBase64} className="w-full h-full object-cover" controls={false} muted autoPlay loop />
                    ) : (
                      <img src={mediaBase64} alt="Attached Media" className="w-full h-full object-cover" />
                    )}
                  </div>
                )}

                {/* Poll Choices Renders styled EXACTLY like the feed block - Renders FIRST */}
                {attachmentType === "poll" && (
                  <div className="space-y-2.5 p-3 rounded-2xl border border-slate-100 dark:border-slate-800/40 bg-slate-50/20 dark:bg-slate-900/10">
                    {pollOptions.map((opt, i) => (
                      <div
                        key={i}
                        className="relative rounded-xl border border-slate-200/50 dark:border-slate-855 bg-white dark:bg-[#1C1C1E] overflow-hidden p-2.5 cursor-pointer hover:border-zinc-500 transition-all flex items-center justify-between"
                      >
                        <span className="text-[10.5px] font-bold text-slate-705 dark:text-slate-250 z-10">
                          {opt || `Choice ${i + 1}`}
                        </span>
                        <span className="text-[10.5px] font-black text-slate-400 z-10 pr-1.5">
                          0%
                        </span>
                        <div className="absolute inset-y-0 left-0 bg-zinc-500/10 transition-all w-0" />
                      </div>
                    ))}
                    <div className="text-[9px] text-slate-455 font-bold tracking-wider uppercase text-center mt-1">
                      0 Votes · Poll Mockup Preview
                    </div>
                  </div>
                )}

                {/* Post Body text - Renders SECOND (down of the media/image) */}
                <p className="text-[11.5px] text-slate-700 dark:text-slate-250 font-medium leading-relaxed break-words">
                  {renderFormattedPreview(content)}
                </p>

                {/* Dynamically tagged users rendered in real-time */}
                {tagsList.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-1 text-[11px] font-bold text-zinc-500 dark:text-zinc-400 select-none">
                    <span>with</span>
                    {tagsList.map((tag, idx) => (
                      <span key={tag} className="hover:underline cursor-pointer">
                        {tag}{idx < tagsList.length - 1 ? "," : ""}
                      </span>
                    ))}
                  </div>
                )}

                {/* Fialgo post action statistics bar */}
                <div className="flex items-center justify-between text-slate-400/80 pt-3 border-t border-slate-100 dark:border-slate-800/50 text-[10.5px] font-bold">
                  <div className="flex items-center gap-1.5 hover:text-rose-500 transition-colors cursor-pointer">
                    <Heart size={14} />
                    <span>0</span>
                  </div>
                  
                  {/* Allow Comments Button working properly */}
                  {allowComments ? (
                    <div className="flex items-center gap-1.5 hover:text-zinc-500 transition-colors cursor-pointer">
                      <MessageSquare size={14} />
                      <span>0</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 text-slate-300 dark:text-slate-700 cursor-not-allowed" title="Comments disabled">
                      <MessageSquare size={14} className="opacity-45" />
                      <span className="text-[9px] font-extrabold uppercase opacity-45">Off</span>
                    </div>
                  )}

                  <div className="flex items-center gap-1.5 text-slate-400 cursor-default">
                    <Globe size={14} className="text-slate-300" />
                    <span>1 view</span>
                  </div>
                  <Share2 size={14} className="hover:text-zinc-500 cursor-pointer" />
                </div>

              </div>

            </div>

            <div className="text-center text-[10px] font-semibold text-slate-400 py-2 border-t border-slate-200/50 dark:border-slate-850/30 shrink-0">
              Matches Fialgo feed card layout exactly.
            </div>
          </div>

        </motion.div>
      </div>
    </AnimatePresence>,
    document.body
  );
}
