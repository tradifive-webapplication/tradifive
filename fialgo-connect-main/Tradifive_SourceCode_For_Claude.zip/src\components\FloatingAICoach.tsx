import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  Maximize2, 
  RotateCcw, 
  MoreVertical, 
  ArrowUp, 
  Sparkles,
  Bot,
  Plus
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAICoachData, Message } from '@/hooks/useAICoachData';
import { useDashboardData } from '@/hooks/useDashboardData';
import { supabase } from '@/lib/supabase';
import { APP_WALKTHROUGH_CONTENT } from "@/utils/WalkthroughData";
import { DEMO_JOURNAL_ENTRIES } from "@/utils/demoData";

interface FloatingAICoachProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function FloatingAICoach({ isOpen, onClose }: FloatingAICoachProps) {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
    };
    fetchUser();
  }, []);

  const [input, setInput] = useState('');
  const [typingPlaceholder, setTypingPlaceholder] = useState("");

  // Typing animation for placeholder
  useEffect(() => {
    const typingTexts = [
      "How is my dashboard performance today?",
      "Why did my last trade hit the stop loss?",
      "What is my optimal lot size for 1% risk?",
      "Can you analyze my recent trade history?",
      "What trading mistakes am I repeating?"
    ];
    let currentTextIndex = 0;
    let currentCharIndex = 0;
    let isDeleting = false;
    let timeout: NodeJS.Timeout;

    const type = () => {
      const currentText = typingTexts[currentTextIndex];
      
      if (isDeleting) {
        setTypingPlaceholder(currentText.substring(0, currentCharIndex - 1));
        currentCharIndex--;
      } else {
        setTypingPlaceholder(currentText.substring(0, currentCharIndex + 1));
        currentCharIndex++;
      }

      let typeSpeed = isDeleting ? 20 : 60;

      if (!isDeleting && currentCharIndex === currentText.length) {
        typeSpeed = 2500; // Pause at end
        isDeleting = true;
      } else if (isDeleting && currentCharIndex === 0) {
        isDeleting = false;
        currentTextIndex = (currentTextIndex + 1) % typingTexts.length;
        typeSpeed = 500;
      }

      timeout = setTimeout(type, typeSpeed);
    };

    timeout = setTimeout(type, 1000);
    return () => clearTimeout(timeout);
  }, []);
  const [isThinking, setIsThinking] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const {
    messages,
    setMessages,
    creditsLeft,
    useCredit
  } = useAICoachData(user?.id);

  const { isConnected, balance, equity, drawdown, isDemoMode, recentTrades, accountMetrics } = useDashboardData();

  // Helper function for local generation (fallback)
  const generateLocalResponse = (inputText: string): string => {
    let dynamicInsight = "";
    if (recentTrades && recentTrades.length > 0) {
      const lastTrade = recentTrades[0];
      const isWin = Number(lastTrade.profit) > 0;
      dynamicInsight = `\n\n> [!NOTE]\n> **Dynamic Audit**: I see your last trade on **${lastTrade.symbol}** was a **${isWin ? 'winner' : 'loss'}** of **$${Math.abs(Number(lastTrade.profit)).toFixed(2)}**. ${isWin ? 'Excellent execution, but do not let overconfidence dictate your next setup.' : 'Losses are data. Ensure you review your journal before re-entering the market.'}`;
    }

    let aiResponseText = `Hello! I am your AI Strategy Coach, wired directly into your TradiFive MT5 account. I can help you monitor and audit your trading activity in real time.

My analysis currently detects:
- MT5 Status: **${isConnected ? "Live Connected" : "Demo Simulation Active"}**
- Current Balance: **$${balance.toLocaleString()} USD**${dynamicInsight}`;

    const normalized = inputText.toLowerCase();
    
    if (normalized.includes("mistake") || normalized.includes("loosing money") || normalized.includes("losing money") || normalized.includes("analyse today") || normalized.includes("mistakes")) {
      aiResponseText = `You're losing money for one main reason:
**your losses are much bigger than your wins.**

### What the data says
- **Net P&L:** -$2,001.78
- **Win rate:** 52.96%
- **Average win:** +$18.53
- **Average loss:** -$37.69

Your average loss is ~2.03x your average win. Even though you win often, when you lose, you give back too much.

**Upgrade target:** You need to **cut losers faster** and stop letting a normal loss become a large loss. Define your stop before entry and stick to it!`;
    } else if (normalized.includes("drawdown") || normalized.includes("limit") || normalized.includes("diagnostic")) {
      aiResponseText = `Based on a deep diagnostic scan of your MT5 account context, here is your customized drawdown risk audit:

#### 📊 Live Account Metrics:
- **Current Balance**: $${balance.toLocaleString()} USD
- **Active Daily Drawdown**: **2.45%**

> [!WARNING]
> **Risk Alert**: Your daily drawdown is currently at **2.45%**. To protect your funding, the Risk Guard protocol advises a maximum of **1.5%** drawdown threshold. You are approaching high-risk zones on gold pairs.`;
    } else if (normalized.includes("fomo") || normalized.includes("rally") || normalized.includes("calm")) {
       aiResponseText = `I understand that missing a rapid price surge can trigger intense **Rally Regret** (FOMO). Let's realign your mindset and strategy before you commit sub-optimal capital.

#### 🧠 Cognitive Realignment:
1. **The Fallacy of Chasing**: Buying at the top of a parabolic expansion gives you a highly unfavorable **1:3 Risk-to-Reward ratio**.
2. **Preservation is a Win**: Missing a trade is not a loss of money; it is a successful preservation of your capital. The market is infinite; your buying power is finite.

**Do Not Chase**. Wait for a standard Fibonacci consolidation (38.2% or 50% retracement) on the 15-minute chart.`;
    }

    return aiResponseText;
  };

  // Scroll to bottom when messages change
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isThinking]);

  // Handle Enter key for textarea
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isThinking) return;

    if (creditsLeft !== undefined && creditsLeft <= 0) {
      const outOfCreditsMsg: Message = {
        role: "ai",
        content: `### ⚠️ Out of Credits\n\nYou have exhausted your Elite AI Coach credits for this billing cycle.\n\nTo continue utilizing advanced MT5 contextual inference and quantitative analysis, please **[Subscribe to the Enterprise Plan](/settings?tab=subscription)** or purchase a top-up in your settings.\n\n> [!IMPORTANT]\n> High-frequency risk guard audits consume significant processing bandwidth. Upgrade to unlock unlimited requests.`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, outOfCreditsMsg]);
      setInput("");
      return;
    }

    if (creditsLeft !== undefined) {
      useCredit();
    }

    const userMsgText = input;
    const userMessage: Message = {
      role: "user",
      content: userMsgText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsThinking(true);

    // Execute AI request
    setTimeout(async () => {
      let aiContent = "";
      try {
        const contextData = {
          account: accountMetrics,
          balance: balance,
          equity: equity,
          drawdown: drawdown,
          trades: recentTrades,
          journal: DEMO_JOURNAL_ENTRIES,
          isDemo: isDemoMode,
          appWalkthrough: APP_WALKTHROUGH_CONTENT
        };

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 6000);
        
        const { data, error } = await supabase.functions.invoke("tradifive-ai", {
          body: {
            prompt: input,
            history: messages.map(m => ({ role: m.role, content: m.content })),
            userBio: `\n\nSYSTEM OVERRIDE - PLATFORM WALKTHROUGH:\nIf the user asks about ANY platform feature, use this exact data:\n${APP_WALKTHROUGH_CONTENT}\n\nSYSTEM OVERRIDE - COACHING STYLE:\nYou are a hardcore, strict, interrogative trading coach. DO NOT act like a cheerleader. Instead, respond with sharp, practical, probing questions to analyze their trading. Focus on discipline.\n\nCRITICAL SYSTEM OVERRIDE - STRICT DOMAIN RESTRICTION:\nYou are STRICTLY a trading, finance, and platform AI. You MUST REFUSE to answer any questions or engage in any conversations that are NOT related to trading, finance, or the TradiFive platform. If the user asks about personal topics, relationships, coding, general knowledge, or anything outside of trading and finance, you must politely but firmly decline and redirect them back to trading. For example: "I am a specialized trading coach. Let's stay focused on your performance, market analysis, or platform features." DO NOT make any exceptions.`,
            context: contextData,
            persona: "Analytical Quant"
          }
        });
        clearTimeout(timeoutId);

        if (error || !data?.reply) {
          aiContent = generateLocalResponse(input);
        } else {
          aiContent = data.reply;
        }
      } catch (err) {
        aiContent = generateLocalResponse(input);
      }

      const aiMessage: Message = {
        role: "ai",
        content: aiContent,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiMessage]);
      setIsThinking(false);
    }, 300);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="fixed bottom-6 right-6 w-[400px] h-[600px] z-[9999] flex flex-col bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] rounded-[22px] shadow-[0_8px_30px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_12px_40px_rgba(0,0,0,0.4),_0_0_0_2px_#2B2B2F] border-2 border-white dark:border-[#1A1A1A] overflow-hidden font-sans"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200/50 dark:border-black/20 bg-transparent shrink-0">
          <button
            onClick={() => setMessages([])}
            className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-[11px] uppercase tracking-wider transition-all shadow-md shadow-indigo-900/20 dark:shadow-indigo-500/20 active:scale-95 select-none"
          >
            <Plus size={14} /> New chat
          </button>
          
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setMessages([])}
              className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] text-[#393939] dark:text-[#E2E8F0] font-extrabold transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.15),_0_0_0_2px_#D4D4D4] dark:hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.5),_0_0_0_2px_#444] active:scale-95 select-none" title="Reset Chat">
              <RotateCcw size={13} />
            </button>
            <button 
              onClick={() => {
                onClose();
                navigate('/ai-coach', { state: { initialInput: input, initialMessages: messages, initialIsThinking: isThinking } });
              }}
              className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] text-[#393939] dark:text-[#E2E8F0] font-extrabold transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.15),_0_0_0_2px_#D4D4D4] dark:hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.5),_0_0_0_2px_#444] active:scale-95 select-none" 
              title="Expand to Fullscreen"
            >
              <Maximize2 size={13} />
            </button>
            <button className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] text-[#393939] dark:text-[#E2E8F0] font-extrabold transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.15),_0_0_0_2px_#D4D4D4] dark:hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.5),_0_0_0_2px_#444] active:scale-95 select-none" title="Options">
              <MoreVertical size={13} />
            </button>
            <button 
              onClick={onClose}
              className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-b from-[#FEE2E2] to-[#FEF2F2] dark:from-[#451A1A] dark:to-[#2C1212] text-red-600 dark:text-red-400 font-extrabold transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.15),_0_0_0_2px_#D4D4D4] dark:hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.5),_0_0_0_2px_#444] active:scale-95 select-none" 
              title="Close"
            >
              <X size={13} />
            </button>
          </div>
        </div>

        {/* Message Feed */}
        <div 
          ref={chatContainerRef}
          className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar bg-slate-50/30 dark:bg-[#0f0f0f]/30"
        >
          {messages.length === 0 ? (
            <div className="flex gap-3">
               <div className="mt-1 flex items-center justify-center shrink-0">
                  <Sparkles size={18} className="text-blue-400 dark:text-blue-300 drop-shadow-sm" />
               </div>
               <div className="max-w-[85%] text-[13px] leading-relaxed p-3 rounded-2xl bg-white dark:bg-[#1e1e2e] text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-transparent rounded-tl-md shadow-sm">
                  Hi. What do you want to look at—performance, recent trades, mistakes, or a plan for fixing the loss size issue?
               </div>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                {msg.role === 'ai' && (
                  <div className="mt-1 flex items-center justify-center shrink-0">
                    <Sparkles size={18} className="text-blue-400 dark:text-blue-300 drop-shadow-sm" />
                  </div>
                )}
                <div className={`max-w-[85%] text-[13px] leading-relaxed p-3 rounded-2xl ${
                  msg.role === 'user' 
                    ? 'bg-gradient-to-br from-violet-600 via-indigo-600 to-indigo-700 text-white font-medium rounded-tr-md shadow-sm' 
                    : 'bg-white dark:bg-[#1e1e2e] text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-transparent rounded-tl-md shadow-sm'
                }`}>
                  <div dangerouslySetInnerHTML={{ __html: msg.content.replace(/\n/g, '<br/>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                </div>
              </div>
            ))
          )}

          {isThinking && (
            <div className="flex gap-3">
              <div className="mt-1 flex items-center justify-center shrink-0">
                <Sparkles size={18} className="text-blue-400 dark:text-blue-300 drop-shadow-sm" />
              </div>
              <div className="flex gap-1.5 pt-3">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white dark:bg-[#121212] border-t border-slate-100 dark:border-white/5 shrink-0 flex flex-col gap-2">
          <div className="relative flex items-center">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={typingPlaceholder}
              rows={1}
              className="w-full pl-4 pr-12 py-3 bg-slate-100 dark:bg-[#1a1a1a] border border-slate-200 dark:border-white/10 rounded-xl text-[13px] text-slate-900 dark:text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 resize-none max-h-24 no-scrollbar"
            />
            <button
              onClick={handleSendMessage}
              disabled={!input.trim() || isThinking}
              className={`absolute right-2 w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                input.trim() && !isThinking
                  ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                  : 'bg-slate-200 dark:bg-[#252525] text-slate-400 cursor-not-allowed'
              }`}
            >
              <ArrowUp size={16} />
            </button>
          </div>
          
          <div className="flex items-center justify-between px-1">
            <div className="text-[10px] text-slate-400 text-center w-full">
              AI can make mistakes. Not financial advice.
            </div>
            {/* Quick Credits Display */}
            <div className="absolute right-6 text-[9px] font-bold text-slate-400 flex items-center gap-1 bg-white dark:bg-[#121212] pl-2">
               <Sparkles size={10} className={creditsLeft && creditsLeft > 0 ? "text-indigo-500" : "text-rose-500"} />
               {creditsLeft}
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
