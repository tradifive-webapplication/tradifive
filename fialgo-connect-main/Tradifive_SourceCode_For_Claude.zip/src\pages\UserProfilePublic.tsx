import React, { useState, useEffect } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { useParams, Link, useNavigate } from "react-router-dom";
import { 
  CheckCircle2, MapPin, Calendar, MoreHorizontal, 
  Search, Heart, MessageCircle, Bookmark, Share2, 
  TrendingUp, Globe, Flame, ShieldCheck, Trophy,
  Star, BarChart2, FileText, Shield, Info, Target, Scale,
  Crown, ArrowRight, ChevronDown, Radio, Play, UserPlus, UserCheck, Mail
} from "lucide-react";
import { supabase } from "@/lib/supabase";
import FeedCard from "@/components/FeedCard";
import { toast } from "sonner";

// Placeholder display names to filter out from suggestions
const PLACEHOLDER_NAMES = ["new trader", "guest trader", "demo trader", "trader", "guest"];

// --- MOCK FALLBACK TRADES ---
const MOCK_TRADES_FALLBACK = [
  { id: "t1", ticket: "8472910", symbol: "XAUUSD", profit: 1420.50, trade_type: 0, lot_size: 2.0, closed_at: new Date(Date.now() - 3600000 * 4).toISOString(), created_at: new Date(Date.now() - 3600000 * 5).toISOString() },
  { id: "t2", ticket: "8472911", symbol: "EURUSD", profit: -340.00, trade_type: 1, lot_size: 1.5, closed_at: new Date(Date.now() - 3600000 * 12).toISOString(), created_at: new Date(Date.now() - 3600000 * 13).toISOString() },
  { id: "t3", ticket: "8472912", symbol: "GBPUSD", profit: 890.20, trade_type: 0, lot_size: 1.0, closed_at: new Date(Date.now() - 3600000 * 24).toISOString(), created_at: new Date(Date.now() - 3600000 * 25).toISOString() },
  { id: "t4", ticket: "8472913", symbol: "XAUUSD", profit: 2450.00, trade_type: 0, lot_size: 3.0, closed_at: new Date(Date.now() - 3600000 * 48).toISOString(), created_at: new Date(Date.now() - 3600000 * 50).toISOString() },
  { id: "t5", ticket: "8472914", symbol: "USDCAD", profit: -120.00, trade_type: 1, lot_size: 1.0, closed_at: new Date(Date.now() - 3600000 * 72).toISOString(), created_at: new Date(Date.now() - 3600000 * 73).toISOString() }
];

function PollBlock({ 
  post, 
  currentUserId, 
  onVoteSuccess 
}: { 
  post: any; 
  currentUserId: string; 
  onVoteSuccess: () => void;
}) {
  const votedOptionKey = `tradifive_voted_poll_${post.id}`;
  const [votedOption, setVotedOption] = useState<number | null>(() => {
    const val = localStorage.getItem(votedOptionKey);
    return val !== null ? Number(val) : null;
  });

  let pollData: { options: string[]; votes: number[] } | null = null;
  if (post.post_type === "poll" && post.media_url) {
    try {
      pollData = JSON.parse(post.media_url);
    } catch (e) {}
  }

  if (!pollData) return null;

  const handleVoteOption = async (index: number) => {
    if (!pollData || votedOption !== null || post.user_id === currentUserId) return;
    const updatedVotes = [...pollData.votes];
    updatedVotes[index]++;
    const updatedPoll = { ...pollData, votes: updatedVotes };
    
    localStorage.setItem(votedOptionKey, String(index));
    setVotedOption(index);
    
    try {
      const { error } = await supabase
        .from('social_posts')
        .update({ media_url: JSON.stringify(updatedPoll) })
        .eq('id', post.id);
      if (error) throw error;
      onVoteSuccess();
    } catch (err) {
      console.error("Error voting:", err);
    }
  };

  const totalPollVotes = pollData.votes.reduce((a, b) => a + b, 0);
  const hasVotedOrOwns = votedOption !== null || post.user_id === currentUserId;

  return (
    <div className="mb-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/30 dark:bg-slate-900/10 space-y-3">
      {pollData.options.map((opt, idx) => {
        const votes = pollData!.votes[idx] || 0;
        const percentage = totalPollVotes > 0 ? Math.round((votes / totalPollVotes) * 100) : 0;
        
        return hasVotedOrOwns ? (
          <div key={idx} className="relative w-full p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-[#0B0D18] overflow-hidden select-none font-semibold text-xs text-slate-800 dark:text-white flex items-center justify-between">
            <div 
              className="absolute left-0 top-0 bottom-0 bg-blue-500/10 dark:bg-blue-500/15 transition-all duration-500" 
              style={{ width: `${percentage}%` }}
            />
            <span className="relative z-10 flex items-center gap-2 font-bold">
              {opt} {votedOption === idx && <span className="text-[10px] text-blue-500 font-extrabold">(Your Vote)</span>}
            </span>
            <span className="relative z-10 font-extrabold text-slate-700 dark:text-slate-355">
              {percentage}% ({votes})
            </span>
          </div>
        ) : (
          <button
            key={idx}
            onClick={() => handleVoteOption(idx)}
            className="w-full text-left p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-600 hover:bg-blue-50/10 dark:hover:bg-blue-500/5 transition-all font-semibold text-xs text-slate-700 dark:text-slate-300 hover:text-blue-500 select-none cursor-pointer"
          >
            {opt}
          </button>
        );
      })}
      <div className="text-[10.5px] font-bold text-slate-400 dark:text-slate-500 px-1 pt-1 flex justify-between">
        <span>Total: {totalPollVotes} vote{totalPollVotes !== 1 ? 's' : ''}</span>
        {post.user_id === currentUserId && <span className="text-blue-500">Your Poll</span>}
      </div>
    </div>
  );
}

export default function UserProfilePublic() {
  const { username } = useParams<{ username: string }>();
  const [currentUserId, setCurrentUserId] = useState<string>("");
  
  const [profile, setProfile] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>("Posts");
  
  // Follow/Profile Stats matching image exactly
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [ownPostsCount, setOwnPostsCount] = useState(0);
  const [followedByCount, setFollowedByCount] = useState(0);

  // Dynamic calculated metrics states
  const [totalTradesCount, setTotalTradesCount] = useState<number>(0);
  const [winRateVal, setWinRateVal] = useState<string>("0%");
  const [roiVal, setRoiVal] = useState<string>("0.00%");
  const [avgRRVal, setAvgRRVal] = useState<string>("1 : 0.0");
  const [streakVal, setStreakVal] = useState<string>("0 Days");

  // Privacy Settings state
  const [privacySettings, setPrivacySettings] = useState({
    show_location: true,
    show_winrate: true,
    show_roi: true,
    show_streak: true,
    show_trades: true,
    is_private: false,
    account_type: 'personal' as 'personal' | 'creator' | 'business'
  });

  const [publicTrades, setPublicTrades] = useState<any[]>([]);
  const [userChannel, setUserChannel] = useState<any>(null);
  const [levelVal, setLevelVal] = useState(14);
  const [xpVal, setXpVal] = useState(2450);
  const [xpRequiredVal, setXpRequiredVal] = useState(5000);

  // Interaction States
  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});
  const [likesOffsets, setLikesOffsets] = useState<Record<string, number>>({});
  const [followedUsers, setFollowedUsers] = useState<Record<string, boolean>>({});
  const [suggestedTraders, setSuggestedTraders] = useState<any[]>([]);

  useEffect(() => {
    fetchProfileAndData();
  }, [username]);

  const fetchProfileAndData = async () => {
    setLoading(true);
    try {
      const lowerUsername = username?.toLowerCase() || "";
      
      let loadedPrivacy: any = {
        show_location: true,
        show_winrate: true,
        show_roi: true,
        show_streak: true,
        show_trades: true,
        is_private: false,
        account_type: 'personal'
      };

      // Try loading privacy settings from localStorage
      const storedPrivacyStr = localStorage.getItem(`tradifive_privacy_user_${lowerUsername}`);
      if (storedPrivacyStr) {
        try {
          loadedPrivacy = { ...loadedPrivacy, ...JSON.parse(storedPrivacyStr) };
        } catch (e) {}
      }

      let profileId = "";

      // ALWAYS query Supabase first for real profile data
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .ilike('username', lowerUsername)
        .maybeSingle();

      if (profileData) {
        // Real profile found in database
        setProfile(profileData);
        profileId = profileData.id;
        
        // Try loading privacy from localStorage by id
        const idPrivacyStr = localStorage.getItem(`tradifive_privacy_${profileData.id}`);
        if (idPrivacyStr) {
          try {
            const parsed = JSON.parse(idPrivacyStr);
            setPrivacySettings({ ...loadedPrivacy, ...parsed });
          } catch(e) {
            setPrivacySettings(loadedPrivacy);
          }
        } else {
          setPrivacySettings(loadedPrivacy);
        }

        // Fetch posts for this user
        const { data: postsData, error: postsErr } = await supabase
          .from('social_posts')
          .select(`*, profiles:user_id (*)`)
          .eq('user_id', profileData.id)
          .order('created_at', { ascending: false });
        
        if (!postsErr && postsData) {
          setPosts(postsData);
          setOwnPostsCount(postsData.length);
        } else {
          setPosts([]);
          setOwnPostsCount(0);
        }

        // Fetch channel for this user
        const { data: channelData } = await supabase
          .from('channels')
          .select('*')
          .eq('created_by', profileData.id)
          .maybeSingle();
        setUserChannel(channelData);
      } else {
        // User not found in database — show generic placeholder profile
        const placeholderProfile = {
          id: 'not-found',
          display_name: username ? username.charAt(0).toUpperCase() + username.slice(1) : "Unknown Trader",
          username: username || "unknown",
          bio: "This trader hasn't set up their profile yet.",
          avatar_url: `https://api.dicebear.com/7.x/initials/svg?seed=${username || "U"}`,
          banner_url: "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1200&fit=crop&q=80",
          location: "",
          country: "",
          country_emoji: "🌍"
        };
        setProfile(placeholderProfile);
        profileId = placeholderProfile.id;
        setPrivacySettings(loadedPrivacy);
        setPosts([]);
        setOwnPostsCount(0);
      }

      // Fetch Trades for stats calculations (only for real DB profiles)
      if (profileId && profileId !== 'not-found' && !profileId.startsWith('mock-')) {
        const { count: followers } = await supabase
          .from('social_follows')
          .select('*', { count: 'exact', head: true })
          .eq('following_id', profileId);

        const { count: following } = await supabase
          .from('social_follows')
          .select('*', { count: 'exact', head: true })
          .eq('follower_id', profileId);

        if (followers !== null) setFollowerCount(followers);
        if (following !== null) setFollowingCount(following);

        const { data: { user: currentUser } } = await supabase.auth.getUser();
        if (currentUser) {
          setCurrentUserId(currentUser.id);
          const { data: followRecord } = await supabase
            .from('social_follows')
            .select('*')
            .eq('follower_id', currentUser.id)
            .eq('following_id', profileId)
            .maybeSingle();

          // Fetch all follows of current user
          const { data: allFollows } = await supabase
            .from('social_follows')
            .select('following_id')
            .eq('follower_id', currentUser.id);

          const map: Record<string, boolean> = { [profileId]: !!followRecord };
          if (allFollows) {
            allFollows.forEach((f: any) => {
              map[f.following_id] = true;
            });
          }
          setFollowedUsers(map);

          // Fetch Liked Posts
          const { data: likedData } = await supabase
            .from('social_post_likes')
            .select('post_id')
            .eq('user_id', currentUser.id);
          if (likedData) {
            const likedMap: Record<string, boolean> = {};
            likedData.forEach(item => { likedMap[item.post_id] = true; });
            setLikedPosts(likedMap);
          }

          // Fetch Suggested Traders from database (users other than logged-in user)
          const { data: sugData } = await supabase
            .from('profiles')
            .select('id, display_name, username, avatar_url, win_rate, bio')
            .neq('id', currentUser.id)
            .limit(10);
          if (sugData) {
            // Filter out placeholder/mock profiles
            const realTraders = sugData.filter((p: any) => {
              const name = (p.display_name || '').trim().toLowerCase();
              return name.length > 0 && !PLACEHOLDER_NAMES.includes(name);
            }).slice(0, 5);
            setSuggestedTraders(realTraders);
          }
        }

        const { data: tradesData } = await supabase
          .from('trades')
          .select('*')
          .eq('user_id', profileId);

        if (tradesData && tradesData.length > 0) {
          const total = tradesData.length;
          const wins = tradesData.filter((t: any) => Number(t.profit) > 0).length;
          const wr = total > 0 ? Math.round((wins / total) * 100) : 0;
          const pnlSum = tradesData.reduce((acc: number, t: any) => acc + Number(t.profit || 0), 0);
          
          setTotalTradesCount(total);
          setWinRateVal(`${wr}%`);
          
          let currentStreak = 0;
          const sortedTrades = [...tradesData].sort((a: any, b: any) => new Date(b.closed_at || b.created_at).getTime() - new Date(a.closed_at || a.created_at).getTime());
          for (const t of sortedTrades) {
            if (Number(t.profit) > 0) {
              currentStreak++;
            } else {
              break;
            }
          }
          setStreakVal(`${currentStreak} Day${currentStreak !== 1 ? 's' : ''}`);

          // Fetch balance for ROI
          const { data: mt5Data } = await supabase
            .from('mt5_accounts')
            .select('balance')
            .eq('user_id', profileId)
            .maybeSingle();

          const balance = mt5Data?.balance || 10000;
          const roiPercent = balance > 0 ? (pnlSum / balance) * 100 : 0;
          setRoiVal((pnlSum >= 0 ? "+" : "") + roiPercent.toFixed(2) + "%");
          setPublicTrades(tradesData);
        } else {
          setTotalTradesCount(0);
          setWinRateVal("0%");
          setStreakVal("0 Days");
          setRoiVal("0.00%");
          setPublicTrades([]);
        }
      } else {
        setTotalTradesCount(0);
        setWinRateVal("0%");
        setStreakVal("0 Days");
        setRoiVal("0.00%");
        setPublicTrades([]);
      }

      // Load gamification stats for this target user
      if (username && currentUserId) {
        // Check if viewing own profile
        const { data: currentProfile } = await supabase
          .from('profiles')
          .select('username')
          .eq('id', currentUserId)
          .maybeSingle();
        
        const isSelf = currentProfile?.username?.toLowerCase() === username.toLowerCase();
        if (isSelf) {
          const selfGam = localStorage.getItem("tradifive_gamification_state");
          if (selfGam) {
            try {
              const parsed = JSON.parse(selfGam);
              setLevelVal(parsed.level || 1);
              setXpVal(parsed.xp || 0);
              setXpRequiredVal(parsed.xp_required || 1000);
            } catch (e) {}
          }
        } else {
          // Fallback level for other public profiles
          const seed = username.length;
          const userLevel = 10 + (seed % 15);
          setLevelVal(userLevel);
          setXpVal(Math.floor(500 * Math.pow(userLevel, 1.1) * 0.4));
          setXpRequiredVal(Math.floor(500 * Math.pow(userLevel, 1.2)));
        }
      }

    } catch (err) {
      console.error(err);
      setPosts([]);
      setPublicTrades([]);
      setTotalTradesCount(0);
      setWinRateVal("0%");
      setStreakVal("0 Days");
      setRoiVal("0.00%");
    } finally {
      setLoading(false);
    }
  };

  const toggleFollowUser = async (targetUserId: string, targetName: string) => {
    // Block follows on placeholder/non-DB profiles
    if (!targetUserId || targetUserId === 'not-found' || targetUserId.startsWith('mock-')) {
      toast.error("This user hasn't set up their profile yet.");
      return;
    }

    const { data: { user: currentUser } } = await supabase.auth.getUser();
    if (!currentUser) {
      toast.error("Please login to follow traders.");
      return;
    }
    if (targetUserId === currentUser.id) {
      toast.error("You cannot follow yourself.");
      return;
    }

    const isFollowing = followedUsers[targetUserId] || false;
    
    // Optimistic UI updates
    setFollowedUsers(prev => ({ ...prev, [targetUserId]: !isFollowing }));
    setFollowerCount(prev => prev + (isFollowing ? -1 : 1));

    try {
      if (isFollowing) {
        const { error } = await supabase
          .from('social_follows')
          .delete()
          .eq('follower_id', currentUser.id)
          .eq('following_id', targetUserId);
        if (error) throw error;
        toast.info(`Unfollowed ${targetName}`);
      } else {
        const { error } = await supabase
          .from('social_follows')
          .insert([{ follower_id: currentUser.id, following_id: targetUserId }]);
        if (error) throw error;
        toast.success(`Followed ${targetName}`);
      }
    } catch (err: any) {
      console.error("Error toggling follow:", err);
      toast.error("Failed to update follow status.");
      // Revert optimistic updates
      setFollowedUsers(prev => ({ ...prev, [targetUserId]: isFollowing }));
      setFollowerCount(prev => prev + (isFollowing ? 1 : -1));
    }
  };

  const navigate = useNavigate();

  const handleStartConversation = async () => {
    try {
      // Always fetch current auth user at click time (don't rely on state)
      const { data: { user: authUser } } = await supabase.auth.getUser();
      if (!authUser) {
        toast.error("Please log in to send messages.");
        return;
      }

      const targetId = profile?.id;
      if (!targetId || targetId === 'not-found' || targetId.startsWith('mock-')) {
        toast.error("This user hasn't set up their profile yet.");
        return;
      }

      if (authUser.id === targetId) {
        toast.error("You cannot message yourself.");
        return;
      }

      // Ensure consistent ordering for the unique constraint
      const user1_id = authUser.id < targetId ? authUser.id : targetId;
      const user2_id = authUser.id > targetId ? authUser.id : targetId;

      // Check if conversation already exists
      const { data: existing } = await supabase
        .from('dm_conversations')
        .select('id')
        .eq('user1_id', user1_id)
        .eq('user2_id', user2_id)
        .maybeSingle();

      if (existing) {
        navigate(`/inbox?conv=${existing.id}`);
        return;
      }

      // Also check with reversed order (in case ordering wasn't enforced before)
      const { data: existingReversed } = await supabase
        .from('dm_conversations')
        .select('id')
        .eq('user1_id', user2_id)
        .eq('user2_id', user1_id)
        .maybeSingle();

      if (existingReversed) {
        navigate(`/inbox?conv=${existingReversed.id}`);
        return;
      }

      // Create new conversation
      const { data: created, error } = await supabase
        .from('dm_conversations')
        .insert({
          user1_id,
          user2_id,
          last_message_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) {
        console.error('DM conversation insert error:', error);
        // If insert fails (RLS, FK, etc.), still navigate to inbox
        toast.info("Opening inbox...");
        navigate('/inbox');
        return;
      }

      navigate(`/inbox?conv=${created.id}`);
    } catch (err) {
      console.error('Error starting conversation:', err);
      // Fallback: navigate to inbox anyway
      toast.info("Opening inbox...");
      navigate('/inbox');
    }
  };

  const handleLikePost = async (postId: string) => {
    if (!currentUserId) {
      toast.error("Please log in to like posts.");
      return;
    }
    const isCurrentlyLiked = likedPosts[postId] || false;
    const nextLiked = !isCurrentlyLiked;
    
    // Optimistic UI update
    setLikedPosts(prev => ({ ...prev, [postId]: nextLiked }));
    setLikesOffsets(prev => ({
      ...prev,
      [postId]: (prev[postId] || 0) + (nextLiked ? 1 : -1)
    }));

    try {
      if (nextLiked) {
        await supabase.from('social_post_likes').insert([{ post_id: postId, user_id: currentUserId }]);
      } else {
        await supabase.from('social_post_likes').delete().eq('post_id', postId).eq('user_id', currentUserId);
      }
      // Fallback for missing SQL triggers
      const { data: postData } = await supabase.from('social_posts').select('like_count').eq('id', postId).single();
      const currentCount = postData?.like_count || 0;
      const newCount = nextLiked ? currentCount + 1 : Math.max(0, currentCount - 1);
      await supabase.from('social_posts').update({ like_count: newCount }).eq('id', postId);
    } catch (err) {
      console.error("Error toggling like:", err);
    }
  };

  const formatCount = (baseVal: number, offset: number) => {
    const total = Math.max(0, baseVal + offset);
    if (total >= 1000) {
      return (total / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
    }
    return total.toString();
  };

  const headerActions = (
    <div className="flex items-center gap-4">
    </div>
  );

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home", path: "/home" }, { label: `@${username || "user"}`, path: `/user/${username || "user"}` }]} headerActions={headerActions} noScroll={true} noPadding={true}>
      <div className="w-full h-full flex flex-col min-h-0 px-4 lg:px-10 pt-6 pb-6 overflow-y-auto amazing-scrollbar select-none font-sans text-slate-800 dark:text-slate-100 bg-[#F8FAFC] dark:bg-[#07090E]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0 relative max-w-7xl mx-auto w-full">
          
          {/* --- LEFT & MIDDLE MAIN CONTENT (col-span-9) --- */}
          <div className="lg:col-span-9 space-y-6">
            
            {/* Header Card (Consistent Tactile Neumorphic / Claymorphic Outer container with dual-border & soft shadow specs) */}
            <div className="bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#181D30] dark:to-[#0E121F] rounded-[32px] overflow-hidden border-2 border-white dark:border-[#1E2538] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#262F47] relative">
              
              {/* Cover Banner */}
              <div className="h-44 sm:h-52 w-full relative bg-slate-900 overflow-hidden border-b border-white/10 dark:border-[#1E2538]">
                {loading ? (
                  <div className="w-full h-full animate-pulse bg-slate-350 dark:bg-slate-800" />
                ) : (
                  <div className="w-full h-full relative">
                    <img 
                      src={profile?.banner_url || "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1200&fit=crop&q=80"} 
                      alt="Cover" 
                      className="w-full h-full object-cover opacity-90 scale-105"
                    />
                    {/* Blue/Cyberpunk gradient overlays to match image banner */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/20" />
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-900/30 to-purple-950/40 mix-blend-multiply" />
                  </div>
                )}


                {/* Cover Banner Crown pill status */}
                <div className="absolute bottom-4 right-6 bg-[#000000]/45 backdrop-blur-md text-white text-[11px] font-extrabold px-3.5 py-2 rounded-full flex items-center gap-1.5 border border-white/10 shadow-lg">
                  <Crown size={12} className="text-yellow-400 fill-yellow-400" />
                  <span>Elite Trader</span>
                </div>
              </div>

              {/* Profile Details Area */}
              <div className="px-8 pb-5 relative pt-4">
                
                {/* Horizontal Layout containing Avatar & Stats top-level row */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                  
                  {/* Left: Avatar container overlapping covers */}
                  <div className="relative -mt-16 sm:-mt-20 shrink-0">
                    <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-white dark:border-[#1A2238] overflow-hidden bg-white dark:bg-[#0E121F] relative">
                      {loading ? (
                        <div className="w-full h-full animate-pulse bg-slate-200 dark:bg-slate-700" />
                      ) : (
                        <img 
                          src={profile?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${profile?.display_name || 'T'}`} 
                          alt="Avatar" 
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                  </div>

                  {/* Right: Stats display horizontally positioned next to the avatar (Using Inter font weights) */}
                  <div className="flex flex-1 justify-around sm:justify-end gap-6 sm:gap-14 w-full sm:w-auto py-2 sm:py-0 text-center sm:text-right">
                    <div className="min-w-[65px] text-center">
                      <p className="text-xl sm:text-[23px] font-extrabold text-slate-900 dark:text-white leading-none tracking-tight font-sans">{ownPostsCount}</p>
                      <p className="text-[10px] font-bold text-slate-450 dark:text-slate-500 uppercase tracking-wider mt-2 leading-none">posts</p>
                    </div>
                    <div className="border-r border-slate-200 dark:border-slate-800/80 h-8 self-center hidden sm:block" />
                    <div className="min-w-[75px] text-center">
                      <p className="text-xl sm:text-[23px] font-extrabold text-slate-900 dark:text-white leading-none tracking-tight font-sans">{followerCount}</p>
                      <p className="text-[10px] font-bold text-slate-450 dark:text-slate-500 uppercase tracking-wider mt-2 leading-none">followers</p>
                    </div>
                    <div className="border-r border-slate-200 dark:border-slate-800/80 h-8 self-center hidden sm:block" />
                    <div className="min-w-[75px] text-center">
                      <p className="text-xl sm:text-[23px] font-extrabold text-slate-900 dark:text-white leading-none tracking-tight font-sans">{followingCount}</p>
                      <p className="text-[10px] font-bold text-slate-450 dark:text-slate-500 uppercase tracking-wider mt-2 leading-none">following</p>
                    </div>

                  </div>

                </div>

                {/* Info and buttons layout below the avatar level */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-6 items-end">
                  
                  {/* Left columns: Profile identity labels & pills */}
                  <div className="md:col-span-8 text-center sm:text-left">
                    <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white flex items-center justify-center sm:justify-start gap-2 leading-tight">
                      {loading ? (
                        <div className="h-8 w-48 bg-slate-200 dark:bg-slate-700 animate-pulse rounded-lg" />
                      ) : (
                        <>
                          {profile?.display_name || username || "Anonymous Trader"}
                          <CheckCircle2 size={20} className="text-blue-500 fill-blue-500 text-white dark:text-[#0E121F] shrink-0" />
                        </>
                      )}
                    </h1>
                     <p className="text-[13px] font-semibold text-slate-455 dark:text-slate-500 mt-1">
                      {loading ? (
                        <div className="h-4 w-32 bg-slate-200 dark:bg-slate-700 animate-pulse rounded-lg inline-block" />
                      ) : (
                        `@${profile?.username || username || "trader"}`
                      )}
                    </p>
                    <div className="flex items-center justify-center sm:justify-start gap-4 mt-2.5 mb-1.5 select-none">
                      <span className="bg-gradient-to-r from-blue-500/20 to-indigo-500/20 text-blue-655 dark:text-blue-400 text-[10.5px] font-black px-2.5 py-1 rounded-lg border border-blue-500/25 flex items-center gap-1 shadow-sm shrink-0">
                        <Crown size={12} className="text-blue-500" /> Lvl {levelVal}
                      </span>
                      <div className="flex items-center gap-2 flex-1 max-w-[180px] min-w-[120px]">
                        <div className="flex-1 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden relative">
                          <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full" style={{ width: `${Math.min(100, (xpVal / xpRequiredVal) * 100)}%` }} />
                        </div>
                        <span className="text-[9.5px] text-slate-455 dark:text-slate-500 font-bold shrink-0">{xpVal}/{xpRequiredVal} XP</span>
                      </div>
                    </div>
                    <p className="text-[14px] text-slate-700 dark:text-slate-300 font-semibold leading-relaxed mt-3.5 max-w-xl">
                      {profile?.bio || "Algo Trading enthusiast & Developer. Building quantitative strategies and custom indicator sets for systematic market execution. Let's make disciplined trade decisions."}
                    </p>

                    {/* Badges row */}
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-500/10 text-purple-650 dark:text-purple-400 text-[11px] font-bold border border-purple-500/10 shadow-sm">
                        <Crown size={11} className="fill-purple-500/20 text-purple-500" /> Elite Trader
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-500/10 text-blue-655 dark:text-blue-400 text-[11px] font-bold border border-blue-500/10 shadow-sm">
                        <Star size={11} className="fill-blue-500/20 text-blue-500" /> Swing Master
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-655 dark:text-emerald-450 text-[11px] font-bold border border-emerald-500/10 shadow-sm">
                        <Shield size={11} className="fill-emerald-500/20 text-emerald-500" /> AI Disciplined
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-500/10 text-orange-655 dark:text-orange-400 text-[11px] font-bold border border-orange-500/10 shadow-sm">
                        <Star size={11} className="fill-orange-500/20 text-orange-500" /> Top Mentor
                      </span>
                    </div>

                    {/* Geographic and join info */}
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-5 gap-y-2 text-slate-500 dark:text-slate-400 text-xs font-bold mt-5 pt-4 border-t border-slate-200/50 dark:border-slate-800/40">
                      {privacySettings.show_location && (
                        <>
                          <span className="flex items-center gap-1.5">
                            {profile?.country_emoji || "🌍"} <span>{profile?.country || "Not set"}</span>
                          </span>
                          <span className="flex items-center gap-1.5">
                            <MapPin size={13.5} className="text-slate-400" /> <span>{profile?.location || "Not set"}</span>
                          </span>
                        </>
                      )}
                      <span className="flex items-center gap-1.5">
                        <Calendar size={13.5} className="text-slate-400" /> <span>Joined Jan 2024</span>
                      </span>
                    </div>
                  </div>

                  {/* Right columns: Compact Action Buttons */}
                  <div className="md:col-span-4 flex items-center justify-center sm:justify-end gap-2.5 w-full pb-2.5">
                    {/* Follow button */}
                    <button 
                      onClick={() => profile?.id && toggleFollowUser(profile.id, profile.display_name)}
                      className={`flex items-center justify-center gap-1.5 px-5 py-2 rounded-full text-[12px] font-bold whitespace-nowrap transition-all duration-300 border-2 active:scale-95 ${
                        followedUsers[profile?.id]
                        ? 'bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#1E2638] dark:to-[#0E121F] text-slate-700 dark:text-slate-200 border-white dark:border-[#222B3F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#262F47]'
                        : 'bg-gradient-to-b from-[#60A5FA] to-[#3B82F6] dark:from-[#3B82F6] dark:to-[#1D4ED8] text-white border-[#93C5FD] dark:border-[#3B82F6] shadow-[0_4px_7px_-5px_rgba(59,130,246,0.25),_0_0_0_2px_#3B82F6] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1D4ED8]'
                      }`}
                    >
                      {followedUsers[profile?.id] ? <><UserCheck size={13} /> Following</> : <><UserPlus size={13} /> Follow</>}
                    </button>

                    {/* Message button */}
                    <button 
                      onClick={handleStartConversation}
                      className="flex items-center justify-center gap-1.5 px-5 py-2 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#181D30] dark:to-[#0E121F] text-[#393939] dark:text-[#E2E8F0] text-[12px] font-bold whitespace-nowrap transition-all border-2 border-white dark:border-[#222B3F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#262F47] active:scale-95"
                    >
                      <Mail size={13} /> Message
                    </button>

                    {/* Channel button (conditional) */}
                    {userChannel && (
                      <Link to={`/channel/${userChannel.id}`} className="flex items-center justify-center gap-1.5 px-5 py-2 rounded-full bg-gradient-to-b from-indigo-50 to-white dark:from-indigo-900/20 dark:to-[#0E121F] text-indigo-600 dark:text-indigo-400 text-[12px] font-bold whitespace-nowrap transition-all border-2 border-indigo-100 dark:border-indigo-800/50 shadow-[0_4px_7px_-5px_rgba(79,70,229,0.15),_0_0_0_2px_#E0E7FF] dark:shadow-[0_4px_7px_-5px_rgba(79,70,229,0.25),_0_0_0_2px_#3730A3] active:scale-95">
                        <Radio size={13} /> Channel
                      </Link>
                    )}

                    {/* More button */}
                    <button className="p-2 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#181D30] dark:to-[#0E121F] text-[#393939] dark:text-[#E2E8F0] border-2 border-white dark:border-[#222B3F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#262F47] active:scale-95 transition-all">
                      <MoreHorizontal size={15} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Private Profile Overlay */}
            {privacySettings.is_private && !followedUsers[profile?.id ?? ''] && currentUserId !== profile?.id && (
              <div className="absolute inset-x-0 bottom-0 top-[320px] z-50 flex flex-col items-center justify-center text-center p-6 bg-white/20 dark:bg-[#0E121F]/30 backdrop-blur-[6px] rounded-3xl mx-6 mb-6 mt-12">
                <div className="w-20 h-20 rounded-full bg-slate-100 dark:bg-[#181D30] border-2 border-white dark:border-[#222B3F] shadow-md flex items-center justify-center text-slate-400 dark:text-slate-500 mb-4 animate-bounce-subtle">
                  <ShieldCheck size={36} className="text-blue-500" />
                </div>
                <h3 className="text-[18px] font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2 drop-shadow-md">This account is private</h3>
                <p className="text-xs text-slate-800 dark:text-slate-300 font-bold max-w-sm drop-shadow-md">Follow this account to see their trades, stats, and posts.</p>
              </div>
            )}
            
            <div className={`space-y-6 ${privacySettings.is_private && !followedUsers[profile?.id ?? ''] && currentUserId !== profile?.id ? 'filter blur-xl pointer-events-none select-none opacity-40' : ''}`}>
              {/* --- QUICK STATS GRID CARDS (5 Cards) --- */}
              {/* Redesigned to have 100% Tactile claymorphic styling matching mockup box shadow specs */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
              {[
                { title: "Trades", value: privacySettings.show_trades ? totalTradesCount.toLocaleString() : "🔒 Private", icon: <BarChart2 size={16} className="text-blue-500" />, color: "bg-blue-500/10 text-blue-600" },
                { title: "Win Rate", value: privacySettings.show_winrate ? winRateVal : "🔒 Private", icon: <CheckCircle2 size={16} className="text-emerald-500" />, color: "bg-emerald-500/10 text-emerald-600" },
                { title: "ROI (All Time)", value: privacySettings.show_roi ? roiVal : "🔒 Private", icon: <TrendingUp size={16} className="text-emerald-500 animate-pulse" />, color: "bg-emerald-500/10 text-emerald-600", highlighted: privacySettings.show_roi },
                { title: "Avg RR", value: privacySettings.show_winrate ? avgRRVal : "🔒 Private", icon: <Target size={16} className="text-purple-500" />, color: "bg-purple-500/10 text-purple-600" },
                { title: "Streak", value: privacySettings.show_streak ? streakVal : "🔒 Private", icon: <Flame size={16} className="text-orange-500 animate-pulse" />, color: "bg-orange-500/10 text-orange-600" }
              ].map((card, idx) => (
                <div key={idx} className="py-3.5 px-5 rounded-2xl bg-gradient-to-b from-[#F4F4F4]/70 to-[#FFFFFF] dark:from-[#181D30]/65 dark:to-[#0E121F] border-2 border-white dark:border-[#222B3F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.35),_0_0_0_2px_#262F47] hover:-translate-y-0.5 transition-all duration-350 flex flex-col gap-2.5 group">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-455 dark:text-slate-500 uppercase tracking-wider">{card.title}</span>
                    <div className={`p-2 rounded-xl ${card.color} transition-transform group-hover:scale-105 duration-300`}>
                      {card.icon}
                    </div>
                  </div>
                  <p className={`text-xl sm:text-[22px] font-extrabold leading-none font-sans tracking-tight ${card.highlighted ? 'text-emerald-500' : 'text-slate-900 dark:text-white'}`}>
                    {card.value}
                  </p>
                </div>
              ))}
            </div>

            {/* --- TWO COLUMN MIDDLE SECTION: PERFORMANCE vs AI ANALYSIS --- */}
            {/* Both styled as tactile rounded-3xl containers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Card A: Trading Performance */}
              <div className="bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335] flex flex-col gap-6 relative overflow-hidden">
                {!privacySettings.show_roi && (
                  <div className="absolute inset-0 bg-white/70 dark:bg-[#0E121F]/85 backdrop-blur-md z-10 flex flex-col items-center justify-center text-center p-6 gap-2 animate-in fade-in duration-300">
                    <Shield size={26} className="text-blue-500" />
                    <p className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Performance analytics private</p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 max-w-[200px] leading-relaxed font-semibold">This trader has hidden their ROI and performance statistics.</p>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider">Trading Performance</h3>
                  
                  {/* Select dropdown style tactile clone */}
                  <span className="text-[11px] font-bold text-[#393939] dark:text-[#E2E8F0] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#181D30] dark:to-[#0E121F] px-3.5 py-1.5 rounded-full border-2 border-white dark:border-[#222B3F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#262F47] cursor-pointer flex items-center gap-1.5 select-none active:scale-95 transition-all">
                    All Time <ArrowRight size={10} className="rotate-90 text-slate-500" />
                  </span>
                </div>

                <div className="grid grid-cols-12 gap-5 items-center">
                  
                  {/* Left part: Total PnL Label & glowing Line Chart */}
                  <div className="col-span-6 flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider leading-none">Total PnL</span>
                    <span className="text-2xl font-extrabold text-emerald-500 tracking-tight leading-none mt-2.5 font-sans">+212.45%</span>
                    
                    <div className="h-24 w-full mt-5 relative">
                      <svg className="w-full h-full filter drop-shadow-[0_4px_8px_rgba(59,130,246,0.2)]" viewBox="0 0 100 40" preserveAspectRatio="none">
                        <defs>
                          <linearGradient id="pnlGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                        <path 
                          d="M0,35 Q12,32 25,24 T55,27 T75,10 T100,3" 
                          fill="none" 
                          stroke="#3b82f6" 
                          strokeWidth="2.5" 
                          strokeLinecap="round"
                        />
                        <path 
                          d="M0,35 Q12,32 25,24 T55,27 T75,10 T100,3 L100,40 L0,40 Z" 
                          fill="url(#pnlGrad)"
                        />
                        {/* Glowing terminal node */}
                        <circle cx="100" cy="3" r="3.5" fill="#3b82f6" className="animate-ping" />
                        <circle cx="100" cy="3" r="2" fill="#3b82f6" />
                      </svg>
                    </div>
                  </div>

                  {/* Right part: stats list styled with Inter weights */}
                  <div className="col-span-6 space-y-3.5 pl-6 border-l border-slate-200 dark:border-slate-800/80">
                    {[
                      { label: "Profit Factor", value: "2.31", color: "text-blue-500", icon: <BarChart2 size={13} className="text-blue-500" /> },
                      { label: "Expectancy", value: "+1.42R", color: "text-emerald-500", icon: <TrendingUp size={13} className="text-emerald-500" /> },
                      { label: "Max Drawdown", value: "-8.72%", color: "text-rose-500", highlighted: true, icon: <Scale size={13} className="text-rose-500" /> },
                      { label: "Consistency Score", value: "82%", color: "text-blue-500", icon: <CheckCircle2 size={13} className="text-blue-500" />, showInfo: true }
                    ].map((stat, i) => (
                      <div key={i} className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-450 dark:text-slate-400 flex items-center gap-2">
                          {/* Inner icon consistency boxes */}
                          <div className="p-1 rounded-lg bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#1E2638] dark:to-[#0E121F] border border-white dark:border-[#222B3F] shadow-sm">
                            {stat.icon}
                          </div>
                          <span className="flex items-center gap-1 font-semibold">
                            {stat.label}
                            {stat.showInfo && <Info size={11} className="text-slate-400 hover:text-slate-650 cursor-pointer" />}
                          </span>
                        </span>
                        <span className={`font-bold tracking-tight font-sans ${stat.highlighted ? 'text-rose-500' : 'text-slate-850 dark:text-slate-200'}`}>{stat.value}</span>
                      </div>
                    ))}
                  </div>

                </div>
              </div>

              {/* Card B: Tradifive AI Analysis (Tactile rounded-3xl container) */}
              <div className="bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335] flex flex-col gap-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider">Tradifive AI Analysis</h3>
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Updated 2h ago</span>
                </div>

                <div className="space-y-4">
                  {/* Emotional Discipline bar */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-2">
                      <span className="text-slate-550 dark:text-slate-400">Emotional Discipline</span>
                      <span className="font-bold text-emerald-500">82%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-850">
                      <div className="h-full bg-[#10b981] rounded-full transition-all duration-1000" style={{ width: '82%' }} />
                    </div>
                  </div>

                  {/* Revenge Trading Risk */}
                  <div className="flex justify-between items-center text-xs py-2.5 border-y border-slate-200/60 dark:border-slate-800/80">
                    <span className="font-semibold text-slate-550 dark:text-slate-400">Revenge Trading Risk</span>
                    <span className="font-bold text-[#10b981] flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] shadow-sm" /> Low
                    </span>
                  </div>

                  {/* Confidence Score bar */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-2">
                      <span className="text-slate-555 dark:text-slate-400">Confidence Score</span>
                      <span className="font-bold text-blue-500">74%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-850">
                      <div className="h-full bg-blue-500 rounded-full transition-all duration-1000" style={{ width: '74%' }} />
                    </div>
                  </div>

                  {/* Two detailed info cells */}
                  <div className="grid grid-cols-2 gap-4 text-xs pt-2.5 border-t border-slate-200/60 dark:border-slate-800/80">
                    <div>
                      <span className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-[9px] block">Best Trading Session</span>
                      <span className="font-bold text-slate-900 dark:text-white mt-1 block font-sans">London (1PM - 5PM)</span>
                    </div>
                    <div>
                      <span className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-[9px] block">Suggested Improvement</span>
                      <span className="font-bold text-slate-900 dark:text-white mt-1 block font-sans">Work on RR consistency</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Pill Tabs Bar Selector */}
            {/* Styled with skeuomorphic outline frame */}
            <div className="bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#1A2238] dark:to-[#0E121F] p-1.5 rounded-full flex items-center border-2 border-white dark:border-[#222B3F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#262F47] select-none overflow-x-auto scrollbar-hide">
              {["Posts", "Trades", "Videos", "Mentions", "Achievements"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 text-center py-2.5 px-5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 shrink-0 ${
                    activeTab === tab 
                      ? "bg-gradient-to-b from-[#60A5FA] to-[#3B82F6] dark:from-[#3B82F6] dark:to-[#1D4ED8] text-white border-2 border-[#93C5FD] dark:border-[#3B82F6] shadow-[0_4px_7px_-5px_rgba(59,130,246,0.2),_0_0_0_2px_#3B82F6] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1D4ED8]" 
                      : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Feed Posts List */}
              <div className="md:col-span-12 max-w-4xl mx-auto w-full space-y-6">
                {activeTab === "Achievements" ? (
                  <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335] space-y-6">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60">
                      <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                        <Trophy size={16} className="text-blue-500" />
                        <span>Trader Badges & Level Progress</span>
                      </h3>
                      <span className="bg-gradient-to-r from-blue-500/15 to-indigo-500/15 text-blue-600 dark:text-blue-400 text-[10px] font-extrabold px-3 py-1.5 rounded-full border border-blue-500/20 shadow-sm uppercase tracking-wider">
                        Rank: Vanguard
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Active Level Widget */}
                      <div className="p-5 rounded-2xl bg-white dark:bg-[#1E2335]/40 border border-slate-150 dark:border-[#222B3F] shadow-sm flex flex-col justify-between h-[120px]">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Progression Level</span>
                            <span className="text-2xl font-extrabold text-slate-900 dark:text-white mt-1 block">Level {levelVal}</span>
                          </div>
                          <Crown size={22} className="text-amber-500 fill-amber-500/20" />
                        </div>
                        <div className="space-y-1.5">
                          <div className="flex justify-between text-[10px] font-bold text-slate-455">
                            <span>XP: {xpVal} / {xpRequiredVal}</span>
                            <span>{Math.round((xpVal / xpRequiredVal) * 100)}%</span>
                          </div>
                          <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-850">
                            <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full" style={{ width: `${(xpVal / xpRequiredVal) * 100}%` }} />
                          </div>
                        </div>
                      </div>

                      {/* Discipline Level Modifier */}
                      <div className="p-5 rounded-2xl bg-white dark:bg-[#1E2335]/40 border border-slate-150 dark:border-[#222B3F] shadow-sm flex flex-col justify-between h-[120px]">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Discipline Score</span>
                            <span className="text-2xl font-extrabold text-emerald-500 mt-1 block">82%</span>
                          </div>
                          <ShieldCheck size={22} className="text-emerald-500" />
                        </div>
                        <div className="text-[10.5px] text-slate-500 dark:text-slate-400 font-semibold leading-relaxed">
                          User rank status is stable. Maintain &gt;75% score to preserve premium badge benefits.
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4 pt-2">
                      <h4 className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Achievements Ledger ({[1,2,3,6].length} Unlocked)</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {[
                          { id: 1, name: "100 Winning Trades", desc: "Executed 100 profitable trades with verified parameters.", status: "unlocked", progress: "100/100" },
                          { id: 2, name: "Discipline Master", desc: "Maintained > 80% discipline score for 10 consecutive days.", status: "unlocked", progress: "10/10" },
                          { id: 3, name: "Drawdown Survivor", desc: "Zero days exceeding 2% drawdown limit this month.", status: "unlocked", progress: "30/30" },
                          { id: 4, name: "Risk Maestro", desc: "All executed positions had defined stop-losses and take-profits.", status: "locked", progress: "80/100" },
                          { id: 5, name: "Streak Legend", desc: "Reached a 15-day trading streak on the platform.", status: "locked", progress: "12/15" },
                          { id: 6, name: "AI Coach Approved", desc: "Cleared 5 personal challenges proposed by the AI Coach.", status: "unlocked", progress: "5/5" }
                        ].map((badge) => (
                          <div 
                            key={badge.id}
                            className={`p-4 rounded-2xl border transition-all duration-300 flex items-start gap-3.5 ${
                              badge.status === "unlocked"
                                ? "bg-white dark:bg-[#1E2335]/30 border-slate-150 dark:border-[#222B3F] hover:border-blue-500/20"
                                : "bg-slate-50/50 dark:bg-slate-900/40 border-transparent opacity-65"
                            }`}
                          >
                            <div className={`p-2.5 rounded-xl shrink-0 ${
                              badge.status === "unlocked" ? "bg-blue-500/10 text-blue-500" : "bg-slate-200 dark:bg-slate-800 text-slate-400"
                            }`}>
                              {badge.id === 1 ? <Trophy size={18} /> : 
                               badge.id === 2 ? <ShieldCheck size={18} /> : 
                               badge.id === 3 ? <TrendingUp size={18} /> : 
                               badge.id === 4 ? <Target size={18} /> : 
                               badge.id === 5 ? <Flame size={18} /> : <Star size={18} />}
                            </div>
                            <div className="space-y-1 min-w-0">
                              <div className="flex justify-between items-center gap-2">
                                <h5 className="text-[12.5px] font-bold text-slate-900 dark:text-white truncate">{badge.name}</h5>
                                <span className={`text-[9px] font-black px-1.5 py-0.5 rounded ${
                                  badge.status === "unlocked" ? "bg-emerald-500/10 text-emerald-500" : "bg-slate-100 dark:bg-slate-800 text-slate-400"
                                }`}>
                                  {badge.status === "unlocked" ? "COMPLETED" : badge.progress}
                                </span>
                              </div>
                              <p className="text-[10.5px] text-slate-500 dark:text-slate-400 leading-snug font-medium">{badge.desc}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : activeTab === "Trades" ? (
                  !privacySettings.show_trades ? (
                    <div className="p-12 rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335] flex flex-col items-center justify-center gap-4 text-center">
                      <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-[#181D30] border-2 border-white dark:border-[#222B3F] shadow-md flex items-center justify-center text-slate-400 dark:text-slate-500 animate-pulse">
                        <Shield size={28} />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">Trading Ledger is Private</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm font-medium">This trader has disabled public visibility for their verified execution ledger.</p>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335]">
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Synchronized Execution Ledger</h3>
                        <span className="text-[11px] font-bold text-[#393939] dark:text-[#E2E8F0] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#181D30] dark:to-[#0E121F] px-3.5 py-1.5 rounded-full border-2 border-white dark:border-[#222B3F] shadow-sm select-none">
                          Verified Execution
                        </span>
                      </div>

                      <div className="overflow-x-auto amazing-scrollbar">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-slate-100 dark:border-slate-800 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                              <th className="pb-3 pl-2">Ticket</th>
                              <th className="pb-3">Symbol</th>
                              <th className="pb-3">Type</th>
                              <th className="pb-3 text-right">Size</th>
                              <th className="pb-3 text-right">Profit</th>
                              <th className="pb-3 text-right pr-2">Date</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100/50 dark:divide-slate-800/40 text-xs font-bold">
                            {publicTrades.map((trade) => {
                              const isWin = Number(trade.profit) > 0;
                              return (
                                <tr key={trade.id} className="hover:bg-slate-50/50 dark:hover:bg-[#1C2335]/30 transition-colors">
                                  <td className="py-3.5 pl-2 font-mono text-slate-500">#{trade.ticket}</td>
                                  <td className="py-3.5 flex items-center gap-1.5">
                                    <span>{trade.symbol.includes("XAU") ? "🇺🇸" : (trade.symbol.includes("BTC") ? "🪙" : "🇪🇺")}</span>
                                    <span className="text-slate-900 dark:text-white">{trade.symbol}</span>
                                  </td>
                                  <td className="py-3.5">
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${trade.trade_type === 0 ? 'bg-blue-500/10 text-blue-500' : 'bg-rose-500/10 text-rose-500'}`}>
                                      {trade.trade_type === 0 ? 'BUY' : 'SELL'}
                                    </span>
                                  </td>
                                  <td className="py-3.5 text-right font-mono text-slate-655 dark:text-slate-300">{Number(trade.lot_size).toFixed(2)}</td>
                                  <td className={`py-3.5 text-right font-mono ${isWin ? 'text-emerald-500' : 'text-rose-500'}`}>
                                    {isWin ? '+' : ''}${Number(trade.profit).toFixed(2)}
                                  </td>
                                  <td className="py-3.5 text-right font-mono text-slate-400 pr-2">
                                    {new Date(trade.closed_at || trade.created_at).toLocaleDateString()}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )
                ) : posts.length === 0 ? (
                  <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335] text-center py-12 flex flex-col items-center justify-center">
                    <p className="text-slate-500 dark:text-slate-400 text-sm font-bold">No Posts Available</p>
                  </div>
                ) : (
                  posts.map((post: any) => {
                    const isLiked = likedPosts[post.id] || false;
                    return (
                        <FeedCard 
                            key={post.id}
                            feed={post}
                            currentUserId={currentUserId || ""}
                            followedUsers={followedUsers}
                            onToggleFollow={toggleFollowUser}
                            isLiked={isLiked}
                            likes={Math.max(0, (post.like_count ?? post.likes_count ?? 0) + (likesOffsets[post.id] || 0))}
                            onLike={() => handleLikePost(post.id)}
                            onVote={async (postId, updatedMediaUrl) => {
                                try {
                                    await supabase.from('social_posts').update({ media_url: updatedMediaUrl }).eq('id', postId);
                                    setPosts(prev => prev.map(p => p.id === postId ? { ...p, media_url: updatedMediaUrl } : p));
                                } catch (error) {
                                    console.error("Error saving vote:", error);
                                }
                            }}
                        />
                    );

                  })
                )}
              </div>
            </div>
            </div>

          </div>
          
          {/* --- COLUMN 3: RIGHT SIDEBAR (col-span-3) --- */}
          {/* All outer sidebar panels aligned to rounded-3xl outer cards with clean borders */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* A. Suggested Traders Widget */}
            <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335]">
              <div className="flex items-center justify-between mb-5">
                <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck size={16} className="text-emerald-500 shrink-0" />
                  <span>Suggested Traders</span>
                </h3>
                <span className="text-[11px] font-bold text-blue-500 hover:underline cursor-pointer">View all</span>
              </div>

              <div className="flex flex-col gap-5">
                {suggestedTraders.length === 0 ? (
                  <p className="text-[11px] font-semibold text-slate-400 text-center py-2">No suggested traders available</p>
                ) : (
                  suggestedTraders.map((person) => {
                    const isFollowing = followedUsers[person.id] || false;
                    const displayName = person.display_name || person.username || "Trader";
                    const displayAvatar = person.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${displayName}`;
                    const displayWinrate = person.win_rate ? `${person.win_rate}% Win Rate` : "Active Trader";
                    const displayRole = person.bio ? (person.bio.length > 30 ? person.bio.substring(0, 30) + "..." : person.bio) : "Tradifive Member";

                    return (
                      <div key={person.id} className="flex items-center justify-between gap-3 group">
                        <div className="flex items-center gap-3 min-w-0">
                          <Link to={`/user/${person.username || ""}`} className="shrink-0 hover:opacity-85 transition-opacity duration-300">
                            <img src={displayAvatar} alt={displayName} className="w-10 h-10 rounded-full border border-slate-200/50 dark:border-slate-700 object-cover bg-slate-100" />
                          </Link>
                          <div className="min-w-0">
                            <Link to={`/user/${person.username || ""}`}>
                              <h4 className="font-bold text-slate-900 dark:text-white text-[13px] leading-tight hover:text-blue-600 cursor-pointer truncate transition-colors">{displayName}</h4>
                            </Link>
                            <p className="text-slate-455 dark:text-slate-455 text-[10.5px] leading-none mt-1 truncate font-semibold">{displayWinrate}</p>
                            <p className="text-slate-400 dark:text-slate-500 text-[10.5px] leading-none mt-1.5 truncate font-semibold">{displayRole}</p>
                          </div>
                        </div>

                        {/* Follow Button */}
                        <button 
                          onClick={() => toggleFollowUser(person.id, displayName)}
                          className={`shrink-0 flex items-center justify-center px-4 py-2.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider transition-all duration-300 border-2 active:scale-95 ${
                            isFollowing 
                              ? 'bg-gradient-to-b from-[#F4F4F4]/50 to-[#FFFFFF]/60 dark:from-[#181D30]/40 dark:to-[#0E121F]/50 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700' 
                              : 'bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#181D30] dark:to-[#0E121F] text-[#393939] dark:text-[#E2E8F0] border-white dark:border-[#222B3F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#262F47]'
                          }`}
                        >
                          {isFollowing ? 'Following' : 'Follow'}
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* B. Trading Streak Widget */}
            <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335] flex flex-col gap-4.5 relative overflow-hidden">
              {!privacySettings.show_streak && (
                <div className="absolute inset-0 bg-white/70 dark:bg-[#0E121F]/85 backdrop-blur-md z-10 flex flex-col items-center justify-center text-center p-4 gap-2 animate-in fade-in duration-300">
                  <Flame size={20} className="text-orange-500" />
                  <p className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Streak Hidden</p>
                </div>
              )}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60 mb-1">
                <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Flame size={16} className="text-orange-500 fill-orange-500/10" />
                  <span>Trading Streak</span>
                </h3>
                <span className="text-[14px] font-bold text-orange-500 leading-none">12 Days</span>
              </div>

              <div className="flex justify-between text-xs font-semibold text-slate-450">
                <span>Current Streak</span>
                <span>Best: <strong className="text-slate-900 dark:text-white font-extrabold">23 Days</strong></span>
              </div>

              {/* Day Dot indicators row matching image exactly (15 dots) */}
              <div className="flex items-center justify-between gap-1.5 py-1">
                {[
                  { status: 'green' }, { status: 'green' }, { status: 'green' }, { status: 'red' }, 
                  { status: 'green' }, { status: 'green' }, { status: 'green' }, { status: 'gray' },
                  { status: 'green' }, { status: 'green' }, { status: 'green' }, { status: 'red' },
                  { status: 'green' }, { status: 'green' }, { status: 'green' }
                ].map((dot, idx) => (
                  <span 
                    key={idx} 
                    className={`w-2.5 h-2.5 rounded-full block border border-white/5 shadow-sm ${
                      dot.status === 'green' ? 'bg-[#10b981]' : (dot.status === 'red' ? 'bg-[#ef4444]' : 'bg-slate-200 dark:bg-slate-800')
                    }`} 
                  />
                ))}
              </div>

              <div className="flex justify-between text-[9px] text-slate-450 font-bold uppercase tracking-widest leading-none">
                <span>12 May</span>
                <span>Today</span>
              </div>
            </div>

            {/* C. Performance Calendar Widget */}
            <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335] flex flex-col gap-4.5 relative overflow-hidden">
              {!privacySettings.show_trades && (
                <div className="absolute inset-0 bg-white/70 dark:bg-[#0E121F]/85 backdrop-blur-md z-10 flex flex-col items-center justify-center text-center p-4 gap-2 animate-in fade-in duration-300">
                  <Calendar size={20} className="text-blue-500" />
                  <p className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Calendar Private</p>
                </div>
              )}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60 mb-1">
                <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Calendar size={15} className="text-blue-500" />
                  <span>Calendar</span>
                </h3>
                {/* Tactical Dropdown trigger clone */}
                <span className="flex items-center justify-between gap-2 px-4 py-2 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#181D30] dark:to-[#0E121F] text-[#393939] dark:text-[#E2E8F0] text-[11px] font-extrabold uppercase tracking-wider transition-all border-2 border-white dark:border-[#222B3F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#262F47] cursor-pointer hover:text-slate-700 select-none active:scale-95 min-w-[105px]">
                  <span>May 2026</span> <ChevronDown size={11} className="text-[#393939] dark:text-[#E2E8F0] shrink-0" />
                </span>
              </div>

              {/* Heatmap Grid Calendar (5 rows of 7 days) */}
              <div className="space-y-2">
                <div className="grid grid-cols-7 gap-1.5 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(d => <span key={d}>{d.substring(0,1)}</span>)}
                </div>

                <div className="grid grid-cols-7 gap-1.5">
                  {/* Highly accurate heatmap block layout matching the reference mockup layout */}
                  {/* Row 1 */}
                  <span className="h-6 rounded-lg bg-emerald-500/10 dark:bg-[#10b981]/5 border border-[#10b981]/15" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-[#10b981]/50 border border-[#10b981]/25 shadow-sm" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  {/* Row 2 */}
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-[#ef4444]/40 border border-[#ef4444]/20 shadow-sm" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-[#ef4444]/10 dark:bg-[#ef4444]/5 border border-[#ef4444]/10" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  {/* Row 3 */}
                  <span className="h-6 rounded-lg bg-[#ef4444]/10 dark:bg-[#ef4444]/5 border border-[#ef4444]/10" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-[#ef4444]/40 border border-[#ef4444]/20 shadow-sm" />
                  <span className="h-6 rounded-lg bg-[#ef4444]/40 border border-[#ef4444]/20 shadow-sm" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  {/* Row 4 */}
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-[#10b981]/60 border border-[#10b981]/30 shadow-sm" />
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  {/* Row 5 */}
                  <span className="h-6 rounded-lg bg-[#10b981]/15 dark:bg-[#10b981]/10 border border-[#10b981]/25" />
                  <span className="h-6 rounded-lg bg-[#10b981]/50 border border-[#10b981]/25 shadow-sm" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-[#10b981]/10 dark:bg-[#10b981]/5 border border-[#10b981]/10" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                  <span className="h-6 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800" />
                </div>
              </div>

              {/* Legend details row */}
              <div className="flex items-center justify-between text-[9px] text-slate-450 dark:text-slate-500 font-extrabold uppercase tracking-wider pt-2.5 border-t border-slate-200/60 dark:border-slate-850">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-[#10b981]" /> Profitable
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-[#ef4444]" /> Loss
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-slate-200 dark:bg-slate-800" /> No Trade
                </span>
              </div>
            </div>

            {/* D. Achievements Widget with gorgeous premium inline SVG medals */}
            {/* Outer box styled with skeuomorphic outline frame */}
            <div className="p-6 rounded-3xl border-2 border-white dark:border-[#1E2538] bg-gradient-to-b from-[#FAFBFD] to-[#FFFFFF] dark:from-[#121625] dark:to-[#0E121F] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.06),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),_0_0_0_2px_#1C2335] flex flex-col gap-4.5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/60 mb-1">
                <h3 className="text-[13px] font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Star size={15} className="text-blue-500" />
                  <span>Achievements</span>
                </h3>
                <span className="text-[11px] font-bold text-blue-500 hover:underline cursor-pointer">View all</span>
              </div>

              <div className="grid grid-cols-3 gap-2.5 text-center text-[9px] font-bold text-slate-500 dark:text-slate-400 select-none">
                
                {/* 1. 100 Winning Trades Medallion */}
                {/* Aligned to tactile claymorphic consistency specs */}
                <div className="flex flex-col items-center justify-center gap-2.5 py-4 px-3 rounded-2xl bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#1E2638] dark:to-[#0E121F] border-2 border-white dark:border-[#222B3F] shadow-[0_2px_4px_rgba(0,0,0,0.03),_0_0_0_1px_#E7E7E7] dark:shadow-[0_2px_4px_rgba(0,0,0,0.2),_0_0_0_1px_#262F47] hover:scale-103 transition-transform duration-350">
                  <svg className="w-12 h-12 shrink-0 select-none" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="45" r="30" fill="url(#goldGlow)" opacity="0.15" />
                    <path d="M35 50 L25 85 L50 72 L75 85 L65 50 Z" fill="url(#goldRibbon)" stroke="#F59E0B" strokeWidth="1.5" />
                    <polygon points="50,15 80,25 80,55 50,80 20,55 20,25" fill="url(#goldShield)" stroke="#D97706" strokeWidth="2.5" strokeLinejoin="round" />
                    <polygon points="50,20 74,28 74,52 50,72 26,52 26,28" fill="none" stroke="#FBBF24" strokeWidth="1" strokeLinejoin="round" />
                    <polygon points="50,28 54,38 65,38 56,44 59,55 50,48 41,55 44,44 35,38 46,38" fill="#FBBF24" />
                    <circle cx="50" cy="52" r="14" fill="#78350F" stroke="#FBBF24" strokeWidth="1.5" />
                    <text x="50" y="56" fill="#FBBF24" fontSize="11" fontWeight="900" textAnchor="middle" fontFamily="sans-serif">100</text>
                    <defs>
                      <radialGradient id="goldGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#F59E0B" />
                        <stop offset="100%" stopColor="#F59E0B" stopOpacity="0" />
                      </radialGradient>
                      <linearGradient id="goldShield" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#FBBF24" />
                        <stop offset="50%" stopColor="#F59E0B" />
                        <stop offset="100%" stopColor="#D97706" />
                      </linearGradient>
                      <linearGradient id="goldRibbon" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#EF4444" />
                        <stop offset="100%" stopColor="#B91C1C" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <span className="leading-tight block uppercase tracking-wider text-[8px] font-bold text-amber-600 dark:text-amber-500 text-center">
                    100<br />Winning<br />Trades
                  </span>
                </div>

                {/* 2. 10 Days Streak Medallion */}
                <div className="flex flex-col items-center justify-center gap-2.5 py-4 px-3 rounded-2xl bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#1E2638] dark:to-[#0E121F] border-2 border-white dark:border-[#222B3F] shadow-[0_2px_4px_rgba(0,0,0,0.03),_0_0_0_1px_#E7E7E7] dark:shadow-[0_2px_4px_rgba(0,0,0,0.2),_0_0_0_1px_#262F47] hover:scale-103 transition-transform duration-350">
                  <svg className="w-12 h-12 shrink-0 select-none" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="45" r="30" fill="url(#purpleGlow)" opacity="0.15" />
                    <path d="M35 50 L25 85 L50 72 L75 85 L65 50 Z" fill="url(#purpleRibbon)" stroke="#A855F7" strokeWidth="1.5" />
                    <polygon points="50,15 80,25 80,55 50,80 20,55 20,25" fill="url(#purpleShield)" stroke="#7E22CE" strokeWidth="2.5" strokeLinejoin="round" />
                    <polygon points="50,20 74,28 74,52 50,72 26,52 26,28" fill="none" stroke="#C084FC" strokeWidth="1" strokeLinejoin="round" />
                    <path d="M50,28 C54,34 52,38 54,42 C51,44 48,42 46,40 C44,45 47,48 50,48 C53,48 56,44 54,37" fill="#F59E0B" />
                    <circle cx="50" cy="52" r="14" fill="#4C1D95" stroke="#C084FC" strokeWidth="1.5" />
                    <text x="50" y="56" fill="#C084FC" fontSize="11" fontWeight="900" textAnchor="middle" fontFamily="sans-serif">10</text>
                    <defs>
                      <radialGradient id="purpleGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#8B5CF6" />
                        <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" />
                      </radialGradient>
                      <linearGradient id="purpleShield" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#C084FC" />
                        <stop offset="50%" stopColor="#8B5CF6" />
                        <stop offset="100%" stopColor="#6D28D9" />
                      </linearGradient>
                      <linearGradient id="purpleRibbon" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#EC4899" />
                        <stop offset="100%" stopColor="#BE185D" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <span className="leading-tight block uppercase tracking-wider text-[8px] font-bold text-purple-650 dark:text-purple-400 text-center">
                    10 Days<br />Streak
                  </span>
                </div>

                {/* 3. 2K Trades Executed Medallion */}
                <div className="flex flex-col items-center justify-center gap-2.5 py-4 px-3 rounded-2xl bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#1E2638] dark:to-[#0E121F] border-2 border-white dark:border-[#222B3F] shadow-[0_2px_4px_rgba(0,0,0,0.03),_0_0_0_1px_#E7E7E7] dark:shadow-[0_2px_4px_rgba(0,0,0,0.2),_0_0_0_1px_#262F47] hover:scale-103 transition-transform duration-350">
                  <svg className="w-12 h-12 shrink-0 select-none" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="45" r="30" fill="url(#blueGlow)" opacity="0.15" />
                    <path d="M35 50 L25 85 L50 72 L75 85 L65 50 Z" fill="url(#blueRibbon)" stroke="#3B82F6" strokeWidth="1.5" />
                    <polygon points="50,15 80,25 80,55 50,80 20,55 20,25" fill="url(#blueShield)" stroke="#1D4ED8" strokeWidth="2.5" strokeLinejoin="round" />
                    <polygon points="50,20 74,28 74,52 50,72 26,52 26,28" fill="none" stroke="#60A5FA" strokeWidth="1" strokeLinejoin="round" />
                    <circle cx="50" cy="38" r="8" fill="#FBBF24" />
                    <path d="M42,48 L58,48 L55,42 L45,42 Z" fill="#FBBF24" />
                    <circle cx="50" cy="52" r="14" fill="#1E3A8A" stroke="#60A5FA" strokeWidth="1.5" />
                    <text x="50" y="55" fill="#60A5FA" fontSize="9" fontWeight="900" textAnchor="middle" fontFamily="sans-serif">2K</text>
                    <defs>
                      <radialGradient id="blueGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#3B82F6" />
                        <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
                      </radialGradient>
                      <linearGradient id="blueShield" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#60A5FA" />
                        <stop offset="50%" stopColor="#3B82F6" />
                        <stop offset="100%" stopColor="#1D4ED8" />
                      </linearGradient>
                      <linearGradient id="blueRibbon" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#10B981" />
                        <stop offset="100%" stopColor="#047857" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <span className="leading-tight block uppercase tracking-wider text-[8px] font-bold text-blue-600 dark:text-blue-400 text-center">
                    2K<br />Trades<br />Executed
                  </span>
                </div>

              </div>
            </div>

          </div>

        </div>
      </div>
    </DashboardLayout>
  );
}

