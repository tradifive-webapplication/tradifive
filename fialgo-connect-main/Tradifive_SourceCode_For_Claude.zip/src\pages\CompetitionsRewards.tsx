import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import DashboardLayout from "@/components/DashboardLayout";
import {
  Gift, Star, Trophy, Zap, Crown, Shield, Target, TrendingUp,
  CheckCircle, Lock, Sparkles, Award, Medal, Flame, ChevronRight
} from "lucide-react";
import { toast } from "sonner";
import { 
  getGamificationState, 
  syncGamificationWithSupabase, 
  unlockBenefit 
} from "@/utils/gamification";
import { useCompetitionsData } from "@/hooks/useCompetitionsData";

export default function CompetitionsRewards() {
  const [gamState, setGamState] = useState(getGamificationState());
  const { redeemXPReward } = useCompetitionsData();
  const [redeeming, setRedeeming] = useState<number | null>(null);

  useEffect(() => {
    syncGamificationWithSupabase().then(() => {
      setGamState(getGamificationState());
    });

    const handleUpdate = () => {
      setGamState(getGamificationState());
    };
    window.addEventListener("tradifive_xp_update", handleUpdate);
    return () => window.removeEventListener("tradifive_xp_update", handleUpdate);
  }, []);

  const currentXP = gamState.bounty_balance;
  const nextMilestoneXP = 2500;
  const progressPct = Math.min(100, (currentXP / nextMilestoneXP) * 100);

  const xpMilestones = [
    { xp: 500,  label: "Rookie",       reward: "$5 Fee Rebate",       icon: Shield,   color: "text-slate-500",  bg: "bg-slate-50 dark:bg-slate-900/20",   border: "border-slate-200 dark:border-slate-800",   unlocked: gamState.level >= 2  },
    { xp: 1000, label: "Competitor",   reward: "$10 Fee Rebate",      icon: Target,   color: "text-emerald-600",bg: "bg-emerald-50 dark:bg-emerald-950/20",border: "border-emerald-200 dark:border-emerald-900",unlocked: gamState.level >= 5  },
    { xp: 2500, label: "Challenger",   reward: "Free Month Pro",      icon: Zap,      color: "text-blue-600",   bg: "bg-blue-50 dark:bg-blue-950/20",      border: "border-blue-200 dark:border-blue-900",     unlocked: gamState.level >= 10 },
    { xp: 5000, label: "Elite Trader", reward: "$50 Cash Prize",      icon: Trophy,   color: "text-amber-600",  bg: "bg-amber-50 dark:bg-amber-950/20",    border: "border-amber-200 dark:border-amber-900",   unlocked: gamState.level >= 15 },
    { xp: 10000,label: "Legend",       reward: "$200 + VIP Badge",    icon: Crown,    color: "text-indigo-600", bg: "bg-indigo-50 dark:bg-indigo-950/20",  border: "border-indigo-200 dark:border-indigo-900", unlocked: gamState.level >= 20 },
  ];

  const redeemableRewards = [
    { id: 1, title: "Fee Rebate",        desc: "Redeem 500 XP for a $5 trading fee rebate on your next challenge.", cost: 500,  icon: TrendingUp, available: !gamState.unlocked_items.includes(1)  },
    { id: 2, title: "Pro Plan — 1 Month",desc: "Unlock one month of Pro features including AI Coach and advanced analytics.", cost: 2000, icon: Sparkles,  available: !gamState.unlocked_items.includes(2)  },
    { id: 3, title: "Exclusive Badge",   desc: "A rare profile badge displayed on your public leaderboard profile.", cost: 1000, icon: Medal,     available: !gamState.unlocked_items.includes(3)  },
    { id: 4, title: "Cash Payout",       desc: "Withdraw $50 directly to your wallet. Requires verified account.", cost: 5000, icon: Gift,      available: false },
  ];

  const badges = [
    { label: "First Win",       icon: Trophy, earned: gamState.level >= 2,   color: "text-amber-500",  glow: "shadow-amber-500/20"  },
    { label: "7-Day Streak",    icon: Flame,  earned: gamState.streak >= 7,  color: "text-orange-500", glow: "shadow-orange-500/20" },
    { label: "Risk Tamer",      icon: Shield, earned: gamState.level >= 8,   color: "text-indigo-500", glow: "shadow-indigo-500/20" },
    { label: "Podium Finisher", icon: Award,  earned: gamState.level >= 12,  color: "text-purple-500",  glow: "shadow-purple-500/20" },
    { label: "Century Trader",  icon: Target, earned: gamState.level >= 18,  color: "text-emerald-500",  glow: "shadow-emerald-500/20" },
    { label: "Legend Status",   icon: Crown,  earned: gamState.level >= 25,  color: "text-indigo-600",  glow: "shadow-indigo-500/20" },
  ];

  const handleRedeem = async (id: number, cost: number, title: string) => {
    if (currentXP < cost) {
      toast.error("Not enough XP", { description: `You need ${cost - currentXP} more XP to redeem this reward.` });
      return;
    }
    setRedeeming(id);
    const ok = unlockBenefit(id, cost);
    if (ok) {
      await redeemXPReward(String(id), cost, title);
    }
    setRedeeming(null);
  };

  return (
    <DashboardLayout>
      <div className="p-6 md:p-8 max-w-[1200px] mx-auto w-full font-sans pb-32 space-y-10 select-none">

        {/* HEADER */}
        <div>
          <h1 className="text-[25px] font-semibold text-slate-800 dark:text-white tracking-tight leading-none">Rewards</h1>
          <p className="text-[12px] text-slate-400 dark:text-slate-500 mt-2 font-medium">Earn XP through competitions and trade activity. Redeem for cash, perks, and exclusive badges.</p>
        </div>

        {/* XP OVERVIEW CARD */}
        <motion.div
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
          className="p-6 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div className="space-y-3 flex-1">
              <span className="text-[9px] font-semibold text-slate-400 uppercase tracking-widest block">Your XP Balance</span>
              <div className="flex items-end gap-3">
                <span className="text-[42px] font-bold text-slate-800 dark:text-white leading-none tabular-nums">{currentXP.toLocaleString()}</span>
                <span className="text-[14px] font-semibold text-slate-400 mb-1.5">XP</span>
              </div>
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Next Milestone: Challenger</span>
                  <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400">{currentXP} / {nextMilestoneXP.toLocaleString()} XP</span>
                </div>
                <div className="h-2 w-full bg-slate-100 dark:bg-[#222222] rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }} animate={{ width: `${progressPct}%` }} transition={{ duration: 1.2, ease: "easeOut" }}
                    className="h-full bg-indigo-600 rounded-full relative"
                  >
                    <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,0.15)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.15)_50%,rgba(255,255,255,0.15)_75%,transparent_75%,transparent)] bg-[length:1rem_1rem] animate-[move-stripe_2s_linear_infinite]" />
                  </motion.div>
                </div>
                <p className="text-[10px] text-slate-400 font-medium">{(nextMilestoneXP - currentXP).toLocaleString()} XP needed to unlock <span className="font-bold text-slate-600 dark:text-slate-300">Free Month Pro</span></p>
              </div>
            </div>

            {/* XP stat pills */}
            <div className="flex sm:flex-col gap-3 sm:gap-2 shrink-0">
              {[
                { label: "This Week", value: "+320 XP", color: "text-emerald-600" },
                { label: "This Month", value: "+890 XP", color: "text-indigo-600" },
                { label: "All Time",  value: "1,240 XP", color: "text-slate-800 dark:text-white" },
              ].map((s) => (
                <div key={s.label} className="px-4 py-2.5 rounded-[16px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#333336] text-right min-w-[120px]">
                  <p className="text-[9px] font-semibold text-slate-400 uppercase tracking-widest">{s.label}</p>
                  <p className={`text-[15px] font-bold ${s.color} tabular-nums mt-0.5`}>{s.value}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* XP MILESTONES */}
        <div className="space-y-4">
          <h2 className="text-[13px] font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">XP Milestones</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {xpMilestones.map((m, i) => {
              const Icon = m.icon;
              const isNext = !m.unlocked && (i === 0 || xpMilestones[i - 1].unlocked);
              return (
                <motion.div
                  key={m.label}
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 * i }}
                  className={`p-4 rounded-[20px] border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] flex flex-col items-center text-center gap-2 relative overflow-hidden transition-all ${m.unlocked ? m.bg : 'bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719]'}`}
                >
                  {isNext && <span className="absolute top-2 right-2 text-[8px] font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 dark:bg-indigo-950/30 px-1.5 py-0.5 rounded-full">Next</span>}
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${m.unlocked ? m.bg : 'bg-slate-100 dark:bg-[#1A1A1A]'} border ${m.border}`}>
                    {m.unlocked
                      ? <Icon size={18} className={m.color} />
                      : <Lock size={14} className="text-slate-300 dark:text-slate-700" />}
                  </div>
                  <div>
                    <p className={`text-[12px] font-bold ${m.unlocked ? 'text-slate-800 dark:text-white' : 'text-slate-400'}`}>{m.label}</p>
                    <p className="text-[9.5px] font-semibold text-slate-400 tabular-nums mt-0.5">{m.xp.toLocaleString()} XP</p>
                  </div>
                  <div className={`w-full px-2 py-1.5 rounded-lg text-[10px] font-bold ${m.unlocked ? m.color + ' ' + m.bg : 'text-slate-400 bg-slate-50 dark:bg-[#1A1A1A]'}`}>
                    {m.reward}
                  </div>
                  {m.unlocked && <CheckCircle size={12} className="text-emerald-500 absolute bottom-2 right-2" />}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* REDEEMABLE REWARDS */}
        <div className="space-y-4">
          <h2 className="text-[13px] font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Redeem Rewards</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {redeemableRewards.map((r, i) => {
              const Icon = r.icon;
              const canAfford = currentXP >= r.cost;
              return (
                <motion.div
                  key={r.id}
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.06 * i }}
                  className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#44444A] transition-all flex items-start gap-4"
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${canAfford ? 'bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600' : 'bg-slate-100 dark:bg-[#1A1A1A] text-slate-400'}`}>
                    <Icon size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="text-[13px] font-semibold text-slate-800 dark:text-white leading-tight">{r.title}</h3>
                        <p className="text-[10.5px] text-slate-400 font-medium mt-1 leading-relaxed">{r.desc}</p>
                      </div>
                      <div className="flex flex-col items-end gap-2 shrink-0">
                        <span className={`text-[11px] font-bold tabular-nums px-2.5 py-1 rounded-lg ${canAfford ? 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/20' : 'text-slate-400 bg-slate-100 dark:bg-[#1A1A1A]'}`}>
                          {r.cost.toLocaleString()} XP
                        </span>
                        <button
                          onClick={() => handleRedeem(r.id, r.cost, r.title)}
                          disabled={!r.available || redeeming === r.id}
                          className={`flex items-center gap-1.5 text-[11px] font-bold px-3 py-1.5 rounded-lg transition-all active:scale-95 ${
                            !r.available
                              ? 'bg-slate-100 dark:bg-[#1A1A1A] text-slate-400 cursor-not-allowed'
                              : canAfford
                                ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm shadow-indigo-600/20'
                                : 'bg-slate-100 dark:bg-[#1A1A1A] text-slate-400 cursor-not-allowed'
                          }`}
                        >
                          {redeeming === r.id ? (
                            <span className="animate-pulse">Processing...</span>
                          ) : !r.available ? (
                            <><Lock size={10} /> Locked</>
                          ) : (
                            <>Redeem <ChevronRight size={12} /></>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* BADGES */}
        <div className="space-y-4">
          <h2 className="text-[13px] font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Achievement Badges</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {badges.map((b, i) => {
              const Icon = b.icon;
              return (
                <motion.div
                  key={b.label}
                  initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.04 * i }}
                  className={`p-4 rounded-[20px] border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.1),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] flex flex-col items-center gap-2.5 text-center transition-all ${b.earned ? 'bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719]' : 'bg-gradient-to-b from-[#F4F4F4] to-[#FAFAFA] dark:from-[#1A1A1A] dark:to-[#141414] opacity-50'}`}
                >
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${b.earned ? `bg-white dark:bg-[#1A1A1A] shadow-lg ${b.glow}` : 'bg-slate-100 dark:bg-[#1A1A1A]'}`}>
                    <Icon size={22} className={b.color} />
                  </div>
                  <p className="text-[10.5px] font-bold text-slate-700 dark:text-slate-300 leading-tight">{b.label}</p>
                  {b.earned
                    ? <span className="text-[9px] font-black uppercase tracking-widest text-emerald-600 bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded-full">Earned</span>
                    : <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 bg-slate-100 dark:bg-[#1A1A1A] px-2 py-0.5 rounded-full">Locked</span>}
                </motion.div>
              );
            })}
          </div>
        </div>

      </div>
    </DashboardLayout>
  );
}
