import React from "react";
import PublicNavbar from "@/components/PublicNavbar";
import PublicFooter from "@/components/PublicFooter";
import { Download, Monitor, Smartphone, Apple } from "lucide-react";

export default function DownloadAppPublic() {
  return (
    <div style={{ background: "#02040A", minHeight: "100vh", color: "#fff", display: "flex", flexDirection: "column" }}>
      <PublicNavbar onSignIn={() => {}} onSignUp={() => {}} onDownloadClick={() => {}} />
      
      <main style={{ flex: 1, padding: "120px 20px 80px", maxWidth: 1200, margin: "0 auto", width: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h1 style={{ fontSize: "3rem", fontWeight: 800, marginBottom: 20 }}>
            Take <span style={{ color: "#3b82f6" }}>TradiFive</span> Everywhere
          </h1>
          <p style={{ fontSize: "1.1rem", color: "rgba(255,255,255,0.6)", maxWidth: 600, margin: "0 auto" }}>
            Institutional-grade execution on your desktop. Powerful insights in your pocket. 
            Download the apps to stay connected to your edge.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 30 }}>
          {/* Desktop Terminal */}
          <div style={{
            background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)",
            borderRadius: 24, padding: 40, textAlign: "center",
            display: "flex", flexDirection: "column", alignItems: "center"
          }}>
            <div style={{ width: 64, height: 64, borderRadius: "50%", background: "rgba(59, 130, 246, 0.1)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 24 }}>
              <Monitor size={32} color="#3b82f6" />
            </div>
            <h2 style={{ fontSize: "1.5rem", fontWeight: 700, marginBottom: 12 }}>Desktop Terminal</h2>
            <p style={{ color: "rgba(255,255,255,0.5)", marginBottom: 30, fontSize: "0.95rem" }}>
              Our flagship Windows and macOS application. Built for multi-monitor setups, complex charting, and split-second MT5 bridge execution.
            </p>
            <div style={{ display: "flex", gap: 12, width: "100%", flexDirection: "column" }}>
              <button style={{ padding: "14px", borderRadius: 12, background: "#fff", color: "#000", fontWeight: 700, border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                <Monitor size={18} /> Download for Windows (.exe)
              </button>
              <button style={{ padding: "14px", borderRadius: 12, background: "rgba(255,255,255,0.05)", color: "#fff", fontWeight: 600, border: "1px solid rgba(255,255,255,0.1)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                <Apple size={18} /> Download for macOS (.dmg)
              </button>
            </div>
          </div>

          {/* Mobile App */}
          <div style={{
            background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)",
            borderRadius: 24, padding: 40, textAlign: "center",
            display: "flex", flexDirection: "column", alignItems: "center"
          }}>
            <div style={{ width: 64, height: 64, borderRadius: "50%", background: "rgba(168, 85, 247, 0.1)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 24 }}>
              <Smartphone size={32} color="#a855f7" />
            </div>
            <h2 style={{ fontSize: "1.5rem", fontWeight: 700, marginBottom: 12 }}>Mobile App</h2>
            <p style={{ color: "rgba(255,255,255,0.5)", marginBottom: 30, fontSize: "0.95rem" }}>
              Manage risk, monitor algorithms, and engage with your channels on the go. Available for iOS and Android devices.
            </p>
            <div style={{ display: "flex", gap: 12, width: "100%", flexDirection: "column" }}>
              <button style={{ padding: "14px", borderRadius: 12, background: "#fff", color: "#000", fontWeight: 700, border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                <Apple size={18} /> Download on App Store
              </button>
              <button style={{ padding: "14px", borderRadius: 12, background: "rgba(255,255,255,0.05)", color: "#fff", fontWeight: 600, border: "1px solid rgba(255,255,255,0.1)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                <Smartphone size={18} /> Get it on Google Play
              </button>
            </div>
          </div>
        </div>
      </main>

      <PublicFooter />
    </div>
  );
}
