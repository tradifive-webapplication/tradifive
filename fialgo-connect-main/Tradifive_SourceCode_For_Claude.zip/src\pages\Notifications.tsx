import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Bell, 
  ShieldAlert, 
  Settings, 
  CreditCard, 
  Zap, 
  Trash2, 
  CheckCircle2,
  Filter,
  Search,
  MessageSquare,
  Heart,
  Sparkles,
  UserCheck,
  Check,
  CheckCheck,
  X,
  Activity,
  Signal,
  ArrowRight,
  Info,
  Clock,
  CornerDownRight,
  Send,
  MoreVertical
} from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";



export default function Notifications() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  
  // Interactive states for inline comment/reply
  const [replyText, setReplyText] = useState("");
  const [submittingReply, setSubmittingReply] = useState(false);
  const [showClearHistoryModal, setShowClearHistoryModal] = useState(false);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { data, error } = await supabase
          .from("notifications")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false });

        if (error) {
          console.error("Supabase notifications fetch error:", error);
          setNotifications([]);
        } else {
          setNotifications(data ?? []);
        }
      } else {
        setNotifications([]);
      }
    } catch (err) {
      console.error("Archive retrieval failed:", err);
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  };

  const markRead = async (id: string) => {
    try {
      await supabase.from("notifications").update({ is_read: true }).eq("id", id);
    } catch (e) {
      console.error("Error updating DB read state:", e);
    }
    
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
    toast.success("Directive flagged as read");
  };

  const markAllRead = async () => {
    const unread = notifications.filter(n => !n.is_read);
    if (unread.length === 0) {
      toast.info("All directives are already marked read");
      return;
    }

    const unreadIds = unread.map(n => n.id);
    if (unreadIds.length > 0) {
      try {
        await supabase.from("notifications").update({ is_read: true }).in("id", unreadIds);
      } catch (e) {
        console.error("Error updating batch DB read state:", e);
      }
    }

    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    toast.success("All archive entries verified as read");
  };

  const deleteNotif = async (id: string) => {
    try {
      await supabase.from("notifications").delete().eq("id", id);
    } catch (e) {
      console.error("Error deleting from DB:", e);
    }
    
    setNotifications(prev => prev.filter(n => n.id !== id));
    if (expandedId === id) setExpandedId(null);
    toast.success("Directive permanently purged from archive");
  };

  const clearAllNotifications = () => {
    if (notifications.length === 0) return;
    setShowClearHistoryModal(true);
  };

  const confirmClearAllNotifications = () => {
    const allIds = notifications.map(n => n.id);
    if (allIds.length > 0) {
      supabase.from("notifications").delete().in("id", allIds).then();
    }
    setNotifications([]);
    setShowClearHistoryModal(false);
    toast.success("Directive Archive completely purged");
  };

  const handleActionClick = (actionLabel: string, notif: any) => {
    toast.dismiss();
    toast.success(`Action successfully executed: "${actionLabel}"`);
  };

  const handleSendReply = (notifId: string, recipient: string) => {
    if (!replyText.trim()) {
      toast.error("Reply input cannot be blank");
      return;
    }
    setSubmittingReply(true);
    toast.success(`Response transmitted to ${recipient}: "${replyText}"`);
    setReplyText("");
    setSubmittingReply(false);
    setExpandedId(null);
    markRead(notifId);
  };

  const getIcon = (type: string, isRead: boolean) => {
    const iconClass = isRead 
      ? "text-slate-400 dark:text-slate-500" 
      : "text-slate-800 dark:text-slate-200";

    switch (type) {
      case 'SOCIAL': 
        return <Heart size={15} className={`${isRead ? "text-slate-450" : "text-rose-500 fill-rose-500/20"}`} />;
      case 'RISK_GUARD': 
        return <ShieldAlert size={15} className={`${isRead ? "text-slate-450" : "text-amber-500"}`} />;
      case 'AI_COACH': 
        return <Sparkles size={15} className={`${isRead ? "text-slate-450" : "text-violet-500"}`} />;
      case 'SYSTEM': 
        return <Activity size={15} className={`${isRead ? "text-slate-450" : "text-emerald-500"}`} />;
      case 'SECURITY': 
        return <ShieldAlert size={15} className="text-red-500" />;
      case 'ACCOUNT': 
        return <Settings size={15} className={iconClass} />;
      case 'PAYMENT': 
        return <CreditCard size={15} className="text-emerald-500" />;
      case 'TRADE': 
        return <Zap size={15} className="text-amber-500" />;
      default: 
        return <Bell size={15} className={iconClass} />;
    }
  };

  const getBadgeStyle = (type: string) => {
    switch (type) {
      case 'AI_COACH':
        return 'bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20';
      case 'SOCIAL':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20';
      case 'RISK_GUARD':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
      case 'SYSTEM':
        return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20';
      default:
        return 'bg-slate-550/10 text-slate-600 dark:text-slate-400 border-slate-550/20';
    }
  };

  const formatCategoryName = (type: string) => {
    return type.replace('_', ' ');
  };

  const filteredNotifs = notifications
    .filter(n => {
      if (filter === "ALL") return true;
      return n.type === filter;
    })
    .filter(n => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return (
        n.title?.toLowerCase().includes(query) ||
        n.message?.toLowerCase().includes(query) ||
        n.tag?.toLowerCase().includes(query) ||
        n.type?.toLowerCase().includes(query)
      );
    });

  const getCounts = (type: string) => {
    if (type === "ALL") return notifications.length;
    return notifications.filter(n => n.type === type).length;
  };

  const getUnreadCount = () => {
    return notifications.filter(n => !n.is_read).length;
  };

  const grouped = (() => {
    const today: any[] = [];
    const yesterday: any[] = [];
    const older: any[] = [];
    
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfYesterday = new Date(startOfToday.getTime() - 24 * 60 * 60 * 1000);
    
    filteredNotifs.forEach(n => {
      const date = new Date(n.created_at || Date.now());
      if (date >= startOfToday) {
        today.push(n);
      } else if (date >= startOfYesterday) {
        yesterday.push(n);
      } else {
        older.push(n);
      }
    });
    
    return { today, yesterday, older };
  })();

  const renderSectionHeader = (title: string, count: number) => {
    if (count === 0) return null;
    return (
      <div className="flex items-center gap-3 pt-4 first:pt-0 pb-2">
        <span className="text-[10px] font-black tracking-[0.2em] text-slate-400 dark:text-slate-550 uppercase">{title}</span>
        <div className="h-[1px] flex-1 bg-slate-100 dark:bg-slate-800/40" />
        <span className="text-[9px] font-bold text-slate-450 dark:text-slate-500 px-2 py-0.5 rounded-md bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850/50">{count}</span>
      </div>
    );
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6 animate-fade-in pb-20 px-2 sm:px-4 font-sans text-slate-800 dark:text-slate-100 select-none">
        
        {/* HEADER SECTION */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800/40 pb-5">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Directive Hub</h1>
              {getUnreadCount() > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-slate-900 text-white dark:bg-[#1A1A1A] dark:text-white border border-transparent dark:border-[#2B2B2F] shadow-sm animate-pulse">
                  {getUnreadCount()} Unread
                </span>
              )}
            </div>
            <p className="text-[12.5px] text-slate-500 dark:text-slate-400 font-medium mt-1">
              Real-time alerts, system risk guards, and institutional updates.
            </p>
          </div>
          
          <div className="flex items-center gap-2 self-start md:self-auto text-[11px] font-bold">
            <button 
              onClick={markAllRead}
              className="px-3.5 py-2.5 rounded-xl transition-all flex items-center gap-1.5 bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] border border-white dark:border-[#1A1A1A] text-slate-900 dark:text-white hover:opacity-90"
              title="Mark All Read"
            >
              <CheckCheck size={13} />
              Verify All
            </button>
            <button 
              onClick={clearAllNotifications}
              className="px-3.5 py-2.5 rounded-xl transition-all flex items-center gap-1.5 bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] border border-white dark:border-[#1A1A1A] text-rose-600 dark:text-rose-500 hover:opacity-90"
              title="Clear All Directives"
            >
              <Trash2 size={13} />
              Purge Archive
            </button>
          </div>
        </div>

        {/* SEARCH AND FILTERS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 items-center bg-slate-50/50 dark:bg-[#121212] p-3 rounded-2xl border border-slate-150 dark:border-[#1A1A1A]">
          {/* SEARCH BOX */}
          <div className="relative col-span-1 lg:col-span-4">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-550" size={15} />
            <input 
              type="text"
              placeholder="Search directives..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100/80 dark:bg-[#1A1A1A] border border-slate-200/50 dark:border-[#1A1A1A] rounded-xl pl-10 pr-4 py-2.5 text-[13px] font-normal placeholder:text-slate-400 dark:placeholder:text-slate-500 text-slate-800 dark:text-white outline-none focus:border-slate-400 focus:bg-white transition-all"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery("")} 
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-650 dark:hover:text-slate-250"
              >
                <X size={12} />
              </button>
            )}
          </div>

          {/* DYNAMIC SCROLLABLE CATEGORY TABS */}
          <div className="col-span-1 lg:col-span-8 flex items-center gap-1.5 p-1 bg-slate-100/80 dark:bg-[#121212] rounded-full border border-slate-200/30 dark:border-[#1A1A1A] text-[11px] font-bold overflow-x-auto scrollbar-hide shrink-0">
            {["ALL", "AI_COACH", "SOCIAL", "RISK_GUARD", "SYSTEM"].map(t => {
              const active = filter === t;
              return (
                <button
                  key={t}
                  onClick={() => setFilter(t)}
                  className={`px-3 py-1.5 rounded-full text-center transition-all flex items-center gap-1 shrink-0 ${
                    active 
                      ? 'bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] border border-white dark:border-[#1A1A1A] text-slate-900 dark:text-white' 
                      : 'text-slate-450 hover:text-slate-850 dark:text-slate-500 dark:hover:text-slate-300 border border-transparent'
                  }`}
                >
                  <span>{formatCategoryName(t)}</span>
                  <span className={`text-[8.5px] font-bold px-1.5 py-0.5 rounded-full ${
                    active 
                      ? 'bg-slate-100 dark:bg-[#1A1A1A] text-slate-900 dark:text-slate-200' 
                      : 'bg-slate-200/60 dark:bg-[#121212] text-slate-500 dark:text-slate-400'
                  }`}>
                    {getCounts(t)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* NOTIFICATIONS CONTAINER */}
        <div className="space-y-6">
          {loading ? (
            <div className="space-y-3">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="h-20 bg-slate-50 dark:bg-[#121212] animate-pulse rounded-2xl border border-slate-100 dark:border-[#1A1A1A]" />
              ))}
            </div>
          ) : filteredNotifs.length > 0 ? (
            <div className="space-y-4">
              
              {/* TODAY GROUP */}
              {grouped.today.length > 0 && (
                <div className="space-y-2.5">
                  {renderSectionHeader("Today", grouped.today.length)}
                  <AnimatePresence initial={false}>
                    {grouped.today.map((n) => renderCard(n))}
                  </AnimatePresence>
                </div>
              )}

              {/* YESTERDAY GROUP */}
              {grouped.yesterday.length > 0 && (
                <div className="space-y-2.5">
                  {renderSectionHeader("Yesterday", grouped.yesterday.length)}
                  <AnimatePresence initial={false}>
                    {grouped.yesterday.map((n) => renderCard(n))}
                  </AnimatePresence>
                </div>
              )}

              {/* OLDER GROUP */}
              {grouped.older.length > 0 && (
                <div className="space-y-2.5">
                  {renderSectionHeader("Archive History", grouped.older.length)}
                  <AnimatePresence initial={false}>
                    {grouped.older.map((n) => renderCard(n))}
                  </AnimatePresence>
                </div>
              )}

            </div>
          ) : (
            <div className="text-center py-20 bg-slate-50/20 dark:bg-slate-900/5 border border-dashed border-slate-200 dark:border-slate-800/40 rounded-3xl">
              <Bell size={36} className="mx-auto text-slate-300 dark:text-slate-700 mb-4 opacity-40 animate-pulse" />
              <p className="text-slate-400 dark:text-slate-550 font-black uppercase tracking-[0.2em] text-[10px]">Matrix Clean</p>
              <p className="text-slate-500 dark:text-slate-650 text-[12px] mt-1 font-medium">No matching directives exist in this archive.</p>
            </div>
          )}
        </div>
      </div>

      {/* Clear Archive Confirmation Modal */}
      <Dialog open={showClearHistoryModal} onOpenChange={setShowClearHistoryModal}>
        <DialogContent className="sm:max-w-[360px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_8px_24px_-4px_rgba(0,0,0,0.5),0_0_0_2px_#2B2B2F] rounded-2xl p-0 overflow-hidden [&>button]:hidden">
          <X 
            size={20} 
            className="absolute right-4 top-4 text-slate-400 dark:text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer z-10" 
            onClick={() => setShowClearHistoryModal(false)} 
          />
          <div className="flex flex-col items-center text-center p-8 space-y-6 pt-10">
            <div className="w-[68px] h-[68px] rounded-full flex items-center justify-center shrink-0">
              <div className="absolute w-[68px] h-[68px] rounded-full bg-rose-500/10 dark:bg-rose-500/20 animate-pulse" />
              <div className="relative w-14 h-14 rounded-full bg-rose-100 dark:bg-rose-500/30 border-4 border-white dark:border-[#1A1A1A] flex items-center justify-center shadow-sm">
                <Trash2 size={24} className="text-rose-600 dark:text-rose-400" />
              </div>
            </div>
            
            <div className="space-y-2.5">
              <DialogTitle className="text-[20px] font-bold text-slate-900 dark:text-white tracking-tight">
                Purge Archive?
              </DialogTitle>
              
              <p className="text-[14px] text-slate-500 dark:text-slate-400 leading-relaxed px-2 font-medium">
                This action is irreversible. All directives and history will be permanently erased from your matrix.
              </p>
            </div>

            <div className="flex w-full gap-3 pt-4">
              <button 
                type="button" 
                onClick={() => setShowClearHistoryModal(false)}
                className="flex-1 py-3.5 rounded-full font-semibold text-slate-700 dark:text-white border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] hover:brightness-95 dark:hover:brightness-110 transition-all text-[15px] active:scale-95"
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={confirmClearAllNotifications}
                className="flex-1 py-3.5 rounded-full font-semibold text-white bg-gradient-to-b from-[#ff6b6b] to-[#fa5252] border-2 border-[#fa5252]/30 shadow-[0_4px_14px_rgba(250,82,82,0.3),0_0_0_2px_rgba(250,82,82,0.15)] hover:brightness-110 transition-all text-[15px] active:scale-95"
              >
                Purge
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );

  // INDIVIDUAL NOTIFICATION CARD RENDER
  function renderCard(n: any) {
    const isExpanded = expandedId === n.id;
    const dateFormatted = n.created_at 
      ? format(new Date(n.created_at), 'HH:mm') 
      : 'Recently';

    return (
      <motion.div 
        layout
        key={n.id} 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.2 }}
        className={`group rounded-2xl border transition-all duration-300 overflow-hidden ${
          !n.is_read 
            ? 'bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] border border-white dark:border-[#1A1A1A]' 
            : 'bg-white dark:bg-[#121212] border-slate-100 dark:border-[#1A1A1A] opacity-60 hover:opacity-100 shadow-2xs'
        }`}
      >
        <div 
          onClick={() => setExpandedId(isExpanded ? null : n.id)}
          className="p-4 cursor-pointer flex gap-4 select-none relative"
        >
          {/* UNREAD SIDE PILL INDICATOR */}
          {!n.is_read && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-8 rounded-r-md bg-slate-550 dark:bg-slate-400" />
          )}

          {/* LEFT AVATAR OR INTEGRATED ICON */}
          <div className="shrink-0 relative">
            {n.avatar ? (
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-slate-200/70 dark:border-[#1A1A1A] shadow-sm bg-slate-100 dark:bg-[#121212]">
                <img src={n.avatar} alt="Sender" className="w-full h-full object-cover" />
              </div>
            ) : (
              <div className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all bg-slate-50 dark:bg-[#1A1A1A] border-slate-200 dark:border-[#1A1A1A]`}>
                {getIcon(n.type, n.is_read)}
              </div>
            )}
            
            {/* MINI TYPE CORNER ICON ON AVATARS */}
            {n.avatar && (
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-md bg-white dark:bg-slate-950 flex items-center justify-center border border-slate-100 dark:border-slate-800 shadow-sm">
                {getIcon(n.type, n.is_read)}
              </div>
            )}
          </div>

          {/* TEXT DESCRIPTION STREAM */}
          <div className="flex-1 min-w-0 space-y-1">
            <div className="flex items-center gap-2">
              <span className={`text-[8.5px] font-bold uppercase tracking-widest px-2 py-0.5 rounded border ${getBadgeStyle(n.type)}`}>
                {formatCategoryName(n.type)}
              </span>
              {n.tag && (
                <span className="text-[9.5px] text-slate-450 dark:text-slate-500 font-bold uppercase tracking-wider hidden sm:inline">
                  &bull; {n.tag}
                </span>
              )}
            </div>

            <h3 className={`text-[13.5px] font-bold text-slate-900 dark:text-white transition-colors truncate ${!n.is_read ? 'text-slate-950 dark:text-slate-50 font-extrabold' : ''}`}>
              {n.title}
            </h3>
            
            <p className="text-[12.5px] text-slate-500 dark:text-slate-405 font-medium leading-relaxed line-clamp-2">
              {n.message}
            </p>
          </div>

          {/* RIGHT ACTION COLUMN (TIME + BUTTONS) */}
          <div className="flex flex-col items-end justify-between shrink-0 pl-2 self-stretch py-0.5">
            <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500 opacity-100">
              <Clock size={11} className="text-slate-400 dark:text-slate-550" />
              <span className="text-[9.5px] font-bold uppercase tracking-wider">{dateFormatted}</span>
            </div>

            <div className="flex items-center gap-1 mt-auto opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity" onClick={e => e.stopPropagation()}>
              {!n.is_read && (
                <button 
                  onClick={() => markRead(n.id)} 
                  className="p-1.5 rounded-lg transition-all bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] border border-white dark:border-[#1A1A1A] text-[#3b82f6] hover:opacity-90" 
                  title="Mark Read"
                >
                  <CheckCheck size={14} />
                </button>
              )}
              <button 
                onClick={() => deleteNotif(n.id)} 
                className="p-1.5 rounded-lg transition-all bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] border border-white dark:border-[#1A1A1A] text-rose-500 hover:opacity-90" 
                title="Delete"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* EXPANDABLE SAAS DRAWER & INTERACTIVE INPUT */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div 
              initial={{ height: 0 }}
              animate={{ height: "auto" }}
              exit={{ height: 0 }}
              transition={{ duration: 0.25 }}
              className="bg-slate-50/50 dark:bg-[#121212] border-t border-slate-100 dark:border-[#1A1A1A] overflow-hidden"
            >
              <div className="p-4 sm:p-5 space-y-4">
                <div className="space-y-2 text-[13px] leading-relaxed font-normal text-slate-600 dark:text-slate-350">
                  <p>{n.details || "No additional technical parameters are logged for this directive archive entry."}</p>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9.5px] font-bold text-slate-405 dark:text-slate-500 uppercase tracking-widest">ID:</span>
                    <code className="text-[9.5px] font-mono bg-slate-100 dark:bg-slate-800/80 px-1.5 py-0.5 rounded text-slate-550 dark:text-slate-400">{n.id}</code>
                  </div>

                  {n.actionLabel && (
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => handleActionClick(n.actionLabel, n)}
                        className="px-4 py-2 rounded-xl text-[11px] font-bold uppercase tracking-widest bg-slate-900 text-white dark:bg-white dark:text-slate-950 hover:opacity-90 transition-all flex items-center gap-1 shadow-3xs"
                      >
                        {n.actionLabel}
                        <ArrowRight size={11} />
                      </button>
                    </div>
                  )}
                </div>

                {/* DYNAMIC REPLY STREAM FOR SOCIAL/COMMENT THREADS */}
                {n.type === "SOCIAL" && n.title.includes("commented") && (
                  <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800/40 space-y-3">
                    <div className="flex items-start gap-2.5">
                      <CornerDownRight size={14} className="text-slate-400 mt-2" />
                      <div className="flex-1 bg-white dark:bg-[#1A1A1A] rounded-xl p-3 border border-slate-200 dark:border-[#1A1A1A] shadow-inner flex gap-2 items-center">
                        <input 
                          type="text" 
                          placeholder={`Write a reply to Marcus...`}
                          value={replyText}
                          onChange={e => setReplyText(e.target.value)}
                          className="flex-1 bg-transparent text-[12.5px] font-normal text-slate-800 dark:text-slate-100 focus:outline-none placeholder:text-slate-400"
                          onKeyDown={e => {
                            if (e.key === 'Enter') handleSendReply(n.id, "Marcus Vance");
                          }}
                        />
                        <button 
                          disabled={submittingReply}
                          onClick={() => handleSendReply(n.id, "Marcus Vance")}
                          className="p-2 bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950 rounded-lg transition-all disabled:opacity-50 flex items-center justify-center shadow-sm"
                        >
                          <Send size={11} className={submittingReply ? "animate-spin" : ""} />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  }
}
