import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import DashboardLayout from "@/components/DashboardLayout";
import { 
  Search, Megaphone, CheckCircle2, MoreVertical, 
  Search as SearchIcon, VolumeX, Volume2, X, Share2, CornerUpRight, SendHorizonal,
  Pin, Gift, Phone, User, Users, Bookmark, Settings as SettingsIcon, 
  Send, Plus, Eye, MessageSquare, Menu, LogOut, AlertTriangle, Info,
  Image as ImageIcon, Film, Folder, Link2, BarChart2, Mic, QrCode, Trash, Paperclip, Smile, Edit2, Copy
} from "lucide-react";
import { toast } from "sonner";
import { 
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import EmojiPicker from 'emoji-picker-react';
import { supabase } from "@/lib/supabase";
import { useChannelData, MessageType } from "@/hooks/useChannelData";

export default function Channel() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [authChecked, setAuthChecked] = useState(false);

  const [activeChannelId, setActiveChannelId] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isMuted, setIsMuted] = useState(false);
  const [inputText, setInputText] = useState("");
  const [showPinned, setShowPinned] = useState(true);
  const [showDetails, setShowDetails] = useState(false); // Drawer state
  const [themeMode, setThemeMode] = useState(() => localStorage.getItem("theme") || "dark");

  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [attachment, setAttachment] = useState<File | null>(null);
  const [attachmentPreview, setAttachmentPreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [activeReactionMessageId, setActiveReactionMessageId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [isPollModalOpen, setIsPollModalOpen] = useState(false);
  const [pollQuestion, setPollQuestion] = useState("");
  const [pollOptions, setPollOptions] = useState(["", ""]);

  const messageEndRef = useRef<HTMLDivElement>(null);

  // 1. Auth session check
  useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        navigate("/login");
      } else {
        setUser(session.user);
        setAuthChecked(true);
      }
    };
    checkUser();
  }, [navigate]);

  // 2. Real-time Database Messaging Hook
  const { channels: dbChannels, messages: dbMessages, loading: dbLoading, sendMessage, updateMessage, deleteMessage, editMessage, clearHistory, markAsSeen, refetchChannels, isMember, joinChannel } = useChannelData(user?.id ?? "", activeChannelId);

  // Create Channel Modal State
  const [createStep, setCreateStep] = useState<1 | 2>(1);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newChannelName, setNewChannelName] = useState("");
  const [newChannelDesc, setNewChannelDesc] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [followedUsers, setFollowedUsers] = useState<any[]>([]);
  const [selectedInvites, setSelectedInvites] = useState<Record<string, boolean>>({});

  // Manage Channel State
  const [isManageModalOpen, setIsManageModalOpen] = useState(false);
  const [manageType, setManageType] = useState("public");
  const [manageMessages, setManageMessages] = useState(true);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [showClearHistoryModal, setShowClearHistoryModal] = useState(false);
  const [showDeleteMessageModal, setShowDeleteMessageModal] = useState<string | null>(null);
  
  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    messageId: string;
    isMe: boolean;
    content: string;
  } | null>(null);

  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  useEffect(() => {
    const closeMenu = () => setContextMenu(null);
    window.addEventListener('click', closeMenu);
    return () => window.removeEventListener('click', closeMenu);
  }, []);

  useEffect(() => {
    if (isCreateModalOpen && user?.id) {
        const fetchFollows = async () => {
            const { data } = await supabase
                .from('social_follows')
                .select('following_id, profiles!social_follows_following_id_fkey(id, username, display_name, avatar_url)')
                .eq('follower_id', user.id);
            if (data) {
                setFollowedUsers(data.map((d: any) => d.profiles));
            }
        };
        fetchFollows();
    } else {
        setCreateStep(1);
        setSelectedInvites({});
        setNewChannelName("");
        setNewChannelDesc("");
    }
  }, [isCreateModalOpen, user?.id]);

  const handleCreateChannel = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (createStep === 1) {
        if (!newChannelName.trim()) {
            toast.error('Channel name is required');
            return;
        }
        setCreateStep(2);
        return;
    }

    setIsCreating(true);
    try {
      const currentUser = user;
      if (!currentUser) {
        toast.error('You must be logged in to create a channel');
        setIsCreating(false);
        return;
      }

      const slug = newChannelName.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Math.floor(Math.random() * 1000);
      
      const { data, error } = await supabase.from('channels').insert({
          name: newChannelName,
          description: newChannelDesc,
          slug: slug,
          created_by: currentUser.id,
          channel_type: 'public',
          is_official: false,
      }).select().single();

      if (error) throw error;

      if (data?.id) {
          await supabase.from('channel_members').insert({
              channel_id: data.id,
              user_id: currentUser.id,
              role: 'admin'
          });
          
          const invitesToInsert = Object.keys(selectedInvites).filter(k => selectedInvites[k]).map(uid => ({
              channel_id: data.id,
              user_id: uid,
              role: 'member'
          }));
          if (invitesToInsert.length > 0) {
              await supabase.from('channel_members').insert(invitesToInsert);
          }
      }

      toast.success("Channel created successfully!");
      setIsCreateModalOpen(false);
      refetchChannels();
      if (data?.id) setActiveChannelId(data.id);
    } catch (err: any) {
        toast.error(`Failed to create channel: ${err.message || JSON.stringify(err)}`);
        console.error("Channel creation error details:", err);
    } finally {
        setIsCreating(false);
    }
  };
  
  const toggleInvite = (uid: string) => {
      setSelectedInvites(prev => ({ ...prev, [uid]: !prev[uid] }));
  };
  
  const handleSaveSettings = async () => {
    if (!activeChannelId) return;
    setIsSavingSettings(true);
    try {
        const { error } = await supabase
            .from('channels')
            .update({
                channel_type: manageType,
                rules: JSON.stringify({ allow_messages: manageMessages })
            })
            .eq('id', activeChannelId);
        
        if (error) throw error;
        toast.success('Channel settings updated');
        setIsManageModalOpen(false);
        refetchChannels();
    } catch(err: any) {
        toast.error('Failed to update settings');
    } finally {
        setIsSavingSettings(false);
    }
  };

  // Sync default active channel once loaded
  useEffect(() => {
    if (dbChannels.length > 0 && !dbChannels.some(c => c.id === activeChannelId)) {
      setActiveChannelId(dbChannels[0].id);
    } else if (dbChannels.length === 0) {
      setActiveChannelId("");
    }
  }, [dbChannels, activeChannelId]);

  const prevMessageCountRef = useRef(0);

  useEffect(() => {
    // Only scroll to bottom if a new message is added (length increased)
    if (dbMessages.length > prevMessageCountRef.current) {
      messageEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
    prevMessageCountRef.current = dbMessages.length;

    // Real-time Views: Mark unseen messages as seen
    const unreadMessages = dbMessages.slice(-20).filter(m => m.user_id !== user?.id);
    unreadMessages.forEach(m => {
        try {
            const parsed = JSON.parse(m.content);
            if (!parsed.seen_by || !parsed.seen_by.includes(user?.id)) {
                markAsSeen(m.id, m.content);
            }
        } catch(e) {}
    });
  }, [dbMessages, user?.id, markAsSeen]);

  useEffect(() => {
    // Force scroll down when switching active channel
    setTimeout(() => {
      messageEndRef.current?.scrollIntoView({ behavior: "auto" });
    }, 100);
  }, [activeChannelId]);

  useEffect(() => {
    const handleStorageChange = () => {
      const currentTheme = localStorage.getItem("theme") || "dark";
      setThemeMode(currentTheme);
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

function ChannelSkeleton() {
  return (
    <div className="w-full h-full flex min-h-0 select-none animate-pulse">
      {/* Sidebar column (Channels List) */}
      <div className="w-[360px] shrink-0 border-r border-slate-150 dark:border-[#1A1A1A] bg-[#F8FAFC] dark:bg-[#121212] p-4 space-y-6">
        <div className="h-9 w-full bg-slate-250 dark:bg-[#1A1A1A] rounded-xl border-2 border-white dark:border-[#1A1A1A] shadow-xs" />
        <div className="space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex items-center gap-3 px-2">
              <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 shrink-0 border border-slate-100 dark:border-[#1A1A1A]" />
              <div className="flex-1 space-y-1.5 min-w-0">
                <div className="h-3.5 w-24 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-2.5 w-full bg-slate-200 dark:bg-slate-800 rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main chat window skeleton */}
      <div className="flex-1 flex flex-col bg-[#F1F5F9] dark:bg-[#0A0A0A]">
        {/* Chat header */}
        <div className="h-[60px] px-6 border-b border-slate-150 dark:border-[#1A1A1A] flex items-center justify-between bg-white dark:bg-[#121212]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 border border-slate-100 dark:border-[#1A1A1A]" />
            <div className="space-y-1.5">
              <div className="h-3.5 w-28 bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="h-2.5 w-16 bg-slate-200 dark:bg-slate-800 rounded" />
            </div>
          </div>
          <div className="flex gap-2">
            <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 border-2 border-white dark:border-[#1A1A1A] shadow-xs" />
            <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 border-2 border-white dark:border-[#1A1A1A] shadow-xs" />
            <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 border-2 border-white dark:border-[#1A1A1A] shadow-xs" />
          </div>
        </div>

        {/* Chat body messages list */}
        <div className="flex-1 p-6 space-y-6 overflow-y-auto">
          {/* Left message (received) */}
          <div className="flex items-start gap-3 max-w-2xl">
            <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 shrink-0 border border-slate-100 dark:border-[#1A1A1A]" />
            <div className="p-4 rounded-2xl rounded-bl-none bg-white dark:bg-[#1A1A1A] border border-slate-200/60 dark:border-white/5 shadow-xs w-2/3 space-y-2">
              <div className="h-3 w-full bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="h-3 w-5/6 bg-slate-200 dark:bg-slate-800 rounded" />
            </div>
          </div>

          {/* Right message (sent) */}
          <div className="flex items-start gap-3 justify-end max-w-2xl ml-auto flex-row-reverse">
            <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 shrink-0 border border-slate-100 dark:border-[#1A1A1A]" />
            <div className="p-4 rounded-2xl rounded-br-none bg-white dark:bg-[#1A1A1A] border border-slate-200/60 dark:border-white/5 shadow-xs w-1/2 space-y-2">
              <div className="h-3 w-full bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="h-3 w-2/3 bg-slate-200 dark:bg-slate-800 rounded" />
            </div>
          </div>

          {/* Left message (received) */}
          <div className="flex items-start gap-3 max-w-2xl">
            <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 shrink-0 border border-slate-100 dark:border-[#1A1A1A]" />
            <div className="p-4 rounded-2xl rounded-bl-none bg-white dark:bg-[#1A1A1A] border border-slate-200/60 dark:border-white/5 shadow-xs w-3/5 space-y-2">
              <div className="h-3 w-full bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="h-3 w-full bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="h-3 w-1/3 bg-slate-200 dark:bg-slate-800 rounded" />
            </div>
          </div>
        </div>

        {/* Chat input footer */}
        <div className="p-4 px-6 border-t border-slate-150 dark:border-[#1A1A1A] bg-white dark:bg-[#121212]">
          <div className="h-12 w-full bg-slate-100 dark:bg-[#1A1A1A] rounded-[24px] border border-transparent" />
        </div>
      </div>
    </div>
  );
}

  if (!authChecked || (dbLoading && dbChannels.length === 0)) {
    return (
      <DashboardLayout noPadding={true} noScroll={true}>
        <ChannelSkeleton />
      </DashboardLayout>
    );
  }

  // Blended Channels mapping
  const finalChannels = dbChannels.map(ch => ({
    id: ch.id,
    name: ch.name,
    handle: ch.slug,
    unread: 0,
    time: new Date(ch.created_at || "").toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
    content: ch.description || "Welcome to the channel!",
    avatar: `https://api.dicebear.com/7.x/identicon/png?seed=${ch.name}`,
    verified: ch.is_official || false,
    subscribers: ch.member_count !== null ? `${ch.member_count} subscribers` : "250 subscribers",
    isBroadcast: ch.channel_type === "public",
    created_by: ch.created_by,
    channel_type: ch.channel_type,
    rules: ch.rules
  }));

  const activeChannel = finalChannels.find(c => c.id === activeChannelId);

  // Blended Messages mapping
  const finalMessages = activeChannelId
    ? dbMessages.map(m => {
        let textContent = m.content;
        let reactionsObj = {};
        let mediaUrl = null;
        let messageType = 'text';
        let msgViews = 1;

        let pollData = null;

        try {
            const parsed = JSON.parse(m.content);
            if (parsed && typeof parsed === 'object' && parsed.type) {
                textContent = parsed.text || '';
                messageType = parsed.type;
                if (parsed.url) mediaUrl = parsed.url;
                if (parsed.reactions) reactionsObj = parsed.reactions;
                if (parsed.views) msgViews = parsed.views;
                if (parsed.type === 'poll') {
                    pollData = {
                        question: parsed.question,
                        options: parsed.options,
                        totalVotes: parsed.totalVotes
                    };
                }
            }
        } catch(e) {
            // normal text
        }

        return {
          id: m.id,
          sender: m.profiles?.full_name || m.profiles?.username || "Anonymous Member",
          avatar: m.profiles?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${m.profiles?.full_name || 'U'}`,
          content: textContent,
          views: msgViews.toString(),
          time: new Date(m.created_at || "").toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
          reactions: reactionsObj,
          image: messageType === 'image' ? mediaUrl : null,
          video: messageType === 'video' ? mediaUrl : null,
          type: messageType,
          poll: pollData,
          isMe: m.user_id === user?.id
        };
      })
    : [];

  const activeDetails = activeChannel ? {
    handle: activeChannel.handle,
    link: `t.me/${activeChannel.handle}`,
    description: activeChannel.content || "Official Tradifive communication channel.",
    giftsCount: "0 gifts",
    photosCount: "12 photos",
    videosCount: "1 video",
    filesCount: "3 files",
    linksCount: "15 shared links",
    pollsCount: "0 polls",
    voicesCount: "0 voice messages",
    gifsCount: "0 GIFs",
    similarCount: "4 similar channels",
    subscribers: activeChannel.subscribers
  } : {
    handle: "",
    link: "",
    description: "",
    giftsCount: "0 gifts",
    photosCount: "0 photos",
    videosCount: "0 videos",
    filesCount: "0 files",
    linksCount: "0 shared links",
    pollsCount: "0 polls",
    voicesCount: "0 voice messages",
    gifsCount: "0 GIFs",
    similarCount: "0 similar channels",
    subscribers: "0 subscribers"
  };

  const handleToggleMute = () => {
    setIsMuted(!isMuted);
    if (!isMuted) {
      toast.info("Channel notifications muted");
    } else {
      toast.success("Channel notifications unmuted");
    }
  };

  const handleReactionClick = async (messageId: string, emoji: string) => {
    const targetMsg = dbMessages.find(m => m.id === messageId);
    if (!targetMsg) return;
    
    let parsedObj: any = {};
    let reactionsObj: Record<string, number> = {};

    try {
      const parsed = JSON.parse(targetMsg.content);
      if (parsed && typeof parsed === 'object' && parsed.type) {
         parsedObj = { ...parsed };
         reactionsObj = parsed.reactions || {};
      } else {
         parsedObj = { type: 'text', text: targetMsg.content };
      }
    } catch(e) {
      parsedObj = { type: 'text', text: targetMsg.content };
    }

    reactionsObj[emoji] = (reactionsObj[emoji] || 0) + 1;
    parsedObj.reactions = reactionsObj;

    const newContent = JSON.stringify(parsedObj);

    // Optimistic Update
    updateMessage(messageId, newContent);

    await supabase.from('channel_messages').update({ content: newContent }).eq('id', messageId);
    setActiveReactionMessageId(null);
  };

  const handleAttachmentSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAttachment(file);
      setAttachmentPreview(URL.createObjectURL(file));
    }
  };

  const removeAttachment = () => {
    setAttachment(null);
    setAttachmentPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSendMessage = async (e: React.FormEvent | React.KeyboardEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !attachment) return;

    if (editingMessageId) {
      const targetMsg = dbMessages.find(m => m.id === editingMessageId);
      if (targetMsg) {
        let parsedObj: any = {};
        
        try {
          const parsed = JSON.parse(targetMsg.content);
          if (parsed && typeof parsed === 'object' && parsed.type) {
            parsedObj = { ...parsed };
          } else {
            parsedObj = { type: 'text' };
          }
        } catch(e) {
          parsedObj = { type: 'text' };
        }
        
        if (parsedObj.type === 'poll') {
           parsedObj.question = inputText.trim();
        } else {
           parsedObj.text = inputText.trim();
        }
        
        const updatedContent = JSON.stringify(parsedObj);
        
        updateMessage(editingMessageId, updatedContent);
        await editMessage(editingMessageId, updatedContent);
      }
      setEditingMessageId(null);
      setInputText("");
      return;
    }

    setIsUploading(true);
    let uploadedUrl = null;
    let msgType = 'text';

    if (attachment) {
      const fileExt = attachment.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${user?.id}/${fileName}`;
      try {
        const { error: uploadError } = await supabase.storage.from('attachments').upload(filePath, attachment);
        if (!uploadError) {
           const { data } = supabase.storage.from('attachments').getPublicUrl(filePath);
           uploadedUrl = data.publicUrl;
           msgType = attachment.type.startsWith('video/') ? 'video' : 'image';
        } else {
           toast.error("Attachment failed. Make sure you have an 'attachments' bucket in Supabase.");
        }
      } catch (err) {}
    }

    const payload = {
      type: msgType,
      text: inputText.trim(),
      url: uploadedUrl,
      reactions: {}
    };

    await sendMessage(JSON.stringify(payload));

    setInputText("");
    removeAttachment();
    setShowEmojiPicker(false);
    setIsUploading(false);

    setTimeout(() => {
      messageEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 50);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(e);
    }
  };

  const handleCreatePoll = async () => {
    const validOptions = pollOptions.filter(o => o.trim() !== "");
    if (!pollQuestion.trim() || validOptions.length < 2) {
      toast.error("Please enter a question and at least 2 options");
      return;
    }
    
    const pollData = {
      type: 'poll',
      question: pollQuestion,
      options: validOptions.map(o => ({ text: o, votes: 0 })),
      totalVotes: 0
    };
    
    await sendMessage(JSON.stringify(pollData));
    setIsPollModalOpen(false);
    setPollQuestion("");
    setPollOptions(["", ""]);
    toast.success("Poll created");
  };

  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setInputText("");
  };

  const onEmojiClick = (emojiData: any) => {
    setInputText(prev => prev + emojiData.emoji);
  };

  const handleSharePost = (channelId: string) => {
    navigator.clipboard.writeText(`${window.location.origin}/channel/${channelId}`);
    toast.success("Channel link copied to clipboard!");
  };

  // Filter channels based on search query
  const filteredChannels = finalChannels.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const headerActions = (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button 
          className="flex items-center justify-center w-10 h-10 rounded-xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.08),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-all active:scale-95 cursor-pointer outline-none"
          title="Channel Menu"
        >
          <Menu size={20} />
        </button>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent align="end" className="w-56 mt-2 rounded-2xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] p-1.5 z-[100] outline-none">
        <DropdownMenuLabel className="px-3 py-2 text-[11px] font-bold text-slate-400 dark:text-slate-505 uppercase tracking-wider">
          Channel Actions
        </DropdownMenuLabel>
        <DropdownMenuSeparator className="my-1 border-slate-100 dark:border-[#1A1A1A]" />
        
        <DropdownMenuItem 
          onClick={() => toast.info("New Group console requested")}
          className="flex items-center gap-3 text-[13.5px] font-medium text-slate-700 dark:text-slate-350 hover:bg-slate-100/80 dark:hover:bg-slate-800/40 px-3 py-2.5 rounded-xl transition-all cursor-pointer outline-none"
        >
          <Users size={16} className="text-slate-400" />
          <span>New Group</span>
        </DropdownMenuItem>

        <DropdownMenuItem 
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-3 text-[13.5px] font-medium text-slate-700 dark:text-slate-350 hover:bg-slate-100/80 dark:hover:bg-slate-800/40 px-3 py-2.5 rounded-xl transition-all cursor-pointer outline-none"
        >
          <Megaphone size={16} className="text-slate-400" />
          <span>New Channel</span>
        </DropdownMenuItem>

        <DropdownMenuItem 
          onClick={() => toast.info("Settings console requested")}
          className="flex items-center gap-3 text-[13.5px] font-medium text-slate-700 dark:text-slate-350 hover:bg-slate-100/80 dark:hover:bg-slate-800/40 px-3 py-2.5 rounded-xl transition-all cursor-pointer outline-none"
        >
          <SettingsIcon size={16} className="text-slate-400" />
          <span>Settings</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  return (
    <DashboardLayout noPadding={true} noScroll={true} headerActions={headerActions}>
      <div className="font-sans relative flex w-full bg-white dark:bg-[#121212] text-slate-800 dark:text-slate-100 rounded-b-[2.4rem] overflow-hidden flex-1 min-h-0 select-none transition-colors duration-200">
        
        <style dangerouslySetInnerHTML={{__html: `
          .amazing-scrollbar::-webkit-scrollbar {
            width: 5px;
            height: 5px;
          }
          .amazing-scrollbar::-webkit-scrollbar-button {
            display: none !important;
            width: 0 !important;
            height: 0 !important;
          }
          .amazing-scrollbar::-webkit-scrollbar-track {
            background: transparent !important;
          }
          .amazing-scrollbar::-webkit-scrollbar-thumb {
            background: transparent !important;
            border-radius: 9999px;
            transition: background 0.15s ease-in-out;
          }
          .amazing-scrollbar:hover::-webkit-scrollbar-thumb {
            background: rgba(148, 163, 184, 0.25) !important;
          }
          .amazing-scrollbar::-webkit-scrollbar-thumb:hover {
            background: rgba(148, 163, 184, 0.45) !important;
          }
          .dark .amazing-scrollbar:hover::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.08) !important;
          }
          .dark .amazing-scrollbar::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.18) !important;
          }
        `}} />

        {/* --- 1. CHANNEL LIST COLUMN --- */}
        <div className="w-[360px] shrink-0 border-r border-slate-150 dark:border-[#1A1A1A] bg-[#F8FAFC] dark:bg-[#121212] flex flex-col overflow-hidden h-full">
          
          {/* List Search Header */}
          <div className="p-3 px-4 flex items-center gap-2 border-b border-slate-100 dark:border-[#1A1A1A] bg-white dark:bg-[#121212] h-[60px] shrink-0">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-550" size={15} />
              <input 
                type="text" 
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] rounded-xl pl-10 pr-4 py-2 text-[13px] font-normal placeholder:text-slate-400 dark:placeholder:text-slate-655 text-slate-800 dark:text-white outline-none focus:border-blue-600 transition-all"
              />
            </div>
            <button 
              onClick={() => setIsCreateModalOpen(true)}
              className="w-9 h-9 shrink-0 flex items-center justify-center rounded-xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-all active:scale-95"
              title="Create Channel or Group"
            >
              <Plus size={16} />
            </button>
          </div>

          {/* Channels Scrollable list */}
          <div className="flex-1 overflow-y-auto amazing-scrollbar bg-white dark:bg-[#121212] min-h-0">
            {filteredChannels.map(ch => {
              const isActive = ch.id === activeChannelId;
              return (
                <div
                  key={ch.id}
                  onClick={() => setActiveChannelId(ch.id)}
                  className={`relative text-left w-full p-4 flex gap-3.5 border-b border-slate-100/60 dark:border-[#1A1A1A] transition-all duration-200 outline-none items-center cursor-pointer select-none ${
                    isActive 
                      ? "bg-slate-100/70 dark:bg-slate-800/30 text-slate-900 dark:text-white" 
                      : "hover:bg-slate-50/50 dark:hover:bg-slate-800/10"
                  }`}
                >
                  {isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-slate-500 dark:bg-slate-400 rounded-r-full shadow-xs" />
                  )}
                  
                  <img src={ch.avatar} alt={ch.name} className="w-10 h-10 rounded-full object-cover shrink-0 border border-slate-100 dark:border-[#1A1A1A] shadow-xs" />
                  
                  <div className="flex-1 min-w-0 flex flex-col gap-1">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-[13.5px] font-semibold leading-none truncate flex items-center gap-1 min-w-0 text-slate-900 dark:text-white">
                        <span className="truncate">{ch.name}</span>
                        {ch.verified && <CheckCircle2 size={13} className="text-slate-400 fill-slate-400 dark:text-slate-505 dark:fill-slate-550 text-white shrink-0" />}
                      </h4>
                      <span className="text-[11px] shrink-0 font-semibold tabular-nums text-slate-400 dark:text-slate-505">
                        {ch.time}
                      </span>
                    </div>
                    
                    <div className="flex items-start justify-between gap-2.5">
                      <p className="text-[12.5px] font-normal leading-snug line-clamp-2 flex-1 text-slate-555 dark:text-slate-400">
                        {ch.content}
                      </p>
                      
                      {ch.unread > 0 && (
                        <span className={`shrink-0 self-end px-2 py-0.5 rounded-full text-[10px] font-extrabold shadow-xs tabular-nums mt-0.5 ${
                          isActive 
                            ? "bg-slate-700 dark:bg-slate-600 text-white" 
                            : "bg-slate-100 dark:bg-slate-800/60 text-slate-650 dark:text-slate-400 border border-slate-200/50 dark:border-[#1A1A1A]"
                        }`}>
                          {ch.unread > 999 ? `${(ch.unread / 1000).toFixed(1)}k` : ch.unread}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

        {/* --- 2. RIGHT CHAT WINDOW COLUMN --- */}
        <div className="flex-1 flex flex-col bg-white dark:bg-[#000000] relative overflow-hidden h-full">
          {activeChannel ? (
            <>
          
          {/* Chat Header */}
          <div className="p-4 px-6 border-b border-slate-150 dark:border-[#1A1A1A] bg-white dark:bg-[#121212] flex items-center justify-between z-10 shadow-xs h-[60px] shrink-0">
            <div className="cursor-pointer flex-1" onClick={() => setShowDetails(!showDetails)}>
              <h2 className="text-[14px] font-bold text-slate-900 dark:text-white flex items-center gap-1.5 leading-none">
                {activeChannel.name}
                {activeChannel.verified && <CheckCircle2 size={14} className="text-slate-400 fill-slate-400 dark:text-slate-505 dark:fill-slate-550 text-white shrink-0" />}
              </h2>
              <p className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider">
                {activeChannel.id === "saved" ? "Personal saved notes" : activeChannel.subscribers || "Conversation"}
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setShowDetails(!showDetails)}
                className={`w-9 h-9 rounded-full flex items-center justify-center transition-all text-slate-400 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] active:scale-95 ${showDetails ? 'dark:from-[#2A2A2A] dark:to-[#222222]' : ''}`}
                title="Channel Details"
              >
                <User size={18} />
              </button>
              
              <button 
                onClick={handleToggleMute}
                className="w-9 h-9 rounded-full flex items-center justify-center transition-all text-slate-400 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] active:scale-95"
                title={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
              </button>
              <button className="w-9 h-9 rounded-full flex items-center justify-center transition-all text-slate-400 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] active:scale-95">
                <SearchIcon size={16} strokeWidth={2.2} />
              </button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="w-9 h-9 rounded-full flex items-center justify-center transition-all text-slate-400 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white outline-none border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] active:scale-95">
                    <MoreVertical size={18} />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[260px] mt-2 rounded-2xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_8px_24px_-4px_rgba(0,0,0,0.5),0_0_0_2px_#2B2B2F] p-1.5 z-[100] outline-none">

                  <DropdownMenuItem
                    onClick={() => toast.info("Channel Info")}
                    className="flex items-center gap-3 px-3.5 py-2.5 text-[14px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer outline-none"
                  >
                    <Info size={18} className="text-slate-400 dark:text-slate-500 shrink-0" />
                    <span>View channel info</span>
                  </DropdownMenuItem>

                  {activeChannel?.created_by === user?.id && (
                    <DropdownMenuItem
                      onClick={() => {
                        const rules = typeof activeChannel.rules === 'string' ? JSON.parse(activeChannel.rules || '{}') : (activeChannel.rules || {});
                        setManageType(activeChannel.channel_type || 'public');
                        setManageMessages(rules.allow_messages !== false);
                        setIsManageModalOpen(true);
                      }}
                      className="flex items-center gap-3 px-3.5 py-2.5 text-[14px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer outline-none"
                    >
                      <SettingsIcon size={18} className="text-slate-400 dark:text-slate-500 shrink-0" />
                      <span>Manage Channel</span>
                    </DropdownMenuItem>
                  )}

                  <DropdownMenuItem
                    onClick={() => toast.info("Story Archive")}
                    className="flex items-center gap-3 px-3.5 py-2.5 text-[14px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer outline-none"
                  >
                    <Folder size={18} className="text-slate-400 dark:text-slate-500 shrink-0" />
                    <span>Story Archive</span>
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    onClick={() => toast.info("Boost Channel")}
                    className="flex items-center gap-3 px-3.5 py-2.5 text-[14px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer outline-none"
                  >
                    <CornerUpRight size={18} className="text-slate-400 dark:text-slate-500 shrink-0" />
                    <span>Boost Channel</span>
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    onClick={() => toast.info("Create Poll")}
                    className="flex items-center gap-3 px-3.5 py-2.5 text-[14px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer outline-none"
                  >
                    <BarChart2 size={18} className="text-slate-400 dark:text-slate-500 shrink-0" />
                    <span>Create poll</span>
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    onClick={() => toast.info("Export chat history")}
                    className="flex items-center gap-3 px-3.5 py-2.5 text-[14px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer outline-none"
                  >
                    <Share2 size={18} className="text-slate-400 dark:text-slate-500 shrink-0" />
                    <span>Export chat history</span>
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    onClick={() => setShowClearHistoryModal(true)}
                    className="flex items-center gap-3 px-3.5 py-2.5 text-[14px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all cursor-pointer outline-none"
                  >
                    <Trash size={18} className="text-slate-400 dark:text-slate-500 shrink-0" />
                    <span>Clear history</span>
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    onClick={() => toast.error("Left channel")}
                    className="flex items-center gap-3 px-3.5 py-2.5 text-[14px] font-medium text-red-500 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-xl transition-all cursor-pointer outline-none mt-1 border-t border-slate-100 dark:border-white/5 pt-2.5"
                  >
                    <LogOut size={18} className="text-red-500 dark:text-red-400 shrink-0" />
                    <span>Leave channel</span>
                  </DropdownMenuItem>

                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* Pinned Messages Banner */}
          {showPinned && activeChannel.id === "c2" && (
            <div className="bg-[#F8FAFC] dark:bg-[#0B101D] border-b border-slate-150 dark:border-[#1A1A1A] px-6 py-2.5 flex items-center justify-between text-xs text-slate-600 dark:text-slate-350 z-10 transition-all shrink-0">
              <div className="flex items-center gap-3 min-w-0 pr-4">
                <Pin size={14} className="text-slate-400 dark:text-slate-500 rotate-45 shrink-0" />
                <div className="border-l-2 border-slate-350 dark:border-[#1A1A1A] pl-3 min-w-0">
                  <p className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest leading-none mb-0.5">Pinned message</p>
                  <p className="text-[11px] font-medium leading-relaxed truncate text-slate-600 dark:text-slate-400">
                    HOW TO JOIN VIP GROUP? 🔑 1. Register* through vantage link. Ensure minimum deposit of $100.
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setShowPinned(false)}
                className="text-slate-400 dark:text-slate-505 hover:text-slate-800 dark:hover:text-white transition-colors p-1"
              >
                <X size={14} />
              </button>
            </div>
          )}

          {/* Messages Stream */}
          <div 
            className="flex-1 overflow-y-auto p-6 space-y-6 amazing-scrollbar min-h-0"
            style={{
              backgroundColor: themeMode === "dark" ? "#0A0A0A" : "#F1F5F9",
              backgroundImage: themeMode === "dark" 
                ? "none" 
                : `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 120 120'%3E%3Cg fill='%2394a3b8' fill-opacity='0.05'%3E%3Cpath d='M9 15c0-1.66 1.34-3 3-3s3 1.34 3 3-1.34 3-3 3-3-1.34-3-3zm3 1c.55 0 1-.45 1-1s-.45-1-1-1-1 .45-1 1 .45 1 1 1zm35 15c0-2.2 1.8-4 4-4s4 1.8 4 4-1.8 4-4 4-4-1.8-4-4zm4 2c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm35-15c0-1.66 1.34-3 3-3s3 1.34 3 3-1.34 3-3 3-3-1.34-3-3zm3 1c.55 0 1-.45 1-1s-.45-1-1-1-1 .45-1 1 .45 1 1 1zM15 75c0-1.66 1.34-3 3-3s3 1.34 3 3-1.34 3-3 3-3-1.34-3-3zm3 1c.55 0 1-.45 1-1s-.45-1-1-1-1 .45-1 1 .45 1 1 1zm72 15c0-2.2 1.8-4 4-4s4 1.8 4 4-1.8 4-4 4-4-1.8-4-4zm4 2c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z'/%3E%3C/g%3E%3C/svg%3E")`
            }}
          >
            
                  {/* Render active channel messages */}
            {finalMessages.map((msg: any) => (
              <div key={msg.id} className={`flex gap-4 items-end max-w-2xl ${msg.isMe ? 'ml-auto flex-row-reverse' : ''}`}>
                <div className="shrink-0 mb-1">
                  <img 
                    src={msg.avatar} 
                    alt={msg.sender} 
                    className="w-9 h-9 rounded-full border border-slate-200/50 dark:border-[#1A1A1A] object-cover shadow-sm" 
                  />
                </div>

                
                {/* Bubble Container */}
                <div 
                  className={`rounded-2xl border shadow-2xs max-w-2xl text-slate-800 dark:text-slate-100 transition-all overflow-hidden ${
                    msg.isMe 
                      ? "rounded-tr-none bg-slate-100/90 border-slate-200/80 dark:bg-[#1A1A1A] dark:border-white/5" 
                      : "rounded-tl-none bg-white border-slate-200/60 dark:bg-[#1A1A1A] dark:border-white/5"
                  }`}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setContextMenu({
                      x: e.clientX,
                      y: e.clientY,
                      messageId: msg.id,
                      isMe: msg.isMe,
                      content: msg.content
                    });
                  }}
                >
                  {/* Sender details (only show for others) */}
                  {!msg.isMe && (
                    <div className={`flex justify-between items-center px-4 pt-3.5 mb-1.5`}>
                      <span className="text-[12.5px] font-extrabold text-slate-700 dark:text-slate-350 flex items-center gap-1 hover:text-blue-500 transition-colors cursor-pointer">
                        {msg.sender}
                        <CheckCircle2 size={12} className="text-slate-400 fill-slate-450 dark:text-slate-500 dark:fill-slate-550 text-white shrink-0" />
                      </span>
                    </div>
                  )}

                  {msg.image && (
                    <div 
                      onClick={() => setLightboxImage(msg.image)}
                      className="w-full flex items-center justify-center relative group cursor-pointer hover:opacity-95 transition-opacity"
                    >
                      <img 
                        src={msg.image} 
                        className="w-full h-auto object-contain block" 
                        alt="Shared image"
                      />
                    </div>
                  )}

                  {msg.video && (
                    <div className="w-full flex items-center justify-center relative group">
                      <video src={msg.video} controls className="w-full h-auto object-contain block" />
                    </div>
                  )}

                  {msg.type === 'poll' && msg.poll && (

                    <div className="mb-2 bg-slate-50 dark:bg-[#121212] rounded-xl p-3 border border-slate-200/60 dark:border-slate-800/60 m-3">
                      <h4 className="font-bold text-sm mb-3 text-slate-800 dark:text-slate-200">{msg.poll.question}</h4>
                      <div className="space-y-2">
                        {msg.poll.options.map((opt: any, idx: number) => {
                          const percentage = msg.poll.totalVotes > 0 ? Math.round((opt.votes / msg.poll.totalVotes) * 100) : 0;
                          return (
                            <div key={idx} className="relative overflow-hidden rounded-lg bg-slate-200/50 dark:bg-slate-800/50 p-2 cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                              onClick={() => {
                                // Dummy click action for the poll to feel interactive
                                toast.success("Vote recorded!");
                              }}
                            >
                              <div className="absolute left-0 top-0 bottom-0 bg-blue-500/20 dark:bg-blue-500/30 transition-all duration-500" style={{ width: `${percentage}%` }} />
                              <div className="relative flex items-center justify-between z-10 text-[12px] font-medium text-slate-700 dark:text-slate-300">
                                <span>{opt.text}</span>
                                <span>{percentage}%</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-2 text-right">
                        {msg.poll.totalVotes} votes
                      </div>
                    </div>
                  )}

                  {msg.content && msg.type !== 'poll' && (
                    <p className={`text-[13.5px] leading-relaxed font-normal whitespace-pre-wrap break-words text-slate-700 dark:text-slate-300 ${msg.isMe ? 'text-right' : ''} px-4 pb-2 ${msg.image || msg.video ? 'pt-3' : (!msg.isMe ? 'pt-0' : 'pt-3.5')}`}>
                      {msg.content}
                    </p>
                  )}

                  <div className={`flex justify-end items-center mt-0.5 text-[10px] font-medium text-slate-400 dark:text-slate-500 gap-2 px-4 pb-2 ${(!msg.content && (msg.image || msg.video)) ? 'pt-3' : 'pt-0'}`}>

                    <div className="flex items-center gap-1">
                      <Eye size={11} />
                      <span className="tabular-nums">{msg.views || "154"}</span>
                    </div>
                    <span className="tabular-nums">{msg.time}</span>
                  </div>

                  {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                    <div className={`flex flex-wrap items-center gap-1.5 mt-2 ${msg.isMe ? 'justify-end' : 'justify-start'} px-4 pb-2 pt-1`}>

                      {Object.entries(msg.reactions).map(([emoji, count]: any) => (
                        <button
                          key={emoji}
                          onClick={() => handleReactionClick(msg.id, emoji)}
                          className="flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-semibold shadow-xs transition-all focus:outline-none border bg-slate-100/50 hover:bg-slate-100 dark:bg-slate-800/40 border-slate-200/50 dark:border-[#2A2A2A] text-slate-650 dark:text-slate-350"
                        >
                          <span className="text-[12px]">{emoji}</span>
                          <span className="opacity-80">{count}</span>
                        </button>
                      ))}
                    </div>
                  )}

                </div>
              </div>
            ))}

            {dbLoading && activeChannelId && finalMessages.length === 0 && (
              <div className="flex items-center justify-center py-10">
                <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin" />
              </div>
            )}

            {finalMessages.length === 0 && !dbLoading && (
              <div className="text-center py-20 rounded-2xl p-6 max-w-sm mx-auto flex-shrink-0 border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-[#121212] flex items-center justify-center mx-auto text-slate-400 dark:text-slate-300 mb-4 border border-slate-200/30 dark:border-white/5">
                  <MessageSquare size={24} />
                </div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-white mb-1">No Broadcasts Yet</h4>
                <p className="text-xs text-slate-500 dark:text-slate-455 max-w-xs mx-auto leading-relaxed">
                  You have successfully joined 📣 {activeChannel.name}. Live execution alerts and signal broadcasts will appear here in real-time.
                </p>
              </div>
            )}

            <div ref={messageEndRef} />
          </div>

          {/* --- RIGHT CHAT FOOTER PANEL --- */}
          <div className="p-4 px-6 border-t border-slate-150 dark:border-[#1A1A1A] bg-white dark:bg-[#121212] flex items-center justify-center z-10 shadow-xs shrink-0 w-full">
            {!isMember && activeChannel?.id !== "saved" ? (
                <button onClick={joinChannel} className="px-8 py-2.5 rounded-full text-[13px] font-bold transition-all border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white active:scale-95">
                    Join Channel
                </button>
            ) : (() => {
                const rules = typeof activeChannel?.rules === 'string' ? JSON.parse(activeChannel.rules || '{}') : (activeChannel?.rules || {});
                const allowMessages = rules.allow_messages !== false;
                const isAdmin = activeChannel?.created_by === user?.id;

                if (!allowMessages && !isAdmin && activeChannel?.id !== "saved") {
                    return <p className="text-[12px] font-bold text-slate-400">Only admins can send messages in this channel.</p>;
                }

                return activeChannel?.id === "saved" || dbChannels.length > 0 ? (
                  <div className="w-full relative flex flex-col gap-2">
                    {attachmentPreview && (
                      <div className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800">
                         <img src={attachmentPreview} className="w-full h-full object-cover" />
                         <button onClick={removeAttachment} className="absolute top-1 right-1 bg-black/50 rounded-full p-1 text-white hover:bg-black/70">
                           <X size={12} />
                         </button>
                      </div>
                    )}
                    {showEmojiPicker && (
                      <div className="absolute bottom-16 left-0 z-50 shadow-2xl">
                        <EmojiPicker onEmojiClick={onEmojiClick} theme={themeMode as any} />
                      </div>
                    )}
                    <form onSubmit={handleSendMessage} className="w-full flex items-center gap-3">
                      <button type="button" onClick={() => setShowEmojiPicker(!showEmojiPicker)} className="w-12 h-12 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#E2E8F0] dark:hover:shadow-[0_6px_10px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#2B2B2F] flex items-center justify-center transition-all text-slate-400 dark:text-slate-500 hover:text-blue-500 shrink-0 outline-none active:scale-95">
                        <Smile size={20} />
                      </button>
                      <button type="button" onClick={() => fileInputRef.current?.click()} className="w-12 h-12 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#E2E8F0] dark:hover:shadow-[0_6px_10px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#2B2B2F] flex items-center justify-center transition-all text-slate-400 dark:text-slate-500 hover:text-blue-500 shrink-0 outline-none active:scale-95">
                        <Paperclip size={20} />
                      </button>
                      <button type="button" onClick={() => setIsPollModalOpen(true)} className="w-12 h-12 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#E2E8F0] dark:hover:shadow-[0_6px_10px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#2B2B2F] flex items-center justify-center transition-all text-slate-400 dark:text-slate-500 hover:text-blue-500 shrink-0 outline-none active:scale-95">
                        <BarChart2 size={20} />
                      </button>

                      <input type="file" ref={fileInputRef} onChange={handleAttachmentSelect} className="hidden" accept="image/*,video/*" />
                      
                      <div className="flex-1 bg-slate-100 dark:bg-[#1A1A1A] border border-transparent rounded-[24px] flex items-center px-5 py-1.5 transition-all relative">
                        {editingMessageId && (
                          <div className="absolute -top-10 left-0 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[11px] px-3 py-1 rounded-full flex items-center gap-2 font-bold uppercase tracking-wider">
                            <span>Editing Message</span>
                            <button onClick={handleCancelEdit} type="button" className="hover:text-blue-800 dark:hover:text-blue-200 bg-white/50 dark:bg-black/20 rounded-full p-0.5">
                              <X size={12} />
                            </button>
                          </div>
                        )}
                        <textarea 
                          value={inputText}
                          onChange={(e) => setInputText(e.target.value)}
                          onKeyDown={handleKeyDown}
                          placeholder={isUploading ? "Uploading attachment..." : "Write a message..."}
                          className="w-full bg-transparent outline-none text-[13.5px] font-medium text-slate-700 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-500 resize-none min-h-[22px] max-h-[120px] py-1 custom-scrollbar"
                          disabled={isUploading}
                          rows={1}
                        />
                      </div>
                      
                      <button 
                        type="submit"
                        disabled={(!inputText.trim() && !attachment) || isUploading}
                        className="w-12 h-12 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#E2E8F0] dark:hover:shadow-[0_6px_10px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#2B2B2F] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center transition-all text-blue-600 dark:text-blue-500 shrink-0 outline-none active:scale-95"
                      >
                        {isUploading ? <div className="w-5 h-5 rounded-full border-2 border-blue-600/20 border-t-blue-600 animate-spin" /> : <SendHorizonal size={20} className="mr-0.5" />}
                      </button>
                    </form>
                  </div>
                ) : (
                  <div className="w-full h-10 border-2 border-dashed border-slate-200 dark:border-[#222] rounded-xl" />
                );
            })()}
          </div>

            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-white dark:bg-[#000000]">
              <div className="text-center py-16 rounded-[24px] p-6 max-w-md w-full mx-auto flex-shrink-0 border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-[#121212] flex items-center justify-center mx-auto text-slate-400 dark:text-slate-300 mb-6 border border-slate-200/30 dark:border-white/5">
                  <Megaphone size={24} />
                </div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-white mb-2">No Channels Yet</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto leading-relaxed">
                  Explore and join official broadcasting channels from the Discover page to keep up with news and signal flows.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* --- 3. SLIDE-OUT CHANNEL DETAILS DRAWER --- */}
        <div 
          className={`shrink-0 border-l border-slate-150 dark:border-[#1A1A1A] bg-white dark:bg-[#121212] flex flex-col transition-all duration-300 ease-in-out h-full ${
            showDetails && activeChannel ? "w-[360px]" : "w-0 overflow-hidden border-l-0"
          }`}
        >
          <div className="p-4 px-6 border-b border-slate-100 dark:border-[#1A1A1A] flex items-center justify-between shrink-0 h-[60px]">
            <span className="text-[14px] font-bold text-slate-800 dark:text-white">User Info</span>
            <button 
              onClick={() => setShowDetails(false)}
              className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors text-slate-400 hover:text-slate-800 dark:hover:text-white outline-none"
            >
              <X size={18} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto amazing-scrollbar p-6 space-y-6">
            {activeChannel && (
              <>
            
            <div className="text-center space-y-2">
              <div className="w-[100px] h-[100px] rounded-full overflow-hidden mx-auto border-2 border-slate-100 dark:border-[#1A1A1A] shadow-sm relative group bg-slate-50">
                <img 
                  src={activeChannel.avatar} 
                  alt={activeChannel.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-[17px] font-extrabold text-slate-900 dark:text-white flex items-center justify-center gap-1 mt-3 leading-tight">
                {activeChannel.name}
                {activeChannel.verified && <CheckCircle2 size={15} className="text-slate-400 fill-slate-450 dark:text-slate-505 dark:fill-slate-550 text-white shrink-0" />}
              </h3>
              <p className="text-[12.5px] text-slate-400 dark:text-slate-550 font-semibold leading-none">
                {activeDetails.subscribers}
              </p>
              
              <Link to={`/user/${activeChannel.name.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase()}`} className="mt-4 inline-flex items-center justify-center gap-1.5 w-full py-2 rounded-xl border border-slate-200 dark:border-[#1A1A1A] text-[12px] font-bold uppercase tracking-wider text-slate-700 hover:text-blue-500 hover:border-blue-500 dark:text-slate-355 dark:hover:text-blue-400 dark:hover:border-blue-500/40 transition-colors shadow-3xs bg-slate-50/5 dark:bg-slate-900/20">
                View Creator Profile
              </Link>
            </div>

            <div className="grid grid-cols-3 gap-2 px-1">
              <button 
                onClick={handleToggleMute}
                className="flex flex-col items-center justify-center py-2.5 rounded-2xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] transition-all group active:scale-95"
              >
                {isMuted ? (
                  <VolumeX size={18} className="text-slate-400 group-hover:text-slate-800 dark:group-hover:text-white mb-1 transition-colors" />
                ) : (
                  <Volume2 size={18} className="text-slate-400 group-hover:text-slate-800 dark:group-hover:text-white mb-1 transition-colors" />
                )}
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-1">Mute</span>
              </button>

              <button 
                onClick={() => toast.success("Gift feature panel coming soon!")}
                className="flex flex-col items-center justify-center py-2.5 rounded-2xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] transition-all group active:scale-95"
              >
                <Gift size={18} className="text-slate-400 group-hover:text-slate-800 dark:group-hover:text-white mb-1 transition-colors" />
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-1">Gift</span>
              </button>

              <button 
                onClick={() => toast.warning("Confirmation: Are you sure you want to leave?")}
                className="flex flex-col items-center justify-center py-2.5 rounded-2xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] transition-all group active:scale-95"
              >
                <LogOut size={18} className="text-slate-400 group-hover:text-rose-500 mb-1 transition-colors" />
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-1">Leave</span>
              </button>
            </div>

            <hr className="border-slate-100 dark:border-[#1A1A1A]" />

            <div className="space-y-4 text-[13px]">
              <div className="flex items-start justify-between gap-3 p-3 rounded-xl border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                <div className="space-y-1">
                  <a 
                    href={`https://${activeDetails.link}`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-slate-700 dark:text-slate-350 hover:underline font-bold text-[13.5px] leading-tight block"
                  >
                    {activeDetails.link}
                  </a>
                  <span className="text-[11px] text-slate-400 font-bold block uppercase tracking-wider">Link</span>
                </div>
                <button 
                  onClick={() => toast.success("QR Code rendered for sharing!")}
                  className="p-2 rounded-lg border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-400 hover:text-slate-700 dark:hover:text-white transition-all active:scale-95"
                >
                  <QrCode size={18} />
                </button>
              </div>

              <div className="space-y-1 p-3 text-left">
                <p className="text-slate-800 dark:text-slate-200 font-medium whitespace-pre-line leading-relaxed text-[13.5px]">
                  {activeDetails.description}
                </p>
                <span className="text-[11px] text-slate-400 font-bold block uppercase tracking-wider pt-1.5">Description</span>
              </div>
            </div>

            <hr className="border-slate-100 dark:border-[#1A1A1A]" />

            <div className="space-y-4 font-semibold text-slate-750 dark:text-slate-350 text-[13px]">
              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <Gift size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.giftsCount}</span>
              </div>

              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <ImageIcon size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.photosCount}</span>
              </div>

              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <Film size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.videosCount}</span>
              </div>

              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <Folder size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.filesCount}</span>
              </div>

              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <Link2 size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.linksCount}</span>
              </div>

              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <BarChart2 size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.pollsCount}</span>
              </div>

              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <Mic size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.voicesCount}</span>
              </div>

              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <Bookmark size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.gifsCount}</span>
              </div>

              <div className="flex items-center gap-3.5 px-1 py-0.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                <Megaphone size={18} className="text-slate-400 shrink-0" />
                <span className="text-[13.5px]">{activeDetails.similarCount}</span>
              </div>
            </div>

            <hr className="border-slate-100 dark:border-[#1A1A1A]" />

            <div className="space-y-4 font-bold text-[13.5px]">
              <button 
                onClick={() => toast.error("Left channel requested")}
                className="flex items-center gap-3.5 px-1 py-1 text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors text-left w-full outline-none"
              >
                <LogOut size={18} className="text-slate-400 shrink-0" />
                <span>Leave channel</span>
              </button>

              <button 
                onClick={() => toast.error("Report dialog opened")}
                className="flex items-center gap-3.5 px-1 py-1 text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-500 transition-colors text-left w-full outline-none"
              >
                <AlertTriangle size={18} className="text-rose-500 dark:text-rose-400 shrink-0" />
                <span>Report</span>
              </button>
            </div>
              </>
            )}
          </div>
        </div>

      </div>

      {/* Create Channel Modal */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent className="sm:max-w-[425px] bg-white dark:bg-[#121212] border border-slate-200 dark:border-[#2A2A2A] rounded-[24px]">
          <DialogHeader>
            <DialogTitle className="text-[18px] font-bold text-slate-900 dark:text-white">
                {createStep === 1 ? "Create New Channel" : "Invite Members"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateChannel} className="space-y-6 pt-4">
            {createStep === 1 ? (
                <>
                    <div className="space-y-2">
                      <label className="text-[13px] font-bold text-slate-700 dark:text-slate-300">Channel Name <span className="text-red-500">*</span></label>
                      <input 
                        type="text" 
                        required
                        value={newChannelName}
                        onChange={(e) => setNewChannelName(e.target.value)}
                        placeholder="e.g. VIP Signals"
                        className="w-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] rounded-xl px-4 py-3 text-[13px] font-semibold text-slate-800 dark:text-white placeholder:text-slate-400 outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[13px] font-bold text-slate-700 dark:text-slate-300">Description</label>
                      <textarea 
                        value={newChannelDesc}
                        onChange={(e) => setNewChannelDesc(e.target.value)}
                        placeholder="What is this channel about?"
                        rows={3}
                        className="w-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] rounded-xl px-4 py-3 text-[13px] font-medium text-slate-800 dark:text-white placeholder:text-slate-400 outline-none focus:border-blue-500 transition-all resize-none"
                      />
                    </div>
                </>
            ) : (
                <div className="max-h-[300px] overflow-y-auto amazing-scrollbar space-y-2 pr-2">
                    {followedUsers.length > 0 ? followedUsers.map(fUser => (
                        <div key={fUser.id} className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer" onClick={() => toggleInvite(fUser.id)}>
                            <div className="flex items-center gap-3">
                                <img src={fUser.avatar_url || "https://api.dicebear.com/7.x/avataaars/svg?seed="+fUser.username} alt={fUser.username} className="w-10 h-10 rounded-full object-cover" />
                                <div>
                                    <p className="text-[13px] font-bold text-slate-800 dark:text-white">{fUser.display_name || fUser.username}</p>
                                    <p className="text-[11px] text-slate-500">@{fUser.username}</p>
                                </div>
                            </div>
                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${selectedInvites[fUser.id] ? "bg-blue-600 border-blue-600" : "border-slate-300 dark:border-[#1A1A1A]"}`}>
                                {selectedInvites[fUser.id] && <CheckCircle2 size={12} className="text-white" />}
                            </div>
                        </div>
                    )) : (
                        <p className="text-center text-[13px] text-slate-400 py-6">You aren't following anyone yet.</p>
                    )}
                </div>
            )}
            
            <DialogFooter className="pt-2">
              <button 
                type="button" 
                onClick={() => createStep === 2 ? setCreateStep(1) : setIsCreateModalOpen(false)}
                className="px-6 py-2.5 rounded-xl border border-slate-200 dark:border-[#1A1A1A] text-[13px] font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                {createStep === 2 ? "Back" : "Cancel"}
              </button>
              <button 
                type="submit" 
                disabled={isCreating || (createStep === 1 && !newChannelName.trim())}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[13px] font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isCreating ? "Creating..." : (createStep === 1 ? "Next" : "Create Channel")}
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Manage Channel Modal */}
      <Dialog open={isManageModalOpen} onOpenChange={setIsManageModalOpen}>
        <DialogContent className="sm:max-w-[425px] bg-white dark:bg-[#121212] border border-slate-200 dark:border-[#2A2A2A] rounded-[24px]">
          <DialogHeader>
            <DialogTitle className="text-[18px] font-bold text-slate-900 dark:text-white">Manage Channel</DialogTitle>
          </DialogHeader>
          <div className="space-y-6 pt-4">
            <div className="space-y-3">
              <label className="text-[13px] font-bold text-slate-700 dark:text-slate-300">Privacy Mode</label>
              <div className="flex gap-3">
                  <button 
                    type="button"
                    onClick={() => setManageType("public")}
                    className={`flex-1 py-3 px-4 rounded-xl border text-[13px] font-bold transition-colors ${manageType === "public" ? "border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-600/10 dark:text-blue-400" : "border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-[#1A1A1A] dark:text-slate-400 dark:hover:bg-slate-800"}`}
                  >
                      Public
                  </button>
                  <button 
                    type="button"
                    onClick={() => setManageType("private")}
                    className={`flex-1 py-3 px-4 rounded-xl border text-[13px] font-bold transition-colors ${manageType === "private" ? "border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-600/10 dark:text-blue-400" : "border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-[#1A1A1A] dark:text-slate-400 dark:hover:bg-slate-800"}`}
                  >
                      Private
                  </button>
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-[13px] font-bold text-slate-700 dark:text-slate-300">Messaging Permissions</label>
              <div 
                onClick={() => setManageMessages(!manageMessages)}
                className="flex items-center justify-between p-4 rounded-xl border border-slate-200 dark:border-[#1A1A1A] cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
              >
                  <div>
                      <p className="text-[13px] font-bold text-slate-800 dark:text-white">Allow Direct Messages</p>
                      <p className="text-[11px] text-slate-500">If disabled, only admins can send messages.</p>
                  </div>
                  <div className={`w-10 h-5 rounded-full relative transition-colors ${manageMessages ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`}>
                      <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${manageMessages ? "left-5.5" : "left-0.5"}`} />
                  </div>
              </div>
            </div>
            
            <DialogFooter className="pt-4">
              <button 
                type="button" 
                onClick={() => setIsManageModalOpen(false)}
                className="px-6 py-2.5 rounded-xl border border-slate-200 dark:border-[#1A1A1A] text-[13px] font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={handleSaveSettings}
                disabled={isSavingSettings}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[13px] font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSavingSettings ? "Saving..." : "Save Settings"}
              </button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
      {/* Poll Creation Modal */}
      <Dialog open={isPollModalOpen} onOpenChange={setIsPollModalOpen}>
        <DialogContent className="sm:max-w-[425px] bg-white dark:bg-[#121212] border border-slate-200 dark:border-[#2A2A2A] rounded-[24px]">
          <DialogHeader>
            <DialogTitle className="text-[18px] font-bold text-slate-900 dark:text-white">Create a Poll</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <label className="text-[13px] font-bold text-slate-700 dark:text-slate-300">Question</label>
              <input 
                type="text" 
                value={pollQuestion}
                onChange={(e) => setPollQuestion(e.target.value)}
                placeholder="Ask a question..."
                className="w-full bg-slate-50 dark:bg-[#1A1A1A] border border-slate-200 dark:border-[#222] rounded-xl px-4 py-3 text-[13.5px] font-medium text-slate-800 dark:text-white outline-none focus:border-blue-500"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-[13px] font-bold text-slate-700 dark:text-slate-300">Options</label>
              {pollOptions.map((opt, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <input 
                    type="text" 
                    value={opt}
                    onChange={(e) => {
                      const newOpts = [...pollOptions];
                      newOpts[idx] = e.target.value;
                      setPollOptions(newOpts);
                    }}
                    placeholder={`Option ${idx + 1}`}
                    className="flex-1 bg-slate-50 dark:bg-[#1A1A1A] border border-slate-200 dark:border-[#222] rounded-xl px-4 py-2.5 text-[13.5px] font-medium text-slate-800 dark:text-white outline-none focus:border-blue-500"
                  />
                  {idx >= 2 && (
                    <button 
                      type="button" 
                      onClick={() => setPollOptions(pollOptions.filter((_, i) => i !== idx))}
                      className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <X size={16} />
                    </button>
                  )}
                </div>
              ))}
              {pollOptions.length < 5 && (
                <button 
                  type="button" 
                  onClick={() => setPollOptions([...pollOptions, ""])}
                  className="text-blue-500 text-[12px] font-bold mt-2 hover:text-blue-600 flex items-center gap-1"
                >
                  <Plus size={14} /> Add Option
                </button>
              )}
            </div>
            
            <DialogFooter className="pt-4">
              <button 
                type="button" 
                onClick={() => setIsPollModalOpen(false)}
                className="px-6 py-2.5 rounded-xl border border-slate-200 dark:border-[#1A1A1A] text-[13px] font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={handleCreatePoll}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[13px] font-bold transition-colors"
              >
                Send Poll
              </button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Clear History Confirmation Modal */}
      <Dialog open={showClearHistoryModal} onOpenChange={setShowClearHistoryModal}>
        <DialogContent className="sm:max-w-[360px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_8px_24px_-4px_rgba(0,0,0,0.5),0_0_0_2px_#2B2B2F] rounded-2xl p-0 overflow-hidden [&>button]:hidden">
          <X 
            size={20} 
            className="absolute right-4 top-4 text-slate-400 dark:text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer z-10" 
            onClick={() => setShowClearHistoryModal(false)} 
          />
          <div className="flex flex-col items-center text-center p-8 space-y-6 pt-10">
            <div className="w-[68px] h-[68px] rounded-full flex items-center justify-center shrink-0">
              <AlertTriangle size={36} className="text-[#fa5252]" />
            </div>
            
            <div className="space-y-2.5">
              <DialogTitle className="text-[20px] font-bold text-slate-900 dark:text-white tracking-tight">
                Clear Channel History?
              </DialogTitle>
              
              <p className="text-[14px] text-slate-500 dark:text-slate-400 leading-relaxed px-2 font-medium">
                This action is permanent and cannot be undone. It will delete all messages for everyone in this channel.
              </p>
            </div>

            <div className="flex w-full gap-3 pt-4">
              <button 
                type="button" 
                onClick={() => setShowClearHistoryModal(false)}
                className="flex-1 py-3.5 rounded-full font-semibold text-slate-700 dark:text-white border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] hover:brightness-95 dark:hover:brightness-110 transition-all text-[15px] active:scale-95"
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={async () => {
                  setShowClearHistoryModal(false);
                  await clearHistory();
                }}
                className="flex-1 py-3.5 rounded-full font-semibold text-white bg-gradient-to-b from-[#ff6b6b] to-[#fa5252] border-2 border-[#fa5252]/30 shadow-[0_4px_14px_rgba(250,82,82,0.3),0_0_0_2px_rgba(250,82,82,0.15)] hover:brightness-110 transition-all text-[15px] active:scale-95"
              >
                Clear History
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Message Confirmation Modal */}
      <Dialog open={!!showDeleteMessageModal} onOpenChange={(open) => !open && setShowDeleteMessageModal(null)}>
        <DialogContent className="sm:max-w-[360px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_8px_24px_-4px_rgba(0,0,0,0.5),0_0_0_2px_#2B2B2F] rounded-2xl p-0 overflow-hidden [&>button]:hidden">
          <X 
            size={20} 
            className="absolute right-4 top-4 text-slate-400 dark:text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer z-10" 
            onClick={() => setShowDeleteMessageModal(null)} 
          />
          <div className="flex flex-col items-center text-center p-8 space-y-6 pt-10">
            <div className="w-[68px] h-[68px] rounded-full flex items-center justify-center shrink-0">
              <Trash size={36} className="text-[#fa5252]" />
            </div>
            
            <div className="space-y-2.5">
              <DialogTitle className="text-[20px] font-bold text-slate-900 dark:text-white tracking-tight">
                Delete Message?
              </DialogTitle>
              
              <p className="text-[14px] text-slate-500 dark:text-slate-400 leading-relaxed px-2 font-medium">
                This action is permanent and cannot be undone. This message will be deleted for everyone.
              </p>
            </div>

            <div className="flex w-full gap-3 pt-4">
              <button 
                type="button" 
                onClick={() => setShowDeleteMessageModal(null)}
                className="flex-1 py-3.5 rounded-full font-semibold text-slate-700 dark:text-white border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] hover:brightness-95 dark:hover:brightness-110 transition-all text-[15px] active:scale-95"
              >
                Cancel
              </button>
              <button 
                type="button" 
                onClick={() => {
                  if (showDeleteMessageModal) {
                    deleteMessage(showDeleteMessageModal);
                    setShowDeleteMessageModal(null);
                  }
                }}
                className="flex-1 py-3.5 rounded-full font-semibold text-white bg-gradient-to-b from-[#ff6b6b] to-[#fa5252] border-2 border-[#fa5252]/30 shadow-[0_4px_14px_rgba(250,82,82,0.3),0_0_0_2px_rgba(250,82,82,0.15)] hover:brightness-110 transition-all text-[15px] active:scale-95"
              >
                Delete
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Telegram Style Custom Context Menu */}
      {contextMenu && (
        <div 
          className="fixed z-[9999] flex flex-col gap-2 animate-in fade-in zoom-in duration-200"
          style={{ 
            ...(contextMenu.y > window.innerHeight / 2 ? { bottom: window.innerHeight - contextMenu.y } : { top: contextMenu.y }),
            ...(contextMenu.x > window.innerWidth / 2 ? { right: window.innerWidth - contextMenu.x } : { left: contextMenu.x }),
            transformOrigin: `${contextMenu.x > window.innerWidth / 2 ? 'right' : 'left'} ${contextMenu.y > window.innerHeight / 2 ? 'bottom' : 'top'}`
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Reactions Pill */}
          <div className="rounded-full px-2.5 py-1.5 flex gap-2.5 text-lg overflow-hidden mb-1.5 border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
            {['❤️', '👍', '👎', '🔥', '🥰', '👏'].map(emoji => (
              <button 
                key={emoji}
                className="hover:scale-125 transition-transform outline-none"
                onClick={() => {
                  handleReactionClick(contextMenu.messageId, emoji);
                  setContextMenu(null);
                }}
              >
                {emoji}
              </button>
            ))}
          </div>
          
          {/* Actions Menu */}
          <div className="w-[240px] rounded-2xl p-1.5 border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_8px_24px_-4px_rgba(0,0,0,0.5),0_0_0_2px_#2B2B2F]">
            <button 
               className="w-full flex items-center gap-3 px-3 py-2 text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all outline-none"
            >
               <CornerUpRight size={17} className="text-slate-400 dark:text-slate-500 shrink-0" /> Reply
            </button>
            
            {contextMenu.isMe && (
              <button 
                onClick={() => {
                  let text = contextMenu.content;
                  try {
                    const parsed = JSON.parse(text);
                    if (parsed && typeof parsed === 'object') {
                       text = parsed.type === 'poll' ? (parsed.question || '') : (parsed.text || '');
                    }
                  } catch(e) {}
                  setEditingMessageId(contextMenu.messageId);
                  setInputText(text);
                  setContextMenu(null);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all outline-none"
              >
                 <Edit2 size={17} className="text-slate-400 dark:text-slate-500 shrink-0" /> Edit
              </button>
            )}

            <button 
               className="w-full flex items-center gap-3 px-3 py-2 text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all outline-none"
            >
               <Pin size={17} className="text-slate-400 dark:text-slate-500 shrink-0" /> Pin
            </button>
            
            <button 
               onClick={() => {
                 let text = contextMenu.content;
                 try {
                   const parsed = JSON.parse(text);
                   if (parsed && typeof parsed === 'object') {
                      text = parsed.type === 'poll' ? (parsed.question || '') : (parsed.text || '');
                   }
                 } catch(e) {}
                 navigator.clipboard.writeText(text);
                 toast.success("Text copied!");
                 setContextMenu(null);
               }}
               className="w-full flex items-center gap-3 px-3 py-2 text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all outline-none"
            >
               <Copy size={17} className="text-slate-400 dark:text-slate-500 shrink-0" /> Copy Text
            </button>

            <button 
               onClick={() => {
                 navigator.clipboard.writeText(`${window.location.origin}/channel/${activeChannelId}?msg=${contextMenu.messageId}`);
                 toast.success("Link copied!");
                 setContextMenu(null);
               }}
               className="w-full flex items-center gap-3 px-3 py-2 text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all outline-none"
            >
               <Link2 size={17} className="text-slate-400 dark:text-slate-500 shrink-0" /> Copy Post Link
            </button>

            <button 
               className="w-full flex items-center gap-3 px-3 py-2 text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all outline-none"
            >
               <Share2 size={17} className="text-slate-400 dark:text-slate-500 shrink-0" /> Forward
            </button>
            
            {contextMenu.isMe && (
              <button 
                onClick={() => {
                  setShowDeleteMessageModal(contextMenu.messageId);
                  setContextMenu(null);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 mt-1 rounded-xl text-red-500 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 cursor-pointer outline-none transition-colors text-[13px] font-medium"
              >
                <Trash size={17} className="text-red-500 dark:text-red-400 shrink-0" />
                <span>Delete Message</span>
              </button>
            )}

            <button 
               className="w-full flex items-center gap-3 px-3 py-2 text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all outline-none border-t border-slate-100 dark:border-white/5 mt-1 pt-2"
            >
               <CheckCircle2 size={17} className="text-slate-400 dark:text-slate-500 shrink-0" /> Select
            </button>
          </div>
        </div>
      )}

      {lightboxImage && (
        <div 
          className="fixed inset-0 bg-black/95 z-[9999] flex items-center justify-center p-4 backdrop-blur-sm select-none cursor-zoom-out"
          onClick={() => setLightboxImage(null)}
        >
          {/* Close button in top right corner (cross button to close) */}
          <button 
            onClick={() => setLightboxImage(null)} 
            className="absolute top-6 right-6 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer border border-white/10 shadow-lg"
            title="Close"
          >
            <X size={24} />
          </button>
          
          {/* Full screen image */}
          <img 
            src={lightboxImage} 
            alt="Fullscreen view" 
            className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" 
            onClick={(e) => e.stopPropagation()} // Prevent closing when clicking the image itself
          />
        </div>
      )}
    </DashboardLayout>
  );
}
