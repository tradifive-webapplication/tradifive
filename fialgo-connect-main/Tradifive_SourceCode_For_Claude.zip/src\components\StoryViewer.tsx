import React, { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export interface StoryGroup {
  userId: string;
  user: {
    name: string;
    avatar: string;
  };
  stories: {
    id: string;
    mediaUrl: string;
    createdAt: string;
  }[];
}

interface StoryViewerProps {
  isOpen: boolean;
  onClose: () => void;
  storyGroups: StoryGroup[];
  initialGroupIndex: number;
}

const STORY_DURATION = 5000; // 5 seconds per story

export default function StoryViewer({
  isOpen,
  onClose,
  storyGroups,
  initialGroupIndex,
}: StoryViewerProps) {
  const [currentGroupIndex, setCurrentGroupIndex] = useState(initialGroupIndex);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const animationRef = useRef<number>();
  const startTimeRef = useRef<number>(Date.now());
  const pausedTimeRef = useRef<number>(0);
  const accumulatedTimeRef = useRef<number>(0);

  useEffect(() => {
    if (isOpen) {
      setCurrentGroupIndex(initialGroupIndex);
      setCurrentStoryIndex(0);
      setProgress(0);
      setIsPaused(false);
      accumulatedTimeRef.current = 0;
      startTimeRef.current = Date.now();
    }
  }, [isOpen, initialGroupIndex]);

  const goToNextStory = () => {
    const currentGroup = storyGroups[currentGroupIndex];
    if (!currentGroup) return;

    if (currentStoryIndex < currentGroup.stories.length - 1) {
      setCurrentStoryIndex(prev => prev + 1);
      setProgress(0);
      accumulatedTimeRef.current = 0;
      startTimeRef.current = Date.now();
    } else if (currentGroupIndex < storyGroups.length - 1) {
      setCurrentGroupIndex(prev => prev + 1);
      setCurrentStoryIndex(0);
      setProgress(0);
      accumulatedTimeRef.current = 0;
      startTimeRef.current = Date.now();
    } else {
      onClose();
    }
  };

  const goToPrevStory = () => {
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(prev => prev - 1);
      setProgress(0);
      accumulatedTimeRef.current = 0;
      startTimeRef.current = Date.now();
    } else if (currentGroupIndex > 0) {
      setCurrentGroupIndex(prev => prev - 1);
      setCurrentStoryIndex(storyGroups[currentGroupIndex - 1].stories.length - 1);
      setProgress(0);
      accumulatedTimeRef.current = 0;
      startTimeRef.current = Date.now();
    } else {
      // Re-start current story
      setProgress(0);
      accumulatedTimeRef.current = 0;
      startTimeRef.current = Date.now();
    }
  };

  useEffect(() => {
    if (!isOpen) {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
      return;
    }

    const animateProgress = () => {
      if (isPaused) {
        if (animationRef.current) cancelAnimationFrame(animationRef.current);
        return;
      }

      const now = Date.now();
      const elapsed = (now - startTimeRef.current) + accumulatedTimeRef.current;
      const newProgress = (elapsed / STORY_DURATION) * 100;

      if (newProgress >= 100) {
        goToNextStory();
      } else {
        setProgress(newProgress);
        animationRef.current = requestAnimationFrame(animateProgress);
      }
    };

    animationRef.current = requestAnimationFrame(animateProgress);

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isOpen, currentGroupIndex, currentStoryIndex, isPaused, storyGroups]);

  const handlePointerDown = () => {
    setIsPaused(true);
    pausedTimeRef.current = Date.now();
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsPaused(false);
    accumulatedTimeRef.current += (Date.now() - pausedTimeRef.current);
    startTimeRef.current = Date.now();

    // Check if click was short enough to be a tap, not a long-press
    const clickDuration = Date.now() - pausedTimeRef.current;
    if (clickDuration < 200) {
      const { clientX } = e;
      const screenWidth = window.innerWidth;
      if (clientX < screenWidth / 3) {
        goToPrevStory();
      } else {
        goToNextStory();
      }
    }
  };

  const handlePointerLeave = () => {
    if (isPaused) {
      setIsPaused(false);
      startTimeRef.current = Date.now();
    }
  };

  if (!isOpen) return null;

  const currentGroup = storyGroups[currentGroupIndex];
  if (!currentGroup) return null;
  const currentStory = currentGroup.stories[currentStoryIndex];
  if (!currentStory) return null;

  return createPortal(
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.2, ease: "easeOut" }}
        className="fixed inset-0 z-[99999] flex items-center justify-center sm:p-4"
      >
        <div 
          className="absolute inset-0 bg-black" 
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerLeave}
        />

        <div className="relative z-10 w-full max-w-md mx-auto h-full flex flex-col pointer-events-none rounded-none sm:rounded-[32px] overflow-hidden bg-zinc-900 border border-zinc-800 shadow-2xl">
          {/* Progress Bars */}
          <div className="absolute top-0 left-0 right-0 pt-3 px-2 flex gap-1 z-30">
            {currentGroup.stories.map((story, idx) => {
              let barProgress = 0;
              if (idx < currentStoryIndex) barProgress = 100;
              else if (idx === currentStoryIndex) barProgress = progress;
              
              return (
                <div key={story.id} className="h-[2px] flex-1 bg-white/30 rounded-full overflow-hidden backdrop-blur-sm">
                  <div 
                    className="h-full bg-white"
                    style={{ width: `${barProgress}%` }}
                  />
                </div>
              );
            })}
          </div>

          {/* Header */}
          <div className="absolute top-0 left-0 right-0 p-4 pt-6 flex items-center justify-between z-20 pointer-events-auto bg-gradient-to-b from-black/80 via-black/40 to-transparent pb-10">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-800 border border-white/20">
                <img src={currentGroup.user.avatar} className="w-full h-full object-cover" />
              </div>
              <span className="text-sm font-bold shadow-sm">{currentGroup.user.name}</span>
            </div>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }} 
              className="p-2 bg-black/40 hover:bg-black/60 rounded-full transition-colors backdrop-blur-md"
            >
              <X size={20} className="text-white" />
            </button>
          </div>

          {/* Story Content */}
          <div className="flex-1 w-full relative">
            <img 
              src={currentStory.mediaUrl} 
              alt="Story" 
              className="w-full h-full object-cover object-center bg-zinc-950"
            />
          </div>
        </div>
      </motion.div>
    </AnimatePresence>,
    document.body
  );
}
