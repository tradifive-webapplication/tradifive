import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabase";
import { useTrading } from "@/contexts/TradingContext";
import logoOnly from "@/assets/logo-only.png";

const loadingSteps = [
  "Connecting to servers",
  "Loading your portfolio",
  "Syncing market data",
  "Preparing dashboard",
  "Almost ready",
];

export const AuthGuard = ({ children }: { children: React.ReactNode }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [showBar, setShowBar] = useState(() => {
    // If the session is already active in this tab session, start immediately without showing a spinner
    return sessionStorage.getItem("fialgo_loaded") !== "true";
  });
  const [barDone, setBarDone] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const navigate = useNavigate();
  const { userSubscription } = useTrading();
  const isMounted = useRef(true);

  // Handle initial theme application
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") || "dark";
    if (savedTheme === 'dark') {
       document.documentElement.classList.add('dark');
    } else {
       document.documentElement.classList.remove('dark');
    }
  }, []);

  useEffect(() => {
    isMounted.current = true;

    const checkSession = async () => {
      try {
        const bypass = sessionStorage.getItem("fialgo_bypass") === "true";

        // Use getSession() — it reads from local storage without acquiring
        // the auth lock. This avoids NavigatorLockAcquireTimeoutError when
        // multiple components (AuthGuard, useDashboardData, AppSidebar)
        // all try to call getUser() simultaneously on mount.
        const { data: { session } } = await supabase.auth.getSession();

        if (!session && !bypass) {
          if (isMounted.current) {
            sessionStorage.removeItem("fialgo_loaded");
            navigate("/login");
          }
          return;
        }

        // Ensure a profile row exists for OAuth users (Google, GitHub)
        if (session?.user) {
          const user = session.user;
          const profileChecked = sessionStorage.getItem(`fialgo_profile_checked_${user.id}`) === "true";
          if (!profileChecked) {
            const { data: existingProfile } = await supabase
              .from('profiles')
              .select('id')
              .eq('id', user.id)
              .maybeSingle();

            if (!existingProfile) {
              // First-time OAuth user — create a profile from auth metadata
              const meta = user.user_metadata || {};
              const emailUsername = user.email?.split('@')[0]?.toLowerCase().replace(/[^a-z0-9]/g, '') || "trader";
              const resolvedName = meta.full_name || meta.name || `${meta.first_name || ''} ${meta.last_name || ''}`.trim() || emailUsername;
              const resolvedUsername = emailUsername + Math.floor(100 + Math.random() * 900);

              await supabase.from('profiles').upsert({
                id: user.id,
                email: user.email,
                first_name: meta.first_name || resolvedName.split(' ')[0] || "",
                last_name: meta.last_name || resolvedName.split(' ').slice(1).join(' ') || "",
                full_name: resolvedName,
                display_name: resolvedName,
                username: resolvedUsername,
                avatar_url: meta.avatar_url || meta.picture || `https://api.dicebear.com/7.x/initials/svg?seed=${resolvedName}`,
                xp_total: 0,
                xp_level: 1,
                streak_days: 0,
                created_at: new Date().toISOString(),
              }, { onConflict: 'id' });
            }
            sessionStorage.setItem(`fialgo_profile_checked_${user.id}`, "true");
          }
        }

        if (!isMounted.current) return;

        // If bypass loading screen is active, just let it render immediately
        if (sessionStorage.getItem("fialgo_loaded") === "true") {
          setBarDone(true);
        }
      } catch (err) {
        console.error("Auth check failed:", err);
        if (isMounted.current) navigate("/login");
      } finally {
        if (isMounted.current) setIsLoading(false);
      }
    };

    checkSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      // Only redirect on an explicit user-initiated sign out.
      // Ignore transient events like TOKEN_REFRESHED or INITIAL_SESSION
      // that can briefly produce a null session during token refresh.
      if (event === "SIGNED_OUT" && !session) {
        // Extra safety: check if bypass is active
        const bypass = sessionStorage.getItem("fialgo_bypass") === "true";
        if (!bypass && isMounted.current) {
          sessionStorage.removeItem("fialgo_loaded");
          navigate("/");
        }
      }
    });

    return () => {
      isMounted.current = false;
      subscription.unsubscribe();
    };
  }, [navigate]);

  useEffect(() => {
    if (!showBar || barDone) return;
    const startTime = Date.now();
    const duration = 2000; // 2 seconds high-fidelity loader

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const calculatedProgress = Math.min((elapsed / duration) * 100, 100);
      setProgress(calculatedProgress);

      if (calculatedProgress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setBarDone(true);
          sessionStorage.setItem("fialgo_loaded", "true");
        }, 300); // Smooth fade transition
      } else {
        const stepProgress = 100 / loadingSteps.length;
        const currentStep = Math.min(Math.floor(calculatedProgress / stepProgress), loadingSteps.length - 1);
        setStepIndex(currentStep);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [showBar, barDone]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-[#D6E4FF] dark:border-[#333333] border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (showBar && !barDone) {
    return (
      <div className="fixed inset-0 z-[9999] bg-[#ffffff] flex flex-col items-center justify-center transition-colors duration-500">
        <div className="w-full max-w-[300px] flex flex-col items-center">
          {/* Logo with awesome entry scaling transformation and pulse effect */}
          <div className="mb-6 transform scale-110 animate-[pulse_2.2s_infinite] transition-transform duration-700 ease-out">
            <img src={logoOnly} className="w-12 h-12 object-contain" alt="TradiFive Logo" />
          </div>

          <p
            key={stepIndex}
            className="text-[10px] text-slate-900 font-bold tracking-[0.3em] uppercase mb-8 animate-[fadeInUp_0.4s_ease-out] text-center animate-pulse"
          >
            {loadingSteps[stepIndex]}
          </p>

          <div className="relative w-full">
            {/* The Bar Track - slightly fatter in height */}
            <div className="w-full h-2 bg-slate-100 border border-slate-200/50 rounded-full overflow-hidden">
              {/* Progress Fill */}
              <motion.div
                className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.1 }}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      {children}
    </>
  );
};





