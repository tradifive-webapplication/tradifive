import React, { useState, useEffect } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Ic } from "./Ic";
import { Download } from "lucide-react";
import tradifiveLogo from "@/assets/tradifive-login-logo.png";

export default function PublicNavbar({ 
  onSignIn, 
  onSignUp, 
  onDownloadClick 
}: { 
  onSignIn: () => void; 
  onSignUp: () => void; 
  onDownloadClick: () => void; 
}) {
  const navigate = useNavigate();
  const location = useLocation();
  const isHome = location.pathname === "/";
  const [scrolled, setScrolled] = useState(false);
  const [showFeatures, setShowFeatures] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, []);

  const handleLogoClick = () => {
    if (isHome) {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      navigate("/");
    }
  };

  const navLinkStyle = { fontSize: 13, fontWeight: 500, textDecoration: "none", color: "inherit" };

  return (
    <nav style={{
      position: "fixed",
      top: isHome ? 40 : 0, left: 0, right: 0,
      height: 90,
      background: scrolled || !isHome ? "rgba(2, 4, 10, 0.85)" : "transparent",
      backdropFilter: scrolled || !isHome ? "blur(20px)" : "none",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000,
      transition: "all 0.4s ease",
      borderBottom: scrolled || !isHome ? "1px solid rgba(255,255,255,0.05)" : "1px solid transparent"
    }}>
      <div style={{ maxWidth: 1200, width: "100%", padding: "0 40px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", cursor: "pointer" }} onClick={handleLogoClick}>
          <img src={tradifiveLogo} style={{ height: 40, width: "auto" }} alt="TradiFive" />
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 32 }}>
          <div style={{ display: "flex", gap: 32, alignItems: "center" }} className="hide-sm">
            {/* Features Dropdown */}
            <div
              onMouseEnter={() => setShowFeatures(true)}
              onMouseLeave={() => setShowFeatures(false)}
              style={{ position: "relative" }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }} className="nav-link">
                <span style={{ fontSize: 13, fontWeight: 500 }}>Features</span>
                <motion.div animate={{ rotate: showFeatures ? 180 : 0 }}>
                  <Ic n="chev" s={12} sw={3} />
                </motion.div>
              </div>
              <AnimatePresence>
                {showFeatures && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    style={{
                      position: "absolute", top: "100%", left: -60, width: 280,
                      background: "rgba(10, 10, 10, 0.98)", border: "1px solid rgba(255,255,255,0.1)",
                      backdropFilter: "blur(25px)", borderRadius: 16, padding: "10px",
                      marginTop: 15, zIndex: 1100, boxShadow: "0 20px 50px rgba(0,0,0,0.8)"
                    }}
                  >
                    {[
                      { label: "Risk Guard", path: "/features/risk-guard", desc: "Autonomous drawdown protection" },
                      { label: "Automated Journal", path: "/features/automated-journal", desc: "Precision telemetry sync" },
                      { label: "Discover", path: "/features/discover", desc: "Explore community trading edges" },
                      { label: "Channels", path: "/features/channels", desc: "Collaborative broker-signal rooms" },
                      { label: "Pulse Feeds", path: "/features/pulse-feeds", desc: "Verified trader media timeline" }
                    ].map(item => (
                      <a key={item.label} href={item.path} className="nav-link" style={{
                        display: "block", padding: "10px 14px", borderRadius: 10, fontSize: 12.5,
                        transition: "all 0.2s", color: "rgba(255,255,255,0.7)",
                        textDecoration: "none"
                      }} onMouseEnter={e => {
                        e.currentTarget.style.background = "rgba(255,255,255,0.05)";
                        e.currentTarget.style.color = "#fff";
                      }}
                        onMouseLeave={e => {
                          e.currentTarget.style.background = "transparent";
                          e.currentTarget.style.color = "rgba(255,255,255,0.7)";
                        }}>
                        <div style={{ fontWeight: 600 }}>{item.label}</div>
                        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{item.desc}</div>
                      </a>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <a href={isHome ? "#pricing" : "/#pricing"} className="nav-link" style={navLinkStyle}>Pricing</a>
            <a href={isHome ? "#wall-of-fame" : "/#wall-of-fame"} className="nav-link" style={navLinkStyle}>Wall of Fame</a>
            <a href="/docs" className="nav-link" style={navLinkStyle}>Docs</a>
            
            <a 
              href="/download"
              className="nav-link" 
              style={{ ...navLinkStyle, background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 5, padding: 0 }}
            >
              <Download size={13} className="text-slate-400" />
              <span>App</span>
            </a>
          </div>

          <div style={{ width: 1, height: 16, background: "rgba(255,255,255,0.15)" }} className="hide-sm" />

          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button
              onClick={onSignIn}
              style={{ background: "none", border: "none", color: "rgba(255,255,255,0.6)", fontSize: 13, fontWeight: 500, cursor: "pointer", padding: "8px 12px", transition: "all 0.2s" }}
              onMouseEnter={(e) => { e.currentTarget.style.color = "#fff"; e.currentTarget.style.fontWeight = "700"; }}
              onMouseLeave={(e) => { e.currentTarget.style.color = "rgba(255,255,255,0.6)"; e.currentTarget.style.fontWeight = "500"; }}
            >
              Sign In
            </button>
            <button
              onClick={onSignUp}
              style={{ padding: "10px 22px", borderRadius: 100, background: "#fff", color: "#000", fontWeight: 700, fontSize: 13, border: "none", cursor: "pointer", transition: "all 0.2s" }}
              onMouseEnter={(e) => { e.currentTarget.style.transform = "scale(1.05)"; e.currentTarget.style.boxShadow = "0 0 20px rgba(255,255,255,0.2)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.boxShadow = "none"; }}
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
