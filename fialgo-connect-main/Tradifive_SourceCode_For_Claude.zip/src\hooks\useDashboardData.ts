import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { recordUserActivity } from '@/lib/activity';
import { createNotification } from '@/lib/notifications';
import { useTrading } from '@/contexts/TradingContext';

export function useDashboardData() {
  const [todayProfit, setTodayProfit] = useState(0);
  const [totalProfit, setTotalProfit] = useState(0);
  const [tradesToday, setTradesToday] = useState(0);
  const [winRate, setWinRate] = useState(0);
  const [drawdown, setDrawdown] = useState(2.45);
  const [recentTrades, setRecentTrades] = useState<any[]>([]);
  const [lastClosedTrade, setLastClosedTrade] = useState<any>(null);
  const [isAlgoRunning, setIsAlgoRunning] = useState(false);
  const [balance, setBalance] = useState(0);
  const [equity, setEquity] = useState(0);
  const [accountMetrics, setAccountMetrics] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [lastImportTime, setLastImportTime] = useState<string>("Feb 18, 2026 05:17 AM");

  // New Live Telemetry State Variables
  const [avgDisciplineScore, setAvgDisciplineScore] = useState<number | null>(null);
  const [dailyXpEarned, setDailyXpEarned] = useState<number>(0);
  const [riskConfig, setRiskConfig] = useState<any | null>(null);
  const [breachLogs, setBreachLogs] = useState<any[]>([]);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Use getSession() instead of getUser() to avoid acquiring the
      // Supabase auth lock. Multiple components calling getUser()
      // simultaneously causes NavigatorLockAcquireTimeoutError.
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (user) {
        // 1. Fetch MT5 account data
        const { data: accountData } = await supabase
          .from('mt5_accounts')
          .select('*')
          .eq('user_id', user.id)
          .limit(1)
          .maybeSingle();

        if (accountData) {
          setAccountMetrics(accountData);
          const bal = accountData.balance || 0;
          const eq = accountData.equity || 0;
          setBalance(bal);
          setEquity(eq);
          setIsAlgoRunning(accountData.algo_status || false);
          
          const calculatedDD = bal > 0 && eq < bal ? ((bal - eq) / bal) * 100 : 0;
          setDrawdown(calculatedDD);

          const formatTime = (date: Date) => {
            return date.toLocaleString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
              hour12: true
            });
          };
          setLastImportTime(formatTime(new Date()));
        } else {
          setAccountMetrics(null);
          setBalance(0);
          setEquity(0);
          setIsAlgoRunning(false);
          setDrawdown(0);
        }

        // 2. Fetch trades data
        const { data: tradesData } = await supabase
          .from('trades')
          .select('*')
          .eq('user_id', user.id)
          .order('closed_at', { ascending: false });

        if (tradesData && tradesData.length > 0) {
          setRecentTrades(tradesData);
          // Track the most recently closed trade for revenge-trade detection
          setLastClosedTrade(tradesData[0]);
          const winners = tradesData.filter(t => t.profit > 0);
          const wr = tradesData.length > 0 ? (winners.length / tradesData.length) * 100 : 0;
          setWinRate(Math.round(wr));

          // Overall P&L across ALL trades
          setTotalProfit(tradesData.reduce((acc, t) => acc + (t.profit || 0), 0));

          const startOfToday = new Date();
          startOfToday.setHours(0, 0, 0, 0);
          const todays = tradesData.filter(t => new Date(t.closed_at || t.created_at) >= startOfToday);
          setTodayProfit(todays.reduce((acc, t) => acc + (t.profit || 0), 0));
          setTradesToday(todays.length);

          // Calculate average discipline score from actual completed trades
          const scoredTrades = tradesData.filter(t => t.discipline_score !== null && t.discipline_score !== undefined);
          const avgScore = scoredTrades.length > 0
            ? Math.round(scoredTrades.reduce((acc, t) => acc + (t.discipline_score || 0), 0) / scoredTrades.length)
            : null;
          setAvgDisciplineScore(avgScore);
        } else {
          setRecentTrades([]);
          setLastClosedTrade(null);
          setWinRate(0);
          setTotalProfit(0);
          setTodayProfit(0);
          setTradesToday(0);
          setAvgDisciplineScore(null);
        }

        // 3. Fetch today's accumulated XP
        const startOfToday = new Date();
        startOfToday.setHours(0, 0, 0, 0);
        const { data: xpData } = await supabase
          .from('user_xp_ledger')
          .select('xp_amount')
          .eq('user_id', user.id)
          .gte('created_at', startOfToday.toISOString());

        const xpSum = xpData ? xpData.reduce((acc, r) => acc + (r.xp_amount || 0), 0) : 0;
        setDailyXpEarned(xpSum);

        // 4. Fetch risk limit configurations
        const { data: configData } = await supabase
          .from('user_risk_configs')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();
        setRiskConfig(configData);

        // 5. Fetch today's active risk logs
        const { data: logsData } = await supabase
          .from('risk_breach_logs')
          .select('*')
          .eq('user_id', user.id)
          .gte('created_at', startOfToday.toISOString())
          .order('created_at', { ascending: false });
        setBreachLogs(logsData || []);
      }
    } catch (err) {
      console.error("Dashboard Data Sync Failure:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    let channel: any = null;
    let isMounted = true;

    fetchData();

    const setupRealtime = async () => {
        const { data: { session } } = await supabase.auth.getSession();
        const user = session?.user;
        if (!user || !isMounted) return;
        
        const uniqueId = Math.random().toString(36).substring(2, 9);
        channel = supabase.channel(`dashboard_sync_v4_${user.id}_${Date.now()}_${uniqueId}`)
          .on('postgres_changes', { event: '*', schema: 'public', table: 'mt5_accounts', filter: `user_id=eq.${user.id}` }, 
              payload => {
                  if (!isMounted) return;
                  setAccountMetrics(payload.new);
                  const bal = payload.new.balance || 0;
                  const eq = payload.new.equity || 0;
                  setBalance(bal);
                  setEquity(eq);
                  setIsAlgoRunning(payload.new.algo_status);

                  const calculatedDD = bal > 0 && eq < bal ? ((bal - eq) / bal) * 100 : 0;
                  setDrawdown(calculatedDD);

                  const formatTime = (date: Date) => {
                    return date.toLocaleString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                      hour12: true
                    });
                  };
                  setLastImportTime(formatTime(new Date()));
              })
          .on('postgres_changes', { event: '*', schema: 'public', table: 'trades', filter: `user_id=eq.${user.id}` }, 
              () => { if (isMounted) fetchData(); })
          .on('postgres_changes', { event: '*', schema: 'public', table: 'user_xp_ledger', filter: `user_id=eq.${user.id}` }, 
              () => { if (isMounted) fetchData(); })
          .on('postgres_changes', { event: '*', schema: 'public', table: 'user_risk_configs', filter: `user_id=eq.${user.id}` }, 
              () => { if (isMounted) fetchData(); })
          .on('postgres_changes', { event: '*', schema: 'public', table: 'risk_breach_logs', filter: `user_id=eq.${user.id}` }, 
              () => { if (isMounted) fetchData(); })
          .subscribe();
    };

    setupRealtime();

    return () => {
      isMounted = false;
      if (channel) supabase.removeChannel(channel);
    };
  }, []);

  const toggleAlgoStatus = async (forcedState?: boolean) => {
    const newState = typeof forcedState === 'boolean' ? forcedState : !isAlgoRunning;
    setIsAlgoRunning(newState);
    
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (user) {
      await supabase.from('mt5_accounts').update({ algo_status: newState }).eq('user_id', user.id);
      await recordUserActivity(newState ? 'SWITCH_ON' : 'SWITCH_OFF', `User manually ${newState ? 'activated' : 'paused'} the trading engine.`);
      await createNotification({
        userId: user.id,
        type: 'TRADE',
        title: newState ? 'Trading Engine Active' : 'Trading Engine Paused',
        message: newState ? 'System synchronized. Automated executions are now active.' : 'Operational halt initiated. No new trades will be placed.'
      });
    }
  };

  const isConnected = !!accountMetrics?.account_number;

  const { terminalState } = useTrading();
  const [demoProfit, setDemoProfit] = useState(42.50);
  const [demoEquity, setDemoEquity] = useState(542.50);
  const [demoTradesCount, setDemoTradesCount] = useState(12);
  const [demoTrades, setDemoTrades] = useState([
    { id: '1', symbol: "EURUSD", profit: 12.50, type: "BUY", volume: 0.1, closed_at: new Date(Date.now() - 1000 * 60 * 5).toISOString() },
    { id: '2', symbol: "XAUUSD", profit: -4.20, type: "SELL", volume: 0.05, closed_at: new Date(Date.now() - 1000 * 60 * 45).toISOString() },
    { id: '3', symbol: "GBPUSD", profit: 8.40, type: "BUY", volume: 0.1, closed_at: new Date(Date.now() - 1000 * 60 * 120).toISOString() },
    { id: '4', symbol: "US30", profit: 25.80, type: "SELL", volume: 0.2, closed_at: new Date(Date.now() - 1000 * 60 * 200).toISOString() },
  ]);

  useEffect(() => {
    if (isConnected) return;

    let interval: NodeJS.Timeout;
    if (terminalState.algoEngine) {
      interval = setInterval(() => {
        const isWin = Math.random() > 0.3; // 70% win rate simulation
        const profitChange = isWin ? (Math.random() * 18 + 2) : -(Math.random() * 12 + 1);
        
        setDemoProfit(prev => prev + profitChange);
        setDemoEquity(prev => prev + profitChange);
        setDemoTradesCount(prev => prev + 1);
        
        const symbols = ["EURUSD", "XAUUSD", "GBPUSD", "US30", "BTCUSD", "US100"];
        const newTrade = {
          id: Math.random().toString(),
          symbol: symbols[Math.floor(Math.random() * symbols.length)],
          profit: profitChange,
          type: Math.random() > 0.5 ? "BUY" : "SELL",
          volume: (Math.random() * 0.5 + 0.01).toFixed(2),
          closed_at: new Date().toISOString()
        };
        
        setDemoTrades(prev => [newTrade, ...prev].slice(0, 50));
      }, 3000);
    }

    return () => clearInterval(interval);
  }, [isConnected, terminalState.algoEngine]);

  return {
    todayProfit: isConnected ? todayProfit : demoProfit,
    totalProfit: isConnected ? totalProfit : demoProfit,
    tradesToday: isConnected ? tradesToday : demoTradesCount,
    winRate: isConnected ? winRate : 68,
    drawdown: isConnected ? drawdown : 2.5,
    recentTrades: isConnected ? recentTrades : demoTrades,
    isAlgoRunning,
    balance: isConnected ? balance : 500.00,
    equity: isConnected ? equity : demoEquity,
    accountMetrics,
    isDemoMode: !isConnected,
    serverData: accountMetrics,
    isConnected,
    loading: isLoading,
    toggleAlgoStatus,
    lastImportTime,
    refetch: fetchData,
    
    // New live fields
    avgDisciplineScore: isConnected ? avgDisciplineScore : 98,
    dailyXpEarned: isConnected ? dailyXpEarned : 150,
    riskConfig,
    breachLogs: isConnected ? breachLogs : [],
    lastClosedTrade
  };
}
