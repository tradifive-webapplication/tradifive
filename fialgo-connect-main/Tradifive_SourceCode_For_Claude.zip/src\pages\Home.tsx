import { Search, Plus, X, MoreHorizontal, Heart, MessageCircle, Bookmark, UserPlus, UserCheck, Flame, ShieldCheck, TrendingUp, Layers, Eye, Calendar, Globe, Sliders, Trash2, Check } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { useState, useRef, useEffect, useMemo } from "react";
import { createPortal } from "react-dom";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useHomeData, FeedPost } from "@/hooks/useHomeData";
import CreatePostModal from "@/components/CreatePostModal";
import CreateStoryModal from "@/components/CreateStoryModal";
import StoryViewer, { StoryGroup } from "@/components/StoryViewer";
import FeedCard from "@/components/FeedCard";

// --- PREMIUM MOCK FALLBACKS (Active when database is fresh & empty) ---
const mockStories = [
    { id: 1, name: "Gladys", avatar: "https://i.pravatar.cc/150?u=1" },
    { id: 2, name: "Kristin", avatar: "https://i.pravatar.cc/150?u=2" },
    { id: 3, name: "Priscilla", avatar: "https://i.pravatar.cc/150?u=3" },
    { id: 4, name: "Connie", avatar: "https://i.pravatar.cc/150?u=4" },
    { id: 5, name: "Brandie", avatar: "https://i.pravatar.cc/150?u=5" },
    { id: 6, name: "Lily", avatar: "https://i.pravatar.cc/150?u=6" },
];

const mockRequests = [
    { id: 1, name: "Lauralee Quintero", avatar: "https://i.pravatar.cc/150?u=20" },
    { id: 2, name: "Brittni Landoma", avatar: "https://i.pravatar.cc/150?u=21" }
];

const mockSuggestions = [
    { id: 1, name: "Chantal Shelburne", location: "Memphis, TN, US", avatar: "https://i.pravatar.cc/150?u=30" },
    { id: 2, name: "Marci Senter", location: "Newark, NJ, US", avatar: "https://i.pravatar.cc/150?u=31" },
    { id: 3, name: "Janetta Rotolo", location: "Fort Worth, TX, US", avatar: "https://i.pravatar.cc/150?u=32" },
    { id: 4, name: "Tyra Dhillon", location: "Springfield, MA, US", avatar: "https://i.pravatar.cc/150?u=33" },
    { id: 5, name: "Marielle Wigington", location: "Honolulu, HI, US", avatar: "https://i.pravatar.cc/150?u=34" }
];

const mockWinningStreaks = [
    { id: 1, name: "Rohan Sharma", streak: "14 days", gain: "+14.2%", avatar: "https://api.dicebear.com/7.x/initials/svg?seed=rohan" },
    { id: 2, name: "Elena Rostova", streak: "9 days", gain: "+9.5%", avatar: "https://api.dicebear.com/7.x/avataaars/png?seed=elena" },
    { id: 3, name: "Amelia Chen", streak: "7 days", gain: "+8.1%", avatar: "https://api.dicebear.com/7.x/open-peeps/png?seed=amelia" }
];

const mockDisciplined = [
    { id: 1, name: "Marcus Vance", score: "100%", description: "0 daily limit breaches", avatar: "https://api.dicebear.com/7.x/open-peeps/png?seed=marcus" },
    { id: 2, name: "You", score: "98%", description: "1 daily limit breach", avatar: "https://api.dicebear.com/7.x/initials/svg?seed=You" },
    { id: 3, name: "David Miller", score: "96%", description: "2 daily limit breaches", avatar: "https://api.dicebear.com/7.x/avataaars/png?seed=david" }
];

const mockFollowerAvatars = [
    "https://i.pravatar.cc/150?u=40",
    "https://i.pravatar.cc/150?u=41",
    "https://i.pravatar.cc/150?u=42",
    "https://i.pravatar.cc/150?u=43",
    "https://i.pravatar.cc/150?u=44",
];

function ToggleRow({ label, checked, onChange }: { label: string, checked: boolean, onChange: (val: boolean) => void }) {
    return (
        <label className="flex items-center justify-between cursor-pointer group">
            <span className="text-[12px] font-semibold text-slate-600 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">{label}</span>
            <div className="relative inline-flex items-center">
                <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="sr-only peer" />
                <div className="w-9 h-5 bg-slate-200 dark:bg-[#333] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-500"></div>
            </div>
        </label>
    );
}

function HomeSkeleton() {
    return (
        <div className="w-full h-full flex flex-col min-h-0 px-4 lg:px-10 pt-0 pb-0 select-none font-sans text-slate-800 dark:text-slate-100 animate-pulse">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-full min-h-0 relative">
                
                {/* --- COLUMN 1: LEFT SIDEBAR (col-span-3) --- */}
                <div className="lg:col-span-3 lg:col-start-1 h-full overflow-y-auto amazing-scrollbar space-y-6 px-4 pt-5 pb-4">
                    {/* Watchlist Skeleton */}
                    <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                        <div className="h-5 w-28 bg-slate-200 dark:bg-slate-800/80 rounded-md mb-5" />
                        <div className="space-y-4">
                            {[1, 2, 3, 4].map((i) => (
                                <div key={i} className="flex items-center justify-between">
                                    <div className="flex items-center gap-2.5">
                                        <div className="w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-800/80" />
                                        <div className="space-y-1.5">
                                            <div className="h-3 w-14 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                            <div className="h-2 w-10 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                        </div>
                                    </div>
                                    <div className="text-right space-y-1.5 flex flex-col items-end">
                                        <div className="h-3 w-12 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                        <div className="h-2.5 w-8 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Calendar Skeleton */}
                    <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                        <div className="h-5 w-36 bg-slate-200 dark:bg-slate-800/80 rounded-md mb-5" />
                        <div className="space-y-4">
                            {[1, 2, 3].map((i) => (
                                <div key={i} className="flex gap-3 items-center">
                                    <div className="w-12 h-8 rounded-xl bg-slate-200 dark:bg-slate-800/80 shrink-0" />
                                    <div className="flex-1 min-w-0 space-y-1.5">
                                        <div className="flex items-center justify-between gap-1.5">
                                            <div className="h-3 w-28 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                            <div className="h-2.5 w-8 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                        </div>
                                        <div className="h-2 w-20 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Followers Stats Skeleton */}
                    <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                        <div className="flex items-center mb-5 pl-3">
                            {[1, 2, 3].map((i) => (
                                <div 
                                    key={i} 
                                    className="w-8 h-8 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-slate-200 dark:bg-slate-800/80 shadow-sm"
                                    style={{ 
                                        marginLeft: i > 1 ? '-12px' : '0px',
                                        zIndex: 4 - i
                                    }}
                                />
                            ))}
                        </div>
                        <div className="h-8 w-24 bg-slate-200 dark:bg-slate-800/80 rounded-md mb-1.5" />
                        <div className="h-3.5 w-36 bg-slate-200 dark:bg-slate-800/80 rounded-md" />
                    </div>
                </div>

                {/* --- COLUMN 2: MIDDLE MAIN CONTENT (col-span-6) --- */}
                <div className="lg:col-span-6 lg:col-start-4 h-full overflow-y-auto amazing-scrollbar space-y-8 px-4 pt-5 pb-6">
                    {/* Stories Skeleton */}
                    <div className="space-y-4">
                        <div className="h-6 w-20 bg-slate-200 dark:bg-slate-800/80 rounded-md" />
                        <div className="flex items-center gap-5 overflow-x-auto pb-2 scrollbar-hide">
                            <div className="shrink-0 flex flex-col items-center gap-2">
                                <div className="w-[68px] h-[68px] rounded-full bg-slate-200 dark:bg-slate-800/80" />
                                <div className="h-2.5 w-12 bg-slate-200 dark:bg-slate-800/80 rounded" />
                            </div>
                            {[1, 2, 3, 4, 5].map((i) => (
                                <div key={i} className="shrink-0 flex flex-col items-center gap-2">
                                    <div className="w-[68px] h-[68px] rounded-full bg-slate-200 dark:bg-slate-800/80" />
                                    <div className="h-2.5 w-12 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Feeds Skeleton */}
                    <div className="space-y-6">
                        <div className="flex items-center justify-between">
                            <div className="h-6 w-16 bg-slate-200 dark:bg-slate-800/80 rounded-md" />
                            <div className="h-8 w-32 bg-slate-200 dark:bg-slate-800/80 rounded-[14px]" />
                        </div>
                        
                        {[1, 2].map((i) => (
                            <div key={i} className="p-6 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] space-y-4">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800/80" />
                                        <div className="space-y-2">
                                            <div className="h-3 w-28 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                            <div className="h-2.5 w-20 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className="h-7 w-14 bg-slate-200 dark:bg-slate-800/80 rounded-[10px]" />
                                        <div className="h-7 w-16 bg-slate-200 dark:bg-slate-800/80 rounded-[10px]" />
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <div className="h-3 w-full bg-slate-200 dark:bg-slate-800/80 rounded" />
                                    <div className="h-3 w-5/6 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                </div>
                                <div className="h-44 w-full bg-slate-200 dark:bg-slate-800/80 rounded-xl" />
                                <div className="flex justify-between items-center pt-2">
                                    <div className="flex gap-6">
                                        <div className="h-4 w-10 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                        <div className="h-4 w-10 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                    </div>
                                    <div className="h-4 w-4 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* --- COLUMN 3: RIGHT SIDEBAR (col-span-3) --- */}
                <div className="lg:col-span-3 lg:col-start-10 h-full overflow-y-auto amazing-scrollbar space-y-6 px-4 pt-5 pb-4">
                    {/* Requests Skeleton */}
                    <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                        <div className="h-5 w-20 bg-slate-200 dark:bg-slate-800/80 rounded-md mb-5" />
                        <div className="space-y-4">
                            {[1, 2].map((i) => (
                                <div key={i} className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800/80" />
                                    <div className="flex-1 space-y-1.5">
                                        <div className="h-3 w-24 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                        <div className="h-2 w-16 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Suggestions Skeleton */}
                    <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                        <div className="h-5 w-32 bg-slate-200 dark:bg-slate-800/80 rounded-md mb-5" />
                        <div className="space-y-4">
                            {[1, 2, 3].map((i) => (
                                <div key={i} className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800/80" />
                                        <div className="space-y-1.5">
                                            <div className="h-3 w-20 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                            <div className="h-2 w-16 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                        </div>
                                    </div>
                                    <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-800/80" />
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Winning Streaks Skeleton */}
                    <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                        <div className="h-5 w-36 bg-slate-200 dark:bg-slate-800/80 rounded-md mb-5" />
                        <div className="space-y-4">
                            {[1, 2, 3].map((i) => (
                                <div key={i} className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800/80" />
                                        <div className="space-y-1.5">
                                            <div className="h-3 w-20 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                            <div className="h-2.5 w-12 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                        </div>
                                    </div>
                                    <div className="h-3 w-10 bg-slate-200 dark:bg-slate-800/80 rounded" />
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
}

// --- SMART WATCHLIST AUTO-DETECTION & ANIMATED LIVE TICKS ---
const detectSymbolDetails = (input: string): { symbol: string; type: 'crypto' | 'forex' } => {
    let clean = input.trim().toUpperCase().replace(/[-_]/g, '/');
    
    // Common crypto base tokens
    const cryptoBases = ['BTC', 'ETH', 'SOL', 'ADA', 'DOGE', 'XRP', 'DOT', 'LINK', 'BNB', 'LTC', 'BCH', 'UNI', 'AVAX', 'MATIC', 'SHIB', 'TRX'];
    // Common crypto quotes
    const cryptoQuotes = ['USDT', 'USDC', 'BUSD', 'DAI'];
    
    // Common forex currencies
    const forexCurrencies = ['EUR', 'GBP', 'AUD', 'NZD', 'USD', 'CAD', 'CHF', 'JPY', 'SGD', 'HKD', 'CNY', 'INR', 'ZAR', 'MXN', 'TRY', 'SEK', 'NOK', 'DKK'];
    
    // 1. If it already has a slash
    if (clean.includes('/')) {
        const [base, quote] = clean.split('/');
        if (cryptoQuotes.includes(quote) || cryptoBases.includes(base)) {
            return { symbol: clean, type: 'crypto' };
        }
        if (forexCurrencies.includes(base) && forexCurrencies.includes(quote)) {
            return { symbol: clean, type: 'forex' };
        }
        return { symbol: clean, type: quote.length > 3 ? 'crypto' : 'forex' };
    }
    
    // 2. If it does not have a slash: e.g. "EURUSD" or "BTCUSDT"
    for (const quote of cryptoQuotes) {
        if (clean.endsWith(quote)) {
            const base = clean.slice(0, -quote.length);
            return { symbol: `${base}/${quote}`, type: 'crypto' };
        }
    }
    
    if (clean.length === 6) {
        const base = clean.substring(0, 3);
        const quote = clean.substring(3, 6);
        if (forexCurrencies.includes(base) && forexCurrencies.includes(quote)) {
            return { symbol: `${base}/${quote}`, type: 'forex' };
        }
        if (cryptoBases.includes(base)) {
            return { symbol: `${base}/${quote}`, type: 'crypto' };
        }
        return { symbol: `${base}/${quote}`, type: 'forex' };
    }
    
    if (clean.length > 6) {
        if (clean.endsWith('USD')) {
            return { symbol: `${clean.slice(0, -3)}/USD`, type: 'crypto' };
        }
        return { symbol: `${clean.substring(0, 4)}/${clean.substring(4)}`, type: 'crypto' };
    }
    
    return { symbol: clean, type: 'crypto' };
};

function WatchlistItem({ asset }: { asset: any }) {
    const prevPriceRef = useRef<string>("");
    const [blinkDirection, setBlinkDirection] = useState<'up' | 'down' | null>(null);

    const price = asset.price;
    const change = asset.change;
    const isPositive = asset.is_positive;
    const displaySymbol = asset.symbol;
    const displayName = asset.symbol_type === "forex" ? "Forex Spot" : "Crypto Spot";

    useEffect(() => {
        if (price === 'Loading...' || price === '...') return;
        if (!prevPriceRef.current) {
            prevPriceRef.current = price;
            return;
        }

        const prevNum = parseFloat(prevPriceRef.current.replace(/,/g, ''));
        const currNum = parseFloat(price.replace(/,/g, ''));

        if (!isNaN(prevNum) && !isNaN(currNum) && prevNum !== currNum) {
            if (currNum > prevNum) {
                setBlinkDirection('up');
            } else if (currNum < prevNum) {
                setBlinkDirection('down');
            }
            
            const timer = setTimeout(() => {
                setBlinkDirection(null);
            }, 600);
            return () => clearTimeout(timer);
        }

        prevPriceRef.current = price;
    }, [price]);

    return (
        <div className="flex items-center justify-between group hover:translate-x-0.5 transition-transform duration-200">
            <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-[#1A1E29] flex items-center justify-center border border-slate-200/50 dark:border-slate-800 shadow-3xs font-bold text-[10px] text-slate-655 dark:text-slate-350">
                    {displaySymbol.split('/')[0]}
                </div>
                <div>
                    <p className="text-[13px] font-semibold text-slate-900 dark:text-white leading-tight tracking-tight">{displaySymbol}</p>
                    <p className="text-[10px] font-medium text-slate-455 dark:text-slate-505 leading-none mt-0.5">{displayName}</p>
                </div>
            </div>
            
            <div className="text-right">
                <p className={`text-[13px] font-bold leading-tight transition-all duration-300 ${
                    blinkDirection === 'up' 
                        ? 'text-emerald-500 dark:text-emerald-450 scale-[1.05] transform origin-right duration-75' 
                        : blinkDirection === 'down'
                            ? 'text-rose-500 dark:text-rose-455 scale-[1.05] transform origin-right duration-75'
                            : 'text-slate-900 dark:text-white'
                }`}>
                    {price}
                </p>
                <span className={`inline-block text-[9.5px] font-bold px-1.5 py-0.5 rounded mt-0.5 leading-none transition-colors ${
                    isPositive 
                        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-450" 
                        : "bg-rose-500/10 text-rose-600 dark:text-rose-400"
                }`}>
                    {change}
                </span>
            </div>
        </div>
    );
}

export default function Home() {
    const navigate = useNavigate();
    const [user, setUser] = useState<any>(null);
    const [authChecked, setAuthChecked] = useState(false);

    const [showWatchlist, setShowWatchlist] = useState(true);
    const [showCalendar, setShowCalendar] = useState(true);
    const [showFollowers, setShowFollowers] = useState(true);
    const [showRequests, setShowRequests] = useState(true);
    const [showSuggestions, setShowSuggestions] = useState(true);
    const [showStreaks, setShowStreaks] = useState(true);
    const [showDisciplined, setShowDisciplined] = useState(true);
    
    // Customize layout elements
    const [showCustomizeMenu, setShowCustomizeMenu] = useState(false);
    const customizeMenuRef = useRef<HTMLDivElement>(null);

    const [customizeActiveTab, setCustomizeActiveTab] = useState<'layout' | 'watchlist' | 'calendar'>('layout');
    const [newSymbolName, setNewSymbolName] = useState("");
    const [newSymbolType, setNewSymbolType] = useState<'crypto' | 'forex'>('crypto');
    const [isAddingSymbol, setIsAddingSymbol] = useState(false);

    const [calendarFilters, setCalendarFilters] = useState<{ high: boolean; medium: boolean; low: boolean }>(() => {
        try {
            const cached = localStorage.getItem('home_calendar_filters');
            return cached ? JSON.parse(cached) : { high: true, medium: true, low: true };
        } catch (e) {
            return { high: true, medium: true, low: true };
        }
    });

    useEffect(() => {
        localStorage.setItem('home_calendar_filters', JSON.stringify(calendarFilters));
    }, [calendarFilters]);

    const handleAddSymbol = async () => {
        if (!newSymbolName.trim() || !user?.id) return;
        
        const { symbol: sym } = detectSymbolDetails(newSymbolName);
        
        // Check duplication
        const exists = watchlist.some((item: any) => item.symbol.toUpperCase() === sym.toUpperCase());
        if (exists) {
            toast.warning(`${sym} is already in your watchlist!`);
            return;
        }

        setIsAddingSymbol(true);
        try {
            const { error } = await supabase.from('feed_watchlist').insert([{
                symbol: sym,
                symbol_type: newSymbolType,
                is_pinned: false,
                sort_order: watchlist.length + 1,
                user_id: user.id
            }]);
            if (error) throw error;
            
            toast.success(`Added ${sym} to watchlist!`);
            setNewSymbolName("");
            refetch();
        } catch (err: any) {
            console.error("Error adding symbol:", err);
            toast.error("Failed to add symbol.");
        } finally {
            setIsAddingSymbol(false);
        }
    };

    const handleDeleteSymbol = async (id: string) => {
        try {
            const { error } = await supabase.from('feed_watchlist').delete().eq('id', id);
            if (error) throw error;
            
            toast.success("Watchlist item removed!");
            refetch();
        } catch (err: any) {
            console.error("Error deleting symbol:", err);
            toast.error("Failed to remove item.");
        }
    };

    // Auth check on mount
    useEffect(() => {
        const checkUser = async () => {
            const { data: { session } } = await supabase.auth.getSession();
            if (!session?.user) {
                navigate("/login");
            } else {
                setUser(session.user);
                setAuthChecked(true);
            }
        };
        checkUser();
    }, [navigate]);

    // Supabase Live Data Fetching
    const { feeds, stories, watchlist, calendar, followers, suggestions, winningStreaks, topDisciplined, loading, refetch } = useHomeData(user?.id ?? "");

    // Group stories by user_id
    const storyGroups = useMemo(() => {
        const groups: Record<string, StoryGroup> = {};
        stories.forEach(story => {
            const uid = story.user_id;
            if (!groups[uid]) {
                groups[uid] = {
                    userId: uid,
                    user: {
                        name: story.profiles?.full_name || story.profiles?.username || "Unknown",
                        avatar: story.profiles?.avatar_url || "https://api.dicebear.com/7.x/initials/svg?seed=U"
                    },
                    stories: []
                };
            }
            groups[uid].stories.push({
                id: story.id,
                mediaUrl: story.media_url || "",
                createdAt: story.created_at || new Date().toISOString()
            });
        });
        return Object.values(groups);
    }, [stories]);

    const [isCreateStoryOpen, setIsCreateStoryOpen] = useState(false);
    const [storyViewerGroupIndex, setStoryViewerGroupIndex] = useState<number | null>(null);

    const [isCreatePostModalOpen, setIsCreatePostModalOpen] = useState(false);
    const [editPost, setEditPost] = useState<FeedPost | null>(null);
    const [followedUsers, setFollowedUsers] = useState<Record<string, boolean>>({});
    const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});
    const [likesOffsets, setLikesOffsets] = useState<Record<string, number>>({});
    const [feedSort, setFeedSort] = useState<'popular' | 'latest'>('popular');

    const handleDeletePost = async (postId: string) => {
        if (!confirm("Are you sure you want to delete this post?")) return;
        try {
            const { error } = await supabase
                .from('social_posts')
                .delete()
                .eq('id', postId);
            if (error) throw error;
            toast.success("Post deleted successfully!");
            refetch();
        } catch (err: any) {
            console.error("Error deleting post:", err);
            toast.error("Failed to delete post.");
        }
    };

    const handleVote = async (postId: string, updatedMediaUrl: string) => {
        try {
            const { error } = await supabase
                .from('social_posts')
                .update({ media_url: updatedMediaUrl })
                .eq('id', postId);
            if (error) throw error;
            refetch();
        } catch (err: any) {
            console.error("Error updating vote:", err);
        }
    };

    // Fetch follows and liked posts on user load
    useEffect(() => {
        const fetchFollows = async () => {
            if (!user?.id) return;
            const { data } = await supabase
                .from('social_follows')
                .select('following_id')
                .eq('follower_id', user.id);
            if (data) {
                const map: Record<string, boolean> = {};
                data.forEach(item => {
                    map[item.following_id] = true;
                });
                setFollowedUsers(map);
            }
        };

        const fetchLikedPosts = async () => {
            if (!user?.id) return;
            const { data } = await supabase
                .from('social_post_likes')
                .select('post_id')
                .eq('user_id', user.id);
            if (data) {
                const map: Record<string, boolean> = {};
                data.forEach(item => {
                    map[item.post_id] = true;
                });
                setLikedPosts(map);
            }
        };

        fetchFollows();
        fetchLikedPosts();
    }, [user?.id]);

    const toggleFollowUser = async (targetUserId: string, targetName: string) => {
        if (!user?.id) return;
        if (targetUserId === user.id) return;
        const isFollowing = followedUsers[targetUserId] || false;
        
        // Optimistic update
        setFollowedUsers(prev => ({ ...prev, [targetUserId]: !isFollowing }));
        
        try {
            if (isFollowing) {
                const { error } = await supabase
                    .from('social_follows')
                    .delete()
                    .eq('follower_id', user.id)
                    .eq('following_id', targetUserId);
                if (error) throw error;
                toast.info(`Unfollowed ${targetName}`);
            } else {
                const { error } = await supabase
                    .from('social_follows')
                    .insert([{ follower_id: user.id, following_id: targetUserId }]);
                if (error) throw error;
                toast.success(`Followed ${targetName}`);
            }
            // Don't refetch all data - optimistic UI update is sufficient
        } catch (err: any) {
            console.error("Error toggling follow:", err);
            toast.error("Failed to update follow state.");
            setFollowedUsers(prev => ({ ...prev, [targetUserId]: isFollowing }));
        }
    };

    const handleLikePost = async (postId: string) => {
        if (!user?.id) return;
        const isCurrentlyLiked = likedPosts[postId] || false;
        const nextLiked = !isCurrentlyLiked;
        
        // Optimistic update
        setLikedPosts(prev => ({ ...prev, [postId]: nextLiked }));
        setLikesOffsets(prev => ({
            ...prev,
            [postId]: (prev[postId] || 0) + (nextLiked ? 1 : -1)
        }));

        try {
            if (nextLiked) {
                await supabase.from('social_post_likes').insert([{ post_id: postId, user_id: user.id }]);
            } else {
                await supabase.from('social_post_likes').delete().eq('post_id', postId).eq('user_id', user.id);
            }
            // Fallback for missing SQL triggers
            const { data: postData } = await supabase.from('social_posts').select('like_count').eq('id', postId).single();
            const currentCount = postData?.like_count || 0;
            const newCount = nextLiked ? currentCount + 1 : Math.max(0, currentCount - 1);
            await supabase.from('social_posts').update({ like_count: newCount }).eq('id', postId);
        } catch (err) {
            console.error("Error toggling like:", err);
        }
    };

    const handleToggle = (
        setter: React.Dispatch<React.SetStateAction<boolean>>,
        value: boolean
    ) => {
        setter(value);
    };

    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (customizeMenuRef.current && !customizeMenuRef.current.contains(event.target as Node)) {
                setShowCustomizeMenu(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    if (!authChecked || loading) {
        return (
            <DashboardLayout breadcrumbs={[{ label: "Home", path: "/home" }]} noScroll={true} noPadding={true}>
                <HomeSkeleton />
            </DashboardLayout>
        );
    }

    const headerActions = (
        <div className="flex items-center gap-4">
            
            <div className="relative" ref={customizeMenuRef}>
                <button 
                    onClick={() => setShowCustomizeMenu(!showCustomizeMenu)}
                    className={`flex items-center justify-center w-10 h-10 rounded-full border shadow-sm transition-colors ${showCustomizeMenu ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 border-blue-500/30' : 'bg-white dark:bg-[#1A1A1A] border-slate-200 dark:border-[#333] text-slate-500 hover:text-blue-500 hover:border-blue-500'}`}
                    title="Customize Layout"
                >
                    <Sliders size={18} />
                </button>
                
                <AnimatePresence>
                    {showCustomizeMenu && (
                        <motion.div
                            initial={{ opacity: 0, y: 10, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.95 }}
                            transition={{ duration: 0.15 }}
                            className="absolute right-0 top-full mt-3 w-[340px] p-5 rounded-2xl bg-white dark:bg-[#171719] border border-slate-200 dark:border-[#333] shadow-2xl z-50 text-slate-800 dark:text-slate-100"
                        >
                            <div className="flex items-center justify-between mb-4">
                                <h4 className="text-[14px] font-bold text-slate-900 dark:text-white tracking-tight">Customize Dashboard</h4>
                            </div>

                            {/* Tabs Header */}
                            <div className="flex bg-slate-100 dark:bg-slate-900/60 p-1 rounded-xl mb-4 text-[10px] font-bold">
                                {(['layout', 'watchlist', 'calendar'] as const).map((tab) => (
                                    <button
                                        key={tab}
                                        onClick={() => setCustomizeActiveTab(tab)}
                                        className={`flex-1 py-1.5 rounded-lg uppercase tracking-wider transition-all ${
                                            customizeActiveTab === tab 
                                                ? 'bg-white dark:bg-[#222] text-blue-600 dark:text-blue-400 shadow-sm border border-slate-200/50 dark:border-slate-800' 
                                                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-400'
                                        }`}
                                    >
                                        {tab}
                                    </button>
                                ))}
                            </div>

                            {/* Tab 1: Layout Toggles */}
                            {customizeActiveTab === 'layout' && (
                                <motion.div
                                    initial={{ opacity: 0, y: 5 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="max-h-[300px] overflow-y-auto amazing-scrollbar pr-2 space-y-5"
                                >
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Market Cards</span>
                                        <button
                                            onClick={() => {
                                                const anyVisible = showWatchlist || showCalendar || showFollowers || showRequests || showSuggestions || showStreaks || showDisciplined;
                                                if (anyVisible) {
                                                    setShowWatchlist(false);
                                                    setShowCalendar(false);
                                                    setShowFollowers(false);
                                                    setShowRequests(false);
                                                    setShowSuggestions(false);
                                                    setShowStreaks(false);
                                                    setShowDisciplined(false);
                                                } else {
                                                    handleToggle(setShowWatchlist, true);
                                                    handleToggle(setShowCalendar, true);
                                                    handleToggle(setShowFollowers, true);
                                                    handleToggle(setShowRequests, true);
                                                    handleToggle(setShowSuggestions, true);
                                                    handleToggle(setShowStreaks, true);
                                                    handleToggle(setShowDisciplined, true);
                                                }
                                            }}
                                            className="text-[9px] font-bold text-blue-500 hover:text-blue-650 transition-colors uppercase tracking-wider"
                                        >
                                            {(showWatchlist || showCalendar || showFollowers || showRequests || showSuggestions || showStreaks || showDisciplined) ? 'Hide All' : 'Show All'}
                                        </button>
                                    </div>
                                    <div className="space-y-3">
                                        <ToggleRow label="My Watchlist" checked={showWatchlist} onChange={(v) => handleToggle(setShowWatchlist, v)} />
                                        <ToggleRow label="Economic Calendar" checked={showCalendar} onChange={(v) => handleToggle(setShowCalendar, v)} />
                                        <ToggleRow label="Followers Stats" checked={showFollowers} onChange={(v) => handleToggle(setShowFollowers, v)} />
                                    </div>

                                    <div>
                                        <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Community Cards</h5>
                                        <div className="space-y-3">
                                            <ToggleRow label="Requests" checked={showRequests} onChange={(v) => handleToggle(setShowRequests, v)} />
                                            <ToggleRow label="Suggestions" checked={showSuggestions} onChange={(v) => handleToggle(setShowSuggestions, v)} />
                                            <ToggleRow label="Winning Streaks" checked={showStreaks} onChange={(v) => handleToggle(setShowStreaks, v)} />
                                            <ToggleRow label="Top Disciplined" checked={showDisciplined} onChange={(v) => handleToggle(setShowDisciplined, v)} />
                                        </div>
                                    </div>
                                </motion.div>
                            )}

                            {/* Tab 2: Watchlist Symbol Manager */}
                            {customizeActiveTab === 'watchlist' && (
                                <motion.div
                                    initial={{ opacity: 0, y: 5 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="space-y-4"
                                >
                                    <div>
                                        <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Add Watchlist Pair</h5>
                                        <div className="space-y-2">
                                            <input
                                                type="text"
                                                placeholder="e.g. BTC/USDT, EUR/USD"
                                                value={newSymbolName}
                                                onChange={(e) => setNewSymbolName(e.target.value)}
                                                className="w-full px-3 py-2 text-[12px] font-semibold bg-slate-50 dark:bg-[#1A1A1C] border border-slate-205 dark:border-slate-800 rounded-xl outline-none focus:border-blue-500 transition-colors"
                                            />
                                            <div className="flex gap-2">
                                                <div className="flex-1 bg-slate-100 dark:bg-slate-900/40 p-0.5 rounded-lg flex text-[10px] font-bold border border-slate-200/50 dark:border-slate-850">
                                                    {(['crypto', 'forex'] as const).map((type) => (
                                                        <button
                                                            key={type}
                                                            type="button"
                                                            onClick={() => setNewSymbolType(type)}
                                                            className={`flex-1 py-1 rounded-md uppercase tracking-wider transition-all ${
                                                                newSymbolType === type 
                                                                    ? 'bg-white dark:bg-[#222] text-slate-900 dark:text-white shadow-xs' 
                                                                    : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-350'
                                                            }`}
                                                        >
                                                            {type}
                                                        </button>
                                                    ))}
                                                </div>
                                                <button
                                                    onClick={handleAddSymbol}
                                                    disabled={isAddingSymbol || !newSymbolName.trim()}
                                                    className="px-4 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-extrabold text-[10px] uppercase tracking-wider transition-all disabled:opacity-50 select-none flex items-center gap-1 shadow-sm"
                                                >
                                                    <Plus size={12} />
                                                    Add
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div>
                                        <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Active Pairs ({watchlist.length})</h5>
                                        <div className="max-h-[160px] overflow-y-auto amazing-scrollbar pr-1 space-y-2">
                                            {watchlist.length === 0 ? (
                                                <p className="text-[11px] font-medium text-slate-405 dark:text-slate-500 text-center py-4 bg-slate-50/50 dark:bg-slate-900/30 rounded-xl border border-dashed border-slate-200/60 dark:border-slate-800">
                                                    No active watchlist pairs
                                                </p>
                                            ) : (
                                                watchlist.map((item: any) => (
                                                    <div 
                                                        key={item.id} 
                                                        className="flex items-center justify-between p-2 rounded-xl bg-slate-50/70 dark:bg-slate-900/40 border border-slate-200/40 dark:border-slate-850 hover:bg-slate-100/50 dark:hover:bg-slate-900/60 transition-colors"
                                                    >
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-[12px] font-bold text-slate-900 dark:text-white uppercase tracking-tight">{item.symbol}</span>
                                                            <span className={`text-[7.5px] font-extrabold px-1.5 py-0.5 rounded uppercase leading-none ${
                                                                item.symbol_type === 'crypto' 
                                                                    ? 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/5' 
                                                                    : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/5'
                                                            }`}>
                                                                {item.symbol_type}
                                                            </span>
                                                        </div>
                                                        <button
                                                            onClick={() => handleDeleteSymbol(item.id)}
                                                            className="p-1 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 transition-all active:scale-95"
                                                            title="Delete symbol"
                                                        >
                                                            <Trash2 size={12} />
                                                        </button>
                                                    </div>
                                                ))
                                            )}
                                        </div>
                                    </div>
                                </motion.div>
                            )}

                            {/* Tab 3: Calendar Filters */}
                            {customizeActiveTab === 'calendar' && (
                                <motion.div
                                    initial={{ opacity: 0, y: 5 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="space-y-4"
                                >
                                    <div>
                                        <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Filter Events Impact</h5>
                                        <p className="text-[10px] font-medium text-slate-400 dark:text-slate-500 mb-4 leading-normal">
                                            Adjust calendar feed to only show events matching these risk levels.
                                        </p>
                                        <div className="space-y-3 bg-slate-50/50 dark:bg-slate-900/30 p-3 rounded-2xl border border-slate-205/60 dark:border-slate-800">
                                            <ToggleRow 
                                                label="High Impact Risk" 
                                                checked={calendarFilters.high} 
                                                onChange={(v) => setCalendarFilters(prev => ({ ...prev, high: v }))} 
                                            />
                                            <ToggleRow 
                                                label="Medium Impact Risk" 
                                                checked={calendarFilters.medium} 
                                                onChange={(v) => setCalendarFilters(prev => ({ ...prev, medium: v }))} 
                                            />
                                            <ToggleRow 
                                                label="Low Impact Risk" 
                                                checked={calendarFilters.low} 
                                                onChange={(v) => setCalendarFilters(prev => ({ ...prev, low: v }))} 
                                            />
                                        </div>
                                    </div>
                                </motion.div>
                            )}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            <div>
                <button 
                    onClick={() => setIsCreatePostModalOpen(!isCreatePostModalOpen)}
                    className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-full bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] text-[#393939] dark:text-[#E2E8F0] font-extrabold text-[11px] uppercase tracking-wider transition-all border-2 border-white dark:border-[#1A1A1A] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),_0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),_0_0_0_2px_#2B2B2F] hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.15),_0_0_0_2px_#D4D4D4] dark:hover:shadow-[0_6px_10px_-4px_rgba(0,0,0,0.5),_0_0_0_2px_#444] active:scale-95 select-none"
                >
                    <Plus size={14} />
                    New Post
                </button>
            </div>
        </div>
    );

    // Blending state check helper (100% Real Database states)
    const followerCountText = followers.count.toLocaleString();
    const followersAvatarsList = followers.avatars;
    
    // Placeholder names to exclude from suggestions
    const PLACEHOLDER_NAMES = ['new trader', 'guest trader', 'demo trader', 'trader', 'guest'];
    // Include all suggestions from the database except the current user and placeholders
    const finalSuggestions = suggestions.filter(
        sug => sug.id !== user?.id &&
        sug.full_name &&
        sug.full_name.trim().length > 0 &&
        !PLACEHOLDER_NAMES.includes(sug.full_name.trim().toLowerCase())
    );
    
    // Filter streak users (100% Real Database states)
    const finalStreaks = winningStreaks.filter(
        u => u.full_name && 
        u.streak_days !== null && 
        u.streak_days > 0
    );

    // Filter disciplined users (100% Real Database states)
    const finalDisciplined = topDisciplined.filter(
        u => u.full_name && 
        u.win_rate !== null && 
        u.win_rate > 0
    );

    return (
        <>
            <DashboardLayout breadcrumbs={[{ label: "Home", path: "/home" }]} headerActions={headerActions} noScroll={true} noPadding={true}>
            <div className="w-full h-full flex flex-col min-h-0 px-4 lg:px-10 pt-0 pb-0 select-none font-sans text-slate-800 dark:text-slate-100">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-full min-h-0 relative">
                    
                    {/* --- COLUMN 1: LEFT SIDEBAR (col-span-3) --- */}
                    {(showWatchlist || showCalendar || showFollowers) && (
                        <div className="lg:col-span-3 lg:col-start-1 h-full overflow-y-auto amazing-scrollbar space-y-6 px-4 pt-5 pb-4">
                        
                        {/* A. My Watchlist / Market Segment */}
                        {showWatchlist && (
                            <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                                <h3 className="text-[16px] font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2 mb-5">
                                    <TrendingUp size={16} className="text-blue-500 shrink-0" />
                                    <span>My Watchlist</span>
                                </h3>
                                
                                <div className="space-y-4">
                                    {watchlist.length === 0 ? (
                                        <div className="flex flex-col items-center justify-center text-center p-6 bg-[#060B14]/40 border border-dashed border-[#1D2433] rounded-2xl select-none font-sans my-1">
                                            <TrendingUp size={22} className="text-blue-500 mb-2" />
                                            <p className="text-[12px] font-bold text-slate-900 dark:text-white leading-tight">Your watchlist is empty</p>
                                            <p className="text-[10px] font-medium text-slate-400 dark:text-slate-500 mt-1 leading-normal max-w-[180px]">Add your favorite forex or crypto assets to track them live!</p>
                                            <button onClick={() => navigate("/discover")} className="mt-3 px-3 py-1.5 rounded-lg bg-blue-500 hover:bg-blue-600 active:scale-95 text-white font-bold text-[10px] uppercase tracking-wider transition-all cursor-pointer">Explore Markets</button>
                                        </div>
                                    ) : (
                                         watchlist.map((asset: any, i) => {
                                             const isPositive = asset.is_positive !== undefined ? asset.is_positive : (asset.symbol_type === "crypto" || asset.is_pinned);
                                             const displaySymbol = asset.symbol;
                                             const displayName = asset.symbol_type === "forex" ? "Forex Spot" : "Crypto Spot";
                                             const price = asset.price || (asset.symbol_type === "forex" ? "1.0850" : "65,400.00");
                                             const change = asset.change || (asset.symbol_type === "forex" ? "-0.15%" : "+2.10%");

                                            return (
                                                <div key={i} className="flex items-center justify-between group hover:translate-x-0.5 transition-transform duration-200">
                                                    <div className="flex items-center gap-2.5">
                                                        <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-[#1A1E29] flex items-center justify-center border border-slate-200/50 dark:border-slate-800 shadow-3xs font-bold text-[10px] text-slate-655 dark:text-slate-350">
                                                            {displaySymbol.split('/')[0]}
                                                        </div>
                                                        <div>
                                                            <p className="text-[13px] font-semibold text-slate-900 dark:text-white leading-tight tracking-tight">{displaySymbol}</p>
                                                            <p className="text-[10px] font-medium text-slate-455 dark:text-slate-505 leading-none mt-0.5">{displayName}</p>
                                                        </div>
                                                    </div>
                                                    
                                                    <div className="text-right">
                                                        <p className="text-[13px] font-semibold text-slate-900 dark:text-white leading-tight">{price}</p>
                                                        <span className={`inline-block text-[9.5px] font-bold px-1.5 py-0.5 rounded mt-0.5 leading-none ${
                                                            isPositive 
                                                                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-455" 
                                                                : "bg-rose-500/10 text-rose-600 dark:text-rose-400"
                                                        }`}>
                                                            {change}
                                                        </span>
                                                    </div>
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                            </div>
                        )}

                        {/* B. Economic Calendar News */}
                        {showCalendar && (
                            <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                                <h3 className="text-[16px] font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2 mb-5">
                                    <Globe size={16} className="text-slate-400 dark:text-slate-550 shrink-0" />
                                    <span>Economic Calendar</span>
                                </h3>
                                <div className="space-y-4">
                                    {(() => {
                                        const filteredCalendar = calendar.filter(news => {
                                            const impact = (news.impact || 'low').toLowerCase();
                                            if (impact === 'high' && !calendarFilters.high) return false;
                                            if (impact === 'medium' && !calendarFilters.medium) return false;
                                            if (impact === 'low' && !calendarFilters.low) return false;
                                            return true;
                                        });

                                        if (filteredCalendar.length === 0) {
                                            return (
                                                <div className="flex flex-col items-center justify-center text-center p-6 bg-slate-50/50 dark:bg-slate-900/30 border border-dashed border-slate-200/50 dark:border-slate-800 rounded-2xl select-none font-sans my-1">
                                                    <Calendar size={22} className="text-slate-455 mb-2" />
                                                    <p className="text-[12px] font-bold text-slate-900 dark:text-white leading-tight">Economic schedule quiet</p>
                                                    <p className="text-[10px] font-medium text-slate-400 dark:text-slate-500 mt-1 leading-normal max-w-[180px]">No major events scheduled matching your active risk filters.</p>
                                                </div>
                                            );
                                        }

                                        return filteredCalendar.map((news, i) => {
                                            const dateObj = new Date(news.event_time);
                                            const displayTime = dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
                                            const displayImpact = news.impact?.toUpperCase() || "LOW";

                                            return (
                                                <div key={i} className="flex gap-3 items-center group">
                                                    <div className="shrink-0 px-2 py-1.5 min-w-[54px] text-center bg-slate-150/40 dark:bg-[#1A1F2B] border border-slate-200/50 dark:border-slate-800 rounded-xl flex flex-col justify-center items-center shadow-3xs">
                                                        <span className="text-[9px] font-bold text-slate-850 dark:text-slate-250 leading-none tracking-tight">{displayTime}</span>
                                                        <span className="text-[7.5px] font-bold text-slate-455 uppercase mt-1 tracking-wider">{news.currency || "USD"}</span>
                                                    </div>
                                                    
                                                    <div className="flex-1 min-w-0">
                                                        <div className="flex items-center justify-between gap-1.5">
                                                            <h4 className="text-[13px] font-semibold text-slate-900 dark:text-white truncate leading-snug">
                                                                {news.event_title}
                                                            </h4>
                                                            <span className={`shrink-0 text-[7.5px] font-bold px-1.5 py-0.5 rounded leading-none ${
                                                                displayImpact === "HIGH" 
                                                                    ? "bg-rose-500/15 text-rose-650 dark:text-rose-400 border border-rose-500/10" 
                                                                    : displayImpact === "MEDIUM"
                                                                        ? "bg-amber-500/10 text-amber-600 dark:text-amber-450 border border-amber-500/10"
                                                                        : "bg-blue-500/10 text-blue-600 dark:text-blue-450 border border-blue-500/10"
                                                            }`}>
                                                                {displayImpact}
                                                            </span>
                                                        </div>
                                                        
                                                        <div className="flex gap-3 mt-1.5 text-[10px] font-semibold text-slate-455 dark:text-slate-500 leading-none">
                                                            <span>Forecast: <strong className="text-slate-655 dark:text-slate-400 font-bold">{news.forecast || "--"}</strong></span>
                                                            <span>Previous: <strong className="text-slate-655 dark:text-slate-400 font-bold">{news.previous || "--"}</strong></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        });
                                    })()}
                                </div>
                            </div>
                        )}

                        {/* C. Followers Stats Box */}
                        {showFollowers && (
                            <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                                
                                <div className="flex items-center mb-5 pl-3">
                                    {followersAvatarsList.map((url, i) => (
                                        <img 
                                            key={i} 
                                            src={url} 
                                            className="w-8 h-8 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-slate-200 shadow-sm" 
                                            style={{ 
                                                zIndex: followersAvatarsList.length - i, 
                                                marginLeft: '-12px' 
                                            }} 
                                        />
                                    ))}
                                </div>
                                <h4 className="text-[28px] font-bold text-slate-900 dark:text-white tracking-tight mb-1">
                                    {followerCountText} <span className="text-[13px] font-bold text-slate-455 uppercase tracking-widest ml-1">Followers</span>
                                </h4>
                                <p className="text-[12px] font-medium text-slate-505 leading-none">Active now on your profile</p>
                            </div>
                        )}

                    </div>
                    )}

                    {/* --- COLUMN 2: MIDDLE MAIN CONTENT --- */}
                    <div className="lg:col-span-6 lg:col-start-4 h-full overflow-y-auto amazing-scrollbar space-y-8 px-4 pt-5 pb-6">
                        
                        {/* Stories Section */}
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <h2 className="text-[22px] font-bold text-slate-900 dark:text-white tracking-tight">Stories</h2>
                            </div>
                            <div className="flex items-center gap-5 overflow-x-auto pb-4 scrollbar-hide select-none">
                                <button 
                                    onClick={() => setIsCreateStoryOpen(true)}
                                    className="shrink-0 flex flex-col items-center gap-2 group"
                                >
                                    <div className="relative w-[68px] h-[68px] rounded-full border-2 border-dashed border-slate-300 dark:border-[#444] flex items-center justify-center text-slate-455 group-hover:border-blue-500 group-hover:text-blue-500 group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 transition-colors shadow-sm overflow-hidden">
                                        {user?.user_metadata?.avatar_url ? (
                                            <>
                                                <img src={user.user_metadata.avatar_url} className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" />
                                                <Plus size={24} className="absolute text-white drop-shadow-md z-10" />
                                            </>
                                        ) : (
                                            <Plus size={24} />
                                        )}
                                    </div>
                                    <span className="text-[12px] font-bold text-slate-700 dark:text-slate-300 mt-1">Add story</span>
                                </button>
                                
                                {storyGroups.map((group, index) => (
                                    <button 
                                        key={group.userId} 
                                        onClick={() => setStoryViewerGroupIndex(index)}
                                        className="shrink-0 flex flex-col items-center gap-2 group"
                                    >
                                        <div className="flex items-center justify-center w-[68px] h-[68px] rounded-full p-[2px] bg-gradient-to-tr from-blue-600 to-cyan-400 group-hover:scale-[1.03] transition-transform shadow-md">
                                            <div className="flex items-center justify-center w-full h-full rounded-full border-[2.5px] border-white dark:border-[#121214] overflow-hidden bg-white dark:bg-[#121214]">
                                                <img src={group.user.avatar} className="w-full h-full object-cover" />
                                            </div>
                                        </div>
                                        <span className="text-[12px] font-bold text-slate-700 dark:text-slate-300 mt-1 max-w-[70px] truncate">{group.user.name.split(' ')[0]}</span>
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Feeds Section */}
                        <div className="space-y-6">
                            <div className="flex items-center justify-between">
                                <h2 className="text-[22px] font-bold text-slate-900 dark:text-white tracking-tight">Feeds</h2>
                                <div className="flex items-center bg-slate-50 dark:bg-[#141414] rounded-full p-1 border border-slate-200 dark:border-[#333]">
                                    <button 
                                        onClick={() => setFeedSort('popular')}
                                        className={`px-5 py-1.5 text-[12px] font-bold rounded-[10px] transition-all ${
                                            feedSort === 'popular' 
                                            ? 'bg-blue-600 text-white shadow-sm' 
                                            : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                                        }`}
                                    >
                                        Popular
                                    </button>
                                    <button 
                                        onClick={() => setFeedSort('latest')}
                                        className={`px-5 py-1.5 text-[12px] font-bold rounded-[10px] transition-all ${
                                            feedSort === 'latest' 
                                            ? 'bg-blue-600 text-white shadow-sm' 
                                            : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                                        }`}
                                    >
                                        Latest
                                    </button>
                                </div>
                            </div>

                            {/* Feed List */}
                            <div className="space-y-8">
                                {feeds.length === 0 ? (
                                    <div className="p-8 rounded-[22px] text-center border-2 border-dashed border-slate-200 dark:border-slate-800 text-slate-400 dark:text-slate-600 font-bold text-[14px]">
                                        No social feeds available. Make a new post to get started!
                                    </div>
                                ) : (
                                    [...feeds].sort((a, b) => {
                                        if (feedSort === 'popular') {
                                            const likesA = a.like_count || a.likes_count || 0;
                                            const likesB = b.like_count || b.likes_count || 0;
                                            if (likesA === likesB) {
                                                const timeA = new Date(a.created_at || 0).getTime();
                                                const timeB = new Date(b.created_at || 0).getTime();
                                                return timeB - timeA;
                                            }
                                            return likesB - likesA;
                                        } else {
                                            const timeA = new Date(a.created_at || 0).getTime();
                                            const timeB = new Date(b.created_at || 0).getTime();
                                            return timeB - timeA;
                                        }
                                    }).map(feed => (
                                        <FeedCard 
                                            key={feed.id} 
                                            feed={feed} 
                                            currentUserId={user?.id ?? ""}
                                            followedUsers={followedUsers}
                                            onToggleFollow={toggleFollowUser}
                                            isLiked={likedPosts[feed.id] || false}
                                            likes={Math.max(0, (feed.like_count ?? feed.likes_count ?? 0) + (likesOffsets[feed.id] || 0))}
                                            onLike={() => handleLikePost(feed.id)}
                                            onEdit={(p) => setEditPost(p)}
                                            onDelete={handleDeletePost}
                                            onVote={handleVote}
                                            
                                        />
                                    ))
                                )}
                            </div>
                        </div>

                    </div>

                    {/* --- COLUMN 3: RIGHT SIDEBAR (col-span-3) --- */}
                    {(showRequests || showSuggestions || showStreaks || showDisciplined) && (
                        <div className="lg:col-span-3 lg:col-start-10 h-full overflow-y-auto amazing-scrollbar space-y-6 px-4 pt-5 pb-4">
                        
                        {/* Requests Section */}
                        {showRequests && (
                            <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                                <h3 className="text-[16px] font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2 mb-5">
                                    <span>Requests</span> 
                                </h3>
                                <div className="space-y-5">
                                    <p className="text-[11px] font-medium text-slate-400 text-center py-2">No pending requests</p>
                                </div>
                            </div>
                        )}

                        {/* Suggestions Section */}
                        {showSuggestions && (
                            <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                                <h3 className="text-[16px] font-bold text-slate-900 dark:text-white tracking-tight mb-5">Suggestions for you</h3>
                                <div className="space-y-4">
                                    {finalSuggestions.length === 0 ? (
                                        <p className="text-[11px] font-medium text-slate-400 text-center py-2">No suggestions available</p>
                                    ) : (
                                        finalSuggestions.map((sug: any) => {
                                            const displayName = sug.display_name || sug.full_name || sug.username || "Trader";
                                            const displaySlug = sug.username || sug.id;
                                            const displayAvatar = sug.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${displayName}`;
                                            const displayLocation = sug.location || "Tradifive Member";

                                            return (
                                                <div key={sug.id} className="flex items-center justify-between group">
                                                    <div className="flex items-center gap-3">
                                                        <Link to={`/user/${displaySlug}`} className="shrink-0 hover:opacity-85 transition-opacity">
                                                            <img src={displayAvatar} alt={displayName} className="w-10 h-10 rounded-full bg-slate-200 object-cover border border-slate-100 dark:border-[#33]" />
                                                        </Link>
                                                        <div>
                                                            <Link to={`/user/${displaySlug}`} className="text-[13px] font-bold text-slate-900 dark:text-white mb-0.5 leading-none hover:text-blue-500 transition-colors block">
                                                                {displayName}
                                                            </Link>
                                                            <p className="text-[11px] font-medium text-slate-455 dark:text-slate-500 leading-none mt-0.5">{displayLocation}</p>
                                                        </div>
                                                    </div>
                                                    <button 
                                                        onClick={() => toggleFollowUser(sug.id, displayName)}
                                                        className={`p-2 rounded-full transition-colors ${
                                                            followedUsers[sug.id]
                                                                ? "text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-500/10"
                                                                : "text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-500/10"
                                                        }`}
                                                    >
                                                        {followedUsers[sug.id] ? <UserCheck size={16} /> : <UserPlus size={16} />}
                                                    </button>
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                                {finalSuggestions.length > 0 && (
                                    <button className="w-full text-center text-[12px] font-bold text-blue-600 pt-3 hover:underline">View All</button>
                                )}
                            </div>
                        )}

                        {/* Top Winning Streaks Section */}
                        {showStreaks && (
                            <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                                <h3 className="text-[16px] font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2 mb-5">
                                    <Flame size={16} className="text-orange-500 animate-pulse shrink-0" />
                                    <span>Top Winning Streaks</span>
                                </h3>
                                <div className="space-y-4">
                                    {finalStreaks.length === 0 ? (
                                        <p className="text-[11px] font-medium text-slate-400 text-center py-2">No active streaks</p>
                                    ) : (
                                        finalStreaks.map((streak: any) => {
                                            const displayName = streak.full_name || streak.name || "Streak Pro";
                                            const displaySlug = streak.username || streak.name?.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || "user";
                                            const displayAvatar = streak.avatar_url || streak.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${displayName}`;
                                            const displayStreak = streak.streak_days ? `${streak.streak_days} days` : streak.streak;
                                            const displayGain = streak.win_rate ? `+${streak.win_rate}% WR` : streak.gain;

                                            return (
                                                <div key={streak.id} className="flex items-center justify-between group">
                                                    <div className="flex items-center gap-3">
                                                        <Link to={`/user/${displaySlug}`} className="shrink-0 hover:opacity-85 transition-opacity">
                                                            <img src={displayAvatar} alt={displayName} className="w-10 h-10 rounded-full bg-slate-200 object-cover border border-slate-100 dark:border-[#33]" />
                                                        </Link>
                                                        <div>
                                                            <Link to={`/user/${displaySlug}`} className="text-[13px] font-bold text-slate-900 dark:text-white mb-0.5 leading-none hover:text-blue-500 transition-colors block">
                                                                {displayName}
                                                            </Link>
                                                            <div className="flex items-center gap-1.5 mt-1 leading-none">
                                                                <span className="bg-orange-500/10 text-orange-600 dark:text-orange-400 px-1.5 py-0.5 rounded text-[9.5px] font-bold uppercase tracking-wider flex items-center gap-0.5 leading-none">
                                                                    🔥 {displayStreak}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="text-right">
                                                        <span className="text-[13px] font-bold text-emerald-600 dark:text-emerald-455">{displayGain}</span>
                                                    </div>
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                            </div>
                        )}
                        {/* Top Disciplined Section */}
                        {showDisciplined && (
                            <div className="p-5 rounded-[22px] border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F]">
                                <h3 className="text-[16px] font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2 mb-5">
                                    <ShieldCheck size={16} className="text-emerald-500 shrink-0" />
                                    <span>Top Disciplined</span>
                                </h3>
                                <div className="space-y-4">
                                    {finalDisciplined.length === 0 ? (
                                        <p className="text-[11px] font-medium text-slate-400 text-center py-2">No disciplined records</p>
                                    ) : (
                                        finalDisciplined.map((disc: any) => {
                                            const displayName = disc.full_name || disc.name || "Disciplined Trader";
                                            const displaySlug = disc.username || disc.name?.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || "user";
                                            const displayAvatar = disc.avatar_url || disc.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${displayName}`;
                                            const displayScore = disc.win_rate ? `${disc.win_rate}% Win Rate` : `${disc.score} Score`;
                                            const displayDescription = disc.total_trades !== undefined ? `${disc.total_trades} total trades` : disc.description;

                                            return (
                                                <div key={disc.id} className="flex items-center justify-between group">
                                                    <div className="flex items-center gap-3">
                                                        <Link to={`/user/${displaySlug}`} className="shrink-0 hover:opacity-85 transition-opacity">
                                                            <img src={displayAvatar} alt={displayName} className="w-10 h-10 rounded-full bg-slate-200 object-cover border border-slate-100 dark:border-[#33]" />
                                                        </Link>
                                                        <div>
                                                            <Link to={`/user/${displaySlug}`} className="text-[13px] font-bold text-slate-900 dark:text-white mb-0.5 leading-none hover:text-blue-500 transition-colors block">
                                                                {displayName}
                                                            </Link>
                                                            <p className="text-[11px] font-medium text-slate-455 leading-none mt-1">{displayDescription}</p>
                                                        </div>
                                                    </div>
                                                    <div className="text-right flex flex-col items-end">
                                                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-455 border border-emerald-500/20 leading-none">
                                                            {displayScore}
                                                        </span>
                                                    </div>
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Footer Links */}
                        <div className="flex flex-wrap gap-x-4 gap-y-2 pt-2 pl-3">
                            {["About", "Accessibility", "Help", "Privacy", "Terms", "Advertising", "Business Services"].map(link => (
                                <a key={link} href="#" className="text-[11px] font-bold text-slate-455 hover:text-slate-655 dark:hover:text-slate-350 transition-colors">
                                    {link}
                                </a>
                            ))}
                        </div>

                    </div>
                    )}

                </div>
            </div>
            
            <style dangerouslySetInnerHTML={{__html: `
                .scrollbar-hide::-webkit-scrollbar { display: none; }
                .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
                
                .amazing-scrollbar::-webkit-scrollbar {
                  width: 4px;
                  height: 4px;
                }
                .amazing-scrollbar::-webkit-scrollbar-button {
                  display: none !important;
                  width: 0 !important;
                  height: 0 !important;
                }
                .amazing-scrollbar::-webkit-scrollbar-track {
                  background: transparent !important;
                }
                .amazing-scrollbar::-webkit-scrollbar-thumb {
                  background: transparent !important;
                  border-radius: 9999px;
                  transition: background 0.15s ease-in-out;
                }
                .amazing-scrollbar:hover::-webkit-scrollbar-thumb {
                  background: rgba(148, 163, 184, 0.2) !important;
                }
                .amazing-scrollbar::-webkit-scrollbar-thumb:hover {
                  background: rgba(148, 163, 184, 0.35) !important;
                }
                .dark .amazing-scrollbar:hover::-webkit-scrollbar-thumb {
                  background: rgba(255, 255, 255, 0.05) !important;
                }
                .dark .amazing-scrollbar::-webkit-scrollbar-thumb:hover {
                  background: rgba(255, 255, 255, 0.12) !important;
                }
            `}} />
            <CreatePostModal 
                isOpen={isCreatePostModalOpen || editPost !== null} 
                onClose={() => {
                    setIsCreatePostModalOpen(false);
                    setEditPost(null);
                }}
                userId={user?.id || "mock-user-id"}
                onSuccess={refetch}
                mode={editPost ? "edit" : "create"}
                postId={editPost?.id}
                initialContent={editPost?.content}
                initialTags={editPost?.tags || []}
                initialMediaUrl={editPost?.media_url}
                initialMediaType={editPost?.media_type as any}
            />

            <CreateStoryModal
                isOpen={isCreateStoryOpen}
                onClose={() => setIsCreateStoryOpen(false)}
                userId={user?.id || "mock-user-id"}
                onSuccess={refetch}
            />

            <StoryViewer
                isOpen={storyViewerGroupIndex !== null}
                onClose={() => setStoryViewerGroupIndex(null)}
                storyGroups={storyGroups}
                initialGroupIndex={storyViewerGroupIndex ?? 0}
            />
        </DashboardLayout>
        </>
    );
}
