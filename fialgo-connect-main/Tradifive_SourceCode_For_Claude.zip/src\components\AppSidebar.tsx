import { 
  LayoutDashboard, Settings, ShieldAlert, BookOpen, Bell, Sparkles, Trophy, HelpCircle, 
  Search, PanelLeftClose, PanelLeftOpen, Lock, ChevronDown, ChevronRight, Inbox, Moon, Palette, ChevronsUpDown, Home, Clock, User, LogOut, CreditCard, MessageSquare, UserCheck,
  Plus, Users, LayoutGrid, Shield, Gift, Compass, BookText, Brain, ShieldCheck, Target, Award, Mail, Crown
} from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import fialgoLogo from "@/assets/tradifive-logo.png";
import logoOnly from "@/assets/logo-only.png";
import React, { useState, useEffect } from "react";
import { 
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";
import { applyThemeWithTransition } from "@/utils/themeTransition";

const MOTIVATIONAL_MESSAGES = [
  "Patience pays off.",
  "Guard your capital.",
  "Master your mind.",
  "Trust the process.",
  "Discipline equals freedom.",
  "Plan your trade.",
  "Trade your plan.",
  "Consistency is key.",
  "Control your risk.",
  "Patience is power.",
  "Focus and execute.",
  "Learn and grow.",
  "Stay highly disciplined.",
  "Master your emotions."
];

// Dynamic communicationMenu will be defined inside AppSidebar component
const mainMenu = [
  { path: "/home", icon: Home, label: "Home" },
  { path: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/discover", icon: Compass, label: "Discover" },
  { path: "/journal", icon: BookText, label: "Journal" },
  { path: "/ai-coach", icon: Sparkles, label: "AI Coach" },
  { path: "/risk-guard", icon: ShieldCheck, label: "Risk Guard" },
  { path: "/channel", icon: Users, label: "Channel / Community" },
];

const engagementMenu = [
  { path: "/competitions/dashboard", icon: Target, label: "Competitions" },
  { path: "/competitions/rewards", icon: Award, label: "Rewards" },
];

interface AppSidebarProps {
  isCollapsed?: boolean;
  toggleCollapse?: () => void;
}

// Sunglasses Avatar component for header
const SunglassesAvatar = () => (
  <div className="w-8 h-8 rounded-full bg-[#121214] flex items-center justify-center overflow-hidden shrink-0 border border-white/10 shadow-[0_2px_8px_rgba(0,0,0,0.15)] select-none pointer-events-none">
    <svg viewBox="0 0 100 100" fill="none" className="w-6 h-6">
      {/* Hair outline & volume */}
      <path d="M26 40C26 28 35 20 50 20C65 20 74 28 74 40C74 43 72 46 70 48L72 58C72 60 70 62 67 62C65 62 64 61 63 60L60 52C58 53 54 54 50 54C46 54 42 53 40 52L37 60C36 61 35 62 33 62C30 62 28 60 28 58L30 48C28 46 26 43 26 40Z" fill="#121214" stroke="#ffffff" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
      {/* Sunglasses */}
      <path d="M33 41C33 39 35 37 37 37H47C49 37 51 39 51 41V45C51 47 49 49 47 49H37C35 49 33 47 33 45V41Z" fill="#ffffff" />
      <path d="M49 41C49 39 51 37 53 37H63C65 37 67 39 67 41V45C67 47 65 49 63 49H53C51 49 49 47 49 45V41Z" fill="#ffffff" />
      <path d="M47 42H53" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" />
      {/* Cheeks & Chin / Neck */}
      <path d="M38 52V56C38 63 43 68 50 68C57 68 62 63 62 56V52" stroke="#ffffff" strokeWidth="4.5" strokeLinecap="round" />
      {/* Mouth */}
      <path d="M46 60H54" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" />
    </svg>
  </div>
);

import { getGamificationState } from "@/utils/gamification";

const getCleanedFirstName = (name: any): string => {
  if (!name) return "Trader";
  let str = String(name).trim();
  if (
    !str ||
    str.toLowerCase() === "null" ||
    str.toLowerCase() === "undefined" ||
    str.toLowerCase() === "null null" ||
    str.toLowerCase() === "guest" ||
    str.toLowerCase() === "guest trader" ||
    str.toLowerCase() === "guest_trader"
  ) {
    return "Trader";
  }
  const parts = str.split(/\s+/).filter(p => p && p.toLowerCase() !== "null" && p.toLowerCase() !== "undefined");
  if (parts.length === 0) return "Trader";
  return parts[0];
};

const getCleanedFullName = (name: any): string => {
  if (!name) return "Trader";
  let str = String(name).trim();
  if (
    !str ||
    str.toLowerCase() === "null" ||
    str.toLowerCase() === "undefined" ||
    str.toLowerCase() === "null null" ||
    str.toLowerCase() === "guest" ||
    str.toLowerCase() === "guest trader" ||
    str.toLowerCase() === "guest_trader"
  ) {
    return "Trader";
  }
  const parts = str.split(/\s+/).filter(p => p && p.toLowerCase() !== "null" && p.toLowerCase() !== "undefined");
  if (parts.length === 0) return "Trader";
  return parts.join(" ");
};

export default function AppSidebar({ isCollapsed = false, toggleCollapse }: AppSidebarProps) {
  const [isMounted, setIsMounted] = useState(false);
  useEffect(() => {
    setIsMounted(true);
  }, []);
  const [showAppearanceMenu, setShowAppearanceMenu] = useState(false);
  const [navSearchQuery, setNavSearchQuery] = useState("");

  const navigate = useNavigate();

  const [theme, setThemeState] = useState(() => (typeof document !== "undefined" && document.documentElement.classList.contains("dark")) ? "dark" : "light");
  const [displayName, setDisplayName] = useState(() => localStorage.getItem("tradifive_cached_display_name") || "Trader");
  const [username, setUsername] = useState(() => localStorage.getItem("tradifive_cached_username") || "trader");
  const [mt5Acc, setMt5Acc] = useState(() => localStorage.getItem("tradifive_cached_mt5_acc") || "");
  const [gamState, setGamState] = useState(() => getGamificationState());
  const [avatarUrl, setAvatarUrl] = useState(() => localStorage.getItem("tradifive_cached_avatar_url") || "");
  const [bannerUrl, setBannerUrl] = useState(() => localStorage.getItem("tradifive_cached_banner_url") || "");
  const [unreadDMs, setUnreadDMs] = useState(0);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [userStatus, setUserStatus] = useState(() => localStorage.getItem("tradifive_user_status") || "Online");
  const [userPlan, setUserPlan] = useState(() => (localStorage.getItem("tradifive_cached_plan") || "beginner").toLowerCase());
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const [isSwitchOpen, setIsSwitchOpen] = useState(false);
  const [isHoveredProfile, setIsHoveredProfile] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState("");
  const [displayedQuote, setDisplayedQuote] = useState("");

  useEffect(() => {
    if (isLoggingOut && selectedQuote) {
      setDisplayedQuote("");
      let currentIndex = 0;
      // Dynamically calculate speed so it finishes in exactly 1.4 seconds (1400ms)
      const charDelay = Math.max(1400 / selectedQuote.length, 30);
      const interval = setInterval(() => {
        currentIndex++;
        setDisplayedQuote(selectedQuote.substring(0, currentIndex));
        if (currentIndex >= selectedQuote.length) {
          clearInterval(interval);
        }
      }, charDelay);
      return () => clearInterval(interval);
    } else {
      setDisplayedQuote("");
    }
  }, [isLoggingOut, selectedQuote]);

  const fetchUnreadDMs = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('dm_conversations')
        .select('user1_id, user2_id, user1_unread_count, user2_unread_count')
        .or(`user1_id.eq.${userId},user2_id.eq.${userId}`);
      
      if (error) {
        console.error("Error fetching unread DMs count:", error);
        return;
      }
      
      if (data) {
        const sum = data.reduce((acc, row) => {
          const count = row.user1_id === userId ? (row.user1_unread_count ?? 0) : (row.user2_unread_count ?? 0);
          return acc + count;
        }, 0);
        setUnreadDMs(sum);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchUnreadNotifications = async (userId: string) => {
    try {
      const { count, error } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('is_read', false);
      
      if (error) {
        console.error("Error fetching unread notifications count:", error);
        return;
      }
      
      setUnreadNotifications(count ?? 0);
    } catch (e) {
      console.error(e);
    }
  };

  const loadUserData = async () => {
     const isBypass = sessionStorage.getItem("fialgo_bypass") === "true";
     if (isBypass) {
        setDisplayName("Demo Trader");
        setUsername("demo");
        setMt5Acc("MT5 #0000000");
        setAvatarUrl("");
        return;
     }

     try {
       const { data: { user } } = await supabase.auth.getUser();
       if (user) {
          setCurrentUserId(user.id);
          // Fetch profile from database (source of truth)
          const { data: profile } = await supabase
             .from('profiles')
             .select('first_name, last_name, display_name, username, avatar_url, banner_url, plan_type, subscription_status')
             .eq('id', user.id)
             .maybeSingle();

          const defaultUsername = user.email?.split('@')[0]?.toLowerCase().replace(/[^a-z0-9]/g, '') || "trader";
          let resolvedName = "";
          let resolvedAvatar = "";
          let resolvedUsername = defaultUsername;
          if (profile) {
             resolvedUsername = profile.username || defaultUsername;
             // Use database profile directly — no localStorage mock overrides
             if (profile.display_name && profile.display_name !== "Guest Trader" && profile.display_name !== "null") {
                resolvedName = profile.display_name;
             } else {
                const fName = profile.first_name || "";
                const lName = profile.last_name || "";
                const composed = `${fName} ${lName}`.trim();
                if (composed && composed !== "null null" && composed !== "null") {
                   resolvedName = composed;
                }
             }
             resolvedAvatar = profile.avatar_url || "";
             const p = (profile.plan_type || profile.subscription_status || "beginner").toLowerCase();
             setUserPlan(p);
             localStorage.setItem("tradifive_cached_plan", p);
          } else {
             // No profile exists yet — use auth metadata
             const meta = user.user_metadata || {};
             resolvedName = meta.full_name || meta.name || "";
             resolvedAvatar = meta.avatar_url || meta.picture || "";
          }
          const finalDisplayName = resolvedName || user.email?.split('@')[0] || "Trader";
          setDisplayName(finalDisplayName);
          setUsername(resolvedUsername);
          
          const finalAvatar = resolvedAvatar || "";
          setAvatarUrl(finalAvatar);
          if (profile?.banner_url) {
             setBannerUrl(profile.banner_url);
             localStorage.setItem("tradifive_cached_banner_url", profile.banner_url);
          }
          
          localStorage.setItem("tradifive_cached_display_name", finalDisplayName);
          localStorage.setItem("tradifive_cached_username", resolvedUsername);
          localStorage.setItem("tradifive_cached_avatar_url", finalAvatar);
          
          // Fetch MT5 Account
          const { data: mt5 } = await supabase
             .from('mt5_accounts')
             .select('account_number')
             .eq('user_id', user.id)
             .order('created_at', { ascending: false })
             .limit(1);
          if (mt5 && mt5.length > 0) {
             const resolvedMt5 = `MT5 #${mt5[0].account_number}`;
             setMt5Acc(resolvedMt5);
             localStorage.setItem("tradifive_cached_mt5_acc", resolvedMt5);
          }
       }
     } catch (e) {
       console.error("Error loading user profile details inside sidebar:", e);
     }
  };

  useEffect(() => {
     loadUserData();
  }, []);

  useEffect(() => {
    if (!currentUserId) return;

    fetchUnreadDMs(currentUserId);
    fetchUnreadNotifications(currentUserId);

    const dmChannel = supabase.channel('sidebar-unread-dms')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'dm_conversations',
      }, () => {
        fetchUnreadDMs(currentUserId);
      })
      .subscribe();

    const notificationsChannel = supabase.channel('sidebar-unread-notifications')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${currentUserId}`
      }, () => {
        fetchUnreadNotifications(currentUserId);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(dmChannel);
      supabase.removeChannel(notificationsChannel);
    };
  }, [currentUserId]);

  useEffect(() => {
    const handleXPUpdate = () => {
      setGamState(getGamificationState());
      loadUserData();
    };
    const handleProfileUpdate = () => {
      loadUserData();
    };

    // Watch class mutations on HTML element for theme changes
    const observer = new MutationObserver(() => {
      const isDark = document.documentElement.classList.contains("dark");
      setThemeState(isDark ? "dark" : "light");
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"]
    });

    const syncTheme = () => {
      const isDark = document.documentElement.classList.contains("dark");
      setThemeState(isDark ? "dark" : "light");
    };

    window.addEventListener("tradifive_xp_update", handleXPUpdate);
    window.addEventListener("tradifive_profile_update", handleProfileUpdate);
    window.addEventListener("storage", syncTheme);
    return () => {
      observer.disconnect();
      window.removeEventListener("tradifive_xp_update", handleXPUpdate);
      window.removeEventListener("tradifive_profile_update", handleProfileUpdate);
      window.removeEventListener("storage", syncTheme);
    };
  }, []);

  const toggleTheme = (e: React.MouseEvent) => {
     e.preventDefault();
     const newTheme = theme === "light" ? "dark" : "light";
     applyThemeWithTransition(newTheme, () => {
        setThemeState(newTheme);
     });
  };

  const handleLogout = async () => {
    const randomIndex = Math.floor(Math.random() * MOTIVATIONAL_MESSAGES.length);
    setSelectedQuote(MOTIVATIONAL_MESSAGES[randomIndex]);
    setIsLoggingOut(true);
    await new Promise((resolve) => setTimeout(resolve, 2000));
    localStorage.removeItem("tradifive_cached_display_name");
    localStorage.removeItem("tradifive_cached_username");
    localStorage.removeItem("tradifive_cached_avatar_url");
    localStorage.removeItem("tradifive_cached_mt5_acc");
    await supabase.auth.signOut();
    setIsLoggingOut(false);
    navigate("/login");
  };

  const communicationMenu = [
    { path: "/inbox", icon: Inbox, label: "Inbox", badge: unreadDMs > 0 ? String(unreadDMs) : undefined },
    { path: "/notifications", icon: Bell, label: "Notifications", badge: unreadNotifications > 0 ? (unreadNotifications > 15 ? "15+" : String(unreadNotifications)) : undefined },
  ];

  const renderMenuItem = (item: any) => {
    const active = location.pathname.startsWith(item.path) || (location.pathname === '/' && item.path === '/dashboard');
    
    return (
      <button
        key={item.label}
        onClick={() => !item.isLocked && item.path !== "#" && navigate(item.path)}
        className={`relative flex items-center justify-between transition-all duration-300 group ${
          isCollapsed ? "rounded-xl py-3 px-0 justify-center mx-2 w-auto" : "rounded-xl px-4 py-3 mx-2 w-auto"
        } ${
          item.isLocked ? "opacity-60 cursor-not-allowed" : "cursor-pointer"
        } ${
          active
            ? "bg-white shadow-[0_4px_20px_rgba(0,0,0,0.03)] dark:bg-transparent dark:shadow-none dark:dark-premium-nav-btn text-slate-900 dark:text-white font-semibold"
            : "text-slate-500 dark:text-neutral-400 font-medium hover:text-slate-900 hover:bg-zinc-200/40 dark:hover:bg-white/5 dark:hover:text-white"
        }`}
        title={isCollapsed ? item.label : undefined}
      >
        <div className={`flex items-center gap-3 ${isCollapsed ? "justify-center w-full" : ""}`}>
          <item.icon size={18} strokeWidth={active ? 2 : 1.75} className={active ? "text-slate-900 dark:text-white" : "text-slate-400 dark:text-neutral-500 group-hover:text-slate-600 dark:group-hover:text-white"} />
          {!isCollapsed && <span className="text-[14px] font-medium">{item.label}</span>}
        </div>
        
        {!isCollapsed && item.isLocked && (
          <div className="flex items-center gap-1.5">
            <Lock size={12} className="text-slate-300" />
            <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 bg-[#EEF2F6] px-2 py-0.5 rounded-full">Soon</span>
          </div>
        )}

        {!isCollapsed && item.badge && (
          <span className="text-[11px] font-extrabold text-rose-500 min-w-[20px] text-right select-none drop-shadow-md">
            {item.badge}
          </span>
        )}

        {!isCollapsed && item.hasDropdown && (
          <ChevronDown size={14} className="text-slate-400 group-hover:text-slate-600" />
        )}

        {active && theme !== "dark" && (
          <div className={`absolute right-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-blue-600 rounded-l-full shadow-[0_0_10px_rgba(37,99,235,0.4)] ${isCollapsed ? 'hidden' : 'block'}`} />
        )}
      </button>
    );
  };

  return (
    <>
      <aside 
        className={`dark-sidebar fixed left-0 top-0 z-40 flex h-screen flex-col bg-transparent dark:bg-[#1E1E1E] backdrop-blur-md dark:backdrop-filter-none border-r-0 dark:border-r dark:border-white/5 ${
        isMounted ? "transition-[width] duration-300" : ""
      } ${isCollapsed ? "w-[80px]" : "w-[280px]"}`}
    >
      
      {/* Header */}
      <div className={`flex h-[90px] items-center shrink-0 ${isCollapsed || theme !== 'dark' ? 'justify-center' : 'justify-between px-6'}`}>
        {!isCollapsed ? (
          <>
            <div className="flex items-center justify-center overflow-hidden">
              {theme === 'dark' ? (
                <div className="flex items-center">
                  <img src={logoOnly} alt="TradiFive Icon" className="h-[50px] object-contain shrink-0" />
                  <img src="/Dark mode logo with white.png" alt="TradiFive Text" className="h-[30px] object-contain shrink-0 -ml-1" />
                </div>
              ) : (
                <img src={fialgoLogo} alt="TradiFive" className="h-[50px] object-contain shrink-0" />
              )}
            </div>
            {toggleCollapse && theme === 'dark' && (
              <button 
                onClick={toggleCollapse} 
                className="p-1.5 rounded-lg border border-slate-200/50 dark:border-white/5 bg-transparent hover:bg-zinc-100 dark:hover:bg-white/5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                title="Collapse Sidebar"
              >
                <PanelLeftClose size={15} />
              </button>
            )}
          </>
        ) : (
          toggleCollapse && theme === 'dark' && (
            <button 
              onClick={toggleCollapse} 
              className="p-1.5 rounded-lg border border-slate-200/50 dark:border-white/5 bg-transparent hover:bg-zinc-100 dark:hover:bg-white/5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              title="Expand Sidebar"
            >
              <PanelLeftOpen size={15} />
            </button>
          )
        )}
      </div>

      {/* Search Bar */}
      <div className={isCollapsed ? "mx-2 border-t border-slate-200 dark:border-white/5" : "mx-6 border-t border-slate-200 dark:border-white/5"} />
      <div className={`py-2 ${isCollapsed ? "px-2" : "px-4"}`}>
        <div className={`flex items-center text-[13.5px] text-slate-500 rounded-xl bg-slate-100/50 dark:bg-[#1C1C1E] dark:border dark:border-white/5 focus-within:bg-slate-100 dark:focus-within:bg-[#1E1E20] focus-within:ring-1 focus-within:ring-slate-300 dark:focus-within:ring-slate-800 transition-all ${
          isCollapsed ? "justify-center p-3 w-full mx-auto cursor-pointer" : "w-full px-4 py-2"
        }`}>
          <Search size={16} strokeWidth={1.5} className="shrink-0 text-slate-400" />
          {!isCollapsed && (
            <>
              <input 
                type="text" 
                value={navSearchQuery}
                onChange={(e) => setNavSearchQuery(e.target.value)}
                placeholder={theme === "dark" ? "Search..." : "Quick search..."} 
                className="w-full bg-transparent border-none outline-none text-slate-900 dark:text-white placeholder:text-slate-500 ml-3 text-[13.5px]"
              />
              <div className="hidden dark:flex items-center gap-0.5 border border-white/10 rounded px-1.5 py-0.5 bg-white/5 text-[9px] text-slate-400 font-mono select-none">
                <span>⌘</span>
                <span>F</span>
              </div>
            </>
          )}
        </div>
      </div>

      <div className={`flex-1 overflow-y-auto scrollbar-hide flex flex-col pb-4 ${isCollapsed ? "px-2" : "px-2"}`}>
        
        {/* COMMUNICATION SECTION */}
        <div className={isCollapsed ? "mx-2 border-t border-slate-200 dark:border-white/5" : "mx-6 border-t border-slate-200 dark:border-white/5"} />
        <div className="pb-3 pt-3">
          {!isCollapsed && (
            <h3 className={theme === "dark" ? "text-neutral-600 text-[9px] font-bold uppercase tracking-[0.2em] px-6 mb-3 font-sans" : "text-[12px] font-medium text-slate-500 px-6 mb-2"}>Communication</h3>
          )}
          <div className="flex flex-col gap-1">
            {communicationMenu.filter(m => m.label.toLowerCase().includes(navSearchQuery.toLowerCase())).map(renderMenuItem)}
          </div>
        </div>

        {/* MAIN NAVIGATION */}
        <div className={isCollapsed ? "mx-2 mb-3 border-t border-slate-200 dark:border-white/5" : "mx-6 mb-3 border-t border-slate-200 dark:border-white/5"} />
        <div className="pb-3">
          {!isCollapsed && (
            <h3 className={theme === "dark" ? "text-neutral-600 text-[9px] font-bold uppercase tracking-[0.2em] px-6 mb-3 font-sans" : "text-[12px] font-medium text-slate-500 px-6 mb-2"}>Main Navigation</h3>
          )}
          <div className="flex flex-col gap-1">
            {mainMenu.filter(m => m.label.toLowerCase().includes(navSearchQuery.toLowerCase())).map(renderMenuItem)}
          </div>
        </div>

        {/* ENGAGEMENT SECTION */}
        <div className={isCollapsed ? "mx-2 mb-3 border-t border-slate-200 dark:border-white/5" : "mx-6 mb-3 border-t border-slate-200 dark:border-white/5"} />
        <div className="pb-3">
          {!isCollapsed && (
            <h3 className={theme === "dark" ? "text-neutral-600 text-[9px] font-bold uppercase tracking-[0.2em] px-6 mb-3 font-sans" : "text-[12px] font-medium text-slate-500 px-6 mb-2"}>Engagement</h3>
          )}
          <div className="flex flex-col gap-1">
            {engagementMenu.filter(m => m.label.toLowerCase().includes(navSearchQuery.toLowerCase())).map(renderMenuItem)}
          </div>
        </div>


        {/* END OF SECTIONS */}
      </div>

      {/* UPGRADE CARDS */}
      {!isCollapsed && userPlan !== "advanced" && userPlan !== "elite" && (
        <div className="px-4 mb-4 mt-1 font-sans">
          <div className="relative overflow-hidden bg-gradient-to-br from-white to-slate-50 dark:from-[#1E1E1E] dark:to-[#151515] rounded-[18px] p-5 py-6 border border-slate-200 dark:border-[#333333] shadow-[0_4px_20px_rgba(0,0,0,0.04)] dark:shadow-lg group">
            {/* Sparkles at corners */}
            <div className={`absolute top-3 right-3 opacity-60 animate-pulse ${(userPlan === "intermediate" || userPlan === "pro") ? "text-yellow-500 dark:text-yellow-400" : "text-violet-400 dark:text-violet-400"}`}>
              <Sparkles size={16} />
            </div>
            
            
            {/* Glow effect */}
            <div className={`absolute -bottom-4 -right-4 w-28 h-28 blur-2xl rounded-full ${(userPlan === "intermediate" || userPlan === "pro") ? "bg-purple-500/10 dark:bg-purple-500/10" : "bg-violet-500/15 dark:bg-violet-500/15"}`} />
            <div className={`absolute -top-4 -left-4 w-24 h-24 blur-2xl rounded-full ${(userPlan === "intermediate" || userPlan === "pro") ? "bg-yellow-500/10 dark:bg-yellow-500/10" : "bg-indigo-500/10 dark:bg-indigo-500/10"}`} />

            <div className="relative z-10 flex flex-col items-center text-center">
              <h4 className="text-slate-800 dark:text-white font-bold text-[16px] tracking-wide mb-1.5 flex items-center justify-center gap-1.5">
                {(userPlan === "intermediate" || userPlan === "pro") ? (
                   <>
                     <Crown size={16} className="text-yellow-500 dark:text-yellow-400 drop-shadow-sm" />
                     TradiFive <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-500 to-amber-500 dark:from-yellow-300 dark:to-yellow-600">Elite</span>
                   </>
                ) : (
                   <>
                     <Award size={16} className="text-violet-500 dark:text-violet-400 drop-shadow-sm" />
                     TradiFive <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-500 to-indigo-500 dark:from-violet-400 dark:to-indigo-400">Pro</span>
                   </>
                )}
              </h4>
              <p className="text-slate-500 dark:text-slate-400 text-[12px] leading-relaxed mb-4 px-1">
                {(userPlan === "intermediate" || userPlan === "pro") 
                  ? "Unlock unlimited AI features, premium metrics & full API copy trading."
                  : "Unlock powerful AI coaching, premium metrics & basic copy trading."}
              </p>
              
              <button 
                onClick={() => navigate("/settings?tab=plan")}
                className={`${(userPlan === "intermediate" || userPlan === "pro") ? "elite-upgrade-btn shadow-amber-500/20" : "pro-upgrade-btn shadow-purple-500/20"} shadow-md active:scale-[0.98] py-2.5 px-5`}
              >
                <span className="fold"></span>
                <div className="points_wrapper">
                  <i className="point"></i><i className="point"></i><i className="point"></i><i className="point"></i><i className="point"></i>
                  <i className="point"></i><i className="point"></i><i className="point"></i><i className="point"></i><i className="point"></i>
                </div>
                <span className="inner text-[14px]">
                  <Sparkles className="icon" size={15} />
                  {(userPlan === "intermediate" || userPlan === "pro") ? "Upgrade to Elite" : "Upgrade to Pro"}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      <div className={isCollapsed ? "mx-2 mb-2 border-t border-slate-200 dark:border-white/5" : "mx-6 mb-2 border-t border-slate-200 dark:border-white/5"} />
      {/* Footer Profile */}
      <div className={`shrink-0 pb-4 flex justify-center ${isCollapsed ? "px-2" : "px-4 w-full"}`}>
         <DropdownMenu>
            <DropdownMenuTrigger asChild>
               <div 
                  onMouseEnter={() => !isCollapsed && setIsHoveredProfile(true)}
                  onMouseLeave={() => !isCollapsed && setIsHoveredProfile(false)}
                  className={`relative cursor-pointer select-none outline-none transition-all duration-200 ${
                     isCollapsed 
                        ? "mx-auto" 
                        : "flex items-center gap-3 w-full p-2 rounded-xl hover:bg-zinc-200/50 dark:hover:bg-zinc-800/50 border border-transparent hover:border-zinc-200/30 dark:hover:border-zinc-700/30"
                  }`}
               >
                  {isCollapsed ? (
                     <>
                        <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center overflow-hidden border border-slate-300/40 hover:brightness-105 transition-all">
                           {avatarUrl ? (
                              <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                           ) : (
                              <span className="text-[14px] font-black text-slate-555 dark:text-slate-400">
                                 {getCleanedFirstName(displayName).charAt(0).toUpperCase()}
                              </span>
                           )}
                        </div>
                        {/* Dynamic Status bubble overlapping bottom profile card avatar */}
                        <div className="absolute -bottom-0.5 -right-0.5 w-[14px] h-[14px] rounded-full bg-white dark:bg-[#0e121f] flex items-center justify-center p-[2px] z-10">
                           {userStatus === "Online" && <div className="w-full h-full rounded-full bg-green-500" />}
                           {userStatus === "Idle" && (
                              <div className="w-full h-full rounded-full bg-amber-500 relative overflow-hidden">
                                 <div className="absolute -top-0.5 -left-0.5 w-1.5 h-1.5 rounded-full bg-white dark:bg-[#0e121f]" />
                              </div>
                           )}
                           {userStatus === "Do Not Disturb" && (
                              <div className="w-full h-full rounded-full bg-red-500 flex items-center justify-center">
                                 <div className="w-1.5 h-[2px] bg-white rounded-full" />
                              </div>
                           )}
                           {userStatus === "Invisible" && (
                              <div className="w-full h-full rounded-full bg-slate-400 dark:bg-slate-500 flex items-center justify-center">
                                 <div className="w-1.5 h-1.5 rounded-full bg-white dark:bg-[#0e121f]" />
                              </div>
                           )}
                        </div>
                     </>
                  ) : (
                     <>
                        {/* Avatar on the left */}
                        <div className="relative shrink-0">
                           <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center overflow-hidden border border-slate-300/40">
                              {avatarUrl ? (
                                 <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                              ) : (
                                 <span className="text-[14px] font-black text-slate-555 dark:text-slate-400">
                                    {getCleanedFirstName(displayName).charAt(0).toUpperCase()}
                                 </span>
                              )}
                           </div>
                           {/* Dynamic Status bubble */}
                           <div className="absolute -bottom-0.5 -right-0.5 w-[14px] h-[14px] rounded-full bg-white dark:bg-[#0e121f] flex items-center justify-center p-[2px] z-10">
                              {userStatus === "Online" && <div className="w-full h-full rounded-full bg-green-500" />}
                              {userStatus === "Idle" && (
                                 <div className="w-full h-full rounded-full bg-amber-500 relative overflow-hidden">
                                    <div className="absolute -top-0.5 -left-0.5 w-1.5 h-1.5 rounded-full bg-white dark:bg-[#0e121f]" />
                                 </div>
                              )}
                              {userStatus === "Do Not Disturb" && (
                                 <div className="w-full h-full rounded-full bg-red-500 flex items-center justify-center">
                                    <div className="w-1.5 h-[2px] bg-white rounded-full" />
                                 </div>
                              )}
                              {userStatus === "Invisible" && (
                                 <div className="w-full h-full rounded-full bg-slate-400 dark:bg-slate-500 flex items-center justify-center">
                                    <div className="w-1.5 h-1.5 rounded-full bg-white dark:bg-[#0e121f]" />
                                 </div>
                              )}
                           </div>
                        </div>

                        {/* Text in the middle */}
                        <div className="flex-1 min-w-0 flex flex-col items-start text-left">
                           <span className="text-[14px] font-bold text-slate-800 dark:text-slate-200 truncate w-full leading-tight font-sans">
                              {getCleanedFullName(displayName)}
                           </span>
                           <div className="relative h-[16px] w-full overflow-hidden mt-0.5 select-none">
                              <span className={`absolute inset-0 text-[12px] text-slate-450 dark:text-slate-400 font-semibold truncate transition-all duration-300 ease-out transform font-sans ${
                                 isHoveredProfile ? "opacity-0 -translate-y-2.5 pointer-events-none" : "opacity-100 translate-y-0"
                              }`}>
                                 {userStatus}
                              </span>
                              <span className={`absolute inset-0 text-[12px] text-slate-450 dark:text-slate-400 font-semibold truncate transition-all duration-300 ease-out transform font-sans ${
                                 isHoveredProfile ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2.5 pointer-events-none"
                              }`}>
                                 @{username}
                              </span>
                           </div>
                        </div>

                        {/* Double Chevron on the right */}
                        <ChevronsUpDown size={16} className="text-slate-455 dark:text-slate-500 shrink-0 mr-1" />
                     </>
                  )}
               </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" side="top" sideOffset={12} className="w-[325px] rounded-[18px] p-0 bg-white dark:bg-[#1E1E1E] border border-slate-200/80 dark:border-white/5 shadow-[0_12px_40px_rgba(0,0,0,0.06),0_1px_4px_rgba(0,0,0,0.02)] overflow-visible font-sans relative">
                {/* Cover Banner (Discord style) */}
                {bannerUrl ? (
                   <div className="h-[100px] w-full relative rounded-t-[18px] overflow-hidden">
                      <img src={bannerUrl} alt="Cover Banner" className="w-full h-full object-cover" />
                   </div>
                ) : (
                   <div className="h-[100px] bg-gradient-to-r from-blue-500 to-indigo-600 dark:from-indigo-600 dark:to-purple-600 w-full relative rounded-t-[18px]" />
                )}
                
                {/* Avatar Overlay & Details */}
                <div className="px-4 pb-3 relative">
                    {/* Avatar circle overlapping banner - exactly half-up the cover pic! */}
                    <div className="absolute -top-[42px] left-3 z-10">
                       <div className="w-[84px] h-[84px] rounded-full bg-white dark:bg-[#1E1E1E] p-1.5 relative select-none">
                          <div className="w-full h-full rounded-full overflow-hidden bg-slate-200 dark:bg-slate-800 flex items-center justify-center relative border border-slate-200/40">
                             {avatarUrl ? (
                                <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                             ) : (
                                <span className="text-[20px] font-black text-slate-555 dark:text-slate-400">
                                   {getCleanedFirstName(displayName).charAt(0).toUpperCase()}
                                </span>
                             )}
                          </div>
                          {/* Dynamic Status bubble matching selected user status */}
                          <div className="absolute bottom-0.5 right-0.5 w-[24px] h-[24px] rounded-full bg-white dark:bg-[#1E1E1E] flex items-center justify-center p-[3px]">
                             {userStatus === "Online" && <div className="w-full h-full rounded-full bg-green-500" />}
                             {userStatus === "Idle" && (
                                <div className="w-full h-full rounded-full bg-amber-500 relative overflow-hidden">
                                   <div className="absolute -top-1 -left-1 w-3.5 h-3.5 rounded-full bg-white dark:bg-[#1E1E1E]" />
                                </div>
                             )}
                             {userStatus === "Do Not Disturb" && (
                                <div className="w-full h-full rounded-full bg-red-500 flex items-center justify-center">
                                   <div className="w-3.5 h-[3px] bg-white rounded-full" />
                                 </div>
                             )}
                             {userStatus === "Invisible" && (
                                <div className="w-full h-full rounded-full bg-slate-400 dark:bg-slate-500 flex items-center justify-center">
                                   <div className="w-2.5 h-2.5 rounded-full bg-white dark:bg-[#1E1E1E]" />
                                </div>
                             )}
                          </div>
                       </div>
                    </div>
                    
                    {/* User Info details - beautifully pushed to the right of the avatar with pt-3 to center vertically alongside the lower half of the avatar */}
                    <div className="pt-3 pl-[92px] flex flex-col min-w-0 font-sans">
                       <span className="font-sans text-[15.5px] font-bold text-slate-800 dark:text-white leading-tight tracking-tight truncate text-left">
                          {getCleanedFullName(displayName)}
                       </span>
                       <span className="font-sans text-[12.5px] text-slate-500 dark:text-slate-400 font-medium leading-none mt-1 text-left">
                          @{username}
                       </span>
                    </div>
                 </div>

                <DropdownMenuSeparator className="mx-4 my-1.5 bg-zinc-100 dark:bg-zinc-800" />
                
                 {/* Menu items (Profile, Online Status, Switch Accounts, Settings) */}
                 <div className="px-2 pb-1.5 pt-0.5 space-y-0.5">
                     {/* Profile */}
                     <DropdownMenuItem 
                        onClick={() => navigate("/profile")} 
                        className="flex items-center justify-between p-2 rounded-xl cursor-pointer transition-all hover:bg-zinc-50 dark:hover:bg-zinc-800/60 focus:bg-zinc-50 dark:focus:bg-zinc-800/60 outline-none group text-slate-700 dark:text-slate-300 font-sans w-full border border-transparent hover:border-zinc-100/50 dark:hover:border-zinc-800/30"
                     >
                        <div className="flex items-center gap-2.5 min-w-0 flex-1">
                           <User size={15} className="text-slate-555 group-hover:text-slate-855 dark:group-hover:text-slate-200 transition-colors shrink-0" />
                           <span className="text-[14px] font-semibold flex-1 text-left truncate font-sans">Profile</span>
                        </div>
                     </DropdownMenuItem>
 
                     {/* Online Status container wrapper with hover states */}
                     <div 
                        onMouseEnter={() => {
                           setIsStatusOpen(true);
                           setIsSwitchOpen(false);
                        }}
                        onMouseLeave={() => {
                           setIsStatusOpen(false);
                        }}
                        className="relative"
                     >
                        <DropdownMenuItem 
                           onSelect={(e) => {
                              e.preventDefault();
                           }}
                           onClick={(e) => {
                              e.stopPropagation();
                              setIsStatusOpen(!isStatusOpen);
                              setIsSwitchOpen(false);
                           }}
                           className="flex items-center justify-between p-2 rounded-xl cursor-pointer transition-all hover:bg-zinc-50 dark:hover:bg-zinc-800/60 focus:bg-zinc-50 dark:focus:bg-zinc-800/60 outline-none group text-slate-700 dark:text-slate-300 font-sans w-full border border-transparent hover:border-zinc-100/50 dark:hover:border-zinc-800/30"
                        >
                           <div className="flex items-center gap-2.5 min-w-0 flex-1">
                              <div className="w-[15px] h-[15px] flex items-center justify-center shrink-0">
                                 {userStatus === "Online" && <div className="w-2.5 h-2.5 rounded-full bg-green-500" />}
                                 {userStatus === "Idle" && (
                                    <div className="w-2.5 h-2.5 rounded-full bg-amber-500 relative overflow-hidden">
                                       <div className="absolute -top-0.5 -left-0.5 w-2 h-2 rounded-full bg-white dark:bg-[#1E1E1E]" />
                                    </div>
                                 )}
                                 {userStatus === "Do Not Disturb" && (
                                    <div className="w-2.5 h-2.5 rounded-full bg-red-500 flex items-center justify-center">
                                       <div className="w-1.5 h-[2px] bg-white rounded-full" />
                                    </div>
                                 )}
                                 {userStatus === "Invisible" && (
                                    <div className="w-2.5 h-2.5 rounded-full bg-slate-400 dark:bg-slate-500 flex items-center justify-center">
                                       <div className="w-1.5 h-1.5 rounded-full bg-white dark:bg-[#1E1E1E]" />
                                    </div>
                                 )}
                              </div>
                              <span className="truncate text-[14px] font-semibold text-left font-sans">Online Status</span>
                           </div>
                           <ChevronRight size={14} className={`text-slate-400 dark:text-slate-505 transition-all duration-200 shrink-0 ${isStatusOpen ? 'translate-x-0.5 text-slate-700 dark:text-slate-300' : ''}`} />
                        </DropdownMenuItem>
 
                        {/* Status Flyout Card (Pops out perfectly aligned vertically next to Online status item!) */}
                        {isStatusOpen && (
                           <div className="absolute left-full top-0 ml-3 w-[260px] bg-white dark:bg-[#1E1E1E] border border-slate-200/80 dark:border-white/5 rounded-[16px] p-2.5 shadow-[0_12px_40px_rgba(0,0,0,0.12),0_1px_4px_rgba(0,0,0,0.02)] z-[100] animate-slideInRight space-y-0.5 select-none text-left font-sans before:absolute before:right-full before:top-0 before:bottom-0 before:w-4 before:bg-transparent">
                              <div 
                                 onClick={(e) => { e.stopPropagation(); setUserStatus("Online"); localStorage.setItem("tradifive_user_status", "Online"); setIsStatusOpen(false); }}
                                 className="flex items-center gap-2.5 p-2 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 rounded-lg cursor-pointer transition-colors"
                              >
                                 <div className="w-2.5 h-2.5 rounded-full bg-green-500 shrink-0" />
                                 <span className="text-[13.5px] font-semibold text-slate-800 dark:text-slate-200 font-sans">Online</span>
                              </div>
                              
                              <div 
                                 onClick={(e) => { e.stopPropagation(); setUserStatus("Idle"); localStorage.setItem("tradifive_user_status", "Idle"); setIsStatusOpen(false); }}
                                 className="flex items-center gap-2.5 p-2 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 rounded-lg cursor-pointer transition-colors"
                              >
                                 <div className="w-2.5 h-2.5 rounded-full bg-amber-500 relative overflow-hidden shrink-0">
                                    <div className="absolute -top-0.5 -left-0.5 w-2 h-2 rounded-full bg-white dark:bg-[#1E1E1E]" />
                                 </div>
                                 <span className="text-[13.5px] font-semibold text-slate-800 dark:text-slate-200 font-sans">Idle</span>
                              </div>
                              
                              <div 
                                 onClick={(e) => { e.stopPropagation(); setUserStatus("Do Not Disturb"); localStorage.setItem("tradifive_user_status", "Do Not Disturb"); setIsStatusOpen(false); }}
                                 className="flex flex-col p-2 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 rounded-lg cursor-pointer transition-colors"
                              >
                                 <div className="flex items-center gap-2.5">
                                    <div className="w-2.5 h-2.5 rounded-full bg-red-500 shrink-0 flex items-center justify-center">
                                       <div className="w-1.5 h-[2px] bg-white rounded-full" />
                                    </div>
                                    <span className="text-[13.5px] font-semibold text-slate-800 dark:text-slate-200 font-sans">Do Not Disturb</span>
                                 </div>
                                 <span className="text-[10px] text-slate-455 dark:text-slate-500 pl-5 mt-0.5 leading-normal font-medium font-sans">You will not receive desktop notifications</span>
                              </div>
                              
                              <div 
                                 onClick={(e) => { e.stopPropagation(); setUserStatus("Invisible"); localStorage.setItem("tradifive_user_status", "Invisible"); setIsStatusOpen(false); }}
                                 className="flex flex-col p-2 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 rounded-lg cursor-pointer transition-colors"
                              >
                                 <div className="flex items-center gap-2.5">
                                    <div className="w-2.5 h-2.5 rounded-full bg-slate-400 dark:bg-slate-500 shrink-0 flex items-center justify-center">
                                       <div className="w-1.5 h-1.5 rounded-full bg-white dark:bg-[#1E1E1E]" />
                                    </div>
                                    <span className="text-[13.5px] font-semibold text-slate-800 dark:text-slate-200 font-sans">Invisible</span>
                                 </div>
                                 <span className="text-[10px] text-slate-455 dark:text-slate-500 pl-5 mt-0.5 leading-normal font-medium font-sans">You will appear offline</span>
                              </div>
                           </div>
                        )}
                     </div>
 
                     {/* Switch Accounts container wrapper with hover states */}
                     <div 
                        onMouseEnter={() => {
                           setIsSwitchOpen(true);
                           setIsStatusOpen(false);
                        }}
                        onMouseLeave={() => {
                           setIsSwitchOpen(false);
                        }}
                        className="relative"
                     >
                        <DropdownMenuItem 
                           onSelect={(e) => {
                              e.preventDefault();
                           }}
                           onClick={(e) => {
                              e.stopPropagation();
                              setIsSwitchOpen(!isSwitchOpen);
                              setIsStatusOpen(false);
                           }}
                           className="flex items-center justify-between p-2 rounded-xl cursor-pointer transition-all hover:bg-zinc-50 dark:hover:bg-zinc-800/60 focus:bg-zinc-50 dark:focus:bg-zinc-800/60 outline-none group text-slate-700 dark:text-slate-300 font-sans w-full border border-transparent hover:border-zinc-100/50 dark:hover:border-zinc-800/30"
                        >
                           <div className="flex items-center gap-2.5 flex-1 min-w-0">
                              <UserCheck size={15} className="text-slate-550 transition-colors shrink-0" />
                              <span className="truncate text-[14px] font-semibold text-left font-sans">Switch Accounts</span>
                           </div>
                           <ChevronRight size={14} className={`text-slate-400 dark:text-slate-550 transition-all duration-200 shrink-0 ${isSwitchOpen ? 'translate-x-0.5 text-slate-700 dark:text-slate-300 font-sans' : ''}`} />
                        </DropdownMenuItem>
 
                        {/* Switch Account Flyout Card (pops out vertically perfectly next to Switch Accounts menu item!) */}
                        {isSwitchOpen && (
                           <div className="absolute left-full top-0 ml-3 w-[310px] bg-white dark:bg-[#1E1E1E] border border-slate-200/80 dark:border-white/5 rounded-[18px] p-3.5 shadow-[0_12px_40px_rgba(0,0,0,0.12),0_1px_4px_rgba(0,0,0,0.02)] z-[100] animate-slideInRight select-none text-left font-sans before:absolute before:right-full before:top-0 before:bottom-0 before:w-4 before:bg-transparent">
                              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2.5 px-0.5 select-none font-sans">
                                 Switch Account
                              </div>
                              
                              {/* Active Profile */}
                              <div className="flex items-center justify-between p-2.5 mb-2.5 bg-zinc-50/20 hover:bg-zinc-50 dark:bg-zinc-800/30 dark:hover:bg-zinc-800/50 border border-zinc-100/50 dark:border-zinc-800/50 rounded-xl cursor-pointer transition-colors group font-sans">
                                 <div className="flex items-center gap-3 min-w-0">
                                    <div className="relative shrink-0">
                                       <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-200 dark:bg-slate-800 flex items-center justify-center border border-slate-300/40 p-0.5">
                                          {avatarUrl ? (
                                             <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover rounded-full" />
                                          ) : (
                                             <span className="text-[11px] font-black text-slate-555 dark:text-slate-400">
                                                {getCleanedFirstName(displayName).charAt(0).toUpperCase()}
                                             </span>
                                          )}
                                       </div>
                                       <div className="absolute -bottom-0.5 -right-0.5 w-[11px] h-[11px] rounded-full bg-white dark:bg-[#1E1E1E] flex items-center justify-center p-[1px] z-10">
                                          <div className="w-full h-full rounded-full bg-green-500" />
                                       </div>
                                    </div>
                                    <div className="flex flex-col min-w-0">
                                       <span className="text-[14px] font-bold text-slate-800 dark:text-slate-200 truncate leading-tight font-sans">{getCleanedFullName(displayName)}</span>
                                       <span className="text-[11.5px] text-slate-400 dark:text-slate-500 font-medium mt-0.5 font-sans">@{username}</span>
                                    </div>
                                 </div>
                                 <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 bg-slate-100/80 dark:bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-200/50 dark:border-slate-700/50 font-mono shadow-sm">
                                    {mt5Acc.replace("MT5 #", "")}
                                 </span>
                              </div>
                              
                              {/* Actions Row */}
                              <div className="flex items-center justify-between pt-1">
                                 <div 
                                    onClick={(e) => { e.stopPropagation(); navigate("/settings"); setIsSwitchOpen(false); }}
                                    className="flex items-center gap-2 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 py-1.5 px-2.5 rounded-lg cursor-pointer transition-colors"
                                 >
                                    <Plus size={14} className="text-slate-450 dark:text-slate-400" />
                                    <span className="text-[13.5px] font-semibold text-slate-600 dark:text-slate-300 font-sans">Create new</span>
                                 </div>
                                 <button 
                                    onClick={(e) => { e.stopPropagation(); navigate("/settings?tab=plan"); setIsSwitchOpen(false); }}
                                    className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold py-1.5 px-3 rounded-lg text-[11.5px] flex items-center gap-1 transition-all shadow-md shadow-indigo-500/10 active:scale-[0.98] font-sans"
                                 >
                                    <Sparkles size={11.5} /> Upgrade
                                 </button>
                              </div>
                           </div>
                        )}
                     </div>
 
                     {/* Settings */}
                     <DropdownMenuItem 
                        onClick={() => navigate("/settings")} 
                        className="flex items-center justify-between p-2 rounded-xl cursor-pointer transition-all hover:bg-zinc-50 dark:hover:bg-zinc-800/60 focus:bg-zinc-50 dark:focus:bg-zinc-800/60 outline-none group text-slate-700 dark:text-slate-300 font-sans w-full border border-transparent hover:border-zinc-100/50 dark:hover:border-zinc-800/30"
                     >
                        <div className="flex items-center gap-2.5 min-w-0 flex-1">
                           <Settings size={15} className="text-slate-550 group-hover:text-slate-850 dark:group-hover:text-slate-200 transition-colors shrink-0" />
                           <span className="text-[14px] font-semibold flex-1 text-left truncate font-sans">Settings</span>
                        </div>
                     </DropdownMenuItem>
                 </div>
                
                <DropdownMenuSeparator className="mx-4 my-1.5 bg-zinc-100 dark:bg-zinc-800" />
                
                {/* Logout button */}
                <div className="px-2 pb-2">
                   <DropdownMenuItem 
                      onClick={handleLogout} 
                      className="flex items-center justify-between p-2 rounded-xl cursor-pointer transition-all hover:bg-red-50 focus:bg-red-50 dark:hover:bg-red-950/20 dark:focus:bg-red-950/20 outline-none text-slate-650 dark:text-slate-400 hover:text-red-650 dark:hover:text-red-400 group w-full"
                   >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                         <LogOut size={15} className="text-slate-550 group-hover:text-red-550 transition-colors shrink-0" />
                         <span className="text-[14px] font-bold flex-1 text-left truncate font-sans">Logout</span>
                      </div>
                   </DropdownMenuItem>
                </div>
             </DropdownMenuContent>
          </DropdownMenu>
       </div>

       <style dangerouslySetInnerHTML={{
         __html: `
         .scrollbar-hide::-webkit-scrollbar {
           display: none;
         }
         .scrollbar-hide {
           -ms-overflow-style: none;
           scrollbar-width: none;
         }
         @keyframes slideInRight {
           from {
             opacity: 0;
             transform: translateX(12px) scale(0.96);
           }
           to {
             opacity: 1;
             transform: translateX(0) scale(1);
           }
         }
         .animate-slideInRight {
           animation: slideInRight 0.24s cubic-bezier(0.16, 1, 0.3, 1) forwards;
         }
         @keyframes fadeIn {
           from {
             opacity: 0;
             transform: translateY(8px);
           }
           to {
             opacity: 1;
             transform: translateY(0);
           }
         }
         .animate-fadeIn {
           animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
         }
       `
       }} />
     </aside>

      {isLoggingOut && (
        <div className="fixed inset-0 z-[99999] bg-[#000000] flex flex-col items-center justify-center select-none font-sans w-screen h-screen">
          <div className="flex flex-col items-center max-w-[420px] px-6 text-center">
            {/* Logo with awesome entry scaling transformation and pulse effect */}
            <div className="mb-6 transform scale-110 animate-[pulse_2.2s_infinite] transition-transform duration-700 ease-out">
              <img src={logoOnly} className="w-12 h-12 object-contain filter drop-shadow-[0_0_12px_rgba(255,255,255,0.15)]" alt="TradiFive Logo" />
            </div>

            {/* Typewritten short message */}
            <p className="text-[20px] text-zinc-100 font-extrabold leading-tight tracking-wide min-h-[28px]">
              "{displayedQuote}"
            </p>

            {/* Faded bottom signature */}
            <p 
              className="text-[11px] text-zinc-500 font-black uppercase tracking-[0.3em] mt-4 opacity-0 animate-fadeIn" 
              style={{ animationDelay: '0.9s' }}
            >
              - TradiFive
            </p>
          </div>
        </div>
      )}
    </>
  );
}
