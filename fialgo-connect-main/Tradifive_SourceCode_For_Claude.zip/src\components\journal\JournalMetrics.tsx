import { useState, useEffect, useRef } from "react";
import { Info, RefreshCw, LayoutGrid, Check, GripVertical, LineChart, Eye, EyeOff, Percent, DollarSign, ChevronDown } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  useSortable,
  arrayMove,
  horizontalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useDashboardData } from "@/hooks/useDashboardData";
import { useTrading } from "@/contexts/TradingContext";
import { Skeleton } from "@/components/ui/skeleton";
import { useJournalSettings, CURRENCIES, CurrencyCode } from "@/contexts/JournalSettingsContext";

// --- Donut/Gauge for Win Rate ---
function WinRateGauge({ winPct, wins, even, losses }: { winPct: number; wins: number; even: number; losses: number }) {
  const r = 32, c = 2 * Math.PI * r;
  const total = wins + even + losses;
  const winArc = total > 0 ? (wins / total) * c : 0;
  const evenArc = total > 0 ? (even / total) * c : 0;
  const lossArc = total > 0 ? c - winArc - evenArc : c;
  return (
    <div className="relative w-[72px] h-[72px] shrink-0">
      <svg viewBox="0 0 80 80" className="w-full h-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="#1e293b" strokeWidth="7" className="dark:stroke-slate-700 stroke-slate-100" />
        <circle cx="40" cy="40" r={r} fill="none" stroke="#10B981" strokeWidth="7" strokeDasharray={`${winArc} ${c - winArc}`} strokeDashoffset="0" strokeLinecap="round" />
        <circle cx="40" cy="40" r={r} fill="none" stroke="#64748b" strokeWidth="7" strokeDasharray={`${evenArc} ${c - evenArc}`} strokeDashoffset={`${-winArc}`} />
        <circle cx="40" cy="40" r={r} fill="none" stroke="#F06363" strokeWidth="7" strokeDasharray={`${lossArc} ${c - lossArc}`} strokeDashoffset={`${-(winArc + evenArc)}`} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-[10px] font-bold" style={{ color: '#10B981' }}>{wins}</span>
        <span className="text-[8px] text-slate-300 font-bold">{even}</span>
        <span className="text-[9px] font-bold" style={{ color: '#F06363' }}>{losses}</span>
      </div>
    </div>
  );
}

// --- Circular Gauge (Profit Factor) ---
function CircularGauge({ value, max = 2 }: { value: number; max?: number }) {
  const r = 32, c = 2 * Math.PI * r;
  const pct = Math.min(value / max, 1);
  const color = value >= 1 ? "#10B981" : "#F06363";
  return (
    <div className="relative w-[60px] h-[60px] shrink-0">
      <svg viewBox="0 0 80 80" className="w-full h-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="#1e293b" strokeWidth="6" className="dark:stroke-slate-700 stroke-slate-100" />
        <circle cx="40" cy="40" r={r} fill="none" stroke={color} strokeWidth="6" strokeDasharray={`${pct * c} ${c - pct * c}`} strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[10px] font-bold" style={{ color }}>{value}</span>
      </div>
    </div>
  );
}

// --- Horizontal bar for avg win/loss ---
function WinLossBar({ avgWin, avgLoss }: { avgWin: number; avgLoss: number }) {
  const { formatMoney, hideBalance, percentageOnly } = useJournalSettings();
  const total = avgWin + Math.abs(avgLoss);
  const winW = total > 0 ? (avgWin / total) * 100 : 50;
  const displayWin = total > 0 ? avgWin : 0;
  const displayLoss = total > 0 ? Math.abs(avgLoss) : 0;
  return (
    <div className="space-y-1.5 w-full max-w-[110px]">
      <div className="flex h-[5px] rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800">
        <div className="rounded-l-full" style={{ width: `${winW}%`, backgroundColor: '#10B981' }} />
        <div className="rounded-r-full" style={{ width: `${100 - winW}%`, backgroundColor: '#F06363' }} />
      </div>
      <div className="flex justify-between text-[9px] font-bold">
        <span className={`transition-all duration-300 ${hideBalance || percentageOnly ? 'blur-[2px] select-none opacity-40' : ''}`} style={{ color: '#10B981' }}>{formatMoney(displayWin, { raw: true })}</span>
        <span className={`transition-all duration-300 ${hideBalance || percentageOnly ? 'blur-[2px] select-none opacity-40' : ''}`} style={{ color: '#F06363' }}>{`-${formatMoney(displayLoss, { raw: true }).replace('-', '')}`}</span>
      </div>
    </div>
  );
}

// --- Streak Pill ---
function StreakPill({ label, value, color, style }: { label: string; value: string; color: string; style?: React.CSSProperties }) {
  return (
    <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${color}`} style={style}>{value} {label}</span>
  );
}

// ── Metric Content Components ────────────────────────────────────────────────
const METRIC_CONTENT: Record<string, React.ReactNode> = {
  pnl: (
    <>
      <div className="flex items-center gap-1.5">
        <p className="text-[13px] font-medium text-slate-500 dark:text-slate-400">Account balance & P&L</p>
        <Info size={13} className="text-slate-400" />
        <span className="bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300 text-[10px] font-bold px-2 py-0.5 rounded-full ml-1">255</span>
      </div>
      <div className="flex items-end justify-between mt-1">
        <div>
          <h3 className="text-[28px] font-bold text-slate-900 dark:text-white tracking-tight leading-none">$0</h3>
          <p className="text-[13px] font-medium text-slate-500 dark:text-slate-400 mt-1">
            P&L: <span className="text-[#F06363]">-$2,001.78</span>
          </p>
        </div>
        <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-500/10 flex items-center justify-center shrink-0">
          <LineChart size={16} className="text-indigo-500" />
        </div>
      </div>
    </>
  ),
  winrate: (
    <>
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Trade Win %</p>
        <Info size={13} className="text-slate-300" />
      </div>
      <div className="flex items-center justify-between">
        <h3 className="text-[26px] font-bold text-slate-900 dark:text-white dark:text-white tracking-tight leading-none">52.96%</h3>
        <WinRateGauge winPct={52.96} wins={134} even={2} losses={119} />
      </div>
    </>
  ),
  streak: (
    <>
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Current Streak</p>
        <Info size={13} className="text-slate-300" />
      </div>
      <div className="space-y-1.5">
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-bold text-slate-400 uppercase w-9">Days</span>
          <span className="w-6 h-6 rounded-lg text-black text-[11px] font-bold flex items-center justify-center" style={{ backgroundColor: '#10B981' }}>2</span>
          <StreakPill label="days" value="2" color="" style={{ backgroundColor: 'rgba(96, 165, 250, 0.1)', color: '#10B981' }} />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-bold text-slate-400 uppercase w-9">Trades</span>
          <span className="w-6 h-6 rounded-lg text-black text-[11px] font-bold flex items-center justify-center" style={{ backgroundColor: '#10B981' }}>1</span>
          <StreakPill label="W" value="36" color="" style={{ backgroundColor: 'rgba(96, 165, 250, 0.1)', color: '#10B981' }} />
          <StreakPill label="L" value="90" color="" style={{ backgroundColor: 'rgba(246, 55, 55, 0.1)', color: '#F06363' }} />
        </div>
      </div>
    </>
  ),
  avgwinloss: (
    <>
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Avg Win/Loss</p>
        <Info size={13} className="text-slate-300" />
      </div>
      <div className="flex items-end justify-between">
        <h3 className="text-[26px] font-bold text-slate-900 dark:text-white dark:text-white tracking-tight leading-none">0.49</h3>
        <WinLossBar avgWin={18.5} avgLoss={37.7} />
      </div>
    </>
  ),
  profitfactor: (
    <>
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Profit Factor</p>
        <Info size={13} className="text-slate-300" />
      </div>
      <div className="flex items-center justify-between">
        <h3 className="text-[26px] font-bold text-slate-900 dark:text-white dark:text-white tracking-tight leading-none">0.55</h3>
        <CircularGauge value={0.55} />
      </div>
    </>
  ),
};

// ── Sortable Wrapper ────────────────────────────────────────────────────────
function SortableMetric({ id, isEditMode, children }: { id: string; isEditMode: boolean; children: React.ReactNode }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id, disabled: !isEditMode });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.3 : 1,
    zIndex: isDragging ? 50 : undefined,
    cursor: isEditMode ? "grab" : "default",
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="relative group h-full"
      {...(isEditMode ? { ...attributes, ...listeners } : {})}
    >
      <div className={`h-[120px] px-5 py-4 rounded-[24px] border-2 border-white dark:border-transparent bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] premium-flat-card shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-none flex flex-col justify-between transition-all duration-300
        ${isEditMode ? "ring-2 ring-[#10B981]/50 ring-offset-2 pointer-events-none" : "hover:scale-[1.02] hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-none"}`}
      >
        {isEditMode && (
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 p-1.5 rounded-xl shadow-xl z-50 border border-slate-100 dark:border-slate-700 animate-bounce-subtle">
            <GripVertical size={14} strokeWidth={3} />
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

export default function JournalMetrics({
  isEditMode = false,
  onEditToggle,
}: {
  isEditMode?: boolean;
  onEditToggle?: () => void;
}) {
  const { todayProfit, totalProfit, winRate, tradesToday, drawdown, recentTrades, lastImportTime, refetch, loading, balance } = useDashboardData();
  const { userSubscription } = useTrading();
  const { formatMoney, hideBalance, setHideBalance, hideOnlyBalance, setHideOnlyBalance, percentageOnly, setPercentageOnly, currency, setCurrency, isSettingsLoading } = useJournalSettings();

  const isPageLoading = loading || isSettingsLoading;
  const [currentUserEmail, setCurrentUserEmail] = useState<string | null>(null);
  const [order, setOrder] = useState(["pnl", "winrate", "streak", "avgwinloss", "profitfactor"]);
  const [currencyOpen, setCurrencyOpen] = useState(false);
  const currencyDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (currencyDropdownRef.current && !currencyDropdownRef.current.contains(e.target as Node)) {
        setCurrencyOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const totalWins = recentTrades ? recentTrades.filter(t => (t.profit || 0) > 0).length : 0;
  const totalLosses = recentTrades ? recentTrades.filter(t => (t.profit || 0) < 0).length : 0;
  const totalEvens = recentTrades ? recentTrades.filter(t => (t.profit || 0) === 0).length : 0;

  const winningTrades = recentTrades ? recentTrades.filter(t => (t.profit || 0) > 0) : [];
  const losingTrades = recentTrades ? recentTrades.filter(t => (t.profit || 0) < 0) : [];

  const avgWin = winningTrades.length > 0
    ? winningTrades.reduce((acc, t) => acc + (t.profit || 0), 0) / winningTrades.length
    : 0;

  const avgLoss = losingTrades.length > 0
    ? Math.abs(losingTrades.reduce((acc, t) => acc + (t.profit || 0), 0) / losingTrades.length)
    : 0;

  const avgWinLossRatio = avgLoss > 0 ? Number((avgWin / avgLoss).toFixed(2)) : 0;

  const grossProfit = winningTrades.reduce((acc, t) => acc + (t.profit || 0), 0);
  const grossLoss = Math.abs(losingTrades.reduce((acc, t) => acc + (t.profit || 0), 0));

  const profitFactor = grossLoss > 0 ? Number((grossProfit / grossLoss).toFixed(2)) : grossProfit > 0 ? Number(grossProfit.toFixed(2)) : 0;

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user?.email) {
        setCurrentUserEmail(session.user.email);
      }
    };
    fetchUser();
  }, []);

  const isSubscriptionNone = userSubscription === "none" && currentUserEmail !== "marketing@fialgo.com" && currentUserEmail !== "nikilharake369@gmail.com";

  const metrics: Record<string, React.ReactNode> = {
    pnl: isPageLoading ? (
      <>
        <div className="flex items-center gap-1.5">
          <p className="text-[13px] font-medium text-slate-500 dark:text-slate-400">Account balance & P&L</p>
          <Info size={13} className="text-slate-400" />
          <span className="bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300 text-[10px] font-bold px-2 py-0.5 rounded-full ml-1">...</span>
        </div>
        <div className="space-y-2 mt-2">
          <Skeleton className="h-7 w-28 bg-slate-200 dark:bg-white/10 animate-pulse" />
          <Skeleton className="h-3.5 w-20 bg-slate-200 dark:bg-white/10 animate-pulse" />
        </div>
      </>
    ) : (
      <>
        <div className="flex items-center gap-1.5">
          <p className="text-[13px] font-medium text-slate-500 dark:text-slate-400">Account balance & P&L</p>
          <Info size={13} className="text-slate-400" />
          <span className="bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300 text-[10px] font-bold px-2 py-0.5 rounded-full ml-1">{recentTrades?.length || 0}</span>
        </div>
        <div className="flex items-end justify-between mt-1">
          <div>
            <h3 className={`text-[28px] font-bold text-slate-900 dark:text-white tracking-tight leading-none transition-all duration-300 ${hideBalance || hideOnlyBalance || percentageOnly ? 'blur-[5px] select-none opacity-40' : ''}`}>
              {formatMoney(balance, { raw: true })}
            </h3>
            <p className="text-[13px] font-medium text-slate-500 dark:text-slate-400 mt-1">
              P&L: <span className={`transition-all duration-300 ${hideBalance ? 'blur-[2px] select-none opacity-40' : ''}`} style={{ color: totalProfit >= 0 ? '#10B981' : '#F06363' }}>
                {percentageOnly ? `${totalProfit >= 0 ? "+" : ""}${((totalProfit / (balance > 0 ? balance : 10000)) * 100).toFixed(2)}%` : formatMoney(totalProfit, { showSign: true, raw: true })}
              </span>
            </p>
          </div>
        </div>
      </>
    ),
    winrate: isPageLoading ? (
      <>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Trade Win %</p>
          <Info size={13} className="text-slate-300" />
        </div>
        <div className="flex items-center justify-between mt-2">
          <Skeleton className="h-7 w-20 bg-slate-200 dark:bg-white/10 animate-pulse" />
          <Skeleton className="h-[50px] w-[50px] rounded-full bg-slate-200 dark:bg-white/10 animate-pulse" />
        </div>
      </>
    ) : (
      <>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Trade Win %</p>
          <Info size={13} className="text-slate-300" />
        </div>
        <div className="flex items-center justify-between">
          <h3 className="text-[26px] font-bold text-slate-900 dark:text-white dark:text-white tracking-tight leading-none">{winRate}%</h3>
          <WinRateGauge winPct={winRate} wins={totalWins} even={totalEvens} losses={totalLosses} />
        </div>
      </>
    ),
    streak: isPageLoading ? (
      <>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Current Streak</p>
          <Info size={13} className="text-slate-300" />
        </div>
        <div className="space-y-3 mt-2">
          <Skeleton className="h-4.5 w-full bg-slate-200 dark:bg-white/10 animate-pulse" />
          <Skeleton className="h-4.5 w-full bg-slate-200 dark:bg-white/10 animate-pulse" />
        </div>
      </>
    ) : (
      <>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Current Streak</p>
          <Info size={13} className="text-slate-300" />
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-bold text-slate-400 uppercase w-[60px] shrink-0">Drawdown</span>
            <span className="w-6 h-6 rounded-lg text-white text-[11px] font-bold flex items-center justify-center" style={{ backgroundColor: '#F06363' }}>{drawdown.toFixed(0)}</span>
            <StreakPill label="risk" value={`${drawdown.toFixed(1)}%`} color="" style={{ backgroundColor: 'rgba(246, 55, 55, 0.1)', color: '#F06363' }} />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-bold text-slate-400 uppercase w-[60px] shrink-0">Trades</span>
            <span className="w-6 h-6 rounded-lg text-black text-[11px] font-bold flex items-center justify-center" style={{ backgroundColor: '#10B981' }}>{recentTrades.length}</span>
            <StreakPill label="W" value={`${totalWins}`} color="" style={{ backgroundColor: 'rgba(96, 165, 250, 0.1)', color: '#10B981' }} />
            <StreakPill label="L" value={`${totalLosses}`} color="" style={{ backgroundColor: 'rgba(246, 55, 55, 0.1)', color: '#F06363' }} />
          </div>
        </div>
      </>
    ),
    avgwinloss: isPageLoading ? (
      <>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Avg Win/Loss</p>
          <Info size={13} className="text-slate-300" />
        </div>
        <div className="flex items-end justify-between mt-2">
          <Skeleton className="h-7 w-16 bg-slate-200 dark:bg-white/10 animate-pulse" />
          <Skeleton className="h-4 w-24 bg-slate-200 dark:bg-white/10 animate-pulse" />
        </div>
      </>
    ) : (
      <>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Avg Win/Loss</p>
          <Info size={13} className="text-slate-300" />
        </div>
        <div className="flex items-end justify-between">
          <h3 className="text-[26px] font-bold text-slate-900 dark:text-white dark:text-white tracking-tight leading-none">
            {avgWinLossRatio > 0 ? avgWinLossRatio.toFixed(2) : "0.00"}
          </h3>
          <WinLossBar avgWin={avgWin} avgLoss={avgLoss} />
        </div>
      </>
    ),
    profitfactor: isPageLoading ? (
      <>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Profit Factor</p>
          <Info size={13} className="text-slate-300" />
        </div>
        <div className="flex items-center justify-between mt-2">
          <Skeleton className="h-7 w-16 bg-slate-200 dark:bg-white/10 animate-pulse" />
          <Skeleton className="h-[50px] w-[50px] rounded-full bg-slate-200 dark:bg-white/10 animate-pulse" />
        </div>
      </>
    ) : (
      <>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Profit Factor</p>
          <Info size={13} className="text-slate-300" />
        </div>
        <div className="flex items-center justify-between">
          <h3 className="text-[26px] font-bold text-slate-900 dark:text-white dark:text-white tracking-tight leading-none">
            {profitFactor > 0 ? profitFactor.toFixed(2) : "0.00"}
          </h3>
          <CircularGauge value={profitFactor > 0 ? profitFactor : 0} />
        </div>
      </>
    ),
  };

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      setOrder((items) => {
        const oldIndex = items.indexOf(active.id as string);
        const newIndex = items.indexOf(over.id as string);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  return (
    <>
      {/* Subscription Inactive Banner */}
      {isSubscriptionNone && (
        <div className="w-full bg-[#FFF1F2] dark:bg-[#F06363]/10 border border-[#F06363]/20 dark:border-[#F06363]/20 rounded-2xl p-5 mb-8 flex items-center gap-4 shadow-sm">
          <span className="text-slate-900 dark:text-white font-black text-sm">$</span>
          <p className="text-[13px] text-slate-700 dark:text-slate-200 font-medium tracking-tight">
            Your subscription is inactive. To continue journaling, <span className="font-bold cursor-pointer hover:underline">activate your subscription now.</span>
          </p>
        </div>
      )}

      {/* Import Bar */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2 text-[13px] text-slate-400 dark:text-slate-500">
          <span className="font-bold text-slate-900 dark:text-white">Last import:</span>
          <span className="font-semibold">{lastImportTime}</span>
          <span className="text-slate-300 dark:text-slate-600">•</span>
          <button
            onClick={async () => {
              toast.promise(
                (async () => {
                  await refetch();
                  setTimeout(() => {
                    window.location.reload();
                  }, 1000);
                })(),
                {
                  loading: 'Synchronizing trades...',
                  success: 'Sync complete! Refreshing page...',
                  error: 'Sync failed'
                }
              );
            }}
            className="text-emerald-500 hover:text-emerald-500 dark:text-emerald-400 dark:hover:text-blue-300 transition-colors font-bold"
          >
            Resync
          </button>
        </div>
        <div className="flex items-center gap-2.5">
          {/* Currency Selector */}
          <div className="relative" ref={currencyDropdownRef}>
            <button
              onClick={() => setCurrencyOpen(v => !v)}
              className={`inline-flex items-center gap-1.5 h-[36px] px-3 rounded-[14px] border-2 text-[11px] font-bold tracking-tight transition-all duration-300 ${
                currencyOpen
                  ? "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#E8E8EC] to-[#F4F4F4] dark:from-[#2A2A2E] dark:to-[#1E1E20] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#44444A] text-slate-900 dark:text-white"
                  : "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#333336] text-slate-700 dark:text-slate-300 hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#44444A]"
              }`}
            >
              <span className="tabular-nums">{currency.code}</span>
              <span className="text-slate-400 dark:text-slate-500 font-medium">{currency.symbol}</span>
              <ChevronDown size={11} className={`transition-transform duration-200 ${currencyOpen ? "rotate-180" : ""}`} />
            </button>
            {currencyOpen && (
              <div className="absolute top-full right-0 mt-2 w-[220px] bg-white dark:bg-[#1C1C1E] border border-slate-100 dark:border-white/10 rounded-2xl shadow-xl shadow-slate-900/10 dark:shadow-black/30 z-50 overflow-hidden py-1.5 animate-in fade-in slide-in-from-top-2 duration-200">
                {CURRENCIES.map(c => (
                  <button
                    key={c.code}
                    onClick={() => { setCurrency(c.code as CurrencyCode); setCurrencyOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-all duration-150 ${
                      currency.code === c.code ? "bg-slate-50 dark:bg-white/5" : "hover:bg-slate-50/60 dark:hover:bg-white/[0.03]"
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <span className="text-[12px] font-bold text-slate-900 dark:text-white">{c.code}</span>
                      <span className="text-[11px] text-slate-400 dark:text-slate-500 ml-2 font-medium">{c.name}</span>
                    </div>
                    <span className="text-[12px] font-bold text-slate-400 dark:text-slate-500 tabular-nums">{c.symbol}</span>
                    {currency.code === c.code && <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] shrink-0" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Hide Balance */}
          <button
            onClick={() => setHideBalance(!hideBalance)}
            className={`inline-flex items-center gap-1.5 h-[36px] px-3 rounded-[14px] border-2 text-[11px] font-bold tracking-tight transition-all duration-300 ${
              hideBalance
                ? "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#FEF3C7] to-[#FFFBEB] dark:from-[#352A18] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#F59E0B40] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#92400E40] text-amber-700 dark:text-amber-400"
                : "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#333336] text-slate-500 dark:text-slate-400 hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#44444A]"
            }`}
          >
            {hideBalance ? <EyeOff size={13} /> : <Eye size={13} />}
            <span>{hideBalance ? "Hidden" : "Hide Balance"}</span>
          </button>

          {/* Hide Only Balance */}
          <button
            onClick={() => setHideOnlyBalance(!hideOnlyBalance)}
            className={`inline-flex items-center gap-1.5 h-[36px] px-3 rounded-[14px] border-2 text-[11px] font-bold tracking-tight transition-all duration-300 ${
              hideOnlyBalance
                ? "border-white dark:border-[#2A2A2E] bg-gradient-to-b from-[#F3F0FF] to-[#FAF8FF] dark:from-[#252530] dark:to-[#1C1C22] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#A78BFA40] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_rgba(139,92,246,0.2)] text-violet-600 dark:text-violet-400"
                : "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#333336] text-slate-500 dark:text-slate-400 hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#44444A]"
            }`}
          >
            {hideOnlyBalance ? <EyeOff size={13} /> : <Eye size={13} />}
            <span>{hideOnlyBalance ? "Hidden Bal" : "Hide Only Balance"}</span>
          </button>

          {/* Show % */}
          <button
            onClick={() => setPercentageOnly(!percentageOnly)}
            className={`inline-flex items-center gap-1.5 h-[36px] px-3 rounded-[14px] border-2 text-[11px] font-bold tracking-tight transition-all duration-300 ${
              percentageOnly
                ? "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#D1FAE5] to-[#ECFDF5] dark:from-[#064E3B] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#10B98140] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#065F4640] text-emerald-600 dark:text-emerald-400"
                : "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#333336] text-slate-500 dark:text-slate-400 hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#44444A]"
            }`}
          >
            <Percent size={13} />
            <span>{percentageOnly ? "Only" : "Show"}</span>
          </button>

          {/* Grid / Edit Layout Button */}
          <button
            onClick={onEditToggle}
            className={`w-[36px] h-[36px] rounded-[14px] border-2 flex items-center justify-center transition-all duration-300 ${
              isEditMode
                ? "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#D1FAE5] to-[#ECFDF5] dark:from-[#064E3B] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#10B98140] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#065F4640] text-emerald-600 dark:text-emerald-400"
                : "border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#333336] text-slate-400 hover:text-slate-600 hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#44444A]"
            }`}
          >
            {isEditMode ? <Check size={16} strokeWidth={3} /> : <LayoutGrid size={16} />}
          </button>
        </div>
      </div>

      {/* 5 Metric Cards — Draggable */}
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={order} strategy={horizontalListSortingStrategy}>
          <div className="grid grid-cols-5 gap-4 h-[120px]">
            {order.map((id) => (
              <SortableMetric key={id} id={id} isEditMode={isEditMode}>
                {metrics[id]}
              </SortableMetric>
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </>
  );
}






