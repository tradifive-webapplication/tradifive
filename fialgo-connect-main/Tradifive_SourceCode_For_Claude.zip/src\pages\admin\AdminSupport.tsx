import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { 
  LifeBuoy, 
  MessageSquare, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  MoreVertical,
  Reply,
  User,
  Hash
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function AdminSupport() {
  const [tickets, setTickets] = useState<any[]>([
    { id: 'TKT-1024', user: 'Arjun S.', email: 'arj@ex.com', subject: 'MT5 Connection Timeout', status: 'open', priority: 'high', date: '2026-04-19' },
    { id: 'TKT-1023', user: 'Rohan G.', email: 'ro@ex.com', subject: 'Refund Request', status: 'in_progress', priority: 'medium', date: '2026-04-18' },
    { id: 'TKT-1022', user: 'Amit P.', email: 'am@ex.com', subject: 'Strategy Configuration Help', status: 'resolved', priority: 'low', date: '2026-04-18' },
    { id: 'TKT-1021', user: 'Suresh R.', email: 'su@ex.com', subject: 'EA Download Link Broken', status: 'open', priority: 'urgent', date: '2026-04-17' },
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-500/10 text-slate-300 border-blue-500/20';
      case 'in_progress': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'resolved': return 'bg-[#D1E4FF] dark:bg-emerald-500/10 text-emerald-400 border-[#D6E4FF] dark:border-emerald-500/20';
      default: return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  const getPriorityColor = (priority: string) => {
      switch (priority) {
        case 'urgent': return 'text-rose-500';
        case 'high': return 'text-amber-500';
        default: return 'text-slate-500';
      }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Support Desk</h1>
          <p className="text-slate-400">Manage user inquiries and technical support tickets.</p>
        </div>
        <div className="flex items-center gap-3">
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <Input placeholder="Search tickets..." className="bg-slate-900 border-slate-800 pl-10 w-[200px]" />
            </div>
            <Button variant="outline" className="border-slate-800 bg-slate-900 text-slate-400">
                <Filter size={16} className="mr-2" />
                Filter
            </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
                <Clock className="text-slate-200" size={18} />
                <span className="text-[10px] font-bold text-slate-500">AVG RESPONSE</span>
            </div>
            <p className="text-2xl font-bold text-white">12m 45s</p>
            <p className="text-xs text-emerald-500 mt-1">-5m from yesterday</p>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
                <AlertCircle className="text-rose-500" size={18} />
                <span className="text-[10px] font-bold text-slate-500">URGENT OPEN</span>
            </div>
            <p className="text-2xl font-bold text-white">4 Tickets</p>
            <p className="text-xs text-rose-500 mt-1">Immediate action required</p>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
                <CheckCircle2 className="text-emerald-500" size={18} />
                <span className="text-[10px] font-bold text-slate-500">RESOLVED TODAY</span>
            </div>
            <p className="text-2xl font-bold text-white">28</p>
            <p className="text-xs text-slate-500 mt-1">Last resolved 4m ago</p>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
                <MessageSquare className="text-purple-500" size={18} />
                <span className="text-[10px] font-bold text-slate-500">NEW MESSAGES</span>
            </div>
            <p className="text-2xl font-bold text-white">12</p>
            <p className="text-xs text-slate-200 mt-1">Click to view feed</p>
        </div>
      </div>

      <div className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left whitespace-nowrap">
            <thead className="text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-slate-950/50 border-b border-slate-800">
              <tr>
                <th className="px-6 py-4">Ticket ID</th>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Subject</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Priority</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {tickets.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/30 transition-all group">
                  <td className="px-6 py-4">
                    <span className="text-xs font-mono font-bold text-slate-300 flex items-center gap-1.5">
                        <Hash size={12} />
                        {t.id}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-slate-400">
                            {t.user.charAt(0)}
                        </div>
                        <div>
                            <p className="text-xs font-bold text-slate-200">{t.user}</p>
                            <p className="text-[10px] text-slate-500">{t.email}</p>
                        </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-slate-300 transition-colors group-hover:text-slate-300">{t.subject}</p>
                    <p className="text-[10px] text-slate-500">{t.date}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${getStatusColor(t.status)}`}>
                        {t.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-bold uppercase tracking-tight ${getPriorityColor(t.priority)}`}>
                        {t.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 px-3 text-slate-300 hover:text-blue-300 hover:bg-blue-500/10 gap-2 border border-transparent hover:border-blue-500/20"
                            onClick={() => toast.info("Reply modal opening...")}
                        >
                            <Reply size={14} />
                            Reply
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500">
                            <MoreVertical size={16} />
                        </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}




