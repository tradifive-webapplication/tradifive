import { useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Mail, ArrowLeft, ArrowRight, RefreshCcw } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { PushableButton } from "@/components/PushableButton";
import { toast } from "sonner";

export default function VerifyEmail() {
  const [code, setCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || "";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error("No email address found. Please try logging in again.");
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: code,
        type: 'signup'
      });

      if (error) {
        toast.error(error.message);
      } else {
        toast.success("Email verified successfully!");
        navigate("/journal");
      }
    } catch (err: any) {
      toast.error("An unexpected error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (!email) return;
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email
      });
      if (error) {
        toast.error(error.message);
      } else {
        toast.success("Verification code resent to your email.");
      }
    } catch (err: any) {
      toast.error("An unexpected error occurred.");
    }
  };

  return (
    <div 
      style={{ fontFamily: "'Inter', sans-serif" }}
      className="flex min-h-screen bg-white dark:bg-[#1A1A1A] items-center justify-center px-6 relative overflow-hidden font-sans"
    >
      <div className="absolute top-0 right-0 w-[50%] h-[50%] bg-slate-50 dark:bg-[#141414] rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2 opacity-30" />

      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-[400px] relative z-10"
      >
        <div className="text-left mb-8 px-2">
          <Link to="/" className="inline-flex items-center text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 hover:text-primary transition-colors mb-8 group">
            <ArrowLeft className="w-3 h-3 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Sign In
          </Link>

          <h1 className="text-4xl font-black tracking-tighter text-slate-900 dark:text-white mb-2">
            Verify <span className="text-primary">Email</span>
          </h1>
          <p className="text-slate-400 font-medium text-sm leading-relaxed max-w-[340px]">
            Check your inbox for the 6-digit code sent to <span className="text-slate-900 dark:text-white font-bold underline decoration-primary decoration-1 underline-offset-4">{email || "your email"}</span>
          </p>
        </div>

        <div className="bg-white dark:bg-[#1A1A1A] border border-slate-100 dark:border-[#333333] rounded-2xl p-8 shadow-[0_15px_40px_rgba(0,0,0,0.02)] text-center relative overflow-hidden">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-[1.5rem] bg-primary/10 mb-8 border border-primary/5 relative z-10 shadow-inner">
            <Mail size={32} className="text-primary animate-pulse" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
            <div className="space-y-3">
              <label className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400 block">Verification code</label>
              <input
                type="text"
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                className="w-full text-center text-4xl tracking-[0.4em] font-black py-5 rounded-2xl border border-slate-100 dark:border-[#333333] bg-slate-50/50 text-slate-900 dark:text-white focus:outline-none focus:ring-4 focus:ring-primary/5 focus:border-primary/20 transition-all placeholder:text-slate-900 selection:bg-primary/20"
                placeholder="000000"
                required
              />
            </div>

            <PushableButton
              type="submit"
              className="w-full"
              disabled={code.length < 6 || isLoading}
            >
              {isLoading ? "Verifying..." : (
                <span className="flex items-center justify-center font-black uppercase tracking-widest text-[11px] py-0.5">
                  Verify Account
                  <ArrowRight className="w-4 h-4 ml-2" />
                </span>
              )}
            </PushableButton>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-50 dark:border-[#222222] dark:border-[#222222] relative z-10">
            <p className="text-[11px] font-black text-slate-400 uppercase tracking-wider">
              No email?{" "}
              <button
                onClick={handleResend}
                type="button"
                className="text-primary hover:text-primary/70 transition-colors inline-flex items-center gap-1.5 group ml-1"
              >
                <RefreshCcw size={12} className="group-hover:rotate-180 transition-transform duration-700" />
                Resend
              </button>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}





