import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Camera, ExternalLink, Check, ChevronDown, CheckCircle2, Circle, ArrowRight } from 'lucide-react';

export default function ProfileTab({ 
   profile, 
   setProfile, 
   privacySettings, 
   setPrivacySettings,
   avatarUploadRef,
   bannerUploadRef
}: any) {
   // Mock state for the UI

   return (
      <div className="flex flex-col xl:flex-row gap-6 pb-24">
         {/* Left Column - Controls */}
         <div className="flex-1 space-y-6">
            {/* Profile Appearance */}
            <div className="bg-white dark:bg-[#151515] rounded-2xl border border-slate-200 dark:border-[#333333] p-6 shadow-sm dark:shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_4px_6px_rgba(0,0,0,0.3)]">
               <div className="flex justify-between items-center mb-6">
                  <div>
                     <h2 className="text-lg font-bold text-slate-900 dark:text-white">Profile Appearance</h2>
                     <p className="text-sm text-slate-500 dark:text-[#949ba4]">Customize how your profile looks to other traders.</p>
                  </div>
                  <button className="hidden sm:flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-[#2B2B2B] hover:bg-slate-200 dark:hover:bg-[#3B3B3B] text-slate-800 dark:text-white text-[13px] font-semibold rounded-lg transition-colors">
                     Preview Profile <ArrowRight size={14} />
                  </button>
               </div>

               {/* Banner & Avatar */}
               <div className="relative mb-16">
                  {/* Banner */}
                  <div className="h-40 rounded-xl overflow-hidden bg-gradient-to-r from-slate-800 to-slate-900 relative group border border-slate-200 dark:border-[#333333]">
                     {profile.bannerUrl ? (
                        <img src={profile.bannerUrl} alt="Banner" className="w-full h-full object-cover" />
                     ) : (
                        <div className="w-full h-full bg-cover bg-center opacity-40" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop')" }}></div>
                     )}
                     <button onClick={() => bannerUploadRef?.current?.click()} className="absolute bottom-4 right-4 flex items-center gap-2 px-3 py-1.5 bg-black/50 hover:bg-black/70 backdrop-blur-md text-white text-[12px] font-semibold rounded-lg transition-colors border border-white/10 z-10">
                        <Camera size={14} /> Change Cover
                     </button>
                  </div>
                  {/* Avatar */}
                  <div className="absolute -bottom-12 left-6">
                     <div className="relative group">
                        <div className="w-24 h-24 rounded-full border-4 border-white dark:border-[#151515] bg-slate-200 dark:bg-[#2B2B2B] overflow-hidden">
                           <img src={profile.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${profile.firstName || 'T'}`} alt="Avatar" className="w-full h-full object-cover" />
                        </div>
                        <button onClick={() => avatarUploadRef?.current?.click()} className="absolute bottom-0 right-0 w-8 h-8 bg-[#3b82f6] hover:bg-blue-600 text-white rounded-full flex items-center justify-center border-2 border-white dark:border-[#151515] transition-colors shadow-md">
                           <Camera size={14} />
                        </button>
                     </div>
                  </div>
               </div>

               {/* Form Fields */}
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="space-y-1.5">
                     <label className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] px-1">Display Name</label>
                     <input type="text" placeholder="nikil harake" value={profile.name || profile.firstName} onChange={e => setProfile({...profile, name: e.target.value})} className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] text-[13px] font-medium text-slate-800 dark:text-white outline-none focus:border-[#3b82f6] transition-all" />
                  </div>
                  <div className="space-y-1.5">
                     <label className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] px-1 flex justify-between">Username <Check size={12} className="text-green-500" /></label>
                     <div className="relative">
                        <input type="text" placeholder="@nikilharake369" value={profile.username || "nikilharake369"} onChange={e => setProfile({...profile, username: e.target.value})} className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] text-[13px] font-medium text-slate-800 dark:text-white outline-none focus:border-[#3b82f6] transition-all" />
                        <span className="absolute -bottom-5 left-1 text-[10px] text-slate-500 dark:text-[#949ba4]">tradifive.com/<span className="text-green-500">{profile.username || "nikilharake369"}</span></span>
                     </div>
                  </div>
               </div>

               <div className="space-y-1.5 mb-6 mt-6">
                  <label className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] px-1 flex justify-between">
                     Bio <span>{(profile.bio?.length || 0)}/120</span>
                  </label>
                  <textarea value={profile.bio || ""} placeholder="No bio yet. Update your profile to tell others about your trading style." onChange={e => setProfile({...profile, bio: e.target.value})} className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] text-[13px] font-medium text-slate-800 dark:text-white outline-none focus:border-[#3b82f6] transition-all resize-none h-20" maxLength={120} />
               </div>

               <div className="space-y-1.5 mb-6">
                  <label className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] px-1">Trading Style Tags</label>
                  <div className="flex flex-wrap gap-2 p-2 rounded-xl bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333]">
                     <div className="px-3 py-1.5 rounded-md bg-blue-500/10 text-[#3b82f6] dark:text-[#60a5fa] text-[12px] font-bold">Swing Trader</div>
                     <div className="px-3 py-1.5 rounded-md bg-green-500/10 text-green-600 dark:text-green-400 text-[12px] font-bold">Price Action</div>
                     <div className="px-3 py-1.5 rounded-md bg-purple-500/10 text-purple-600 dark:text-purple-400 text-[12px] font-bold">Risk Manager</div>
                     <button className="px-3 py-1.5 rounded-md bg-slate-200 dark:bg-[#2B2B2B] hover:bg-slate-300 dark:hover:bg-[#3B3B3B] text-slate-700 dark:text-slate-300 text-[12px] font-bold transition-colors flex items-center gap-1">+ Add Tag</button>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="space-y-1.5">
                     <label className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] px-1">Location</label>
                     <div className="relative">
                        <input type="text" placeholder="Mumbai, Maharashtra" value={profile.city || ""} onChange={e => setProfile({...profile, city: e.target.value})} className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] text-[13px] font-medium text-slate-800 dark:text-white outline-none focus:border-[#3b82f6] transition-all pl-9" />
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="absolute left-3 top-3 text-slate-400"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                     </div>
                  </div>
                  <div className="space-y-1.5">
                     <label className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] px-1">Country</label>
                     <div className="relative">
                        <input type="text" placeholder="India" value={profile.country || ""} onChange={e => setProfile({...profile, country: e.target.value})} className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] text-[13px] font-medium text-slate-800 dark:text-white outline-none focus:border-[#3b82f6] transition-all pl-9" />
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="absolute left-3 top-3 text-slate-400"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                     </div>
                  </div>
                  <div className="space-y-1.5">
                     <label className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] px-1">Website</label>
                     <div className="relative">
                        <input type="text" placeholder="linktr.ee/..." value={profile.website || ""} onChange={e => setProfile({...profile, website: e.target.value})} className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] text-[13px] font-medium text-slate-800 dark:text-white outline-none focus:border-[#3b82f6] transition-all pl-9" />
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="absolute left-3 top-3 text-slate-400"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                        <ExternalLink size={14} className="absolute right-3 top-3 text-slate-400" />
                     </div>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                     <label className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] px-1 flex items-center gap-1">Profile Badges Visibility <Circle size={10} className="fill-slate-500 text-slate-500"/></label>
                     <div className="relative">
                        <select className="w-full appearance-none px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] text-[13px] font-medium text-slate-800 dark:text-white outline-none focus:border-[#3b82f6] transition-all">
                           <option>Everyone</option>
                           <option>Followers Only</option>
                           <option>Only Me</option>
                        </select>
                        <ChevronDown size={14} className="absolute right-4 top-3.5 text-slate-400 pointer-events-none" />
                     </div>
                  </div>
                  <div className="hidden md:block"></div>
               </div>
            </div>

            {/* Account Type */}
            <div className="bg-white dark:bg-[#151515] rounded-2xl border border-slate-200 dark:border-[#333333] p-6 shadow-sm dark:shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_4px_6px_rgba(0,0,0,0.3)]">
               <div className="flex justify-between items-center mb-6">
                  <div>
                     <h2 className="text-lg font-bold text-slate-900 dark:text-white">Account Type</h2>
                     <p className="text-sm text-slate-500 dark:text-[#949ba4]">Choose the mode that best describes you.</p>
                  </div>
                  <button className="px-4 py-2 bg-slate-100 dark:bg-[#2B2B2B] hover:bg-slate-200 dark:hover:bg-[#3B3B3B] text-slate-800 dark:text-white text-[12px] font-bold rounded-lg transition-colors">
                     Compare features
                  </button>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Personal */}
                  <div onClick={() => setPrivacySettings({...privacySettings, account_type: 'personal'})} className={`relative p-4 rounded-xl border-2 cursor-pointer transition-all ${privacySettings?.account_type === 'personal' ? 'border-[#3b82f6] bg-blue-500/5' : 'border-slate-200 dark:border-[#333333] bg-slate-50 dark:bg-[#1C1C1E] hover:border-slate-300 dark:hover:border-white/10'}`}>
                     {privacySettings?.account_type === 'personal' && <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#3b82f6] flex items-center justify-center"><Check size={12} className="text-white" /></div>}
                     <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500">
                           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        </div>
                        <div>
                           <h3 className="text-[14px] font-bold text-slate-900 dark:text-white">Personal</h3>
                           <p className="text-[11px] text-slate-500">For individual traders</p>
                        </div>
                     </div>
                     <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Standard profile</div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Basic analytics</div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Connect with traders</div>
                     </div>
                  </div>
                  
                  {/* Creator */}
                  <div onClick={() => setPrivacySettings({...privacySettings, account_type: 'creator'})} className={`relative p-4 rounded-xl border-2 cursor-pointer transition-all ${privacySettings?.account_type === 'creator' ? 'border-purple-500 bg-purple-500/5' : 'border-slate-200 dark:border-[#333333] bg-slate-50 dark:bg-[#1C1C1E] hover:border-slate-300 dark:hover:border-white/10'}`}>
                     {privacySettings?.account_type === 'creator' && <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-purple-500 flex items-center justify-center"><Check size={12} className="text-white" /></div>}
                     <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-500">
                           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        </div>
                        <div>
                           <div className="flex items-center gap-2">
                              <h3 className="text-[14px] font-bold text-slate-900 dark:text-white">Creator</h3>
                              <span className="text-[8px] px-1.5 py-0.5 bg-purple-500 text-white rounded font-bold uppercase">PRO</span>
                           </div>
                           <p className="text-[11px] text-slate-500">For mentors & influencers</p>
                        </div>
                     </div>
                     <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Advanced analytics</div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Grow your audience</div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Premium content</div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Monetization tools</div>
                     </div>
                  </div>

                  {/* Business */}
                  <div onClick={() => setPrivacySettings({...privacySettings, account_type: 'business'})} className={`relative p-4 rounded-xl border-2 cursor-pointer transition-all ${privacySettings?.account_type === 'business' ? 'border-green-500 bg-green-500/5' : 'border-slate-200 dark:border-[#333333] bg-slate-50 dark:bg-[#1C1C1E] hover:border-slate-300 dark:hover:border-white/10'}`}>
                     {privacySettings?.account_type === 'business' && <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-green-500 flex items-center justify-center"><Check size={12} className="text-white" /></div>}
                     <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center text-green-500">
                           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
                        </div>
                        <div>
                           <div className="flex items-center gap-2">
                              <h3 className="text-[14px] font-bold text-slate-900 dark:text-white">Business</h3>
                              <span className="text-[8px] px-1.5 py-0.5 bg-green-500 text-white rounded font-bold uppercase">PRO</span>
                           </div>
                           <p className="text-[11px] text-slate-500">For teams & organizations</p>
                        </div>
                     </div>
                     <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Team management</div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Multi-user access</div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Verified business badge</div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300"><Check size={14} className="text-green-500" /> Advanced permissions</div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         {/* Right Column - Previews */}
         <div className="w-full xl:w-[350px] shrink-0 space-y-6">
            {/* Live Preview Card */}
            <div className="bg-white dark:bg-[#151515] rounded-2xl border border-slate-200 dark:border-[#333333] overflow-hidden shadow-sm dark:shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_4px_6px_rgba(0,0,0,0.3)]">
               <div className="p-4 text-[11px] text-slate-500 dark:text-[#949ba4] font-medium border-b border-slate-100 dark:border-[#2a2a2a]">
                  This is how others will see your profile.
               </div>
               
               <div className="h-28 bg-gradient-to-r from-slate-800 to-slate-900 relative">
                  {profile.bannerUrl ? (
                     <img src={profile.bannerUrl} alt="Banner" className="w-full h-full object-cover" />
                  ) : (
                     <div className="w-full h-full bg-cover bg-center opacity-40" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop')" }}></div>
                  )}
               </div>
               
               <div className="px-4 pb-4 relative pt-12">
                  <div className="absolute -top-10 left-4 w-20 h-20 rounded-full border-4 border-white dark:border-[#151515] bg-slate-200 dark:bg-[#2B2B2B] overflow-hidden">
                     <img src={profile.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${profile.firstName || 'T'}`} alt="Avatar" className="w-full h-full object-cover" />
                  </div>
                  
                  <div className="absolute top-3 right-4 px-2 py-1 bg-yellow-500/10 text-yellow-500 rounded text-[10px] font-bold flex items-center gap-1 border border-yellow-500/20">
                     👑 Elite Trader
                  </div>

                  <div className="mb-4">
                     <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-1">
                        {profile.name || profile.firstName || "nikil harake"} <span className="text-[#3b82f6]"><CheckCircle2 size={14} className="fill-[#3b82f6] text-white dark:text-[#151515]" /></span>
                     </h3>
                     <p className="text-[12px] text-slate-500 dark:text-[#949ba4]">@{profile.username || "nikilharake369"}</p>
                  </div>

                  <div className="flex items-center gap-2 mb-4">
                     <span className="text-[10px] font-bold text-[#3b82f6] bg-blue-500/10 px-1.5 py-0.5 rounded">👑 Lv 1</span>
                     <div className="flex-1 h-1.5 bg-slate-200 dark:bg-[#2B2B2B] rounded-full overflow-hidden">
                        <div className="w-[10%] h-full bg-[#3b82f6] rounded-full" />
                     </div>
                     <span className="text-[10px] font-bold text-slate-500">0/500 XP</span>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-4">
                     <div className="px-2 py-0.5 rounded bg-blue-500/10 text-[#3b82f6] dark:text-[#60a5fa] text-[10px] font-bold border border-blue-500/20">☆ Swing Trader</div>
                     <div className="px-2 py-0.5 rounded bg-green-500/10 text-green-600 dark:text-green-400 text-[10px] font-bold border border-green-500/20">☆ Price Action</div>
                     <div className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-600 dark:text-purple-400 text-[10px] font-bold border border-purple-500/20">☆ Risk Manager</div>
                  </div>

                  <div className="flex items-center gap-4 text-[11px] text-slate-500 dark:text-[#949ba4] mb-6 flex-wrap">
                     <div className="flex items-center gap-1 truncate"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="shrink-0"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg> <span className="truncate">{profile.city || "Mumbai, Maharashtra"}</span></div>
                     {profile.website && (
                        <div className="flex items-center gap-1 text-[#3b82f6] hover:underline cursor-pointer truncate"><ExternalLink size={12} className="shrink-0" /> <span className="truncate">{profile.website.replace(/^https?:\/\//, '')}</span></div>
                     )}
                     <div className="flex items-center gap-1 shrink-0"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="shrink-0"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> Joined Jan 2024</div>
                  </div>

                  <div className="flex justify-between border-t border-slate-100 dark:border-[#2a2a2a] pt-4">
                     <div className="text-center">
                        <div className="text-[14px] font-bold text-slate-900 dark:text-white">0</div>
                        <div className="text-[10px] font-medium text-slate-500">Posts</div>
                     </div>
                     <div className="text-center">
                        <div className="text-[14px] font-bold text-slate-900 dark:text-white">0</div>
                        <div className="text-[10px] font-medium text-slate-500">Followers</div>
                     </div>
                     <div className="text-center">
                        <div className="text-[14px] font-bold text-slate-900 dark:text-white">0</div>
                        <div className="text-[10px] font-medium text-slate-500">Following</div>
                     </div>
                  </div>
               </div>
            </div>

            {/* Profile Summary Card */}
            <div className="bg-white dark:bg-[#151515] rounded-2xl border border-slate-200 dark:border-[#333333] p-6 shadow-sm dark:shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_4px_6px_rgba(0,0,0,0.3)]">
               <h3 className="text-[11px] font-extrabold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-6">Profile Summary</h3>
               
               <div className="flex items-center gap-4 mb-6">
                  {/* Progress Circle Mockup */}
                  <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
                     <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                        <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" className="text-slate-100 dark:text-[#2B2B2B]" strokeWidth="3" />
                        <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#10b981" strokeWidth="3" strokeDasharray="72, 100" />
                     </svg>
                     <div className="absolute text-[13px] font-bold text-slate-900 dark:text-white">72%</div>
                  </div>
                  <div>
                     <h4 className="text-[13px] font-bold text-slate-900 dark:text-white">Profile Completeness</h4>
                     <p className="text-[11px] text-slate-500 dark:text-[#949ba4] leading-tight mt-1">Complete your profile to increase trust and visibility.</p>
                  </div>
               </div>

               <div className="space-y-3">
                  <div className="flex items-center gap-3">
                     <CheckCircle2 size={16} className="text-green-500" />
                     <span className="text-[12px] font-medium text-slate-800 dark:text-slate-300">Add profile picture</span>
                  </div>
                  <div className="flex items-center gap-3">
                     <CheckCircle2 size={16} className="text-green-500" />
                     <span className="text-[12px] font-medium text-slate-800 dark:text-slate-300">Add cover photo</span>
                  </div>
                  <div className="flex items-center gap-3">
                     <CheckCircle2 size={16} className="text-green-500" />
                     <span className="text-[12px] font-medium text-slate-800 dark:text-slate-300">Add trading style tags</span>
                  </div>
                  <div className="flex items-center gap-3">
                     <Circle size={16} className="text-slate-300 dark:text-[#2B2B2B]" />
                     <span className="text-[12px] font-medium text-slate-500">Write bio</span>
                  </div>
                  <div className="flex items-center gap-3">
                     <Circle size={16} className="text-slate-300 dark:text-[#2B2B2B]" />
                     <span className="text-[12px] font-medium text-slate-500">Connect social links</span>
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
}
