import { useTheme } from "next-themes";
import { Toaster as Sonner, toast } from "sonner";
import { CheckCircle2, AlertCircle, Info } from "lucide-react";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme();

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      className="toaster group"
      position="top-center"
      icons={{
        success: <CheckCircle2 className="h-[18px] w-[18px] text-[#FFFFFF] fill-[#10b981]" />,
        error: <AlertCircle className="h-[18px] w-[18px] text-[#FFFFFF] fill-[#f97316]" />,
        info: <Info className="h-[18px] w-[18px] text-[#FFFFFF] fill-[#64748b]" />,
      }}
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-[#F1F5F9] group-[.toaster]:border group-[.toaster]:border-slate-200 group-[.toaster]:text-[#111111] group-[.toaster]:shadow-sm group-[.toaster]:rounded-xl group-[.toaster]:py-2.5 group-[.toaster]:px-4 font-sans text-[14px] font-normal tracking-tight",
          description: "group-[.toast]:text-[#111111]/80 text-[13px]",
          actionButton: "group-[.toast]:bg-transparent group-[.toast]:text-[#111111] font-normal text-[13px] px-3 py-1 border-l border-slate-300 rounded-none ml-auto",
          cancelButton: "group-[.toast]:bg-transparent group-[.toast]:text-[#111111]/70 font-normal rounded-xl text-[13px] px-3 py-1",
        },
      }}
      {...props}
    />
  );
};

export { Toaster, toast };
