import React, { useState } from 'react';
import { Check, CheckCircle, Sparkles } from 'lucide-react';
import logoOnly from '@/assets/Logo_only.png';
import { toast } from 'sonner';

interface PricingCardsProps {
  selectedPlan: 'starter' | 'pro' | 'elite';
  onSelectPlan: (plan: 'starter' | 'pro' | 'elite') => void;
  onUpgradeClick?: (plan: 'starter' | 'pro' | 'elite') => void;
  isStandalone?: boolean;
}

export function PricingCards({ selectedPlan, onSelectPlan, onUpgradeClick, isStandalone = false }: PricingCardsProps) {
  const [starterExpanded, setStarterExpanded] = useState(false);
  const [proExpanded, setProExpanded] = useState(false);
  const [eliteExpanded, setEliteExpanded] = useState(false);

  const handleUpgrade = (plan: 'starter' | 'pro' | 'elite') => {
    if (onUpgradeClick) {
      onUpgradeClick(plan);
    } else {
      toast.success("Checkout process initialized! Thank you.");
    }
  };

  return (
    <div className={`grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto w-full ${isStandalone ? 'dark' : ''}`}>
      {/* Basic Plan */}
      <div 
         onClick={() => onSelectPlan('starter')}
         className={`cursor-pointer p-6 rounded-[32px] border-[2px] transition-all duration-300 flex flex-col relative overflow-hidden ${
            selectedPlan === 'starter' 
            ? 'border-slate-300 dark:border-[#444] bg-gradient-to-b from-[#FFFFFF] to-[#F4F4F5] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_8px_30px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#CBD5E1] dark:shadow-[0_8px_30px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#555] md:-translate-y-2 scale-[1.02] z-10' 
            : 'border-transparent dark:border-transparent bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#1C1C1E] dark:to-[#121214] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_1px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_1px_#2B2B2F] hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.05),0_0_0_1px_#CBD5E1] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.2),0_0_0_1px_#3f4148]'
         }`}
      >
         {/* Faded Background Logo & Glow */}
         <div className="absolute -bottom-10 -right-10 z-0 pointer-events-none opacity-[0.08] dark:opacity-[0.05] transform -rotate-12 grayscale">
            <img src={logoOnly} alt="" className="w-[200px] h-[200px] object-contain" />
         </div>
         <div className={`absolute -bottom-10 -right-10 w-64 h-64 bg-amber-500/15 dark:bg-amber-500/10 blur-3xl rounded-full z-0 pointer-events-none transition-opacity duration-700 ${selectedPlan === 'starter' ? 'opacity-100' : 'opacity-0'}`}></div>

         <h3 className="text-[16px] font-bold text-slate-800 dark:text-white mb-2 relative z-10">Starter</h3>
         <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-6 min-h-[36px]">Perfect for beginners starting their trading journey.</p>
         <div className="flex items-baseline gap-1 mb-6">
            <span className="text-[32px] font-extrabold text-slate-900 dark:text-white">$0</span>
            <span className="text-[12px] font-medium text-slate-500">/ forever</span>
         </div>
         <button 
           onClick={() => handleUpgrade('starter')}
           className="w-full flex items-center justify-center h-10 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-700 dark:text-slate-300 font-bold text-[12px] hover:text-slate-600 dark:hover:text-slate-100 transition-all hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.05),0_0_0_2px_#CBD5E1] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.2),0_0_0_2px_#3f4148] active:scale-95 mb-8"
         >
           Current Plan
         </button>
         
         <div className="space-y-2 flex-grow">
            <h4 className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-3">Includes:</h4>
            {[
               "Track your trades automatically",
               "1 Broker connection",
               "Trading journal access",
               "Basic AI trading insights",
               "Community access",
               "Risk Guard protection",
               "20 AI Coach Credits/day",
               "Earn XP & rewards"
            ].slice(0, starterExpanded ? undefined : 4).map((feature, i) => (
               <div key={i} className="flex items-start gap-2">
                  <Check size={13} className="text-slate-400 mt-[3px] shrink-0" />
                  <span className="text-[12px] font-medium text-slate-800 dark:text-[#DBDEE1] leading-tight">{feature}</span>
               </div>
            ))}
            <div className="pt-1 text-center">
               <button 
                  onClick={(e) => { e.stopPropagation(); setStarterExpanded(!starterExpanded); }}
                  className="text-[11px] font-bold text-slate-500 hover:text-slate-700 dark:text-[#949ba4] dark:hover:text-slate-300 transition-colors cursor-pointer"
               >
                  {starterExpanded ? 'Show less' : 'Show all 8 features'}
               </button>
            </div>
         </div>
      </div>

      {/* Pro Plan */}
      <div 
         onClick={() => onSelectPlan('pro')}
         className={`cursor-pointer p-6 rounded-[32px] border-[2px] transition-all duration-300 flex flex-col relative overflow-hidden ${
            selectedPlan === 'pro' 
            ? 'border-[#fbbf24] dark:border-[#f59e0b]/80 bg-gradient-to-b from-[#f59e0b]/5 to-transparent dark:from-[#78350f]/20 dark:to-[#121214] shadow-[0_8px_20px_-5px_rgba(245,158,11,0.2)] md:-translate-y-2 scale-[1.02] z-10' 
            : 'border-[#fde68a] dark:border-[#f59e0b]/30 bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#1C1C1E] dark:to-[#121214] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12)] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3)] hover:border-[#fbbf24] dark:hover:border-[#f59e0b]/60 hover:shadow-[0_8px_15px_-5px_rgba(245,158,11,0.15)]'
         }`}
      >
         {/* Faded Background Logo & Glow */}
         <div className="absolute -top-8 -right-8 z-0 pointer-events-none opacity-[0.05] dark:opacity-[0.08] transform rotate-12 mix-blend-overlay">
            <img src={logoOnly} alt="" className="w-[200px] h-[200px] object-contain" />
         </div>
         <div className="absolute top-0 right-0 w-40 h-40 bg-amber-500/10 blur-3xl rounded-full z-0 pointer-events-none mix-blend-screen"></div>
         
         {/* Floating Glassy Badge at Full Corner */}
         <div className="absolute top-0 right-0 px-4 py-2 bg-white/5 border-l border-b border-white/10 backdrop-blur-md text-amber-500 dark:text-amber-400 text-[9px] font-extrabold uppercase tracking-widest rounded-bl-[24px] rounded-tr-[32px] flex items-center gap-1 z-20 shadow-sm">
            Most Popular
         </div>

         <h3 className="text-[16px] font-bold text-slate-800 dark:text-white mb-2 flex items-center gap-2 relative z-10">
            Pro <Sparkles size={16} className="text-amber-500" />
         </h3>
         <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-6 min-h-[36px]">Built for traders who want consistency and discipline.</p>
         <div className="flex items-baseline gap-1 mb-6">
            <span className="text-[32px] font-extrabold text-slate-900 dark:text-white">$29</span>
            <span className="text-[12px] font-medium text-slate-500">/ month</span>
         </div>
         <button 
            onClick={() => handleUpgrade('pro')}
            className="w-full flex items-center justify-center h-10 rounded-full border-2 border-[#fcd34d]/40 dark:border-[#fbbf24]/30 bg-gradient-to-b from-amber-500 to-amber-600 dark:from-amber-600 dark:to-amber-700 shadow-[0_4px_7px_-5px_rgba(245,158,11,0.4),0_0_0_2px_rgba(245,158,11,0.2)] text-white font-bold text-[12px] hover:brightness-110 transition-all hover:shadow-[0_8px_15px_-5px_rgba(245,158,11,0.6),0_0_0_2px_rgba(245,158,11,0.4)] active:scale-95 mb-8"
         >
            Upgrade to Pro
         </button>
         
         <div className="space-y-2 flex-grow">
            <h4 className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-3">Everything in Starter, plus:</h4>
            {[
               "Real-time AI trade coaching",
               "Up to 6 broker connections",
               "Daily performance reports",
               "Advanced Risk Guard controls",
               "Voice notes with AI Coach",
               "AI detects revenge trading behavior",
               "Faster trade synchronization",
               "VIP trader channels access",
               "100 AI Coach Credits/day",
               "Join 1 Trading Competition/month",
               "Advanced performance analytics",
               "Priority support"
            ].slice(0, proExpanded ? undefined : 4).map((feature, i) => (
               <div key={i} className="flex items-start gap-2">
                  <CheckCircle size={13} className="text-amber-500 mt-[3px] shrink-0" />
                  <span className="text-[12px] font-medium text-slate-800 dark:text-[#DBDEE1] leading-tight">{feature}</span>
               </div>
            ))}
            <div className="pt-1 text-center">
               <button 
                  onClick={(e) => { e.stopPropagation(); setProExpanded(!proExpanded); }}
                  className="text-[11px] font-bold text-amber-600 hover:text-amber-700 dark:text-amber-500 dark:hover:text-amber-400 transition-colors cursor-pointer"
               >
                  {proExpanded ? 'Show less' : 'Show all 12 features'}
               </button>
            </div>
         </div>
      </div>

      {/* Elite Plan */}
      <div 
         onClick={() => onSelectPlan('elite')}
         className={`cursor-pointer p-6 rounded-[32px] border-[2px] transition-all duration-300 flex flex-col relative overflow-hidden ${
            selectedPlan === 'elite' 
            ? 'border-purple-400 dark:border-purple-500/80 bg-gradient-to-b from-purple-50/50 to-[#FFFFFF] dark:from-purple-900/20 dark:to-[#121214] shadow-[0_8px_30px_-5px_rgba(168,85,247,0.25)] md:-translate-y-2 scale-[1.02] z-10' 
            : 'border-transparent dark:border-transparent bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#1C1C1E] dark:to-[#121214] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_1px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_1px_#2B2B2F] hover:shadow-[0_8px_15px_-5px_rgba(168,85,247,0.15),0_0_0_1px_#c084fc] dark:hover:border-purple-500/40 dark:hover:shadow-[0_8px_15px_-5px_rgba(168,85,247,0.2)]'
         }`}
      >
         {/* Glowing visual effect for elite */}
         <div className="absolute -top-10 -left-10 w-40 h-40 bg-purple-500/10 blur-3xl rounded-full z-0 pointer-events-none mix-blend-screen transition-opacity duration-700"></div>

         <h3 className="text-[16px] font-bold text-slate-800 dark:text-white mb-2 relative z-10">Elite</h3>
         <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-6 min-h-[36px] relative z-10">Built for traders who want maximum discipline, mentorship, and automation.</p>
         <div className="flex items-baseline gap-1 mb-6">
            <span className="text-[32px] font-extrabold text-slate-900 dark:text-white">$99</span>
            <span className="text-[12px] font-medium text-slate-500">/ month</span>
         </div>
         <button 
            onClick={() => handleUpgrade('elite')}
            className="w-full flex items-center justify-center h-10 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-700 dark:text-slate-300 font-bold text-[12px] hover:text-slate-600 dark:hover:text-slate-100 transition-all hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.05),0_0_0_2px_#CBD5E1] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.2),0_0_0_2px_#3f4148] active:scale-95 mb-8"
         >
            Upgrade to Elite
         </button>
         
         <div className="space-y-2 flex-grow">
            <h4 className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-3">Everything in Pro, plus:</h4>
            {[
               "Unlimited broker connections",
               "Mentor account monitoring access",
               "Shared trading workspace access",
               "AI-assisted automated trading",
               "Personal performance reviews",
               "Custom Risk Guard controls",
               "Advanced trading analytics",
               "Early access to new features",
               "Dedicated premium support",
               "Unlimited AI Coach Credits",
               "Join 2 Trading Competitions/month",
               "Premium Elite badge & profile perks"
            ].slice(0, eliteExpanded ? undefined : 4).map((feature, i) => (
               <div key={i} className="flex items-start gap-2">
                  <Check size={13} className="text-slate-400 mt-[3px] shrink-0" />
                  <span className="text-[12px] font-medium text-slate-800 dark:text-[#DBDEE1] leading-tight">{feature}</span>
               </div>
            ))}
            <div className="pt-1 text-center">
               <button 
                  onClick={(e) => { e.stopPropagation(); setEliteExpanded(!eliteExpanded); }}
                  className="text-[11px] font-bold text-purple-600 hover:text-purple-700 dark:text-purple-400 dark:hover:text-purple-300 transition-colors cursor-pointer"
               >
                  {eliteExpanded ? 'Show less' : 'Show all 12 features'}
               </button>
            </div>
         </div>
      </div>
    </div>
  );
}
