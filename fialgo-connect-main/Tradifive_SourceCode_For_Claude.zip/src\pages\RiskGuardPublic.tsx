import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Shield, Lock, Zap, Activity, ArrowLeft, Cpu, RefreshCw, BarChart2 } from "lucide-react";
import tradifiveLogo from "@/assets/tradifive-login-logo.png";
import PublicNavbar from "@/components/PublicNavbar";
import PublicFooter from "@/components/PublicFooter";

const G = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
    :root {
      --bg: #02040a;
      --ink: #ffffff;
      --ink2: rgba(255, 255, 255, 0.7);
      --ink3: rgba(255, 255, 255, 0.4);
      --azure: #3b82f6;
      --slate: #94a3b8;
    }
    body {
      background: var(--bg);
      color: var(--ink);
      font-family: 'Inter', sans-serif;
    }
    h1, h2, h3 {
      font-family: 'Inter', sans-serif;
      letter-spacing: -0.02em;
    }
    .text-glow {
      background: linear-gradient(to right, #fff 20%, #cccccc 80%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .feat-card {
      background: rgba(255, 255, 255, 0.02);
      border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 24px;
      padding: 32px;
      transition: all 0.3s ease;
    }
    .feat-card:hover {
      background: rgba(255, 255, 255, 0.04);
      border-color: rgba(255, 255, 255, 0.15);
      transform: translateY(-5px);
    }
    .noise {
      position: fixed;
      top: 0; left: 0; width: 100%; height: 100%;
      background: url('https://grainy-gradients.vercel.app/noise.svg');
      opacity: 0.05;
      pointer-events: none;
      z-index: 0;
    }
  `}</style>
);

export default function RiskGuardPublic() {
  const navigate = useNavigate();

  return (
    <div style={{ minHeight: "100vh", background: "#02040a", color: "#fff", position: "relative", overflow: "hidden" }}>
      <G />
      <div className="noise" />

      {/* Background Aura */}
      <div style={{ position: "absolute", top: "-10%", left: "-10%", width: "800px", height: "800px", background: "radial-gradient(circle, rgba(59, 130, 246, 0.08) 0%, transparent 70%)", pointerEvents: "none" }} />

      {/* Nav */}
      <PublicNavbar onStart={() => navigate("/login")} />

      {/* Hero Section */}
      <section style={{ position: "relative", paddingTop: 180, paddingBottom: 100 }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 40px", display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 60, alignItems: "center" }}>

          {/* Left Content */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div style={{ background: "rgba(255, 255, 255, 0.08)", border: "1px solid rgba(255, 255, 255, 0.2)", padding: "6px 16px", borderRadius: "100px", marginBottom: 32, display: "flex", alignItems: "center", gap: 8, width: "fit-content" }}>
              <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#3b82f6" }} />
              <span style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.6)", textTransform: "none", letterSpacing: "0.2px" }}>Institutional Protection Protocol</span>
            </div>

            <h1 style={{ fontSize: "clamp(36px, 5vw, 68px)", fontWeight: 800, lineHeight: 1.1, letterSpacing: "-0.05em", marginBottom: 24, color: "#fff", fontFamily: "Inter, sans-serif" }}>
              <span style={{ background: "linear-gradient(to right, #3b82f6, #ffffff 60%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Sleep Better with.</span><br />
              <span className="text-glow">Risk Guard.</span>
            </h1>

            <p style={{ fontSize: 18, color: "var(--ink2)", lineHeight: 1.6, maxWidth: 540, marginBottom: 40, fontWeight: 400 }}>
              Our autonomous risk protocol enforces discipline when human emotion fails. Set your rules, lock your switch, and trade with absolute peace of mind.
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 24, marginBottom: 48 }}>
              <div className="feat-card">
                <Lock size={20} color="#3b82f6" style={{ marginBottom: 16 }} />
                <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 12 }}>Drawdown Lock</h3>
                <p style={{ fontSize: 14, color: "rgba(255,255,255,0.4)", lineHeight: 1.6 }}>Automatically halt trading when your daily loss limit is hit.</p>
              </div>
              <div className="feat-card">
                <Activity size={20} color="#3b82f6" style={{ marginBottom: 16 }} />
                <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 12 }}>Live Telemetry</h3>
                <p style={{ fontSize: 14, color: "rgba(255,255,255,0.4)", lineHeight: 1.6 }}>Monitor exposure across multiple symbols in real-time.</p>
              </div>
            </div>

            <button
              onClick={() => navigate("/login")}
              style={{ padding: "14px 32px", borderRadius: 100, background: "#3b82f6", color: "#fff", fontWeight: 800, fontSize: 14, border: "none", cursor: "pointer", transition: "all 0.3s" }}
            >
              Activate Risk Guard
            </button>
          </motion.div>

          {/* Right Visual */}
          <div style={{ position: "relative", zIndex: 5, display: "flex", justifyContent: "flex-end" }}>
            <div style={{
              position: "relative",
              left: "150px",
              top: "-20px",
              width: "180%",
              aspectRatio: "1/1",
              overflow: "hidden",
              borderRadius: "40px",
              background: "#02040a",
            }}>
              <img
                src="/Riskguard.png"
                alt="Risk Guard"
                style={{ width: "100%", height: "100%", display: "block", opacity: 1, objectFit: "cover" }}
              />

              {/* 4-Way Black Fades */}
              <div style={{
                position: "absolute",
                inset: 0,
                background: `
                  linear-gradient(to right, #02040a 0%, transparent 25%),
                  linear-gradient(to left, #02040a 0%, transparent 25%),
                  linear-gradient(to bottom, #02040a 0%, transparent 25%),
                  linear-gradient(to top, #02040a 0%, transparent 25%)
                `,
                pointerEvents: "none",
                zIndex: 6
              }} />
            </div>
          </div>

        </div>
      </section>

      {/* Institutional HUD Showcase */}
      <section style={{ padding: "100px 40px", background: "rgba(255,255,255,0.01)", borderTop: "1px solid rgba(255,255,255,0.05)", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 80, alignItems: "center" }} className="flex-col-sm">
            <div>
              <div style={{ background: "rgba(59, 130, 246, 0.1)", border: "1px solid rgba(59, 130, 246, 0.2)", padding: "6px 16px", borderRadius: "100px", marginBottom: 24, display: "flex", alignItems: "center", gap: 8, width: "fit-content" }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: "#3b82f6", textTransform: "uppercase", letterSpacing: "1px" }}>Protocol Architecture</span>
              </div>
              <h2 style={{ fontSize: 42, fontWeight: 800, marginBottom: 24, lineHeight: 1.2 }}>Level 12 Architect</h2>
              <p style={{ fontSize: 18, color: "var(--ink2)", lineHeight: 1.6, marginBottom: 32 }}>
                Our proprietary XP-based risk journey rewards disciplined trading. As you maintain consistency, you unlock higher protocol levels and advanced tactical HUD components.
              </p>

              <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 24, padding: 32 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 16 }}>
                  <div>
                    <p style={{ fontSize: 10, fontWeight: 800, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "2px", marginBottom: 8 }}>Exposure Limit</p>
                    <p style={{ fontSize: 28, fontWeight: 900, color: "#fff" }}>2.0 Lots</p>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <p style={{ fontSize: 10, fontWeight: 800, color: "rgba(59, 130, 246, 0.6)", textTransform: "uppercase", letterSpacing: "2px", marginBottom: 8 }}>Current Risk</p>
                    <p style={{ fontSize: 20, fontWeight: 900, color: "#3b82f6" }}>0.8 Lots</p>
                  </div>
                </div>
                <div style={{ height: 8, width: "100%", background: "rgba(255,255,255,0.05)", borderRadius: 100, overflow: "hidden" }}>
                  <motion.div initial={{ width: 0 }} whileInView={{ width: "40%" }} transition={{ duration: 1.5, ease: "easeOut" }} style={{ height: "100%", background: "#3b82f6" }} />
                </div>
              </div>
            </div>

            <div style={{ position: "relative" }}>
              <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", width: "120%", height: "120%", background: "radial-gradient(circle, rgba(59, 130, 246, 0.1) 0%, transparent 70%)", zIndex: 0 }} />
              <div style={{ position: "relative", zIndex: 1, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 40, padding: 48, backdropFilter: "blur(20px)" }}>
                <div style={{ display: "flex", gap: 12, marginBottom: 40 }}>
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={i} style={{ width: 60, height: 60, borderRadius: 16, background: i <= 3 ? "rgba(59, 130, 246, 0.1)" : "rgba(255,255,255,0.02)", border: i <= 3 ? "1px solid rgba(59, 130, 246, 0.3)" : "1px solid rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <Zap size={24} color={i <= 3 ? "#3b82f6" : "rgba(255,255,255,0.1)"} />
                    </div>
                  ))}
                </div>
                <h3 style={{ fontSize: 24, fontWeight: 800, marginBottom: 16 }}>Execution Discipline</h3>
                <p style={{ color: "var(--ink2)", lineHeight: 1.6, marginBottom: 24 }}>
                  Limit your daily mental fatigue. Once your tactical execution slots are exhausted, the protocol locks your terminal to prevent over-trading.
                </p>
                <div style={{ display: "flex", alignItems: "center", gap: 12, color: "#3b82f6", fontWeight: 800, fontSize: 14, letterSpacing: "1px" }}>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#3b82f6", boxShadow: "0 0 10px #3b82f6" }} />
                  SYNCHRONIZED: 3 / 5 SLOTS
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* High Fidelity Session Sentinel */}
      <section style={{ padding: "100px 40px" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 80, alignItems: "center" }} className="flex-col-sm">
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 24 }}>
              {[
                { name: "London", time: "13:30 - 22:00", active: true },
                { name: "New York", time: "17:30 - 02:00", active: true },
                { name: "Sydney", time: "03:30 - 12:00", active: false },
                { name: "Asian", time: "05:30 - 14:30", active: false }
              ].map(session => (
                <div key={session.name} style={{ background: session.active ? "rgba(59, 130, 246, 0.03)" : "rgba(255,255,255,0.01)", border: session.active ? "1px solid rgba(59, 130, 246, 0.2)" : "1px solid rgba(255,255,255,0.05)", borderRadius: 24, padding: 32, transition: "all 0.3s" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                    <span style={{ fontSize: 12, fontWeight: 900, textTransform: "uppercase", letterSpacing: "2px", color: session.active ? "#3b82f6" : "rgba(255,255,255,0.3)" }}>{session.name}</span>
                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: session.active ? "#3b82f6" : "rgba(255,255,255,0.1)", boxShadow: session.active ? "0 0 10px #3b82f6" : "none" }} />
                  </div>
                  <p style={{ fontSize: 16, fontWeight: 700, color: session.active ? "#fff" : "rgba(255,255,255,0.2)" }}>{session.time}</p>
                </div>
              ))}
            </div>

            <div>
              <div style={{ background: "rgba(59, 130, 246, 0.1)", border: "1px solid rgba(59, 130, 246, 0.2)", padding: "6px 16px", borderRadius: "100px", marginBottom: 24, display: "flex", alignItems: "center", gap: 8, width: "fit-content" }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: "#3b82f6", textTransform: "uppercase", letterSpacing: "1px" }}>Temporal Control</span>
              </div>
              <h2 style={{ fontSize: 42, fontWeight: 800, marginBottom: 24, lineHeight: 1.2 }}>Session Sentinel</h2>
              <p style={{ fontSize: 18, color: "var(--ink2)", lineHeight: 1.6, marginBottom: 32 }}>
                Trade only when the liquidity is highest. The Session Sentinel automatically restricts execution outside of your predefined volatility windows, ensuring you stay focused on the highest-probability setups.
              </p>
              <div style={{ display: "flex", alignItems: "center", gap: 16, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", padding: "20px 24px", borderRadius: 20 }}>
                <div style={{ padding: 12, borderRadius: 12, background: "rgba(59, 130, 246, 0.1)" }}>
                  <Activity size={20} color="#3b82f6" />
                </div>
                <div>
                  <p style={{ fontSize: 14, fontWeight: 700, color: "#fff", marginBottom: 2 }}>Volatility Filter Active</p>
                  <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>High-frequency data sync verified.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emotionless Trading Freeze Section */}
      <section style={{ padding: "100px 40px", background: "linear-gradient(to bottom, transparent, rgba(59, 130, 246, 0.02))" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 80, alignItems: "center" }} className="flex-col-sm">
            <div>
              <div style={{ background: "rgba(59, 130, 246, 0.1)", border: "1px solid rgba(59, 130, 246, 0.2)", padding: "6px 16px", borderRadius: "100px", marginBottom: 24, display: "flex", alignItems: "center", gap: 8, width: "fit-content" }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: "#3b82f6", textTransform: "uppercase", letterSpacing: "1px" }}>Psychological Edge</span>
              </div>
              <h2 style={{ fontSize: 42, fontWeight: 800, marginBottom: 24, lineHeight: 1.2 }}>Emotionless Freeze</h2>
              <p style={{ fontSize: 18, color: "var(--ink2)", lineHeight: 1.6, marginBottom: 32 }}>
                When emotions take over, the protocol takes command. Set a mandatory cooldown period to reset your psychology and prevent catastrophic decision-making.
              </p>

              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {[
                  { label: "Standard Reset", time: "6 Hours", desc: "Short-term mental reset after a minor breach." },
                  { label: "Deep Recalibration", time: "12 Hours", desc: "Overnight lock to prevent revenge trading." },
                  { label: "Institutional Shutdown", time: "24 Hours", desc: "Full 24-hour terminal lockout for maximum capital protection.", active: true }
                ].map(tier => (
                  <div key={tier.label} style={{ background: tier.active ? "rgba(59, 130, 246, 0.05)" : "rgba(255,255,255,0.01)", border: tier.active ? "1px solid rgba(59, 130, 246, 0.2)" : "1px solid rgba(255,255,255,0.05)", borderRadius: 20, padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <p style={{ fontSize: 14, fontWeight: 800, color: tier.active ? "#fff" : "rgba(255,255,255,0.4)", marginBottom: 4 }}>{tier.label}</p>
                      <p style={{ fontSize: 12, color: "rgba(255,255,255,0.3)" }}>{tier.desc}</p>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <p style={{ fontSize: 16, fontWeight: 900, color: tier.active ? "#3b82f6" : "rgba(255,255,255,0.2)" }}>{tier.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ position: "relative" }}>
              <div style={{ position: "relative", zIndex: 1, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 40, padding: 60, textAlign: "center" }}>
                <div style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", background: "radial-gradient(circle, rgba(59, 130, 246, 0.05) 0%, transparent 70%)", pointerEvents: "none" }} />
                <div style={{ width: 120, height: 120, borderRadius: "50%", border: "4px solid rgba(59, 130, 246, 0.1)", margin: "0 auto 40px", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                  <div style={{ position: "absolute", inset: -4, borderRadius: "50%", border: "4px solid #3b82f6", borderRightColor: "transparent", animate: "spin 4s linear infinite" }} />
                  <Lock size={48} color="#3b82f6" />
                </div>
                <p style={{ fontSize: 12, fontWeight: 800, color: "#3b82f6", textTransform: "uppercase", letterSpacing: "4px", marginBottom: 16 }}>Protocol Lock Active</p>
                <h3 style={{ fontSize: 48, fontWeight: 900, color: "#fff", marginBottom: 8, fontVariantNumeric: "tabular-nums" }}>23:59:59</h3>
                <p style={{ fontSize: 14, color: "rgba(255,255,255,0.4)" }}>Terminal access restricted by Risk Guard.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Kill Switch Showcase */}
      <section style={{ padding: "100px 40px", background: "rgba(239, 68, 68, 0.02)", borderTop: "1px solid rgba(239, 68, 68, 0.1)", borderBottom: "1px solid rgba(239, 68, 68, 0.1)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 80, alignItems: "center" }} className="flex-col-sm">
            <div>
              <div style={{ background: "rgba(239, 68, 68, 0.1)", border: "1px solid rgba(239, 68, 68, 0.2)", padding: "6px 16px", borderRadius: "100px", marginBottom: 24, display: "flex", alignItems: "center", gap: 8, width: "fit-content" }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#ef4444", animate: "pulse 2s infinite" }} />
                <span style={{ fontSize: 11, fontWeight: 700, color: "#ef4444", textTransform: "uppercase", letterSpacing: "1px" }}>Safety Protocol</span>
              </div>
              <h2 style={{ fontSize: 42, fontWeight: 800, marginBottom: 24, lineHeight: 1.2 }}>Autonomous Kill Switch</h2>
              <p style={{ fontSize: 18, color: "var(--ink2)", lineHeight: 1.6, marginBottom: 32 }}>
                The final line of defense. If your account equity falls below your predefined hard floor, Risk Guard instantly terminates all open positions and disables terminal access for 24 hours.
              </p>
              <div style={{ display: "flex", gap: 20 }}>
                <div style={{ flex: 1, background: "rgba(239, 68, 68, 0.05)", border: "1px solid rgba(239, 68, 68, 0.1)", borderRadius: 20, padding: 24 }}>
                  <p style={{ fontSize: 10, fontWeight: 800, color: "rgba(239,68,68,0.6)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 8 }}>Hard Equity Floor</p>
                  <p style={{ fontSize: 24, fontWeight: 900, color: "#ef4444" }}>$95,000</p>
                </div>
                <div style={{ flex: 1, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 20, padding: 24 }}>
                  <p style={{ fontSize: 10, fontWeight: 800, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 8 }}>Current Equity</p>
                  <p style={{ fontSize: 24, fontWeight: 900, color: "#fff" }}>$102,450</p>
                </div>
              </div>
            </div>

            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 40, padding: 48, position: "relative", overflow: "hidden" }}>
              <div style={{ position: "absolute", top: 0, right: 0, width: "100%", height: "100%", background: "linear-gradient(135deg, transparent, rgba(239, 68, 68, 0.05))", pointerEvents: "none" }} />
              <div style={{ display: "flex", alignItems: "center", justifyBetween: "space-between", marginBottom: 40 }}>
                <div style={{ width: 64, height: 64, borderRadius: 20, background: "#ef4444", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 10px 30px rgba(239, 68, 68, 0.4)" }}>
                  <Shield size={32} color="#fff" />
                </div>
                <div style={{ marginLeft: "auto", padding: "8px 16px", borderRadius: 100, border: "1px solid #ef4444", color: "#ef4444", fontSize: 11, fontWeight: 900, textTransform: "uppercase", letterSpacing: "1px" }}>
                  ARMED & READY
                </div>
              </div>
              <h3 style={{ fontSize: 24, fontWeight: 800, marginBottom: 16 }}>Principal Protection</h3>
              <p style={{ color: "var(--ink2)", lineHeight: 1.6, marginBottom: 32 }}>
                Set your "Zero Line". If emotions take over and you start chasing losses, Risk Guard steps in to save your principal capital before it's too late.
              </p>
              <div style={{ padding: "20px", background: "rgba(239, 68, 68, 0.1)", borderRadius: 16, border: "1px dashed rgba(239, 68, 68, 0.3)", textAlign: "center" }}>
                <span style={{ fontSize: 13, fontWeight: 800, color: "#ef4444", letterSpacing: "1px" }}>CRITICAL LIMIT: -5.0% DAILY DRAWDOWN</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Features Grid Replaced with the above high-fidelity sections, but keeping the final pill */}
      <section style={{ padding: "80px 40px" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ background: "rgba(59, 130, 246, 0.05)", border: "1px solid rgba(59, 130, 246, 0.1)", borderRadius: 24, padding: "24px 40px", display: "flex", alignItems: "center", justifyContent: "center", gap: 20 }}>
            <Shield size={24} color="#3b82f6" />
            <span style={{ fontSize: 18, fontWeight: 800, letterSpacing: "0.05em", color: "#3b82f6", fontStyle: "italic" }}>
              IF YOU LOSE CONTROL, RISK GUARD TAKES CONTROL.
            </span>
          </div>
        </div>
      </section>

      <PublicFooter />
    </div>
  );
}
