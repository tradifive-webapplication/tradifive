import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import '../theme-switch.css';
import DashboardLayout from '@/components/DashboardLayout';
import logoOnly from '@/assets/Logo_only.png';
import AccountTab from '@/components/settings/AccountTab';
import ProfileTab from '@/components/settings/ProfileTab';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { applyThemeWithTransition } from '@/utils/themeTransition';

const TabHeaderUpdater = ({ title, setHeaderTitle }) => {
   useEffect(() => {
      setHeaderTitle(title);
   }, [title, setHeaderTitle]);
   return null;
};
import ThemeSwitch from '@/components/ThemeSwitch';
import { 
   User, Settings as SettingsIcon, Bell, Palette, Camera, Check, Link2, 
   Twitter, Instagram, Youtube, Trash2, Mail, Shield, MessageSquare, 
   Smartphone, AlertTriangle, Monitor, Moon, Sun, MonitorSmartphone, Power, X,
   Key, Lock, Globe, Bot, Brain, TrendingUp, Gem, Receipt, Hash, Award, HelpCircle, 
   FileText, Search, CreditCard, ChevronRight, CheckCircle, RefreshCw, Eye, EyeOff,
   Info, ArrowUpRight, ShieldCheck, Sparkles, Terminal, Volume2, Calendar, LockKeyhole, Crown,
   CircleUserRound, Languages, BellRing, MessageCircle, AlertCircle, Inbox, MoreVertical, ArrowRight, Plus, Minus, Download, LogOut, Pencil
} from 'lucide-react';

const PushableButton = ({ children, onClick, type = 'primary', className = '', ...props }: any) => {
   const baseClasses = "relative rounded-xl font-bold transition-all duration-200 active:top-[2px] active:shadow-none overflow-hidden";
   
   const types = {
      primary: "bg-indigo-650 text-white shadow-[0_4px_0_rgb(67,56,202)] hover:bg-indigo-700 active:shadow-[0_0px_0_rgb(67,56,202)]",
      secondary: "bg-white dark:bg-[#121212] text-slate-700 dark:text-slate-200 shadow-[0_4px_0_rgb(203,213,225)] dark:shadow-[0_4px_0_rgb(15,15,15)] hover:bg-slate-50 dark:hover:bg-[#222225] border border-slate-200 dark:border-transparent",
      danger: "bg-red-500 text-white shadow-[0_4px_0_rgb(185,28,28)] hover:bg-red-400 active:shadow-[0_0px_0_rgb(185,28,28)]"
   };

   return (
      <button 
         className={`${baseClasses} ${types[type as keyof typeof types]} ${className}`}
         onClick={onClick}
         {...props}
      >
         <div className="absolute inset-0 bg-white/20 dark:bg-black/10 translate-y-[-50%] rounded-full blur-md"></div>
         <span className="relative z-10 block">{children}</span>
      </button>
   );
};

const ConsistencyToggleButton = ({ label, checked, onChange, icon: Icon, type = 'button' }: any) => (
   <button
      type={type}
      onClick={onChange}
      className={`inline-flex items-center gap-1.5 h-[44px] px-5 rounded-[16px] border-2 text-[12px] font-bold tracking-tight transition-all duration-300 ${
         checked
         ? "border-white dark:border-transparent bg-gradient-to-b from-[#E0E7FF] to-[#EEF2FF] dark:from-[#1E1E1E] dark:to-[#121212] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#818CF840] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#3730A340] text-indigo-700 dark:text-indigo-400"
         : "border-white dark:border-transparent bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#121212] dark:to-[#121212] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#333336] text-slate-500 dark:text-slate-400 hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#44444A]"
      }`}
   >
      {Icon && <Icon size={14} />}
      <span>{label}</span>
   </button>
);

const AnimatedCheckbox = ({ checked, onChange }: { checked: boolean, onChange: (checked: boolean) => void }) => (
   <button 
      type="button" 
      onClick={() => onChange(!checked)} 
      className={`group relative flex items-center justify-center w-[18px] h-[18px] rounded-[5px] transition-all duration-200 overflow-hidden outline-none ring-0 border ${checked ? 'border-[#5865F2] bg-[#5865F2]' : 'border-slate-300 dark:border-[#313338] bg-white dark:bg-[#1e1f22]'}`}
   >
      {checked && <Check size={11} strokeWidth={4} className="relative z-10 text-white" />}
   </button>
);

const SettingsToggle = ({ checked, onChange, disabled = false }: { checked: boolean, onChange: (v: boolean) => void, disabled?: boolean }) => (
   <button
      type="button"
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative w-9 h-[20px] rounded-full transition-colors duration-200 outline-none focus:outline-none ${disabled ? 'opacity-40 cursor-not-allowed' : ''} ${checked ? 'bg-[#3b82f6]' : 'bg-slate-300 dark:bg-[#2b2d31]'}`}
   >
      <div className={`absolute top-1/2 -translate-y-1/2 left-[3px] w-[14px] h-[14px] rounded-full bg-white shadow-sm transition-transform duration-200 ${checked ? 'translate-x-[16px]' : 'translate-x-0'}`} />
   </button>
);

const BrokerIcon = ({ name, size = 36 }: { name: string; size?: number }) => {
   const colors: Record<string, string> = {
      icmarkets: "from-emerald-500 to-teal-600 text-white",
      zerodha: "from-blue-500 to-sky-600 text-white",
      dhan: "from-amber-400 to-yellow-500 text-slate-900",
      upstox: "from-purple-500 to-indigo-600 text-white",
      groww: "from-cyan-500 to-teal-500 text-white",
      angelone: "from-orange-500 to-amber-600 text-white"
   };
   
   const initials: Record<string, string> = {
      icmarkets: "IC",
      zerodha: "Z",
      dhan: "D",
      upstox: "U",
      groww: "G",
      angelone: "A"
   };

   const colorClass = colors[name] || "from-slate-400 to-slate-500 text-white";
   const letter = initials[name] || name.charAt(0).toUpperCase();

   return (
      <div 
         style={{ width: size, height: size }}
         className={`rounded-xl bg-gradient-to-br ${colorClass} flex items-center justify-center font-extrabold text-[12px] tracking-wider shadow-sm shrink-0`}
      >
         {letter}
      </div>
   );
};

export default function Settings() {
   const navigate = useNavigate();
   const [activeTab, setActiveTab] = useState('account');
   const [headerTitle, setHeaderTitle] = useState('Settings');
   const [activeSubTab, setActiveSubTab] = useState('account-info');
   const [selectedPlan, setSelectedPlan] = useState('pro');
   const [searchQuery, setSearchQuery] = useState('');
   const [loading, setLoading] = useState(false);
   const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
   
   // Modals State
   const [isEditModalOpen, setIsEditModalOpen] = useState(false);
   const [showSmsModal, setShowSmsModal] = useState(false);
   const [showBrokerConnectModal, setShowBrokerConnectModal] = useState(false);
   const [selectedBrokerToConnect, setSelectedBrokerToConnect] = useState('');
   
   // Profile State
   const [profile, setProfile] = useState({
      firstName: '',
      lastName: '',
      name: '',
      email: '',
      avatarUrl: '',
      bannerUrl: '',
      bio: '',
      website: '',
      twitter: '',
      instagram: '',
      youtube: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      country: '',
      dob: '',
      gender: '',
      countryEmoji: '🌍',
      isPrivate: false,
      hideFollowers: false,
      hideTrades: false
   });
   
   const [password, setPassword] = useState({ current: '', new: '', confirm: '' });
   const avatarUploadRef = useRef<HTMLInputElement>(null);
   const bannerUploadRef = useRef<HTMLInputElement>(null);

   // Privacy State
   const [privacySettings, setPrivacySettings] = useState<Record<string, any>>({
      show_location: true,
      show_winrate: true,
      show_roi: true,
      show_streak: true,
      show_trades: true,
      is_private: false,
      account_type: 'personal'
   });

   // Notifications State
   const [globalOff, setGlobalOff] = useState(false);
   const [globalEmailOnly, setGlobalEmailOnly] = useState(false);
   const [notifications, setNotifications] = useState({
      messages: [
         { id: 'direct', label: 'Direct Messages', push: true, app: true, email: false },
         { id: 'group', label: 'Group Messages', push: true, app: true, email: false },
         { id: 'mentions', label: 'Mentions & Tags', push: true, app: true, email: true },
      ],
      text: [
         { id: 'sms_alerts', label: 'SMS Security Alerts', push: true, app: false, email: false },
         { id: 'push_marketing', label: 'Push Marketing & Promos', push: false, app: false, email: false },
      ],
      alerts: [
         { id: 'trade', label: 'Trade Execution Alerts', push: true, app: true, email: true },
         { id: 'price', label: 'Price Drops & Spikes', push: true, app: true, email: false },
         { id: 'risk', label: 'Risk Guard Warnings', push: true, app: true, email: true },
      ],
      ai_coach: [
         { id: 'insights', label: 'AI Coach Insights', push: true, app: true, email: false },
         { id: 'weekly_report', label: 'Weekly Performance Reports', push: false, app: true, email: true },
      ],
      channels: [
         { id: 'announcements', label: 'Channel Announcements', push: true, app: true, email: true },
         { id: 'replies', label: 'Replies & Threads', push: true, app: true, email: false },
      ],
      inboxes: [
         { id: 'news', label: 'Community News', push: false, app: true, email: true },
         { id: 'invites', label: 'Friend & Group Invites', push: true, app: true, email: false },
      ]
   });

    // Appearance State
    const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'dark');
   const [accentColor, setAccentColor] = useState('blue');
   const [layoutDensity, setLayoutDensity] = useState('comfortable');
   const [terminalLogging, setTerminalLogging] = useState(false);

   // New Tab States
   const [language, setLanguage] = useState('en');
   const [aiTone, setAiTone] = useState('strict');
   const [aiVoice, setAiVoice] = useState('female');
   const [aiFrequency, setAiFrequency] = useState('medium');
   const [connectedBroker, setConnectedBroker] = useState<string>('icmarkets');
   const [isSyncing, setIsSyncing] = useState(false);
   const [lastSyncedTime, setLastSyncedTime] = useState('Just now');
   const [billingInterval, setBillingInterval] = useState<'monthly' | 'annual'>('monthly');
   
   // Creator Settings
   const [creatorHandle, setCreatorHandle] = useState('');
   const [creatorCategory, setCreatorCategory] = useState('Day Trading');
   const [creatorBio, setCreatorBio] = useState('');
   
   // Channel Settings
   const [feedVisibility, setFeedVisibility] = useState('public');
   const [channelRules, setChannelRules] = useState('No self-promotion, maintain civil discussions.');

   // Help FAQ Open state
   const [openFaqId, setOpenFaqId] = useState<number | null>(null);

   // Report State
   const [reportCategory, setReportCategory] = useState('bug');
   const [reportSubject, setReportSubject] = useState('');
   const [reportDescription, setReportDescription] = useState('');

   // Global User ID for AI Credits
   const [globalUserId, setGlobalUserId] = useState<string>('');
   const [aiCredits, setAiCredits] = useState<number>(50);
   const [customTopupAmount, setCustomTopupAmount] = useState<string>('');

   // Billing Cards Expand State
   const [starterExpanded, setStarterExpanded] = useState(false);
   const [proExpanded, setProExpanded] = useState(false);
   const [eliteExpanded, setEliteExpanded] = useState(false);

   // Escape key close handling
   useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
         if (e.key === 'Escape') {
            navigate(-1);
         }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
         window.removeEventListener('keydown', handleKeyDown);
      };
   }, [navigate]);

   // Read tab parameter from URL search params with aliases
   useEffect(() => {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab');
      if (tabParam) {
         if (tabParam === 'plan') {
            setActiveTab('billing_plans');
         } else if (tabParam === 'profiles') {
            setActiveTab('profile');
         } else if (tabParam === 'File Setup') {
            setActiveTab('trading');
         } else {
            setActiveTab(tabParam);
         }
      }
      const planParam = params.get('plan');
      if (planParam && ['starter', 'pro', 'elite'].includes(planParam)) {
         setSelectedPlan(planParam);
      }
   }, []);

   // Load privacy settings and profile details on mount
   useEffect(() => {
      const fetchUserData = async () => {
         const { data: { user } } = await supabase.auth.getUser();
         if (user) {
            // Load privacy settings from localStorage
            const storedPrivacy = localStorage.getItem(`tradifive_privacy_${user.id}`);
            if (storedPrivacy) {
               setPrivacySettings(JSON.parse(storedPrivacy));
            }
            
            setGlobalUserId(user.id);
            const storedCredits = localStorage.getItem(`tradifive_ai_credits_${user.id}`);
            if (storedCredits) {
               setAiCredits(parseInt(storedCredits, 10));
            } else {
               localStorage.setItem(`tradifive_ai_credits_${user.id}`, '50');
               setAiCredits(50);
            }
            
            // Load profile details from database
            const { data } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
            if (data) {
               setProfile({
                  firstName: data.first_name || '',
                  lastName: data.last_name || '',
                  name: data.username || '',
                  email: user.email || '',
                  avatarUrl: data.avatar_url || '',
                  bannerUrl: data.banner_url || '',
                  bio: data.bio || '',
                  website: data.website || '',
                  twitter: data.twitter_url || '',
                  instagram: data.instagram_url || '',
                  youtube: data.youtube_url || '',
                  address: data.address || '',
                  city: data.city || '',
                  state: data.state || '',
                  zipCode: data.zip_code || '',
                  country: data.country || '',
                  dob: data.dob || '',
                  gender: data.gender || '',
                  countryEmoji: data.country_emoji || '🌍',
                  isPrivate: data.is_private || false,
                  hideFollowers: data.hide_followers || false,
                  hideTrades: data.hide_trades || false
               });
               setCreatorHandle(data.username ? `@${data.username}_trades` : '');
            } else {
               // Load fallback from localStorage cache
               const cached = localStorage.getItem('prof_cache_data');
               if (cached) {
                  const parsed = JSON.parse(cached);
                  setProfile({
                     firstName: parsed.first_name || '',
                     lastName: parsed.last_name || '',
                     name: parsed.username || '',
                     email: user.email || '',
                     avatarUrl: parsed.avatar_url || '',
                     bannerUrl: parsed.banner_url || '',
                     bio: parsed.bio || '',
                     website: parsed.website || '',
                     twitter: parsed.twitter_url || '',
                     instagram: parsed.instagram_url || '',
                     youtube: parsed.youtube_url || '',
                     address: parsed.address || '',
                     city: parsed.city || '',
                     state: parsed.state || '',
                     zipCode: parsed.zip_code || '',
                     country: parsed.country || '',
                     dob: parsed.dob || '',
                     gender: parsed.gender || '',
                     countryEmoji: parsed.country_emoji || '🌍',
                     isPrivate: parsed.is_private || false,
                     hideFollowers: parsed.hide_followers || false,
                     hideTrades: parsed.hide_trades || false
                  });
                  setCreatorHandle(parsed.username ? `@${parsed.username}_trades` : '');
               }
            }
         }
      };
      fetchUserData();
   }, []);

   const handleToggle = (category: string, id: string, type: 'app' | 'push' | 'email') => {
      setNotifications(prev => ({
         ...prev,
         [category]: (prev as any)[category].map((n: any) => 
            n.id === id ? { ...n, [type]: !n[type] } : n
         )
      }));
   };

   const handleGlobalOff = () => {
      const newState = !globalOff;
      setGlobalOff(newState);
      if (newState) setGlobalEmailOnly(false);
      
      const newNotifs = { ...notifications };
      Object.keys(newNotifs).forEach(key => {
         (newNotifs as any)[key] = (newNotifs as any)[key].map((n: any) => ({
            ...n, app: !newState, push: !newState, email: !newState
         }));
      });
      setNotifications(newNotifs);
   };

   const handleEmailOnly = () => {
      const newState = !globalEmailOnly;
      setGlobalEmailOnly(newState);
      if (newState) setGlobalOff(false);
      
      const newNotifs = { ...notifications };
      Object.keys(newNotifs).forEach(key => {
         (newNotifs as any)[key] = (newNotifs as any)[key].map((n: any) => ({
            ...n, app: !newState, push: !newState, email: true
         }));
      });
      setNotifications(newNotifs);
   };

   const handleUpdateProfile = async (e?: React.FormEvent) => {
      if (e) e.preventDefault();
      try {
         const { data: { user } } = await supabase.auth.getUser();
         if (!user) return;
         setLoading(true);
         
         // Update profile in DB
         const { error } = await supabase.from('profiles').update({
            first_name: profile.firstName,
            last_name: profile.lastName,
            username: profile.name,
            bio: profile.bio,
            website: profile.website,
            twitter_url: profile.twitter,
            instagram_url: profile.instagram,
            youtube_url: profile.youtube,
            address: profile.address,
            city: profile.city,
            state: profile.state,
            zip_code: profile.zipCode,
            country: profile.country,
            dob: profile.dob,
            gender: profile.gender,
            country_emoji: profile.countryEmoji
         }).eq('id', user.id);
         
         if (error) throw error;
         
         // Save privacy settings locally
         localStorage.setItem(`tradifive_privacy_${user.id}`, JSON.stringify(privacySettings));
         localStorage.setItem(`tradifive_privacy_user_${profile.name.toLowerCase()}`, JSON.stringify(privacySettings));
         
         const updatedCache = {
            id: user.id,
            first_name: profile.firstName,
            last_name: profile.lastName,
            display_name: `${profile.firstName} ${profile.lastName}`.trim() || profile.name,
            username: profile.name,
            avatar_url: profile.avatarUrl,
            banner_url: profile.bannerUrl,
            bio: profile.bio,
            location: profile.city,
            country: profile.country,
            country_emoji: profile.countryEmoji
         };
         
         localStorage.setItem('prof_cache_data', JSON.stringify(updatedCache));
         localStorage.setItem(`tradifive_mock_profile_${profile.name.toLowerCase()}`, JSON.stringify(updatedCache));
         
         // Update tradifive cache keys for sidebar
         localStorage.setItem("tradifive_cached_display_name", `${profile.firstName} ${profile.lastName}`.trim() || profile.name);
         localStorage.setItem("tradifive_cached_username", profile.name);
         localStorage.setItem("tradifive_cached_avatar_url", profile.avatarUrl);
         
         // Dispatch update event
         window.dispatchEvent(new Event("tradifive_profile_update"));
         
         toast.success('Preferences saved successfully');
      } catch (e: any) {
         console.error(e);
         toast.error('Failed to update profile');
      } finally {
         setLoading(false);
      }
   };

   const handleThemeChange = (newTheme: string) => {
      setTheme(newTheme);
      applyThemeWithTransition(newTheme as 'light' | 'dark', () => {
         // Theme transition completed
      });
   };

   const handleForceSync = () => {
      setIsSyncing(true);
      setTimeout(() => {
         setIsSyncing(false);
         setLastSyncedTime('Just now');
         toast.success('Synchronized trading activity from IC Markets!');
      }, 1500);
   };

   const handleConnectBrokerSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      setConnectedBroker(selectedBrokerToConnect);
      setShowBrokerConnectModal(false);
      toast.success(`Successfully connected to ${selectedBrokerToConnect.toUpperCase()}!`);
   };

   const handleReportSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!reportSubject || !reportDescription) {
         toast.error('Please fill out all problem report fields');
         return;
      }
   toast.success('Problem report logged. Our support team will investigate.');
      setReportSubject('');
      setReportDescription('');
   };

   // Define structural settings categories for left sidebar
   const sidebarSections = [
      {
         title: "My Account",
         items: [
            { 
               id: "account", 
               label: "Account", 
               icon: User,
               children: [
                  { id: "account-info", label: "Account Info" },
                  { id: "password-security", label: "Password & Security" },
                  { id: "account-standing", label: "Account Standing" },
                  { id: "family-center", label: "Family Center" }
               ]
            }
         ]
      },
      {
         title: "Personalization",
         items: [
            { id: "appearance", label: "Appearance", icon: Palette },
            { id: "notifications", label: "Notifications", icon: Bell }
         ]
      },
      {
         title: "AI & Tools",
         items: [
            { id: "ai", label: "AI Assistant", icon: Sparkles },
            { id: "trading", label: "Broker & Integrations", icon: Link2 }
         ]
      },
      {
         title: "Billing",
         items: [
            { id: "billing_plans", label: "Billing & Plans", icon: Crown },
            { id: "subscription", label: "Subscription", icon: CreditCard }
         ]
      },
      {
         title: "Community & Channels",
         items: [
            { id: "channel", label: "Channel Settings", icon: MessageSquare },
            { id: "creator", label: "Creator / Business", icon: Gem }
         ]
      },
      {
         title: "Support",
         items: [
            { id: "help", label: "Help Center", icon: HelpCircle },
            { id: "report", label: "Report a Problem", icon: AlertTriangle },
            { id: "logout", label: "Log Out", icon: LogOut }
         ]
      }
   ];

    // Filter the sidebar list using query search
   const filteredSections = sidebarSections.map(section => {
      const items = section.items.filter(item => 
         item.label.toLowerCase().includes(searchQuery.toLowerCase())
      );
      return { ...section, items };
   }).filter(section => section.items.length > 0);

   const displayName = `${profile.firstName} ${profile.lastName}`.trim() || profile.name || "username";

   const tabTitles: Record<string, string> = {
      general: "General Details",
      profile: "Edit Profile & Privacy",
      security: "Account & Security",
      privacy: "Privacy & Community",
      appearance: "Appearance",
      notifications: "Notifications",
      ai: "AI Assistant",
      trading: "Broker & Integrations",
      billing_plans: "Billing & Plans",
      subscription: "Subscription",
      channel: "Channel Settings",
      creator: "Creator / Business",
      help: "Help Center",
      report: "Report a Problem",
      terms: "Terms & Policies"
   };

   return (
      <DashboardLayout breadcrumbs={[{ label: "Home", path: "/home" }, { label: "Settings", path: "/settings" }]}>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 backdrop-blur-[3px] p-4 sm:p-6 md:p-8 select-none font-sans">
         
         {/* Click outside backdrop container back to dashboard page */}
         <div className="absolute inset-0" onClick={() => navigate(-1)} />

         {/* Centered Settings Dialog Modal Box */}
         <div className="relative w-full h-full max-w-[1440px] max-h-[880px] rounded-[16px] bg-white dark:bg-[#121212] text-slate-800 dark:text-[#dbdee1] flex overflow-hidden shadow-2xl border border-slate-200/60 dark:border-white/5 z-10">
            
            {/* LEFT SIDEBAR PANEL inside Modal */}
            <div className="w-60 sm:w-64 bg-[#f2f3f5] dark:bg-[#1E1E1E] flex flex-col h-full border-r border-slate-200/60 dark:border-white/5 shrink-0">
               <div className="py-6 px-4 flex flex-col gap-4 h-full overflow-y-auto amazing-scrollbar">
                            {/* Mini Profile Display */}
                  <div 
                     onClick={() => setActiveTab('profile')}
                     className="group bg-slate-200/50 dark:bg-[#121212] p-3 rounded-[16px] flex items-center gap-3 shadow-sm border border-slate-300/30 dark:border-transparent cursor-pointer hover:bg-slate-300/30 dark:hover:bg-[#292929]/50 transition-all"
                  >
                     <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 bg-slate-300 dark:bg-[#111111] shadow-inner">
                        <img 
                           src={profile.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${profile.firstName || profile.name || 'T'}`} 
                           alt="Avatar" 
                           className="w-full h-full object-cover" 
                        />
                     </div>
                     <div className="min-w-0 flex-1 text-left">
                        <p className="text-[12px] font-semibold text-slate-800 dark:text-white truncate leading-tight">
                           {displayName}
                        </p>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <span className="text-[11px] text-blue-500 dark:text-blue-400 font-bold tracking-wide group-hover:text-blue-600 dark:group-hover:text-blue-300 transition-colors">
                              edit profile
                           </span>
                           <Pencil size={11} className="text-blue-500 dark:text-blue-400 group-hover:text-blue-600 dark:group-hover:text-blue-300 transition-colors" />
                        </div>
                     </div>
                     <div className="text-slate-500 dark:text-slate-400 p-1">
                        <User size={16} />
                     </div>
                  </div>

                  {/* Navigation Search Input */}
                  <div className="relative">
                     <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 dark:text-[#949ba4]" size={13} />
                     <input 
                        type="text" 
                        placeholder="Search settings..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-8 pr-3 py-1.5 rounded-md bg-[#e3e5e8] dark:bg-[#121212] border border-transparent text-[12px] placeholder:text-slate-500 text-slate-800 dark:text-slate-200 outline-none focus:bg-slate-100 dark:focus:bg-[#000000] transition-colors"
                     />
                     {searchQuery && (
                        <button onClick={() => setSearchQuery('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 hover:text-slate-655 dark:hover:text-slate-200">
                           Clear
                        </button>
                     )}
                  </div>

                  {/* Sections Iterations */}
                  <div className="space-y-4">
                     {filteredSections.map((section, idx) => (
                        <div key={idx}>
                           <h3 className="text-[12px] font-bold text-slate-550 dark:text-[#949ba4] uppercase tracking-wider mb-2 px-2">
                              {section.title}
                           </h3>
                           <div className="space-y-0.5">
                              {section.items.map((item: any) => {
                                 const isActive = activeTab === item.id;
                                 return (
                                    <div key={item.id} className="flex flex-col">
                                       <button
                                          onClick={async () => { 
                                             if (item.id === 'logout') {
                                                await supabase.auth.signOut();
                                                toast.success("Logged out successfully");
                                                navigate('/login');
                                             } else {
                                                setActiveTab(item.id); 
                                                if(item.children) setActiveSubTab(item.children[0].id); 
                                             }
                                          }}
                                          className={`w-full flex items-center gap-3 px-3 py-1.5 rounded-md text-[15px] font-medium transition-all duration-150 text-left ${
                                             item.id === 'logout'
                                             ? 'text-rose-500 hover:bg-rose-500/10 dark:hover:bg-rose-500/10'
                                             : isActive 
                                             ? 'bg-[#e3e5e8] dark:bg-[#3F4147]/60 text-slate-800 dark:text-white shadow-sm font-semibold' 
                                             : 'text-slate-600 dark:text-[#B5BAC1] hover:bg-[#e3e5e8]/60 dark:hover:bg-[#3F4147]/40 hover:text-slate-800 dark:hover:text-[#DBDEE1]'
                                          }`}
                                       >
                                          <item.icon size={17.5} className={item.id === 'logout' ? 'text-rose-500' : isActive ? 'text-indigo-650 dark:text-white' : ''} />
                                          <span>{item.label}</span>
                                       </button>
                                       {item.children && isActive && (
                                          <div className="mt-1.5 ml-4 pl-3.5 border-l border-slate-300 dark:border-[#333] flex flex-col gap-1.5 relative py-1">
                                             {item.children.map((child: any) => (
                                                <button
                                                   key={child.id}
                                                   onClick={() => {
                                                      setActiveSubTab(child.id);
                                                      const el = document.getElementById(child.id);
                                                      const container = document.getElementById('settings-scroll-container');
                                                      if (el && container) {
                                                         container.scrollTo({ top: el.offsetTop - 100, behavior: 'smooth' });
                                                      }
                                                   }}
                                                   className={`relative text-left text-[14px] font-medium transition-colors py-1 ${
                                                      activeSubTab === child.id 
                                                      ? 'text-slate-800 dark:text-white' 
                                                      : 'text-slate-500 dark:text-[#B5BAC1] hover:text-slate-700 dark:hover:text-[#DBDEE1]'
                                                   }`}
                                                >
                                                   {activeSubTab === child.id && (
                                                      <div className="absolute left-[-16px] top-1/2 -translate-y-1/2 w-[2px] h-3.5 bg-slate-800 dark:bg-white rounded-r-full" />
                                                   )}
                                                   {child.label}
                                                </button>
                                             ))}
                                          </div>
                                       )}
                                    </div>
                                 );
                              })}
                           </div>
                           {idx < filteredSections.length - 1 && section.title !== "Support" && (
                              <div className="h-[1px] bg-slate-300/40 dark:bg-white/5 my-3.5 mx-1.5" />
                           )}
                        </div>
                     ))}
                  </div>

                  <div className="mt-auto pt-4 pb-2 px-2 flex flex-col gap-1 select-none">
                     <p className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400 dark:text-neutral-500">Tradifive Connect</p>
                     <div className="flex items-center justify-between text-[10px] font-semibold text-slate-500 dark:text-neutral-500">
                        <span>v1.4.2 stable build</span>
                        <button onClick={() => setActiveTab('terms')} className="hover:text-indigo-500 dark:hover:text-neutral-300 transition-colors">Terms & Privacy Policy</button>
                     </div>
                  </div>
               </div>
            </div>

            {/* RIGHT CONTENT PANEL inside Modal */}
            <div className="flex-1 bg-white dark:bg-[#121212] h-full overflow-hidden relative flex flex-col">
               
               {/* Fixed Header outside the scrollable container at the top */}
               <div className="bg-white/95 dark:bg-[#1E1E1E]/95 backdrop-blur-sm px-6 py-3 sm:px-8 border-b border-slate-150 dark:border-white/5 flex items-center justify-between shrink-0">
                  <h1 className="text-[13px] font-extrabold text-slate-900 dark:text-white uppercase tracking-wider">
                     {headerTitle}
                  </h1>
                  
                  <button
                      onClick={() => navigate(-1)}
                      className="group flex items-center justify-center w-8 h-8 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-450 hover:text-rose-500 dark:hover:text-rose-400 transition-all hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#FCA5A5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#7F1D1D] active:scale-95 shrink-0"
                      title="Close Settings"
                   >
                      <X size={15} className="transition-transform group-hover:rotate-90 duration-200" />
                   </button>
               </div>

               {/* Scrollable Content Container */}
               <div id="settings-scroll-container" className="w-full flex-1 overflow-y-auto amazing-scrollbar scroll-smooth">

                  {/* Scrollable Content wrapper with padding */}
                  <div className="w-full mx-auto pt-10 px-6 pb-12 sm:px-10 space-y-6">
                     <AnimatePresence mode="wait">

                     {/* TAB 0: ACCOUNT SETTINGS */}
                     {activeTab === 'account' && (
                        <motion.div
                           key="account"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <AccountTab 
                              setActiveSubTab={setActiveSubTab} 
                              onEditProfile={() => setActiveTab('profile')}
                              onEditPhone={() => setShowSmsModal(true)}
                           />
                        </motion.div>
                     )}

                     {/* TAB 1: PROFILE INFORMATION & PRIVACY */}
                     {activeTab === 'profile' && (
                        <motion.div
                           key="profile"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[1100px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />


                           <ProfileTab 
                              profile={profile} 
                              setProfile={setProfile} 
                              privacySettings={privacySettings} 
                              setPrivacySettings={setPrivacySettings} 
                              avatarUploadRef={avatarUploadRef} 
                              bannerUploadRef={bannerUploadRef} 
                           />

                           {/* Hidden inputs triggers */}
                           <input type="file" ref={avatarUploadRef} accept="image/*" className="hidden" onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                 const reader = new FileReader();
                                 reader.onloadend = () => setProfile(p => ({...p, avatarUrl: reader.result as string}));
                                 reader.readAsDataURL(file);
                              }
                           }} />
                           <input type="file" ref={bannerUploadRef} accept="image/*" className="hidden" onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                 const reader = new FileReader();
                                 reader.onloadend = () => setProfile(p => ({...p, bannerUrl: reader.result as string}));
                                 reader.readAsDataURL(file);
                              }
                           }} />

                        </motion.div>
                     )}

                     {/* TAB 2: ACCOUNT & SECURITY */}
                     {activeTab === 'security' && (
                        <motion.div
                           key="security"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           

                           <div className="p-6 rounded-xl bg-slate-50 dark:bg-[#121212] border border-slate-200/50 dark:border-transparent space-y-5">
                              <h4 className="text-[11px] font-semibold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                 <Key size={14} className="text-indigo-650" /> Password Controls
                              </h4>
                              <p className="text-[12px] text-slate-500">Need to update your security credentials? Click below to dispatch an automated secure reset trigger to your registered email.</p>
                              <button 
                                 onClick={() => { toast.success("Password reset token dispatched to registered address."); }}
                                 className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded transition-all shadow-sm"
                              >
                                 Change Password
                              </button>
                           </div>

                           {/* MFA Card */}
                           <div className="p-6 rounded-xl bg-slate-50 dark:bg-[#121212] border border-slate-200/50 dark:border-transparent space-y-5">
                              <div className="flex justify-between items-start">
                                 <div className="space-y-1">
                                    <h4 className="text-[11px] font-semibold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                       <ShieldCheck size={14} className="text-indigo-650" /> Two-Factor Authentication (2FA)
                                    </h4>
                                    <p className="text-[12px] text-slate-500 max-w-md">Protect your Tradifive account with an extra layer of security. Verify logging attempts with an authenticator app (Google Authenticator, Duo).</p>
                                 </div>
                                 <span className="px-2 py-0.5 rounded bg-slate-250 dark:bg-[#121212] text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-widest border border-slate-300 dark:border-transparent">Disabled</span>
                              </div>
                              <button 
                                 onClick={() => { toast.info("Authenticating via SMS code setup modal instead"); setShowSmsModal(true); }}
                                 className="px-5 py-2.5 bg-slate-250 hover:bg-slate-350 dark:bg-[#121212] dark:hover:bg-[#222225] text-slate-800 dark:text-white font-bold text-xs rounded transition-all shadow-sm"
                              >
                                 Enable 2FA Authentication
                              </button>
                           </div>

                           {/* Danger zone */}
                           <div className="p-6 rounded-xl border-2 border-red-500/20 bg-red-50 dark:bg-red-950/5 space-y-5">
                              <div className="space-y-1">
                                 <h4 className="text-[11px] font-semibold text-red-650 dark:text-red-400 uppercase tracking-wider flex items-center gap-2">
                                    <AlertTriangle size={14} /> Danger Zone / Account Suspension
                                 </h4>
                                 <p className="text-[12px] text-red-700/80 dark:text-red-400/80">Deactivating deletes active billing, stops AI sync engines, and hides trading logs instantly. This action cannot be reversed without support verification.</p>
                              </div>
                              <div className="flex gap-4">
                                 <button 
                                    onClick={() => { toast.error("Deactivation request initialized. Check email for details."); }}
                                    className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded transition-all shadow-md active:translate-y-[1px]"
                                 >
                                    Deactivate Account
                                 </button>
                              </div>
                           </div>

                        </motion.div>
                     )}

                     {/* TAB 3: PRIVACY & COMMUNITY */}
                     {activeTab === 'privacy' && (
                        <motion.div
                           key="privacy"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           

                           {/* Select Account Type */}
                           <div className="p-6 rounded-xl bg-slate-50 dark:bg-[#121212] border border-slate-200/50 dark:border-transparent space-y-4">
                              <h4 className="text-[11px] font-semibold text-slate-900 dark:text-white uppercase tracking-wider">Account Type</h4>
                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                 {['personal', 'creator', 'business'].map(type => {
                                    const isActive = privacySettings.account_type === type;
                                    return (
                                       <button
                                          key={type}
                                          type="button"
                                          onClick={() => {
                                             setPrivacySettings((prev: any) => ({
                                                ...prev,
                                                account_type: type,
                                                is_private: type !== 'personal' ? false : prev.is_private
                                             }));
                                             toast.success(`Account switched to ${type.toUpperCase()}`);
                                          }}
                                          className={`p-4 rounded-xl border-2 text-[11px] font-bold uppercase tracking-wider transition-all flex flex-col items-center justify-center gap-2 shadow-sm ${
                                             isActive
                                             ? "bg-indigo-500/5 border-indigo-500 text-indigo-600 dark:text-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.15)]"
                                             : "bg-white dark:bg-[#121212] border-slate-200 dark:border-transparent text-slate-550 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-[#292929]/50"
                                          }`}
                                       >
                                          <span>{type}</span>
                                          {type !== 'personal' && (
                                             <span className="text-[8px] px-1.5 py-0.5 rounded bg-indigo-650 text-white font-extrabold">PRO</span>
                                          )}
                                       </button>
                                    );
                                 })}
                              </div>
                           </div>

                           {/* Visibility list */}
                           <div className="p-6 rounded-xl bg-slate-50 dark:bg-[#121212] border border-slate-200/50 dark:border-transparent space-y-4">
                              <h4 className="text-[11px] font-semibold text-slate-900 dark:text-white uppercase tracking-wider">Analytics Sharing Preferences</h4>
                              
                              <div className="space-y-3">
                                 <div className={`p-4 rounded-lg bg-white dark:bg-[#121212] flex items-center justify-between transition-opacity ${privacySettings.account_type !== 'personal' ? 'opacity-40 pointer-events-none' : ''}`}>
                                    <div className="flex flex-col gap-0.5 max-w-[80%]">
                                       <span className="text-[13px] font-bold text-slate-800 dark:text-white">Private Profile Account</span>
                                       <span className="text-[11px] text-slate-500">Only approved followers can view your feed posts and calendar heatmap.</span>
                                    </div>
                                    <SettingsToggle checked={privacySettings.is_private} onChange={(v) => setPrivacySettings((prev: any) => ({ ...prev, is_private: v }))} disabled={privacySettings.account_type !== 'personal'} />
                                 </div>

                                 {[
                                    { key: "show_location", label: "Share Location Indicators", desc: "Allow community members to view city, state, and flag emojis." },
                                    { key: "show_winrate", label: "Share Win Rate Stats", desc: "Publicly showcase win rate metrics in feed panels." },
                                    { key: "show_roi", label: "Share ROI (All Time)", desc: "Render active PnL curve percentages on public profiles." },
                                    { key: "show_streak", label: "Share Active Trading Streaks", desc: "Show consecutive green/red trading days." },
                                    { key: "show_trades", label: "Share Active Trade Ledger", desc: "Allows open viewing of individual position histories." }
                                 ].map((item) => (
                                    <div key={item.key} className="p-4 rounded-lg bg-white dark:bg-[#121212] flex items-center justify-between">
                                       <div className="flex flex-col gap-0.5 max-w-[80%]">
                                          <span className="text-[13px] font-bold text-slate-800 dark:text-white">{item.label}</span>
                                          <span className="text-[11px] text-slate-500">{item.desc}</span>
                                       </div>
                                       <SettingsToggle checked={privacySettings[item.key]} onChange={(v) => setPrivacySettings((prev: any) => ({ ...prev, [item.key]: v }))} />
                                    </div>
                                 ))}
                              </div>
                           </div>

                        </motion.div>
                     )}

                     {/* TAB 4: APPEARANCE */}
                     {activeTab === 'appearance' && (
                        <motion.div
                           key="appearance"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              Appearance
                           </h2>
                           <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-4">
                              Customize how the app looks and feels across all your devices. Tweak lighting, colors, and layout density to create your perfect workspace.
                           </p>

                           {/* Color Theme Box */}
                           <div className="bg-slate-50 dark:bg-[#151515] p-5 rounded-2xl border border-slate-200 dark:border-[#2a2a2a] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6 mt-4">
                              <div className="flex gap-4">
                                 <div className="w-10 h-10 rounded-full bg-slate-200/60 dark:bg-[#202022] flex items-center justify-center shrink-0 text-slate-600 dark:text-slate-300">
                                    {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
                                 </div>
                                 <div className="space-y-1">
                                    <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-1">Global Color Theme</h3>
                                    <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] max-w-md">
                                       Toggles the full lighting environment across the entire application interface. Changes are applied instantly.
                                    </p>
                                 </div>
                              </div>
                              <ThemeSwitch checked={theme === 'dark'} onChange={() => handleThemeChange(theme === 'dark' ? 'light' : 'dark')} />
                           </div>

                        </motion.div>
                     )}


                     {/* TAB 6: NOTIFICATIONS */}
                     {activeTab === 'notifications' && (
                        <motion.div
                           key="notifications"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 dark:border-[#3f4147] pb-4 mb-6">
                              <h2 className="text-[20px] font-bold text-slate-900 dark:text-white">
                                 Notifications
                              </h2>
                              {/* Global Control Hub */}
                              <div className="flex items-center gap-3 text-[12px] font-bold">
                                 <button 
                                    onClick={handleGlobalOff} 
                                    className="group flex items-center justify-center gap-2 h-8 px-4 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-500 dark:text-slate-400 hover:text-rose-500 dark:hover:text-rose-400 transition-all hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#FCA5A5] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#7F1D1D] active:scale-95 shrink-0"
                                 >
                                    <Power size={14} className="transition-transform group-hover:scale-110 duration-200" /> Switch off all
                                 </button>
                                 <button 
                                    onClick={handleEmailOnly} 
                                    className="group flex items-center justify-center gap-2 h-8 px-4 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-500 dark:text-slate-400 hover:text-indigo-500 dark:hover:text-indigo-400 transition-all hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#A5B4FC] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#3730A3] active:scale-95 shrink-0"
                                 >
                                    <Mail size={14} className="transition-transform group-hover:scale-110 duration-200" /> Email only
                                 </button>
                              </div>
                           </div>
                           <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-8">Configure push alerts, app notifications, security reminders, and emails.</p>

                           {/* Sections iteration */}
                           {[
                              { key: 'messages', title: 'Message Preferences', desc: 'Alerts for direct messages, groups, and @username mentions.', icon: MessageSquare },
                              { key: 'text', title: 'SMS Security Alerts', desc: 'Secure phone log alerts and promotional bulletins.', icon: Smartphone },
                              { key: 'alerts', title: 'Trading Execution Alerts', desc: 'Price ticks, target alerts, and risk guard parameters.', icon: AlertTriangle },
                              { key: 'ai_coach', title: 'AI Coach Notifications', desc: 'Insights, performance reports, and coaching suggestions.', icon: Brain },
                              { key: 'channels', title: 'Channels & Communities', desc: 'Announcements, replies, and channel activities.', icon: Hash },
                              { key: 'inboxes', title: 'Inboxes & Networking', desc: 'Friend requests, invites, and community news.', icon: Inbox }
                           ].map((section) => (
                              <div key={section.key} className="space-y-6 p-6 rounded-xl bg-slate-50 dark:bg-[#1a1b1e]">
                                 <div className="flex gap-4 items-start">
                                    <div className="w-10 h-10 bg-[#1e1f22] rounded-full flex items-center justify-center shrink-0 text-[#DBDEE1]">
                                       <section.icon size={18} />
                                    </div>
                                    <div>
                                       <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-1">{section.title}</h3>
                                       <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">{section.desc}</p>
                                    </div>
                                 </div>

                                 <div className="space-y-1">
                                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 dark:text-[#80848e] uppercase tracking-wider mb-2">
                                       <span>Event Type</span>
                                       <div className="flex text-center w-48 justify-end">
                                          <span className="w-16">Push</span>
                                          <span className="w-16">App</span>
                                          <span className="w-16">Email</span>
                                       </div>
                                    </div>

                                    {(notifications as any)[section.key].map((notif: any) => (
                                       <div key={notif.id} className="flex items-center justify-between py-2 group">
                                          <span className="text-[15px] font-medium text-slate-800 dark:text-[#DBDEE1] pr-4">{notif.label}</span>
                                          <div className="flex justify-end w-48 shrink-0">
                                             <div className="w-16 flex justify-center">
                                                <AnimatedCheckbox checked={notif.push} onChange={() => handleToggle(section.key, notif.id, 'push')} />
                                             </div>
                                             <div className="w-16 flex justify-center">
                                                <AnimatedCheckbox checked={notif.app} onChange={() => handleToggle(section.key, notif.id, 'app')} />
                                             </div>
                                             <div className="w-16 flex justify-center">
                                                <AnimatedCheckbox checked={notif.email} onChange={() => handleToggle(section.key, notif.id, 'email')} />
                                             </div>
                                          </div>
                                       </div>
                                    ))}
                                 </div>
                              </div>
                           ))}
                        </motion.div>
                     )}

                     {/* TAB 7: AI ASSISTANT */}
                     {activeTab === 'ai' && (
                        <motion.div
                           key="ai"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              AI Assistant
                           </h2>
                           <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-8">Configure your AI Coach's tone, voice, and analysis frequency.</p>

                           {/* AI Credits Card */}
                           <div className="p-6 rounded-xl border-2 border-indigo-500/20 bg-indigo-50/50 dark:bg-indigo-500/10 shadow-sm flex flex-col gap-4">
                              <div className="flex items-center justify-between">
                                 <div className="space-y-1">
                                    <h3 className="text-[16px] font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                       <Sparkles size={16} className="text-indigo-600" /> AI Usage & Credits
                                    </h3>
                                    <p className="text-[13px] text-slate-600 dark:text-slate-400 max-w-md">
                                       Your Elite plan includes high-tier AI inference bandwidth. Each prompt consumes 1 credit.
                                    </p>
                                 </div>
                                 <div className="text-right">
                                    <p className="text-3xl font-black text-indigo-600 dark:text-indigo-400 tracking-tight">
                                       {aiCredits} <span className="text-sm font-semibold text-slate-500">/ 50</span>
                                    </p>
                                    <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Credits Remaining</p>
                                 </div>
                              </div>
                              <div className="w-full bg-indigo-200 dark:bg-indigo-950/50 rounded-full h-2 mt-2">
                                 <div 
                                    className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full" 
                                    style={{ width: `${Math.min(100, Math.max(0, (aiCredits / 50) * 100))}%` }}
                                 />
                              </div>
                              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 mt-4">
                                 <div className="flex items-center gap-2">
                                    <button 
                                       onClick={() => {
                                          const newAmount = aiCredits + 50;
                                          setAiCredits(newAmount);
                                          localStorage.setItem(`tradifive_ai_credits_${globalUserId}`, String(newAmount));
                                          toast.success("50 AI Credits added! (₹50)");
                                       }}
                                       className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-all shadow-md"
                                    >
                                       +50 (₹50)
                                    </button>
                                    <button 
                                       onClick={() => {
                                          const newAmount = aiCredits + 100;
                                          setAiCredits(newAmount);
                                          localStorage.setItem(`tradifive_ai_credits_${globalUserId}`, String(newAmount));
                                          toast.success("100 AI Credits added! (₹100)");
                                       }}
                                       className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-all shadow-md"
                                    >
                                       +100 (₹100)
                                    </button>
                                 </div>
                                 
                                 <div className="flex items-center gap-2 w-full sm:w-auto">
                                    <input 
                                       type="number" 
                                       placeholder="Custom ₹" 
                                       value={customTopupAmount}
                                       onChange={(e) => setCustomTopupAmount(e.target.value)}
                                       className="w-24 px-3 py-2 bg-white dark:bg-[#1C1C1E] border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-bold text-slate-800 dark:text-white outline-none focus:border-indigo-500 transition-colors"
                                    />
                                    <button 
                                       onClick={() => {
                                          const val = parseInt(customTopupAmount);
                                          if (isNaN(val) || val <= 0) {
                                             toast.error("Enter a valid amount");
                                             return;
                                          }
                                          const newAmount = aiCredits + val;
                                          setAiCredits(newAmount);
                                          localStorage.setItem(`tradifive_ai_credits_${globalUserId}`, String(newAmount));
                                          setCustomTopupAmount("");
                                          toast.success(`${val} AI Credits added! (₹${val})`);
                                       }}
                                       className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-all shadow-md whitespace-nowrap"
                                    >
                                       Top Up
                                    </button>
                                 </div>
                              </div>
                           </div>

                           {/* Tone */}
                           <div className="p-6 rounded-xl bg-white dark:bg-[#1a1b1e] border border-slate-200/80 dark:border-white/5 shadow-sm transition-all hover:border-slate-300 dark:hover:border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                              <div className="space-y-1 max-w-md">
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-1">AI Coach Tone</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">Pick how the AI Coach behaves when reviewing trades.</p>
                              </div>
                              <select 
                                 value={aiTone} 
                                 onChange={e => { setAiTone(e.target.value); toast.success(`AI Coach tone updated to: ${e.target.value}`); }} 
                                 className="w-full md:w-64 bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50"
                              >
                                 <option value="strict">Strict & Disciplined</option>
                                 <option value="supportive">Encouraging & Supportive</option>
                                 <option value="analytical">Analytical & Data-Driven</option>
                                 <option value="sarcastic">Passive-Sarcastic</option>
                              </select>
                           </div>

                           {/* Voice */}
                           <div className="p-6 rounded-xl bg-white dark:bg-[#1a1b1e] border border-slate-200/80 dark:border-white/5 shadow-sm transition-all hover:border-slate-300 dark:hover:border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                              <div className="space-y-1 max-w-md">
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-1">Voice Model Profile</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">TTS profile for reading alert messages aloud.</p>
                              </div>
                              <select 
                                 value={aiVoice} 
                                 onChange={e => { setAiVoice(e.target.value); toast.success(`Voice profile updated!`); }} 
                                 className="w-full md:w-64 bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50"
                              >
                                 <option value="female">Sophia (Female)</option>
                                 <option value="male">Alexander (Male)</option>
                                 <option value="robotic">T-800 (Robotic Synth)</option>
                              </select>
                           </div>

                           {/* Frequencies */}
                           <div className="p-6 rounded-xl bg-white dark:bg-[#1a1b1e] border border-slate-200/80 dark:border-white/5 shadow-sm transition-all hover:border-slate-300 dark:hover:border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                              <div className="space-y-1 max-w-md">
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-1">Review Frequency Cycle</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">Configure how often AI inspects open positions.</p>
                              </div>
                              <select 
                                 value={aiFrequency} 
                                 onChange={e => { setAiFrequency(e.target.value); toast.success(`Feedback cycles updated!`); }} 
                                 className="w-full md:w-64 bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50"
                              >
                                 <option value="realtime">Real-time alerts</option>
                                 <option value="daily">Daily digests</option>
                                 <option value="weekly">Weekly performance logs</option>
                                 <option value="manual">Manual triggers only</option>
                              </select>
                           </div>
                        </motion.div>
                     )}

                     {/* TAB 8: BROKER & INTEGRATIONS */}
                     {activeTab === 'trading' && (
                        <motion.div
                           key="trading"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[1100px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              Broker & Integrations
                           </h2>
                           <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-8">Manage your connected trading accounts and third-party integrations.</p>

                           {/* Connected Brokers Box */}
                           <div className="p-6 rounded-2xl border border-slate-200/60 dark:border-[#2a2a2a] bg-slate-50 dark:bg-[#151515]">
                              <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-6">Connected Brokers</h3>
                              
                              {connectedBroker ? (
                                 <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-lg bg-white dark:bg-[#121212] mb-4">
                                    <div className="flex items-center gap-4">
                                       <div className="w-10 h-10 flex items-center justify-center bg-slate-100 dark:bg-[#1e1f22] rounded-lg shrink-0">
                                          <BrokerIcon name={connectedBroker} size={24} />
                                       </div>
                                       <div className="min-w-[120px]">
                                          <span className="text-[15px] font-bold text-slate-800 dark:text-[#DBDEE1] block capitalize">{connectedBroker === 'icmarkets' ? 'IC Markets' : connectedBroker}</span>
                                          <div className="flex items-center gap-1.5 mt-0.5">
                                             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                                             <span className="text-[11px] font-medium text-emerald-600 dark:text-emerald-500">Connected</span>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 items-center w-full md:w-auto flex-grow md:pl-10">
                                       <div>
                                          <p className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-1">Account ID</p>
                                          <p className="text-[14px] font-medium text-slate-800 dark:text-[#DBDEE1]">XX1234</p>
                                       </div>
                                       <div>
                                          <p className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-1">Server</p>
                                          <p className="text-[14px] font-medium text-slate-800 dark:text-[#DBDEE1] capitalize">{connectedBroker} Live</p>
                                       </div>
                                       <div>
                                          <p className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-1">Last Sync</p>
                                          <p className="text-[14px] font-medium text-slate-800 dark:text-[#DBDEE1]">{lastSyncedTime || '2 mins ago'}</p>
                                       </div>
                                       <div className="flex items-center gap-3 justify-end md:ml-auto">
                                          <button 
                                             onClick={handleForceSync}
                                             disabled={isSyncing}
                                             className="flex items-center gap-2 px-3 py-1.5 rounded border border-slate-200/60 dark:border-[#2a2a2a] bg-white dark:bg-[#151515] hover:bg-slate-50 dark:hover:bg-[#202022] text-slate-700 dark:text-white transition-all text-[12px] font-bold shadow-sm shrink-0"
                                          >
                                             <RefreshCw size={12} className={isSyncing ? 'animate-spin' : ''} />
                                             Sync Now
                                          </button>
                                          <button onClick={() => { setConnectedBroker(''); toast.info("Broker disconnected."); }} className="text-slate-400 hover:text-rose-500 transition-colors" title="Disconnect Broker">
                                             <MoreVertical size={16} />
                                          </button>
                                       </div>
                                    </div>
                                 </div>
                              ) : (
                                 <div className="p-8 text-center bg-white dark:bg-[#121212] rounded-lg mb-4">
                                    <p className="text-[13px] text-slate-500 font-medium">No broker connected yet.</p>
                                 </div>
                              )}
                              <div className="border-t border-slate-200/60 dark:border-[#2a2a2a] pt-4 text-center mt-2">
                                 <button className="text-[12px] font-bold text-indigo-500 hover:text-indigo-400 flex items-center justify-center gap-1 mx-auto">
                                    View all connected brokers <ArrowRight size={12} />
                                 </button>
                              </div>
                           </div>

                           <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                              {/* Available Brokers */}
                              <div className="p-5 sm:p-6 rounded-2xl border border-slate-200/60 dark:border-[#2a2a2a] bg-slate-50 dark:bg-[#151515] shadow-sm flex flex-col">
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-1">Available Brokers</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-6">Connect a new broker to get started.</p>
                                 
                                 <div className="space-y-3 flex-grow">
                                    {[
                                       { id: "zerodha", label: "Zerodha", desc: "India's largest retail broker" },
                                       { id: "upstox", label: "Upstox", desc: "Fast, reliable trading platform" },
                                       { id: "dhan", label: "Dhan", desc: "Modern trading, simplified" },
                                       { id: "angelone", label: "Angel One", desc: "Smart investing, expert insights" },
                                       { id: "sharekhan", label: "Sharekhan", desc: "Trusted by millions" }
                                    ].map((item) => (
                                       <div key={item.id} className="flex items-center justify-between py-1 group">
                                          <div className="flex items-center gap-4">
                                             <div className="w-10 h-10 rounded-xl overflow-hidden flex items-center justify-center bg-white dark:bg-[#121212] shrink-0 border border-slate-200/60 dark:border-[#2a2a2a]">
                                                <BrokerIcon name={item.id} size={22} />
                                             </div>
                                             <div>
                                                <span className="text-[15px] font-bold text-slate-800 dark:text-[#DBDEE1] block group-hover:text-indigo-500 transition-colors">{item.label}</span>
                                                <span className="text-[13px] text-slate-500 dark:text-[#B5BAC1] block mt-0.5">{item.desc}</span>
                                             </div>
                                          </div>
                                          <button 
                                             onClick={() => { setSelectedBrokerToConnect(item.id); setShowBrokerConnectModal(true); }}
                                             className="px-4 py-1.5 rounded-full border border-slate-300 dark:border-[#2a2a2a] hover:bg-slate-100 dark:hover:bg-[#202022] text-[11px] font-bold text-slate-700 dark:text-white transition-colors"
                                          >
                                             Connect
                                          </button>
                                       </div>
                                    ))}
                                 </div>
                                 
                                 <div className="border-t border-slate-200/60 dark:border-[#2a2a2a] pt-4 text-center mt-6">
                                    <button className="text-[12px] font-bold text-indigo-500 hover:text-indigo-400 flex items-center justify-center gap-1 mx-auto">
                                       View all brokers <ArrowRight size={12} />
                                    </button>
                                 </div>
                              </div>

                              {/* Integrations */}
                              <div className="p-5 sm:p-6 rounded-2xl border border-slate-200/60 dark:border-[#2a2a2a] bg-slate-50 dark:bg-[#151515] shadow-sm flex flex-col">
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-1">Integrations</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-6">Connect tools and platforms you use.</p>
                                 
                                 <div className="space-y-3 flex-grow">
                                    {[
                                       { id: "tradingview", label: "TradingView", desc: "Advanced charting & analysis", icon: "https://upload.wikimedia.org/wikipedia/commons/9/94/TradingView_Logo.png", active: true },
                                       { id: "telegram", label: "Telegram", desc: "Get trade alerts & updates", icon: "https://upload.wikimedia.org/wikipedia/commons/8/82/Telegram_logo.svg", active: true },
                                       { id: "gcal", label: "Google Calendar", desc: "Track events & trading schedule", icon: "https://upload.wikimedia.org/wikipedia/commons/a/a5/Google_Calendar_icon_%282020%29.svg", active: false },
                                       { id: "slack", label: "Slack", desc: "Team notifications & alerts", icon: "https://upload.wikimedia.org/wikipedia/commons/d/d5/Slack_icon_2019.svg", active: false }
                                    ].map((item) => (
                                       <div key={item.id} className="flex items-center justify-between py-1 group cursor-pointer" onClick={() => toast.success(`${item.label} settings opened.`)}>
                                          <div className="flex items-center gap-4">
                                             <div className="w-10 h-10 rounded-xl overflow-hidden flex items-center justify-center bg-white dark:bg-[#121212] shrink-0 border border-slate-200/60 dark:border-[#2a2a2a]">
                                                <img src={item.icon} alt={item.label} className="w-5 h-5 object-contain" />
                                             </div>
                                             <div>
                                                <span className="text-[15px] font-bold text-slate-800 dark:text-[#DBDEE1] block group-hover:text-indigo-500 transition-colors">{item.label}</span>
                                                <span className="text-[13px] text-slate-500 dark:text-[#B5BAC1] block mt-0.5">{item.desc}</span>
                                             </div>
                                          </div>
                                          <div className={`w-9 h-5 rounded-full flex items-center px-0.5 transition-colors ${item.active ? 'bg-indigo-500' : 'bg-slate-300 dark:bg-[#2b2d31]'}`}>
                                             <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${item.active ? 'translate-x-4' : 'translate-x-0'}`} />
                                          </div>
                                       </div>
                                    ))}
                                 </div>
                                 
                                 <div className="border-t border-slate-200/60 dark:border-[#2a2a2a] pt-4 text-center mt-6">
                                    <button className="text-[12px] font-bold text-indigo-500 hover:text-indigo-400 flex items-center justify-center gap-1 mx-auto">
                                       View all integrations <ArrowRight size={12} />
                                    </button>
                                 </div>
                              </div>
                           </div>

                           {/* Security Info */}
                           <div className="mt-8 flex items-center gap-4">
                              <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-[#121212] border border-slate-200 dark:border-[#2b2d31] flex items-center justify-center text-slate-700 dark:text-white shrink-0">
                                 <ShieldCheck size={20} />
                              </div>
                              <div>
                                 <h4 className="text-[13px] font-extrabold text-slate-900 dark:text-white">Your data is secure</h4>
                                 <p className="text-[11px] font-medium text-slate-500 mt-0.5 max-w-xl">We use bank-level encryption to keep your broker credentials safe. Read our <span className="text-indigo-500 cursor-pointer hover:underline font-bold">security policy</span></p>
                              </div>
                           </div>

                        </motion.div>
                     )}

                     {/* TAB 9: BILLING & PLANS */}
                     {activeTab === 'billing_plans' && (
                        <motion.div
                           key="billing_plans"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-8 w-full max-w-[1100px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              Tradifive Plans & Pricing
                           </h2>
                           <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-8">Choose the tier that fits your trading volume and intelligence needs. Upgrade or downgrade anytime, no hidden fees.</p>

                           <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
                              {/* Basic Plan */}
                              <div 
                                 onClick={() => setSelectedPlan('starter')}
                                 className={`cursor-pointer p-6 rounded-[32px] border-[2px] transition-all duration-300 flex flex-col relative overflow-hidden ${
                                    selectedPlan === 'starter' 
                                    ? 'border-slate-300 dark:border-[#444] bg-gradient-to-b from-[#FFFFFF] to-[#F4F4F5] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_8px_30px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#CBD5E1] dark:shadow-[0_8px_30px_-5px_rgba(0,0,0,0.4),0_0_0_2px_#555] md:-translate-y-2 scale-[1.02] z-10' 
                                    : 'border-transparent dark:border-transparent bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#1C1C1E] dark:to-[#121214] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_1px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_1px_#2B2B2F] hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.05),0_0_0_1px_#CBD5E1] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.2),0_0_0_1px_#3f4148]'
                                 }`}
                              >
                                 {/* Faded Background Logo & Glow */}
                                 <div className="absolute -bottom-10 -right-10 z-0 pointer-events-none opacity-[0.08] dark:opacity-[0.05] transform -rotate-12 grayscale">
                                    <img src={logoOnly} alt="" className="w-[200px] h-[200px] object-contain" />
                                 </div>
                                 <div className={`absolute -bottom-10 -right-10 w-64 h-64 bg-amber-500/15 dark:bg-amber-500/10 blur-3xl rounded-full z-0 pointer-events-none transition-opacity duration-700 ${selectedPlan === 'starter' ? 'opacity-100' : 'opacity-0'}`}></div>

                                 <h3 className="text-[16px] font-bold text-slate-800 dark:text-white mb-2 relative z-10">Starter</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-6 min-h-[36px]">Perfect for beginners starting their trading journey.</p>
                                 <div className="flex items-baseline gap-1 mb-6">
                                    <span className="text-[32px] font-extrabold text-slate-900 dark:text-white">$0</span>
                                    <span className="text-[12px] font-medium text-slate-500">/ forever</span>
                                 </div>
                                 <button className="w-full flex items-center justify-center h-10 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-700 dark:text-slate-300 font-bold text-[12px] hover:text-slate-600 dark:hover:text-slate-100 transition-all hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.05),0_0_0_2px_#CBD5E1] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.2),0_0_0_2px_#3f4148] active:scale-95 mb-8">Current Plan</button>
                                 
                                 <div className="space-y-2 flex-grow">
                                    <h4 className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-3">Includes:</h4>
                                    {[
                                       "Track your trades automatically",
                                       "1 Broker connection",
                                       "Trading journal access",
                                       "Basic AI trading insights",
                                       "Community access",
                                       "Risk Guard protection",
                                       "20 AI Coach Credits/day",
                                       "Earn XP & rewards"
                                    ].slice(0, starterExpanded ? undefined : 4).map((feature, i) => (
                                       <div key={i} className="flex items-start gap-2">
                                          <Check size={13} className="text-slate-400 mt-[3px] shrink-0" />
                                          <span className="text-[12px] font-medium text-slate-800 dark:text-[#DBDEE1] leading-tight">{feature}</span>
                                       </div>
                                    ))}
                                    <div className="pt-1 text-center">
                                       <button 
                                          onClick={(e) => { e.stopPropagation(); setStarterExpanded(!starterExpanded); }}
                                          className="text-[11px] font-bold text-slate-500 hover:text-slate-700 dark:text-[#949ba4] dark:hover:text-slate-300 transition-colors cursor-pointer"
                                       >
                                          {starterExpanded ? 'Show less' : 'Show all 8 features'}
                                       </button>
                                    </div>
                                 </div>
                              </div>

                              {/* Pro Plan */}
                              <div 
                                 onClick={() => setSelectedPlan('pro')}
                                 className={`cursor-pointer p-6 rounded-[32px] border-[2px] transition-all duration-300 flex flex-col relative overflow-hidden ${
                                    selectedPlan === 'pro' 
                                    ? 'border-[#fbbf24] dark:border-[#f59e0b]/80 bg-gradient-to-b from-[#f59e0b]/5 to-transparent dark:from-[#78350f]/20 dark:to-[#121214] shadow-[0_8px_20px_-5px_rgba(245,158,11,0.2)] md:-translate-y-2 scale-[1.02] z-10' 
                                    : 'border-[#fde68a] dark:border-[#f59e0b]/30 bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#1C1C1E] dark:to-[#121214] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12)] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3)] hover:border-[#fbbf24] dark:hover:border-[#f59e0b]/60 hover:shadow-[0_8px_15px_-5px_rgba(245,158,11,0.15)]'
                                 }`}
                              >
                                 {/* Faded Background Logo & Glow */}
                                 <div className="absolute -top-8 -right-8 z-0 pointer-events-none opacity-[0.05] dark:opacity-[0.08] transform rotate-12 mix-blend-overlay">
                                    <img src={logoOnly} alt="" className="w-[200px] h-[200px] object-contain" />
                                 </div>
                                 <div className="absolute top-0 right-0 w-40 h-40 bg-amber-500/10 blur-3xl rounded-full z-0 pointer-events-none mix-blend-screen"></div>
                                 

                                 {/* Floating Glassy Badge at Full Corner */}
                                 <div className="absolute top-0 right-0 px-4 py-2 bg-white/5 border-l border-b border-white/10 backdrop-blur-md text-amber-500 dark:text-amber-400 text-[9px] font-extrabold uppercase tracking-widest rounded-bl-[24px] rounded-tr-[32px] flex items-center gap-1 z-20 shadow-sm">
                                    Most Popular
                                 </div>

                                 <h3 className="text-[16px] font-bold text-slate-800 dark:text-white mb-2 flex items-center gap-2 relative z-10">
                                    Pro <Sparkles size={16} className="text-amber-500" />
                                 </h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-6 min-h-[36px]">Built for traders who want consistency and discipline.</p>
                                 <div className="flex items-baseline gap-1 mb-6">
                                    <span className="text-[32px] font-extrabold text-slate-900 dark:text-white">$29</span>
                                    <span className="text-[12px] font-medium text-slate-500">/ month</span>
                                 </div>
                                 <button 
                                    onClick={() => toast.success("Checkout process initialized! Thank you.")}
                                    className="w-full flex items-center justify-center h-10 rounded-full border-2 border-[#fcd34d]/40 dark:border-[#fbbf24]/30 bg-gradient-to-b from-amber-500 to-amber-600 dark:from-amber-600 dark:to-amber-700 shadow-[0_4px_7px_-5px_rgba(245,158,11,0.4),0_0_0_2px_rgba(245,158,11,0.2)] text-white font-bold text-[12px] hover:brightness-110 transition-all hover:shadow-[0_8px_15px_-5px_rgba(245,158,11,0.6),0_0_0_2px_rgba(245,158,11,0.4)] active:scale-95 mb-8"
                                 >
                                    Upgrade to Pro
                                 </button>
                                 
                                 <div className="space-y-2 flex-grow">
                                    <h4 className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-3">Everything in Starter, plus:</h4>
                                    {[
                                       "Real-time AI trade coaching",
                                       "Up to 6 broker connections",
                                       "Daily performance reports",
                                       "Advanced Risk Guard controls",
                                       "Voice notes with AI Coach",
                                       "AI detects revenge trading behavior",
                                       "Faster trade synchronization",
                                       "VIP trader channels access",
                                       "100 AI Coach Credits/day",
                                       "Join 1 Trading Competition/month",
                                       "Advanced performance analytics",
                                       "Priority support"
                                    ].slice(0, proExpanded ? undefined : 4).map((feature, i) => (
                                       <div key={i} className="flex items-start gap-2">
                                          <CheckCircle size={13} className="text-amber-500 mt-[3px] shrink-0" />
                                          <span className="text-[12px] font-medium text-slate-800 dark:text-[#DBDEE1] leading-tight">{feature}</span>
                                       </div>
                                    ))}
                                    <div className="pt-1 text-center">
                                       <button 
                                          onClick={(e) => { e.stopPropagation(); setProExpanded(!proExpanded); }}
                                          className="text-[11px] font-bold text-amber-600 hover:text-amber-700 dark:text-amber-500 dark:hover:text-amber-400 transition-colors cursor-pointer"
                                       >
                                          {proExpanded ? 'Show less' : 'Show all 12 features'}
                                       </button>
                                    </div>
                                 </div>
                              </div>

                              {/* Elite Plan */}
                              <div 
                                 onClick={() => setSelectedPlan('elite')}
                                 className={`cursor-pointer p-6 rounded-[32px] border-[2px] transition-all duration-300 flex flex-col relative overflow-hidden ${
                                    selectedPlan === 'elite' 
                                    ? 'border-purple-400 dark:border-purple-500/80 bg-gradient-to-b from-purple-50/50 to-[#FFFFFF] dark:from-purple-900/20 dark:to-[#121214] shadow-[0_8px_30px_-5px_rgba(168,85,247,0.25)] md:-translate-y-2 scale-[1.02] z-10' 
                                    : 'border-transparent dark:border-transparent bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#1C1C1E] dark:to-[#121214] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_1px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_1px_#2B2B2F] hover:shadow-[0_8px_15px_-5px_rgba(168,85,247,0.15),0_0_0_1px_#c084fc] dark:hover:border-purple-500/40 dark:hover:shadow-[0_8px_15px_-5px_rgba(168,85,247,0.2)]'
                                 }`}
                              >
                                 {/* Glowing visual effect for elite */}
                                 <div className="absolute -top-10 -left-10 w-40 h-40 bg-purple-500/10 blur-3xl rounded-full z-0 pointer-events-none mix-blend-screen transition-opacity duration-700"></div>

                                 <h3 className="text-[16px] font-bold text-slate-800 dark:text-white mb-2 relative z-10">Elite</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-6 min-h-[36px] relative z-10">Built for traders who want maximum discipline, mentorship, and automation.</p>
                                 <div className="flex items-baseline gap-1 mb-6">
                                    <span className="text-[32px] font-extrabold text-slate-900 dark:text-white">$99</span>
                                    <span className="text-[12px] font-medium text-slate-500">/ month</span>
                                 </div>
                                 <button 
                                    onClick={() => toast.success("Checkout process initialized! Thank you.")}
                                    className="w-full flex items-center justify-center h-10 rounded-full border-2 border-white dark:border-[#1A1A1A] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#212123] dark:to-[#171719] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#2B2B2F] text-slate-700 dark:text-slate-300 font-bold text-[12px] hover:text-slate-600 dark:hover:text-slate-100 transition-all hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.05),0_0_0_2px_#CBD5E1] dark:hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.2),0_0_0_2px_#3f4148] active:scale-95 mb-8"
                                 >
                                    Upgrade to Elite
                                 </button>
                                 
                                 <div className="space-y-2 flex-grow">
                                    <h4 className="text-[11px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-3">Everything in Pro, plus:</h4>
                                    {[
                                       "Unlimited broker connections",
                                       "Mentor account monitoring access",
                                       "Shared trading workspace access",
                                       "AI-assisted automated trading",
                                       "Personal performance reviews",
                                       "Custom Risk Guard controls",
                                       "Advanced trading analytics",
                                       "Early access to new features",
                                       "Dedicated premium support",
                                       "Unlimited AI Coach Credits",
                                       "Join 2 Trading Competitions/month",
                                       "Premium Elite badge & profile perks"
                                    ].slice(0, eliteExpanded ? undefined : 4).map((feature, i) => (
                                       <div key={i} className="flex items-start gap-2">
                                          <Check size={13} className="text-slate-400 mt-[3px] shrink-0" />
                                          <span className="text-[12px] font-medium text-slate-800 dark:text-[#DBDEE1] leading-tight">{feature}</span>
                                       </div>
                                    ))}
                                    <div className="pt-1 text-center">
                                       <button 
                                          onClick={(e) => { e.stopPropagation(); setEliteExpanded(!eliteExpanded); }}
                                          className="text-[11px] font-bold text-purple-600 hover:text-purple-700 dark:text-purple-400 dark:hover:text-purple-300 transition-colors cursor-pointer"
                                       >
                                          {eliteExpanded ? 'Show less' : 'Show all 12 features'}
                                       </button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           
                           {/* Compare Plans Section */}
                           <div className="max-w-4xl mx-auto mt-24 mb-10 space-y-8">
                              <div className="text-center mb-10">
                                 <h3 className="text-[20px] font-bold text-slate-900 dark:text-white mb-2">Compare Features</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">See exactly what you get with each tier to make the best decision for your trading.</p>
                              </div>

                              <div className="overflow-x-auto rounded-[24px] border border-slate-200 dark:border-[#2b2d31] bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#1C1C1E] dark:to-[#121214] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12)] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3)]">
                                 <table className="w-full text-left border-collapse min-w-[700px]">
                                    <thead>
                                       <tr className="border-b border-slate-200 dark:border-[#3f4147]">
                                          <th className="py-5 px-6 text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider w-1/3">Features</th>
                                          <th className="py-5 px-6 text-[14px] font-bold text-slate-800 dark:text-white text-center w-2/9">Starter</th>
                                          <th className="py-5 px-6 text-[14px] font-bold text-amber-600 dark:text-amber-500 text-center w-2/9 border-l border-r border-amber-500/10 dark:border-amber-500/5 bg-amber-500/5 dark:bg-amber-500/[0.02]">
                                             Pro <span className="text-[9px] bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full ml-1 align-middle uppercase tracking-wider font-extrabold">Popular</span>
                                          </th>
                                          <th className="py-5 px-6 text-[14px] font-bold text-indigo-600 dark:text-indigo-400 text-center w-2/9">Elite</th>
                                       </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 dark:divide-[#2b2d31]">
                                       {[
                                          { feature: "Broker Connections", starter: "1", pro: "Up to 6", elite: "Unlimited" },
                                          { feature: "AI Coach Credits", starter: "20/day", pro: "100/day", elite: "Unlimited" },
                                          { feature: "Trade Sync Speed", starter: "Live Sync", pro: "Faster Sync", elite: "Instant Sync" },
                                          { feature: "Risk Guard", starter: "Essential", pro: "Advanced", elite: "Full Control" },
                                          { feature: "Trading Competitions", starter: false, pro: "1/month", elite: "2/month" },
                                          { feature: "Community Access", starter: "Community", pro: "VIP Trader Rooms", elite: "Elite Community" },
                                          { feature: "Support", starter: "Community", pro: "Priority", elite: "Dedicated Manager" },
                                          { feature: "Trading journal access", starter: true, pro: true, elite: true },
                                          { feature: "Basic AI trading insights", starter: true, pro: true, elite: true },
                                          { feature: "Daily performance reports", starter: false, pro: true, elite: true },
                                          { feature: "Voice notes with AI Coach", starter: false, pro: true, elite: true },
                                          { feature: "AI detects revenge trading behavior", starter: false, pro: true, elite: true },
                                          { feature: "Personal performance reviews", starter: false, pro: false, elite: true },
                                          { feature: "Give mentor access", starter: false, pro: false, elite: true },
                                          { feature: "Shared team/workspace", starter: false, pro: false, elite: true },
                                          { feature: "AI-assisted automated trading", starter: false, pro: false, elite: true }
                                       ].map((row, i) => (
                                          <tr key={i} className="hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors">
                                             <td className="py-4 px-6 text-[13px] font-medium text-slate-700 dark:text-[#DBDEE1]">{row.feature}</td>
                                             <td className="py-4 px-6 text-center">
                                                {typeof row.starter === 'boolean' 
                                                   ? (row.starter ? <Check size={16} className="text-emerald-500 mx-auto" /> : <Minus size={16} className="text-slate-300 dark:text-[#444] mx-auto" />)
                                                   : <span className="text-[13px] font-medium text-slate-600 dark:text-[#B5BAC1]">{row.starter}</span>
                                                }
                                             </td>
                                             <td className="py-4 px-6 text-center bg-amber-500/5 dark:bg-amber-500/[0.02] border-l border-r border-amber-500/10 dark:border-amber-500/5">
                                                {typeof row.pro === 'boolean' 
                                                   ? (row.pro ? <Check size={16} className="text-emerald-500 mx-auto" /> : <Minus size={16} className="text-slate-300 dark:text-[#444] mx-auto" />)
                                                   : <span className="text-[13px] font-bold text-slate-800 dark:text-[#DBDEE1]">{row.pro}</span>
                                                }
                                             </td>
                                             <td className="py-4 px-6 text-center">
                                                {typeof row.elite === 'boolean' 
                                                   ? (row.elite ? <Check size={16} className="text-emerald-500 mx-auto" /> : <Minus size={16} className="text-slate-300 dark:text-[#444] mx-auto" />)
                                                   : <span className="text-[13px] font-bold text-indigo-600 dark:text-indigo-400">{row.elite}</span>
                                                }
                                             </td>
                                          </tr>
                                       ))}
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           

                        </motion.div>
                     )}

                     {/* TAB 10: SUBSCRIPTION MANAGEMENT */}
                     {activeTab === 'subscription' && (
                        <motion.div
                           key="subscription"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <div className="flex items-center justify-between mb-8 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              <div>
                                 <h2 className="text-[20px] font-bold text-slate-900 dark:text-white">Subscription & Billing</h2>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mt-1">Manage your plan, payment methods, and billing history.</p>
                              </div>
                              <div className="flex items-center gap-3">
                                 <button 
                                    className="px-5 py-2.5 border border-rose-200/80 dark:border-rose-950/30 bg-rose-50/50 hover:bg-rose-100/60 dark:bg-rose-950/20 dark:hover:bg-rose-950/35 text-[#E23939] dark:text-rose-400 text-[12px] font-bold rounded-full transition-all shadow-sm"
                                 >
                                    Cancel Plan
                                 </button>
                                 <button 
                                    onClick={() => setActiveTab('billing_plans')}
                                    className="px-5 py-2.5 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-[12px] font-bold rounded-full border-none transition-all shadow-md shadow-indigo-600/10 active:scale-[0.98]"
                                 >
                                    Upgrade
                                 </button>
                              </div>
                           </div>

                           <div className="flex flex-col gap-6">
                              {/* Current Plan Overview */}
                              <div className="p-6 rounded-[20px] bg-white dark:bg-[#151515] border border-slate-200/80 dark:border-white/5 relative overflow-hidden shadow-sm">
                                 
                                 <div className="flex items-start justify-between relative z-10 mb-8">
                                    <div className="flex items-center gap-4">
                                       <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center shadow-lg shadow-amber-500/20">
                                          <Crown size={24} className="text-white" />
                                       </div>
                                       <div>
                                          <h3 className="text-[16px] font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-0.5">
                                             Elite 
                                             <span className="px-2 py-0.5 rounded text-emerald-500 text-[10px] font-bold uppercase tracking-wide border border-emerald-500/30 ml-1">Active</span>
                                          </h3>
                                          <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">Billed monthly. Next charge on Jun 25, 2026.</p>
                                       </div>
                                    </div>
                                    <div className="text-right">
                                       <div className="text-[24px] font-black text-slate-900 dark:text-white">$29.00</div>
                                       <div className="text-[12px] text-slate-500 font-medium">per month</div>
                                    </div>
                                 </div>

                                 <div className="grid grid-cols-2 gap-4 relative z-10">
                                    <div className="p-4 rounded-[16px] border border-slate-200 dark:border-[#2b2d31] bg-transparent">
                                       <div className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-1">API Requests</div>
                                       <div className="flex items-center gap-2">
                                          <span className="text-[15px] font-medium text-slate-800 dark:text-[#DBDEE1]">Unlimited</span>
                                          <span className="text-[12px] text-emerald-500 font-medium">Included</span>
                                       </div>
                                    </div>
                                    <div className="p-4 rounded-[16px] border border-slate-200 dark:border-[#2b2d31] bg-transparent">
                                       <div className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wider mb-1">Brokers Linked</div>
                                       <div className="flex items-center gap-2">
                                          <span className="text-[15px] font-medium text-slate-800 dark:text-[#DBDEE1]">4</span>
                                          <span className="text-[12px] text-slate-500 dark:text-[#B5BAC1] font-medium">/ 10 Active</span>
                                       </div>
                                    </div>
                                 </div>
                              </div>

                              {/* Payment Method */}
                              <div className="p-6 rounded-[20px] bg-white dark:bg-[#151515] border border-slate-200/80 dark:border-white/5 flex flex-col relative overflow-hidden shadow-sm">
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2 relative z-10">
                                    <CreditCard size={16} className="text-indigo-500" /> Payment Method
                                 </h3>
                                 
                                 <div className="flex-1 relative z-10">
                                    <div className="p-4 bg-transparent rounded-[16px] border border-slate-200 dark:border-[#2b2d31] mb-6">
                                       <div className="flex items-center gap-3">
                                          <div className="w-10 h-7 rounded bg-[#18274B] text-white flex items-center justify-center font-bold text-[9px] tracking-wider shrink-0 shadow-sm">
                                             VISA
                                          </div>
                                          <div>
                                             <span className="text-[15px] font-bold text-slate-800 dark:text-[#DBDEE1] block">•••• 4242</span>
                                             <span className="text-[13px] text-slate-500 dark:text-[#B5BAC1] block mt-0.5">Expires 08/2029</span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 
                                 <button 
                                    onClick={() => { toast.success("Redirecting to secure Stripe billing portal..."); }}
                                    className="w-full py-3 bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-[12px] font-bold rounded-full border-none transition-all text-center flex items-center justify-center gap-2 relative z-10 shadow-sm"
                                 >
                                    <SettingsIcon size={14} /> Manage in Stripe
                                 </button>
                              </div>
                           </div>

                           {/* Billing History */}
                           <div className="py-2 mt-8">
                              <div className="flex items-center justify-between mb-6">
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                    <Receipt size={16} className="text-slate-400" /> Billing History
                                 </h3>
                                 <button className="px-4 py-2 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 text-[11.5px] font-bold rounded-full border-none transition-all flex items-center gap-1.5 shadow-sm">
                                    <Download size={14} /> Download All
                                 </button>
                              </div>
                              
                              <div className="divide-y divide-slate-100 dark:divide-white/5">
                                 {[
                                    { date: "May 25, 2026", amt: "$29.00", id: "INV-8931", status: "PAID" },
                                    { date: "Apr 25, 2026", amt: "$29.00", id: "INV-7821", status: "PAID" },
                                    { date: "Mar 25, 2026", amt: "$29.00", id: "INV-6210", status: "PAID" }
                                 ].map((item, idx) => (
                                    <div key={idx} className="flex items-center justify-between py-6 group">
                                       <div className="flex items-center gap-4">
                                          <div className="w-10 h-10 rounded-full bg-zinc-100 dark:bg-zinc-900 flex items-center justify-center shrink-0 border border-zinc-200/50 dark:border-white/5">
                                             <FileText size={16} className="text-slate-400" />
                                          </div>
                                          <div>
                                             <span className="text-[15px] font-medium text-slate-800 dark:text-[#DBDEE1] block">{item.date}</span>
                                             <span className="text-[13px] text-slate-500 dark:text-[#B5BAC1] block mt-0.5">Elite • {item.id}</span>
                                          </div>
                                       </div>
                                       <div className="flex items-center gap-6">
                                          <span className="text-[14px] font-bold text-slate-900 dark:text-white">{item.amt}</span>
                                          <div className="flex items-center gap-1 text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded text-[10px] font-bold tracking-wide">
                                             <Check size={12} /> {item.status}
                                          </div>
                                          <button className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 flex items-center justify-center text-zinc-700 dark:text-zinc-200 transition-all border-none hidden sm:flex shadow-sm">
                                             <Download size={14} />
                                          </button>
                                       </div>
                                    </div>
                                 ))}
                              </div>
                           </div>
                        </motion.div>
                     )}

                     {/* TAB 11: CHANNEL SETTINGS */}
                     {activeTab === 'channel' && (
                        <motion.div
                           key="channel"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              Channel Settings
                           </h2>

                           <div className="space-y-8">
                              {/* Channel Privacy Level (Discord Spam filter style) */}
                              <div>
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-1">Channel Privacy Level</h3>
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-4">Determine who can search, view, and interact with posts in your channel.</p>
                                 
                                 <div className="space-y-4">
                                    <div className="flex items-start gap-3 cursor-pointer group" onClick={() => { setFeedVisibility('public'); toast.success('Visibility updated!'); }}>
                                       <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${feedVisibility === 'public' ? 'border-[#5865F2]' : 'border-slate-300 dark:border-[#80848E] group-hover:border-slate-400 dark:group-hover:border-[#DBDEE1]'}`}>
                                          {feedVisibility === 'public' && <div className="w-2.5 h-2.5 rounded-full bg-[#5865F2]"></div>}
                                       </div>
                                       <div>
                                          <div className="text-[15px] font-medium text-slate-800 dark:text-[#DBDEE1]">Public (Everyone)</div>
                                          <div className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">Anyone can search and read posts.</div>
                                       </div>
                                    </div>

                                    <div className="flex items-start gap-3 cursor-pointer group" onClick={() => { setFeedVisibility('request'); toast.success('Visibility updated!'); }}>
                                       <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${feedVisibility === 'request' ? 'border-[#5865F2]' : 'border-slate-300 dark:border-[#80848E] group-hover:border-slate-400 dark:group-hover:border-[#DBDEE1]'}`}>
                                          {feedVisibility === 'request' && <div className="w-2.5 h-2.5 rounded-full bg-[#5865F2]"></div>}
                                       </div>
                                       <div>
                                          <div className="text-[15px] font-medium text-slate-800 dark:text-[#DBDEE1]">Request-Only</div>
                                          <div className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">Users must request access to join and read posts.</div>
                                       </div>
                                    </div>

                                    <div className="flex items-start gap-3 cursor-pointer group" onClick={() => { setFeedVisibility('private'); toast.success('Visibility updated!'); }}>
                                       <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${feedVisibility === 'private' ? 'border-[#5865F2]' : 'border-slate-300 dark:border-[#80848E] group-hover:border-slate-400 dark:group-hover:border-[#DBDEE1]'}`}>
                                          {feedVisibility === 'private' && <div className="w-2.5 h-2.5 rounded-full bg-[#5865F2]"></div>}
                                       </div>
                                       <div>
                                          <div className="text-[15px] font-medium text-slate-800 dark:text-[#DBDEE1]">Private (Paid subscription)</div>
                                          <div className="text-[13px] text-slate-500 dark:text-[#B5BAC1]">Only paid subscribers have access to this channel.</div>
                                       </div>
                                    </div>
                                 </div>
                              </div>

                              {/* Divider */}
                              <div className="h-[1px] w-full bg-slate-200 dark:bg-[#3f4147]"></div>

                              {/* Channel Guidelines */}
                              <div>
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-4">Channel Guidelines</h3>
                                 <textarea
                                    rows={4}
                                    value={channelRules}
                                    onChange={e => setChannelRules(e.target.value)}
                                    className="w-full p-4 rounded-md bg-slate-50 dark:bg-[#1E1F22] border border-transparent text-[14px] text-slate-800 dark:text-[#DBDEE1] outline-none resize-none focus:ring-1 focus:ring-[#5865F2] placeholder-slate-400 dark:placeholder-[#80848E]"
                                    placeholder="Set the rules and guidelines for your channel..."
                                 />
                                 <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mt-2">These rules will be displayed to users before they join your channel.</p>
                              </div>
                           </div>
                        </motion.div>
                     )}

                     {/* TAB 12: CREATOR / BUSINESS ACCOUNT */}
                     {activeTab === 'creator' && (
                        <motion.div
                           key="creator"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-8 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              Creator & Business
                           </h2>

                           {/* Status tracker */}
                           <div className="space-y-4">
                              <div className="flex justify-between items-center">
                                 <h3 className="text-[12px] font-bold text-slate-900 dark:text-white uppercase tracking-wider">Verification Application Status</h3>
                                 <span className="px-3 py-1 rounded bg-indigo-500/10 text-indigo-400 text-[11px] font-bold uppercase tracking-wider border border-indigo-500/20">Under Review</span>
                              </div>
                              <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] leading-relaxed">Our content moderation board is currently validating your trading history and audience metrics. You will receive an automated email notification once approved.</p>
                           </div>

                           <div className="h-px w-full bg-slate-200 dark:bg-[#3f4147] my-8" />

                           {/* Creator options fields */}
                           <div className="space-y-6">
                              <h3 className="text-[12px] font-bold text-slate-900 dark:text-white uppercase tracking-wider">Professional Creator Handle</h3>
                              
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                 <div className="space-y-2">
                                    <label className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wide">Custom Handle</label>
                                    <input 
                                       type="text" 
                                       value={creatorHandle} 
                                       onChange={e => setCreatorHandle(e.target.value)} 
                                       className="w-full bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50"
                                    />
                                 </div>
                                 <div className="space-y-2">
                                    <label className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wide">Category Focus</label>
                                    <select 
                                       value={creatorCategory} 
                                       onChange={e => setCreatorCategory(e.target.value)}
                                       className="w-full bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50"
                                    >
                                       <option value="Day Trading">Day Trading & Scalping</option>
                                       <option value="Swing Trading">Swing Trading Positions</option>
                                       <option value="Options">Options & Derivatives</option>
                                       <option value="Crypto">Crypto Assets</option>
                                    </select>
                                 </div>
                              </div>

                              <div className="space-y-2">
                                 <label className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wide">Professional Bio Summary</label>
                                 <textarea
                                    rows={3}
                                    value={creatorBio}
                                    placeholder="Tell your potential subscribers about your trading philosophy..."
                                    onChange={e => setCreatorBio(e.target.value)}
                                    className="w-full bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50 resize-none"
                                 />
                                 <div className="pt-2">
                                    <ConsistencyToggleButton 
                                       label="Save Details" 
                                       checked={true} 
                                       onChange={() => { toast.success("Creator details updated!"); }} 
                                    />
                                 </div>
                              </div>
                           </div>

                        </motion.div>
                     )}

                     {/* TAB 13: HELP CENTER */}
                     {activeTab === 'help' && (
                        <motion.div
                           key="help"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              Help Center
                           </h2>
                           <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-8">Read FAQ guides or lookup help request ticketing logs.</p>

                           <div className="space-y-3">
                              {[
                                 { id: 1, q: "How do I connect my MT5 broker account?", a: "To link MT5, select the 'Broker & Integrations' tab, select connect for IC Markets, inputs MetaTrader credential fields, and submit. Trades pull instantly." },
                                 { id: 2, q: "Can I cancel my premium subscription anytime?", a: "Yes. Cancel subscriptions at any point using the 'Manage in Stripe Portal' link inside the Subscription Management tab. Services persist until expiry." },
                                 { id: 3, q: "What is the difference between AI Coach tones?", a: "Strict tone checks parameters tightly and issues warning logs on drawdowns. Supportive tone highlights wins and logs encouraging alerts. Analytical maps data metrics." },
                                 { id: 4, q: "Is my trading ledger public by default?", a: "No. All trading ledgers are private by default. Adjust metric share checkboxes under the Privacy & Safety configurations page." }
                              ].map((item) => {
                                 const isOpen = openFaqId === item.id;
                                 return (
                                    <div key={item.id} className="border border-slate-200 dark:border-[#2b2d31] rounded-xl overflow-hidden bg-white dark:bg-[#1a1b1e] transition-colors">
                                       <button
                                          onClick={() => setOpenFaqId(isOpen ? null : item.id)}
                                          className="w-full p-4 flex justify-between items-center text-left text-[15px] font-bold text-slate-800 dark:text-[#DBDEE1] select-none hover:bg-slate-50 dark:hover:bg-[#2b2d31]/50 transition-colors"
                                       >
                                          <span>{item.q}</span>
                                          <ChevronRight size={18} className={`transition-transform duration-200 ${isOpen ? 'rotate-90 text-[#5865F2]' : 'text-slate-400 dark:text-[#80848E]'}`} />
                                       </button>
                                       <AnimatePresence initial={false}>
                                          {isOpen && (
                                             <motion.div
                                                initial={{ height: 0 }}
                                                animate={{ height: 'auto' }}
                                                exit={{ height: 0 }}
                                                className="overflow-hidden border-t border-slate-200 dark:border-[#2b2d31]"
                                             >
                                                <p className="p-4 text-[13px] text-slate-500 dark:text-[#B5BAC1] leading-relaxed">
                                                   {item.a}
                                                </p>
                                             </motion.div>
                                          )}
                                       </AnimatePresence>
                                    </div>
                                 );
                              })}
                           </div>
                        </motion.div>
                     )}

                     {/* TAB 14: REPORT A PROBLEM */}
                     {activeTab === 'report' && (
                        <motion.div
                           key="report"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="space-y-6 w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              Report a Problem
                           </h2>
                           <p className="text-[13px] text-slate-500 dark:text-[#B5BAC1] mb-8">Submit bug tickets, billing issues, or feedback directly to our developer team.</p>

                           <form onSubmit={handleReportSubmit} className="space-y-6">
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                 <div className="space-y-2">
                                    <label className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wide">Category</label>
                                    <select 
                                       value={reportCategory}
                                       onChange={e => setReportCategory(e.target.value)}
                                       className="w-full bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50"
                                    >
                                       <option value="bug">Technical Bug / Glitch</option>
                                       <option value="billing">Billing & Upgrade Invoices</option>
                                       <option value="features">Feature Request Proposal</option>
                                       <option value="feedback">General Platform Feedback</option>
                                    </select>
                                 </div>
                                 <div className="space-y-2">
                                    <label className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wide">Subject Summary</label>
                                    <input 
                                       type="text" 
                                       placeholder="Brief title of the problem"
                                       value={reportSubject} 
                                       onChange={e => setReportSubject(e.target.value)} 
                                       className="w-full bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50"
                                    />
                                 </div>
                              </div>

                              <div className="space-y-2">
                                 <label className="text-[12px] font-bold text-slate-500 dark:text-[#949ba4] uppercase tracking-wide">Description Details</label>
                                 <textarea
                                    rows={5}
                                    placeholder="Explain the steps to reproduce the bug or details regarding the billing question..."
                                    value={reportDescription}
                                    onChange={e => setReportDescription(e.target.value)}
                                    className="w-full bg-white dark:bg-[#1e1f22] border border-slate-300 dark:border-[#2b2d31] rounded-[6px] px-3 py-2.5 text-[15px] font-medium text-slate-800 dark:text-[#dbdee1] outline-none hover:border-slate-400 dark:hover:border-slate-600 transition-colors focus:ring-2 focus:ring-indigo-500/50 resize-none"
                                 />
                              </div>

                              <div className="pt-2">
                                 <button 
                                    type="submit" 
                                    className="px-5 py-1.5 bg-slate-200 hover:bg-slate-300 dark:bg-[#2b2d31] dark:hover:bg-[#3f4147] text-slate-800 dark:text-white font-bold text-[14px] rounded-full transition-colors"
                                 >
                                    Submit Ticket
                                 </button>
                              </div>
                           </form>
                        </motion.div>
                     )}

                     {/* TAB 15: TERMS & PRIVACY POLICY */}
                     {activeTab === 'terms' && (
                        <motion.div
                           key="terms"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           transition={{ duration: 0.2 }}
                           className="w-full max-w-[740px] mx-auto"
                        >
                           <TabHeaderUpdater title={tabTitles[activeTab] || "Settings"} setHeaderTitle={setHeaderTitle} />
                           <h2 className="text-[20px] font-bold text-slate-900 dark:text-white mb-6 border-b border-slate-200 dark:border-[#3f4147] pb-4">
                              Terms & Privacy Policy
                           </h2>
                           
                           <div className="space-y-6 max-h-[60vh] overflow-y-auto amazing-scrollbar pr-4">
                              <div>
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-2">1. User Account Terms</h3>
                                 <p className="text-[14px] text-slate-600 dark:text-[#DBDEE1] leading-relaxed">By connecting a brokerage account or subscribing to the Elite program, you grant Tradifive consent to pull read-only transaction parameters to compute analytics metrics. We will never place orders or manage assets without explicit manual execution authorizations.</p>
                              </div>
                              
                              <div>
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-2">2. Data Security & Storage</h3>
                                 <p className="text-[14px] text-slate-600 dark:text-[#DBDEE1] leading-relaxed">All MetaTrader credentials and token signatures are stored in encrypted vaults utilizing industry-standard AES-256 protocols. Your trade details remain strictly confidential and will never be shared with external third-party agencies unless explicitly toggled in public profile sharing lists.</p>
                              </div>

                              <div>
                                 <h3 className="text-[16px] font-bold text-slate-900 dark:text-white mb-2">3. Trading Risks warning</h3>
                                 <p className="text-[14px] text-slate-600 dark:text-[#DBDEE1] leading-relaxed">AI coaching logs and parameters serve illustrative educational objectives and do not represent financial advisory recommendations. Trading derivatives holds significant risk. You bear all liabilities for drawdown events occurred during broker sync cycles.</p>
                              </div>
                           </div>
                        </motion.div>
                     )}

                  </AnimatePresence>
                  </div>

               </div>
            </div>

         </div>

         {/* EDIT PROFILE DETAILS MODAL */}
         <AnimatePresence>
            {isEditModalOpen && (
               <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                  <motion.div
                     initial={{ opacity: 0, scale: 0.95 }}
                     animate={{ opacity: 1, scale: 1 }}
                     exit={{ opacity: 0, scale: 0.95 }}
                     className="bg-white dark:bg-[#1E1E1E] border border-slate-200/60 dark:border-[#333333] rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl"
                  >
                     <div className="p-6 border-b border-slate-100 dark:border-[#333333] flex justify-between items-center">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white">Edit Profile Details</h3>
                        <button type="button" onClick={() => setIsEditModalOpen(false)} className="text-slate-400 hover:text-slate-650 dark:hover:text-slate-250">
                           <X size={20} />
                        </button>
                     </div>
                     <form onSubmit={(e) => { e.preventDefault(); handleUpdateProfile(); setIsEditModalOpen(false); }} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto amazing-scrollbar">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">First Name</label>
                              <input type="text" value={profile.firstName} onChange={e => setProfile({...profile, firstName: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Last Name</label>
                              <input type="text" value={profile.lastName} onChange={e => setProfile({...profile, lastName: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                        </div>
                        <div>
                           <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Username</label>
                           <input type="text" value={profile.name} onChange={e => setProfile({...profile, name: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                        </div>
                        <div>
                           <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Email</label>
                           <input type="email" value={profile.email} onChange={e => setProfile({...profile, email: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Address</label>
                              <input type="text" value={profile.address || ''} onChange={e => setProfile({...profile, address: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">City</label>
                              <input type="text" value={profile.city || ''} onChange={e => setProfile({...profile, city: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">State</label>
                              <input type="text" value={profile.state || ''} onChange={e => setProfile({...profile, state: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Zip Code</label>
                              <input type="text" value={profile.zipCode || ''} onChange={e => setProfile({...profile, zipCode: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Country</label>
                              <input type="text" value={profile.country || ''} onChange={e => setProfile({...profile, country: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Date of Birth</label>
                              <input type="text" value={profile.dob || ''} onChange={e => setProfile({...profile, dob: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Gender</label>
                              <input type="text" value={profile.gender || ''} onChange={e => setProfile({...profile, gender: e.target.value})} className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                           </div>
                        </div>
                        <div className="pt-4 border-t border-slate-100 dark:border-[#333333] flex justify-end items-center gap-3">
                           <button type="button" onClick={() => setIsEditModalOpen(false)} className="px-5 py-2.5 bg-slate-100 dark:bg-[#2C2C2E] text-slate-700 dark:text-slate-200 font-bold text-xs rounded-xl hover:bg-slate-200 dark:hover:bg-[#3C3C3E] transition-colors">Cancel</button>
                           <ConsistencyToggleButton 
                              label="Save Details" 
                              checked={true} 
                              type="submit" 
                           />
                        </div>
                     </form>
                  </motion.div>
               </div>
            )}
         </AnimatePresence>

         {/* PHONE VERIFICATION MODAL */}
         <AnimatePresence>
            {showSmsModal && (
               <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                  <motion.div
                     initial={{ opacity: 0, scale: 0.95 }}
                     animate={{ opacity: 1, scale: 1 }}
                     exit={{ opacity: 0, scale: 0.95 }}
                     className="bg-white dark:bg-[#1E1E1E] border border-slate-200/60 dark:border-[#333333] rounded-3xl w-full max-w-md overflow-hidden shadow-2xl p-6"
                  >
                     <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white">Add Phone Number</h3>
                        <button type="button" onClick={() => setShowSmsModal(false)} className="text-slate-400 hover:text-slate-655 dark:hover:text-slate-250">
                           <X size={20} />
                        </button>
                     </div>
                     <p className="text-xs text-slate-505 mb-4">Enter your mobile phone number to receive SMS security alerts and code verifications.</p>
                     <div className="space-y-4">
                        <div>
                           <label className="text-xs font-bold text-slate-555 uppercase tracking-wide block mb-1">Phone Number</label>
                           <input type="tel" placeholder="+1 (555) 000-0000" className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                        </div>
                        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-[#333333]">
                           <button type="button" onClick={() => setShowSmsModal(false)} className="px-5 py-2 bg-slate-100 dark:bg-[#2C2C2E] text-slate-700 dark:text-slate-200 font-semibold text-xs rounded-xl hover:bg-slate-200 dark:hover:bg-[#3C3C3E] transition-colors">Cancel</button>
                           <button type="button" onClick={() => { toast.success("Phone number verified successfully!"); setShowSmsModal(false); }} className="px-6 py-2 bg-indigo-650 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-md transition-colors">Save Number</button>
                        </div>
                     </div>
                  </motion.div>
               </div>
            )}
         </AnimatePresence>

         {/* CONNECT BROKER MODAL */}
         <AnimatePresence>
            {showBrokerConnectModal && (
               <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                  <motion.div
                     initial={{ opacity: 0, scale: 0.95 }}
                     animate={{ opacity: 1, scale: 1 }}
                     exit={{ opacity: 0, scale: 0.95 }}
                     className="bg-white dark:bg-[#1E1E1E] border border-slate-200/60 dark:border-[#333333] rounded-3xl w-full max-w-md overflow-hidden shadow-2xl p-6"
                  >
                     <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white capitalize font-sans">Connect {selectedBrokerToConnect}</h3>
                        <button type="button" onClick={() => setShowBrokerConnectModal(false)} className="text-slate-400 hover:text-slate-655 dark:hover:text-slate-255">
                           <X size={20} />
                        </button>
                     </div>
                     <p className="text-xs text-slate-505 mb-4 font-sans">Link your live trading account. Enter your secure API key or login credentials to pull transaction histories.</p>
                     
                     <form onSubmit={handleConnectBrokerSubmit} className="space-y-4">
                        {selectedBrokerToConnect === 'icmarkets' ? (
                           <>
                              <div>
                                 <label className="text-xs font-bold text-slate-555 uppercase tracking-wide block mb-1">MT5 Login ID</label>
                                 <input type="text" required placeholder="e.g. 98310842" className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                              </div>
                              <div>
                                 <label className="text-xs font-bold text-slate-555 uppercase tracking-wide block mb-1">MT5 Investor Password</label>
                                 <input type="password" required className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                              </div>
                           </>
                        ) : (
                           <>
                              <div>
                                 <label className="text-xs font-bold text-slate-555 uppercase tracking-wide block mb-1">API Key Token</label>
                                 <input type="text" required placeholder="KITE-XXXXX or DHAN-XXXXX" className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                              </div>
                              <div>
                                 <label className="text-xs font-bold text-slate-555 uppercase tracking-wide block mb-1">Client ID</label>
                                 <input type="text" required placeholder="User unique ID" className="w-full bg-slate-50 dark:bg-[#202020] border border-slate-200/60 dark:border-[#333333] rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 transition-all" />
                              </div>
                           </>
                        )}
                        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-[#333333]">
                           <button type="button" onClick={() => setShowBrokerConnectModal(false)} className="px-5 py-2 bg-slate-100 dark:bg-[#2C2C2E] text-slate-700 dark:text-slate-200 font-semibold text-xs rounded-xl hover:bg-slate-200 dark:hover:bg-[#3C3C3E] transition-colors">Cancel</button>
                           <button type="submit" className="px-6 py-2 bg-indigo-650 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-md transition-colors">Connect Account</button>
                        </div>
                     </form>
                  </motion.div>
               </div>
            )}
         </AnimatePresence>

      </div>
      </DashboardLayout>
   );
}
