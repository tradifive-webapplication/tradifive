import React, { useState, useRef } from "react";
import { createPortal } from "react-dom";
import { X, Image, Plus, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";

interface CreateStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  userId: string;
}

export default function CreateStoryModal({
  isOpen,
  onClose,
  onSuccess,
  userId,
}: CreateStoryModalProps) {
  const [mediaBase64, setMediaBase64] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast.error("File is too large! Please upload a file smaller than 10MB.");
      return;
    }

    const reader = new FileReader();
    reader.onloadstart = () => setIsSubmitting(true);
    reader.onloadend = () => {
      setMediaBase64(reader.result as string);
      setIsSubmitting(false);
    };
    reader.onerror = () => {
      toast.error("Error reading file");
      setIsSubmitting(false);
    };
    reader.readAsDataURL(file);
  };

  const removeMedia = () => {
    setMediaBase64(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!mediaBase64) {
      toast.error("Please select an image for your story!");
      return;
    }

    setIsSubmitting(true);

    try {
      const newStoryObject = {
        user_id: userId,
        content: "Story",
        media_url: mediaBase64,
        media_type: "image",
        post_type: "story",
        created_at: new Date().toISOString(),
        is_public: true
      };

      const { error } = await supabase.from("social_posts").insert([newStoryObject]);
      
      if (error) {
        console.warn("Supabase insert failed, using fallback:", error);
        throw error;
      }
      
      toast.success("Story published successfully!");
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      // Local fallback
      const localPosts = JSON.parse(localStorage.getItem('fialgo_local_posts') || '[]');
      localPosts.unshift({
        id: `local-story-${Date.now()}`,
        user_id: userId,
        content: "Story",
        media_url: mediaBase64,
        media_type: "image",
        post_type: "story",
        created_at: new Date().toISOString(),
        is_public: true,
        profiles: {
          id: userId,
          full_name: "You",
          username: "you",
          avatar_url: "https://api.dicebear.com/7.x/initials/svg?seed=You"
        }
      });
      localStorage.setItem('fialgo_local_posts', JSON.stringify(localPosts));
      toast.success("Story published successfully (Offline Workspace Backup)!");
      if (onSuccess) onSuccess();
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return createPortal(
    <AnimatePresence>
      <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
        <div 
          className="fixed inset-0 bg-slate-950/75 backdrop-blur-md cursor-pointer" 
          onClick={onClose} 
        />
        <motion.div
          initial={{ opacity: 0, y: 35, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 35, scale: 0.96 }}
          transition={{ duration: 0.22, ease: "easeOut" }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white dark:bg-[#121214] border border-slate-200 dark:border-[#1A1A1A] shadow-2xl flex flex-col relative z-50 w-full max-w-md rounded-3xl overflow-hidden font-sans"
        >
          <div className="p-4 border-b border-slate-100 dark:border-slate-800/60 flex items-center justify-between shrink-0">
            <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              Add to Story
            </h2>
            <button
              onClick={onClose}
              disabled={isSubmitting}
              className="w-8 h-8 rounded-full flex items-center justify-center bg-slate-50 dark:bg-slate-800/40 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X size={16} className="text-slate-500" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-5 flex flex-col gap-5">
            <input
              type="file"
              accept="image/*"
              className="hidden"
              ref={fileInputRef}
              onChange={handleFileChange}
            />

            {mediaBase64 ? (
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-[#1A1A1A] bg-slate-950 aspect-[9/16] flex items-center justify-center shadow-sm cursor-pointer group"
                title="Click image to change"
              >
                <img src={mediaBase64} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-xs font-bold gap-1">
                  <Plus size={18} />
                  <span>Change Image</span>
                </div>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); removeMedia(); }}
                  className="absolute top-3 right-3 bg-black/60 hover:bg-black/90 text-white rounded-full p-1.5 transition-colors z-10 shadow-lg"
                >
                  <X size={14} />
                </button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-200 dark:border-[#1A1A1A] rounded-2xl bg-slate-50/50 dark:bg-[#1C1C1E]/20 hover:bg-slate-50 dark:hover:bg-[#1C1C1E]/40 cursor-pointer flex flex-col items-center justify-center text-center transition-all group relative aspect-[9/16]"
              >
                <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800/80 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-3 group-hover:scale-110 transition-transform">
                  <Image size={24} />
                </div>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-350">
                  Select photo for your story
                </p>
                <p className="text-xs text-slate-400 mt-2 max-w-[200px]">
                  Stories disappear after 24 hours. Only image format is supported.
                </p>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting || !mediaBase64}
              className={`w-full py-3.5 rounded-xl text-sm font-bold shadow-md transition-all ${
                !mediaBase64 || isSubmitting
                  ? "bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed"
                  : "bg-zinc-800 hover:bg-zinc-700 dark:bg-white dark:hover:bg-slate-100 dark:text-black text-white hover:scale-[1.02] active:scale-95"
              } flex items-center justify-center gap-2`}
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  Publishing...
                </>
              ) : (
                "Add to Story"
              )}
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>,
    document.body
  );
}
