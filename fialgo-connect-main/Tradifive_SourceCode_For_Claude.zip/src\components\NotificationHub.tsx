import React, { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { triggerCustomNotification } from "./CustomNotification";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Bell, 
  X, 
  ShieldAlert, 
  Settings, 
  CreditCard, 
  Zap, 
  CircleCheck,
  MoreVertical,
  Clock
} from "lucide-react";

export default function NotificationHub() {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const fetchNotifications = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data } = await supabase
        .from("notifications")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);

      if (data) {
        setNotifications(data);
        setUnreadCount(data.filter(n => !n.is_read).length);
      }
    };

    fetchNotifications();

    // Listen for real-time notifications
    const setupRealtime = async () => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const channel = supabase.channel(`notifications_${user.id}`)
          .on('postgres_changes', { 
            event: 'INSERT', 
            schema: 'public', 
            table: 'notifications',
            filter: `user_id=eq.${user.id}`
          }, (payload: any) => {
            const newNotif = payload.new;
            setNotifications(prev => [newNotif, ...prev]);
            setUnreadCount(prev => prev + 1);
            
            // Map the notification type to the toast type
            let toastType: 'info' | 'error' | 'success' = 'info';
            if (newNotif.type === 'SECURITY' || newNotif.priority === 'high') {
              toastType = 'error';
            } else if (newNotif.type === 'SYSTEM' || newNotif.type === 'ACCOUNT') {
              toastType = 'success';
            }
            
            triggerCustomNotification({
              title: newNotif.title,
              message: newNotif.message,
              type: toastType,
              persist: false // Already in DB
            });
          })
          .subscribe();

        return channel;
    };

    const channelPromise = setupRealtime();
    return () => {
      channelPromise.then(channel => {
        if (channel) supabase.removeChannel(channel);
      });
    };
  }, []);

  const markAsRead = async (id: string) => {
    const { error } = await supabase
      .from("notifications")
      .update({ is_read: true })
      .eq("id", id);

    if (!error) {
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    }
  };

  const markAllRead = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from("notifications")
      .update({ is_read: true })
      .eq("user_id", user.id)
      .eq("is_read", false);

    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    setUnreadCount(0);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'SECURITY': return <ShieldAlert size={16} className="text-rose-500" />;
      case 'ACCOUNT': return <Settings size={16} className="text-slate-200" />;
      case 'PAYMENT': return <CreditCard size={16} className="text-emerald-500" />;
      default: return <Zap size={16} className="text-amber-500" />;
    }
  };

  return (
    <div className="relative">
      {/* Trigger Bell */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="relative p-2.5 rounded-xl hover:bg-white/10 transition-all group"
        >
          <Bell size={18} className="text-muted-foreground group-hover:text-foreground transition-colors" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 text-rose-500 text-[10px] font-extrabold flex items-center justify-center animate-pulse drop-shadow-md">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

      {/* Slide-out Panel */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-[100]"
            />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95, x: 20 }}
              animate={{ opacity: 1, y: 0, scale: 1, x: 0 }}
              exit={{ opacity: 0, y: 10, scale: 0.95, x: 20 }}
              className="absolute right-0 top-14 w-[380px] bg-white dark:bg-[#1A1A1A] dark:bg-[#0F0F0F] rounded-3xl shadow-[0_32px_64px_-16px_rgba(0,0,0,0.3)] border border-neutral-100 dark:border-white/5 overflow-hidden z-[110]"
            >
              {/* Header */}
              <div className="px-6 py-5 border-b border-neutral-100 dark:border-white/5 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black tracking-tight text-foreground dark:text-white uppercase">Notification Hub</h3>
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mt-0.5">Fialgo Intelligence System</p>
                </div>
                <button 
                  onClick={markAllRead}
                  className="text-[10px] font-bold text-white hover:text-slate-200 uppercase tracking-widest"
                >
                  Mark all as read
                </button>
              </div>

              {/* List */}
              <div className="max-h-[480px] overflow-y-auto custom-scrollbar">
                {notifications.length === 0 ? (
                  <div className="py-20 flex flex-col items-center justify-center text-center px-8">
                     <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-white/5 flex items-center justify-center mb-4">
                        <Bell size={24} className="text-neutral-300 dark:text-neutral-700" />
                     </div>
                     <p className="text-xs font-bold text-foreground dark:text-white uppercase tracking-tight">Zero Signals Detected</p>
                     <p className="text-[11px] text-muted-foreground mt-2 leading-relaxed">Your account activity is optimal. No system pings at this time.</p>
                  </div>
                ) : (
                  <div className="divide-y divide-neutral-100 dark:divide-white/5">
                    {notifications.map((n) => (
                      <div 
                        key={n.id}
                        onClick={() => markAsRead(n.id)}
                        className={`group relative p-6 hover:bg-neutral-50 dark:hover:bg-white/[0.02] transition-colors cursor-pointer ${!n.is_read ? 'bg-blue-50/30 dark:bg-white/5' : ''}`}
                      >
                        {!n.is_read && (
                          <div className="absolute left-0 top-0 bottom-0 w-1 bg-white" />
                        )}
                        <div className="flex gap-4">
                          <div className="mt-0.5 select-none shrink-0">
                             <div className="w-9 h-9 rounded-xl bg-neutral-100 dark:bg-white/5 flex items-center justify-center border border-neutral-200 dark:border-white/5">
                                {getIcon(n.type)}
                             </div>
                          </div>
                          <div className="flex-1 min-w-0 pr-4">
                            <div className="flex items-center justify-between gap-2 mb-1">
                               <p className="text-[13px] font-bold text-foreground dark:text-white leading-tight truncate">{n.title}</p>
                               <span className="text-[9px] text-muted-foreground font-mono shrink-0">{new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            </div>
                            <p className="text-[12px] text-muted-foreground/80 leading-relaxed mb-3">{n.message}</p>
                            <div className="flex items-center gap-3">
                               <div className="flex items-center gap-1.5 text-[9px] font-bold text-muted-foreground uppercase tracking-wider">
                                  <Clock size={10} />
                                  {new Date(n.created_at).toLocaleDateString()}
                               </div>
                               {n.priority === 'high' && (
                                 <span className="px-1.5 py-0.5 rounded-full bg-rose-500/10 text-rose-500 text-[8px] font-black uppercase tracking-widest border border-rose-500/20">
                                    Priority
                                 </span>
                               )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="px-6 py-4 border-t border-neutral-100 dark:border-white/5 bg-neutral-50 dark:bg-white/[0.02] text-center">
                 <button 
                  onClick={() => setIsOpen(false)}
                  className="text-[11px] font-black text-neutral-400 dark:text-neutral-500 hover:text-foreground dark:hover:text-white uppercase tracking-[0.2em] transition-colors"
                >
                    Dismiss Terminal
                 </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}


