import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  TrendingUp,
  Activity,
  Zap,
  ShieldAlert,
  Search,
  Sparkles,
  ChevronRight,
  User,
  ShieldCheck,
  AlertTriangle,
  Flame,
  MessageCircle,
  BarChart3,
  Clock,
  Info,
  Share2,
  ChevronDown,
  LayoutGrid,
  BarChart2,
  BrainCircuit,
  TrendingDown,
  Target,
  Brain,
  Trophy,
  Focus,
  Plus,
  QrCode,
  X,
  Download,
  MoreHorizontal
} from "lucide-react";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine } from "recharts";
import DashboardLayout from "@/components/DashboardLayout";
import { useDashboardData } from "@/hooks/useDashboardData";
import { supabase } from "@/lib/supabase";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

// --- Components ---

const GlassCard = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className={`bg-gradient-to-b from-[#F8F9FC] to-[#FFFFFF] dark:from-[#171717] dark:to-[#0A0A0A] border-2 border-white dark:border-[#262626] rounded-[22px] p-5 shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E2E8F0] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#262626] premium-flat-card transition-all ${className}`}
  >
    {children}
  </motion.div>
);

const SimpleSparkline = ({ data, color }: { data: any[], color: string }) => (
  <div className="h-[35px] w-[70px]">
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data}>
        <Area type="monotone" dataKey="v" stroke={color} strokeWidth={2} fill="transparent" dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  </div>
);

const CircularProgress = ({ percentage, value, label, title = "Total Exposure" }: { percentage: number, value: string, label: string, title?: string }) => {
  const radius = 65;
  const circumference = 2 * Math.PI * radius;
  const arcLength = circumference * 0.75;
  const strokeDashoffset = arcLength - (percentage / 100) * arcLength;

  return (
    <div className="relative flex items-center justify-center w-48 h-48">
      <svg className="w-full h-full transform rotate-[135deg]">
        <circle
          cx="96" cy="96" r={radius}
          stroke="currentColor" strokeWidth="12" fill="transparent"
          strokeDasharray={`${arcLength} ${circumference}`}
          className="text-slate-100 dark:text-white/5"
          strokeLinecap="round"
        />
        <motion.circle
          cx="96" cy="96" r={radius}
          stroke="#10B981" strokeWidth="12"
          strokeDasharray={`${arcLength} ${circumference}`}
          initial={{ strokeDashoffset: arcLength }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          strokeLinecap="round" fill="transparent"
          style={{ filter: "drop-shadow(0 0 12px rgba(16, 185, 129, 0.4))" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center pt-2">
        <span className="text-[10px] font-bold text-slate-400 mb-1">{title}</span>
        <span className="text-[28px] font-bold text-emerald-500 tracking-tight">{value}</span>
        <span className="text-[10px] font-medium text-slate-400 mt-1">{label}</span>
      </div>
    </div>
  );
};

const SessionIntensityGauge = ({ loading }: { loading?: boolean }) => {
  const [heatScore, setHeatScore] = useState(30);

  // Simulate live telemetry
  useEffect(() => {
    const interval = setInterval(() => {
      setHeatScore(prev => {
        // Randomly fluctuate between -5 and +8
        const change = Math.floor(Math.random() * 14) - 5;
        let next = prev + change;

        // Random 5% chance of a high-frequency spike
        if (Math.random() > 0.95) next = 85;

        if (next < 0) next = 5;
        if (next > 100) next = 100;
        return next;
      });
    }, 2500); // Updates every 2.5 seconds

    return () => clearInterval(interval);
  }, []);

  let barColor = "bg-blue-400";
  let animateClass = "";
  if (heatScore >= 80) {
    barColor = "bg-orange-500";
    animateClass = "animate-pulse";
  } else if (heatScore >= 41) {
    barColor = "bg-yellow-400";
  }

  return (
    <GlassCard className="p-6">
      <div className="flex flex-col mb-6">
        <h2 className="text-[14px] font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-1">Session Intensity</h2>
        <span className="text-[11px] font-medium text-slate-500 uppercase tracking-widest flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
          Live Execution Velocity
        </span>
      </div>

      {loading ? (
        <Skeleton className="w-full h-8 bg-slate-200 dark:bg-white/10 rounded-full animate-pulse" />
      ) : (
        <div className="w-full h-8 bg-white/50 dark:bg-black/20 backdrop-blur-md shadow-inner rounded-full overflow-hidden border border-slate-200 dark:border-[#262626] mb-2 relative">
          <div
            className={`h-full ${barColor} ${animateClass} transition-all duration-700 ease-in-out`}
            style={{ width: `${heatScore}%` }}
          />
        </div>
      )}

      <AnimatePresence>
        {heatScore >= 80 && (
          <motion.div
            initial={{ opacity: 0, y: 10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            className="mt-4 p-4 rounded-xl border border-orange-500/50 bg-orange-500/10 shadow-[0_0_15px_rgba(249,115,22,0.2)]"
          >
            <div className="flex gap-3">
              <div className="mt-0.5 text-orange-500 flex-shrink-0">
                <BrainCircuit size={16} />
              </div>
              <div>
                <p className="text-[13px] font-bold text-orange-600 dark:text-orange-400 mb-1">Kimi AI:</p>
                <p className="text-[12px] text-orange-700 dark:text-orange-300/80 font-medium leading-relaxed">
                  Warning: Your execution velocity has spiked. You are exhibiting high-frequency behavior. Take a 5-minute break away from the charts before the Revenge Guard enforces a mandatory lock.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </GlassCard>
  );
};

const DefenseProtocols = ({ loading }: { loading?: boolean }) => {
  return (
    <GlassCard className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <ShieldCheck size={20} className="text-emerald-500" />
          <h2 className="text-[14px] font-bold text-slate-900 dark:text-white tracking-widest uppercase">Terminal Defense</h2>
        </div>
        <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20">All Systems Armed</span>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-[#262626]">
              <div className="flex items-center gap-3 w-full animate-pulse">
                <Skeleton className="w-8 h-8 rounded-full bg-slate-200 dark:bg-white/10 shrink-0" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-2/3 bg-slate-200 dark:bg-white/10" />
                  <Skeleton className="h-3 w-1/2 bg-slate-200 dark:bg-white/10" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-[#262626]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <ShieldAlert size={14} className="text-emerald-500" />
              </div>
              <div className="flex flex-col">
                <span className="text-[12px] font-bold text-slate-900 dark:text-white">Risk Guard</span>
                <span className="text-[10px] font-medium text-slate-500">Auto-Flatten</span>
              </div>
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)] animate-pulse"></div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-[#262626]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <TrendingDown size={14} className="text-emerald-500" />
              </div>
              <div className="flex flex-col">
                <span className="text-[12px] font-bold text-slate-900 dark:text-white">Drawdown</span>
                <span className="text-[10px] font-medium text-slate-500">Hard Limit Active</span>
              </div>
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)] animate-pulse"></div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-[#262626]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <Activity size={14} className="text-emerald-500" />
              </div>
              <div className="flex flex-col">
                <span className="text-[12px] font-bold text-slate-900 dark:text-white">Slippage</span>
                <span className="text-[10px] font-medium text-slate-500">Max 2.0 Pips</span>
              </div>
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)] animate-pulse"></div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-[#262626]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <Zap size={14} className="text-emerald-500" />
              </div>
              <div className="flex flex-col">
                <span className="text-[12px] font-bold text-slate-900 dark:text-white">News Filter</span>
                <span className="text-[10px] font-medium text-slate-500">Block ±15m</span>
              </div>
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)] animate-pulse"></div>
          </div>
        </div>
      )}
    </GlassCard>
  );
};

// --- Mock Data ---
const MOCK_SPARKLINE = [{ v: 40 }, { v: 60 }, { v: 45 }, { v: 70 }, { v: 55 }, { v: 85 }, { v: 75 }];

const ShareModal = ({ trade, onClose }: { trade: any, onClose: () => void }) => {
  if (!trade) return null;

  const netString = trade.net || trade.pnl || "+0.00";
  const isProfit = netString.startsWith('+');
  const themeColor = isProfit ? "#22C55E" : "#EF4444"; 
  const bgImage = isProfit ? "/Profit_2.jpeg" : "/loss 2 .jpeg";

  const netValue = parseFloat(netString.replace(/[^0-9.-]+/g, "")) || 0;
  const roiValue = isProfit ? `+${(netValue * 15.3).toFixed(2)}%` : `-${(Math.abs(netValue) * 15.3).toFixed(2)}%`;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md" onClick={onClose}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-[420px] rounded-[32px] overflow-hidden bg-black text-white shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-6 right-6 z-30 p-2 hover:bg-white/10 rounded-full transition-colors">
          <X size={20} className="text-white/40" />
        </button>

        <div className="relative w-full aspect-[0.85/1] select-none flex flex-col bg-black">
          
          {/* Header Section */}
          <div className="px-8 pt-8 pb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5">
                <div className="w-8 h-8 flex items-center justify-center">
                  <img src="/logo.png" alt="Logo" className="w-6 h-6 object-contain" />
                </div>
                <span className="text-[22px] font-bold tracking-tight">TradiFive</span>
              </div>
              <div className="ml-2 px-3 py-1 bg-[#222222] rounded-full text-[12px] font-bold text-white/80">
                Demo
              </div>
            </div>
            <span className="text-[14px] font-medium text-white/40 tabular-nums">
              Shared on {new Date().toLocaleDateString('en-GB')}
            </span>
          </div>

          {/* Asset & ROI Section */}
          <div className="px-8 pt-4 space-y-6">
            {/* Asset */}
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 bg-[#3B82F6] rounded flex items-center justify-center text-[14px] font-black text-white">
                {(trade.asset || "A").charAt(0)}
              </div>
              <h1 className="text-[28px] font-bold tracking-tight text-white">{trade.asset || "Asset"}</h1>
            </div>

            {/* ROI */}
            <div className="space-y-1">
              <span className="text-[16px] font-medium text-white/40">Unrealised ROI</span>
              <div 
                className="text-[72px] font-black leading-none tracking-tighter"
                style={{ color: themeColor }}
              >
                {roiValue}
              </div>
            </div>
          </div>

          {/* Prices Section */}
          <div className="px-8 py-8 space-y-6 relative z-10">
            <div className="space-y-1.5">
              <span className="text-[15px] font-medium text-white/40">Open Price</span>
              <div className="text-[26px] font-bold tabular-nums text-white">{trade.entry || "0.00"}</div>
            </div>
            
            <div className="space-y-1.5">
              <span className="text-[15px] font-medium text-white/40">Current Price</span>
              <div className="text-[26px] font-bold tabular-nums text-white">{trade.exit || "0.00"}</div>
            </div>
          </div>

          {/* Background Image (Lower half) */}
          <div className="absolute inset-x-0 bottom-[140px] top-[40%] z-0 pointer-events-none">
            <img 
              src={bgImage} 
              alt="Background" 
              className="w-full h-full object-cover opacity-80"
              style={{ maskImage: 'linear-gradient(to bottom, transparent, black 20%)', WebkitMaskImage: 'linear-gradient(to bottom, transparent, black 20%)' }}
            />
          </div>

          {/* Footer Section */}
          <div className="mt-auto px-8 py-8 bg-black/80 backdrop-blur-sm border-t border-white/5 flex items-end justify-between relative z-10">
            <div className="space-y-1.5">
              <div className="text-[18px] font-medium text-white">
                Referral Code: <span className="font-bold text-white tracking-widest">072SE5</span>
              </div>
              <p className="text-[14px] text-white/40 font-medium">
                Keep the returns coming! Trade on TradiFive App.
              </p>
            </div>
            
            <div className="w-[84px] h-[84px] bg-white rounded-xl p-1.5 flex items-center justify-center shadow-2xl">
              <QrCode size={72} className="text-black" strokeWidth={1.5} />
            </div>
          </div>
        </div>

        {/* Minimalist Action Controls */}
        <div className="p-6 bg-black border-t border-white/5 flex items-center justify-center gap-8">
          <button className="w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 transition-all flex items-center justify-center text-white/60">
            <Download size={22} />
          </button>
          <button 
            className="w-12 h-12 rounded-full text-white transition-all shadow-xl flex items-center justify-center"
            style={{ backgroundColor: isProfit ? '#2563EB' : '#DC2626' }}
          >
            <Share2 size={22} />
          </button>
          <button className="w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 transition-all flex items-center justify-center text-white/60">
            <MoreHorizontal size={22} />
          </button>
        </div>
      </motion.div>
    </div>
  );
};

const LiveNewsFeed = () => {
  const [news, setNews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const res = await fetch('https://nfs.faireconomy.media/ff_calendar_thisweek.json');
        const data = await res.json();
        
        // Filter high impact and upcoming events
        const highImpact = data
          .filter((item: any) => item.impact === 'High' || item.impact === 'Medium')
          .filter((item: any) => new Date(item.date).getTime() > Date.now() - 6 * 60 * 60 * 1000) // from last 6 hours onwards
          .sort((a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime())
          .slice(0, 4); // show top 4
          
        setNews(highImpact);
      } catch (err) {
        console.error('Failed to fetch news', err);
      } finally {
        setLoading(false);
      }
    };
    fetchNews();
    
    // Refresh every 5 minutes
    const interval = setInterval(fetchNews, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <GlassCard className="flex flex-col p-6">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-3">
          <h2 className="text-[14px] font-bold text-slate-900 dark:text-white tracking-widest uppercase">Live Market News</h2>
          <div className="bg-rose-500/20 text-rose-500 text-[10px] font-bold px-2 py-0.5 rounded-full border border-rose-500/30 animate-pulse">
            LIVE
          </div>
        </div>
      </div>

      {loading ? (
        <div className="space-y-4 pt-4">
          {Array.from({ length: 3 }).map((_, idx) => (
            <div key={idx} className="flex items-center gap-4 py-2 border-b border-slate-100 dark:border-[#262626] last:border-0">
              <Skeleton className="w-8 h-8 rounded-full bg-slate-200 dark:bg-white/10 shrink-0" />
              <div className="flex-1 space-y-1.5">
                <Skeleton className="h-4 w-2/3 bg-slate-200 dark:bg-white/10" />
                <Skeleton className="h-3 w-1/2 bg-slate-200 dark:bg-white/10" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-0 pt-2">
          {news.length === 0 ? (
            <div className="p-4 rounded-xl border border-dashed border-slate-200 dark:border-white/10 text-center text-slate-400 text-[12px] py-6">
              No major impact news upcoming this week.
            </div>
          ) : (
            news.map((item: any, idx: number) => {
              const eventDate = new Date(item.date);
              const timeStr = eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              const dateStr = eventDate.toLocaleDateString([], { month: 'short', day: 'numeric' });
              const isToday = eventDate.toDateString() === new Date().toDateString();
              
              const isHigh = item.impact === 'High';
              const iconClass = isHigh ? "text-rose-500 border-rose-500/50 bg-rose-500/10 shadow-[0_0_12px_rgba(244,63,94,0.3)]" : "text-amber-500 border-amber-500/50 bg-amber-500/10 shadow-[0_0_12px_rgba(245,158,11,0.2)]";
              
              return (
                <div key={idx} className="flex items-center gap-4 py-3 border-b border-slate-100 dark:border-[#262626] last:border-0">
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full border-[1.5px] flex flex-col items-center justify-center ${iconClass}`}>
                    <span className="text-[10px] font-black">{item.country}</span>
                  </div>
                  <div className="flex-1">
                    <p className="text-[13px] font-bold text-slate-900 dark:text-white leading-tight mb-1 line-clamp-1">{item.title}</p>
                    <div className="flex items-center gap-2 text-[11px] font-medium text-slate-500">
                      <span className={isToday ? (isHigh ? "text-rose-500" : "text-amber-500") : ""}>{isToday ? "Today" : dateStr}, {timeStr}</span>
                      {item.forecast && (
                         <>
                           <span>•</span>
                           <span>FC: {item.forecast}</span>
                         </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </GlassCard>
  );
};

export default function Dashboard() {
  const navigate = useNavigate();
  const [userName, setUserName] = useState<string | null>(null);
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    setIsDark(document.documentElement.classList.contains("dark"));
    const observer = new MutationObserver(() => {
      setIsDark(document.documentElement.classList.contains("dark"));
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"]
    });
    return () => observer.disconnect();
  }, []);

  const dynamicTooltipStyle = useMemo(() => {
    if (isDark) {
      return {
        backgroundColor: "#1A1A1C",
        border: "1px solid rgba(255, 255, 255, 0.08)",
        borderRadius: "12px",
        boxShadow: "0 10px 25px -5px rgba(0,0,0,0.5)",
        fontSize: "12px",
        fontWeight: "600",
        color: "#fff",
      };
    }
    return {
      backgroundColor: "#fff",
      border: "1px solid #e2e8f0",
      borderRadius: "12px",
      boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
      fontSize: "12px",
      fontWeight: "600",
      color: "#0f172a",
    };
  }, [isDark]);
  
  const { 
    todayProfit, 
    totalProfit, 
    tradesToday,
    winRate, 
    loading, 
    recentTrades, 
    balance, 
    equity, 
    accountMetrics, 
    isConnected,
    avgDisciplineScore,
    dailyXpEarned,
    riskConfig,
    breachLogs
  } = useDashboardData();

  const [shareTrade, setShareTrade] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<"positions" | "pending" | "closed" | "alerts">("positions");
  const [emergencyStop, setEmergencyStop] = useState(false);

  const openPositionsCount = useMemo(() => {
    if (isConnected) {
      return recentTrades.filter((t: any) => !t.closed_at && !t.is_pending).length;
    }
    return 2; // Demo count
  }, [isConnected, recentTrades]);

  const pendingOrdersCount = useMemo(() => {
    if (isConnected) {
      return recentTrades.filter((t: any) => t.is_pending).length;
    }
    return 0; // Demo count
  }, [isConnected, recentTrades]);

  const closedPositionsCount = useMemo(() => {
    if (isConnected) {
      return recentTrades.filter((t: any) => t.closed_at && !t.is_pending).length;
    }
    return 2; // Demo count
  }, [isConnected, recentTrades]);

  const displayTrades = useMemo(() => {
    if (isConnected && recentTrades && recentTrades.length > 0) {
      if (activeTab === "positions") {
        return recentTrades.filter((t: any) => !t.closed_at && !t.is_pending);
      }
      if (activeTab === "closed") {
        return recentTrades.filter((t: any) => t.closed_at && !t.is_pending);
      }
      if (activeTab === "pending") {
        return recentTrades.filter((t: any) => t.is_pending);
      }
      return [];
    } else {
      // Demo trades mode
      if (activeTab === "positions") {
        return [
          { id: 'd1', symbol: "EURUSD", opened_at: new Date(Date.now() - 1000 * 60 * 5).toISOString(), trade_type: 0, lot_size: 0.1, entry_price: 1.0854, closed_at: null, exit_price: null, commission: 0, swap: 0, profit: 12.50 },
          { id: 'd2', symbol: "XAUUSD", opened_at: new Date(Date.now() - 1000 * 60 * 45).toISOString(), trade_type: 1, lot_size: 0.05, entry_price: 2345.10, closed_at: null, exit_price: null, commission: 0, swap: 0, profit: -4.20 },
        ];
      }
      if (activeTab === "closed") {
        return [
          { id: 'd3', symbol: "XAUUSD", opened_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(), trade_type: 0, lot_size: 0.01, entry_price: 2330.15, closed_at: new Date(Date.now() - 1000 * 60 * 110).toISOString(), exit_price: 2332.85, commission: 0, swap: 0, profit: 2.70 },
          { id: 'd4', symbol: "GBPUSD", opened_at: new Date(Date.now() - 1000 * 60 * 240).toISOString(), trade_type: 0, lot_size: 0.02, entry_price: 1.2710, closed_at: new Date(Date.now() - 1000 * 60 * 220).toISOString(), exit_price: 1.2725, commission: 0, swap: 0, profit: 3.00 },
        ];
      }
      return [];
    }
  }, [activeTab, isConnected, recentTrades]);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) {
        const metadata = data.user.user_metadata;
        const emailPrefix = data.user.email?.split('@')[0] || "Trader";

        // Priority: first_name -> full_name split -> email prefix cleaned
        let name = metadata?.first_name || metadata?.full_name?.split(' ')[0] || emailPrefix;

        // Clean up names derived from emails (remove numbers and common separators)
        if (!metadata?.first_name && !metadata?.full_name) {
          name = name.replace(/[0-9]/g, '').split(/[._-]/)[0];
        }

        // Capitalize first letter
        const formattedName = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
        setUserName(formattedName || "Trader");
      }
    });
  }, []);

  // Dynamically calculate cumulative P&L daily grouping
  const cumulativePnL = useMemo(() => {
    const hasData = recentTrades && recentTrades.length > 0;
    if (!hasData) {
      return [
        { date: '05/23', v: 26 },
        { date: '05/23', v: 33 },
        { date: '05/23', v: 30 },
        { date: '05/23', v: 43 },
      ];
    }
    const closedTrades = recentTrades.filter((t: any) => t.closed_at && !t.is_pending);
    const sortedTrades = [...closedTrades].sort((a: any, b: any) => new Date(a.closed_at).getTime() - new Date(b.closed_at).getTime());
    const dailyMap = new Map<string, { profit: number; dateObject: Date }>();
    sortedTrades.forEach((t) => {
      const d = new Date(t.closed_at);
      const dateStr = d.toLocaleDateString(undefined, { month: '2-digit', day: '2-digit' });
      const current = dailyMap.get(dateStr) || { profit: 0, dateObject: d };
      current.profit += t.profit;
      dailyMap.set(dateStr, current);
    });
    const dailyList = Array.from(dailyMap.entries()).map(([dateStr, info]) => ({
      dateStr,
      profit: info.profit,
      time: info.dateObject.getTime()
    })).sort((a, b) => a.time - b.time);
    let cum = 0;
    const cPnL: any[] = [];
    dailyList.forEach((item) => {
      cum += item.profit;
      cPnL.push({ date: item.dateStr, v: cum });
    });
    return cPnL;
  }, [recentTrades]);

  // Alert Center Calculations
  const alertCenterAlerts = useMemo(() => {
    if (!isConnected) {
      // Demo alerts
      return [
        {
          id: 'demo-alert-1',
          type: 'danger',
          title: 'Risk limit reached',
          subtitle: 'Daily drawdown was approached',
          time: '10m ago',
          icon: 'plus'
        },
        {
          id: 'demo-alert-2',
          type: 'warning',
          title: 'High volatility detected',
          subtitle: 'XAUUSD volatility is high',
          time: '25m ago',
          icon: 'zap'
        },
        {
          id: 'demo-alert-3',
          type: 'info',
          title: 'License Security Active',
          subtitle: 'Your connection is fully protected',
          time: '1h ago',
          icon: 'number'
        },
        {
          id: 'demo-alert-4',
          type: 'purple',
          title: 'Soft Intercept Triggered',
          subtitle: 'Execution velocity spike detected',
          time: '2h ago',
          icon: 'brain'
        }
      ];
    }

    if (breachLogs.length === 0) {
      // Return a premium stable protection message
      return [
        {
          id: 'live-alert-security',
          type: 'info',
          title: 'License Security Active',
          subtitle: 'Your MT5 connection is fully protected and monitored.',
          time: '1h ago',
          icon: 'number'
        },
        {
          id: 'live-alert-standby',
          type: 'success',
          title: 'Risk Guard Standby',
          subtitle: 'All real-time protection protocols are armed and active.',
          time: 'Just now',
          icon: 'shield'
        }
      ];
    }

    return breachLogs.map((log: any) => {
      const timeStr = log.created_at
        ? new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : 'Just now';

      let title = 'Risk Threshold Triggered';
      let subtitle = `Rule limit: ${log.rule_value} | Actual: ${log.actual_value}`;
      let type = log.severity?.toLowerCase() === 'critical' ? 'danger' : 'warning';
      let icon = 'zap';

      if (log.breach_type === 'DAILY_DRAWDOWN') {
        title = 'Risk limit warning';
        subtitle = `Daily drawdown reached ${parseFloat(log.actual_value).toFixed(2)}%`;
        icon = 'plus';
        type = 'danger';
      } else if (log.breach_type === 'MAX_LOT_SIZE') {
        title = 'Sizing rule warning';
        subtitle = `Position lot size of ${log.actual_value} exceeded limit`;
        icon = 'zap';
        type = 'warning';
      } else if (log.breach_type === 'MAX_OPEN_TRADES') {
        title = 'Trade count limit reached';
        subtitle = `Reached max open trade limit of ${log.rule_value}`;
        icon = 'plus';
        type = 'danger';
      }

      return {
        id: log.id,
        type,
        title,
        subtitle,
        time: timeStr,
        icon
      };
    });
  }, [isConnected, breachLogs]);

  // Journal Preview Calculations
  const journalPreviewData = useMemo(() => {
    if (!isConnected) {
      // Demo trades for Journal Preview
      return {
        bestSymbolInsight: {
          title: "Best performance on XAUUSD this week.",
          subtitle: "You've taken high quality setups with good risk management."
        },
        trades: [
          {
            id: 'd-j-1',
            symbol: 'XAUUSD',
            time: 'Today, 10:24 AM',
            profit: 54.60,
            note: 'High quality breakout trade.'
          },
          {
            id: 'd-j-2',
            symbol: 'EURUSD',
            time: 'Today, 09:58 AM',
            profit: 21.15,
            note: 'Good risk management.'
          }
        ]
      };
    }

    // 1. Calculate best symbol insight
    const symbolPnL = new Map<string, number>();
    const closedTrades = recentTrades.filter((t: any) => t.closed_at && !t.is_pending);
    closedTrades.forEach((t: any) => {
      const current = symbolPnL.get(t.symbol) || 0;
      symbolPnL.set(t.symbol, current + (t.profit || 0));
    });
    const sortedSymbols = Array.from(symbolPnL.entries()).sort((a, b) => b[1] - a[1]);
    const bestSymbol = sortedSymbols.length > 0 && sortedSymbols[0][1] > 0 ? sortedSymbols[0][0] : null;

    let bestSymbolInsight = {
      title: "No completed trade insights yet.",
      subtitle: "Execute and close your first trades to unlock automated coaching insights."
    };

    if (bestSymbol) {
      bestSymbolInsight = {
        title: `Best performance on ${bestSymbol} this period.`,
        subtitle: `You've taken high quality setups on ${bestSymbol} with successful outcomes.`
      };
    }

    // 2. Fetch the 2 most recent completed trades
    const recentCompleted = closedTrades.slice(0, 2).map((t: any) => {
      const date = new Date(t.closed_at);
      const isToday = date.toDateString() === new Date().toDateString();
      const timeStr = isToday
        ? `Today, ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
        : date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

      return {
        id: t.id,
        symbol: t.symbol,
        time: timeStr,
        profit: t.profit || 0,
        note: t.notes || t.entry_reason || t.setup || 'Standard execution log.'
      };
    });

    return {
      bestSymbolInsight,
      trades: recentCompleted
    };
  }, [isConnected, recentTrades]);

  // Risk Monitor Calculations
  const riskMonitorData = useMemo(() => {
    if (!isConnected) {
      return {
        executionsCount: 2,
        executionsLimit: 3,
        executionsRemaining: 1,
        executionsPercentage: 66.6,
        drawdownDollar: 249.32,
        drawdownLimitDollar: 937.26,
        drawdownPercentage: 1.34,
        drawdownLimitPercentage: 5.00,
        drawdownProgressPercent: 26.6,
        revengeGuardStatus: "Standby",
        revengeGuardColor: "bg-emerald-500",
        revengeGuardTextClass: "text-emerald-500",
        riskLevelText: "Low",
        riskLevelClass: "bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/30 text-emerald-600 dark:text-emerald-400"
      };
    }

    // Dynamic execution limits
    const maxExecutions = riskConfig?.max_open_trades || 5;
    const executionsCount = tradesToday;
    const executionsRemaining = Math.max(0, maxExecutions - executionsCount);
    const executionsPercentage = Math.min(100, (executionsCount / maxExecutions) * 100);

    // Dynamic daily drawdown limits
    const currentDrawdownDollar = Math.max(0, balance - equity);
    
    // Support prop firm fixed daily loss limit vs default percentage limit
    const maxLossPercent = riskConfig?.max_daily_loss_percent || 5.0;
    const drawdownLimitDollar = (riskConfig?.is_prop_firm_mode && riskConfig?.prop_firm_daily_loss)
      ? riskConfig.prop_firm_daily_loss
      : balance * (maxLossPercent / 100);

    const drawdownPercentage = balance > 0 ? (currentDrawdownDollar / balance) * 100 : 0;
    const drawdownLimitPercentage = maxLossPercent;
    
    const drawdownProgressPercent = drawdownLimitDollar > 0
      ? Math.min(100, (currentDrawdownDollar / drawdownLimitDollar) * 100)
      : 0;

    // Determine Revenge Guard status
    const isEngaged = currentDrawdownDollar >= drawdownLimitDollar || executionsCount >= maxExecutions;
    const revengeGuardStatus = isEngaged ? "Engaged" : "Standby";
    const revengeGuardColor = isEngaged ? "bg-rose-500" : "bg-emerald-500";
    const revengeGuardTextClass = isEngaged ? "text-rose-500" : "text-emerald-500";

    // Determine risk level based on drawdown progress
    let riskLevelText = "Low";
    let riskLevelClass = "bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/30 text-emerald-600 dark:text-emerald-400";
    if (drawdownProgressPercent >= 80) {
      riskLevelText = "High";
      riskLevelClass = "bg-rose-50 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900/30 text-rose-600 dark:text-rose-400";
    } else if (drawdownProgressPercent >= 40) {
      riskLevelText = "Moderate";
      riskLevelClass = "bg-amber-50 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/30 text-amber-600 dark:text-amber-400";
    }

    return {
      executionsCount,
      executionsLimit: maxExecutions,
      executionsRemaining,
      executionsPercentage,
      drawdownDollar: currentDrawdownDollar,
      drawdownLimitDollar,
      drawdownPercentage,
      drawdownLimitPercentage,
      drawdownProgressPercent,
      revengeGuardStatus,
      revengeGuardColor,
      revengeGuardTextClass,
      riskLevelText,
      riskLevelClass
    };
  }, [isConnected, riskConfig, tradesToday, balance, equity]);

  // AI Coach Insights mapping based on logs vs stats
  const aiInsights = useMemo(() => {
    if (!isConnected) {
      // Demo insights
      return [
        {
          id: 'demo-1',
          type: 'warning',
          title: 'You exceeded your normal lot size during NY session.',
          subtitle: 'Consider reducing lot size after 8PM.',
          time: '10m ago',
          icon: 'alert'
        },
        {
          id: 'demo-2',
          type: 'warning',
          title: 'Win rate drops when trading after 8PM.',
          subtitle: 'Your performance is 27% better before 8PM.',
          time: '25m ago',
          icon: 'chart'
        },
        {
          id: 'demo-3',
          type: 'success',
          title: 'Risk Guard prevented a high drawdown trade.',
          subtitle: 'Good job! Your discipline saved you $312.50 today.',
          time: '1h ago',
          icon: 'shield'
        },
        {
          id: 'demo-4',
          type: 'info',
          title: 'Focus Pair: XAUUSD',
          subtitle: 'You perform best on XAUUSD. Consider increasing focus.',
          time: '2h ago',
          icon: 'target'
        }
      ];
    }

    if (breachLogs.length === 0) {
      // Smart positive coaching insights based on live statistics
      const insights = [];
      
      // Insight 1: Discipline Score
      if (avgDisciplineScore && avgDisciplineScore >= 90) {
        insights.push({
          id: 'live-insight-discipline-high',
          type: 'success',
          title: 'Excellent discipline score maintained today.',
          subtitle: `Your average discipline score is ${avgDisciplineScore}/100. Keep sticking to your rules.`,
          time: 'Just now',
          icon: 'shield'
        });
      } else if (avgDisciplineScore && avgDisciplineScore < 80) {
        insights.push({
          id: 'live-insight-discipline-low',
          type: 'warning',
          title: 'Discipline score is below optimal target.',
          subtitle: `Average score is ${avgDisciplineScore}/100. Focus on placing trades that align strictly with your playbook.`,
          time: 'Just now',
          icon: 'alert'
        });
      }

      // Insight 2: Win Rate
      if (winRate >= 60) {
        insights.push({
          id: 'live-insight-winrate-high',
          type: 'info',
          title: 'High win rate registered this period.',
          subtitle: `You are maintaining a strong ${winRate}% win rate. Continue executing on your edge.`,
          time: '5m ago',
          icon: 'chart'
        });
      } else if (winRate > 0 && winRate < 45) {
        insights.push({
          id: 'live-insight-winrate-low',
          type: 'warning',
          title: 'Win rate is currently under pressure.',
          subtitle: `Your win rate is ${winRate}%. Re-evaluate market conditions and focus on smaller sizes.`,
          time: '5m ago',
          icon: 'chart'
        });
      }

      // Insight 3: Stable status
      insights.push({
        id: 'live-insight-stable',
        type: 'success',
        title: 'All operational metrics are completely stable.',
        subtitle: 'No risk rule breaches or threshold warnings have been logged today.',
        time: 'Active',
        icon: 'shield'
      });

      // Insight 4: Focus asset based on recent trades if any
      const recentSymbols = recentTrades.map((t: any) => t.symbol);
      const mostFrequentSymbol = recentSymbols.length > 0 
        ? recentSymbols.sort((a, b) => recentSymbols.filter(v => v === a).length - recentSymbols.filter(v => v === b).length).pop()
        : null;

      if (mostFrequentSymbol) {
        insights.push({
          id: 'live-insight-focus',
          type: 'info',
          title: `Active trading pair: ${mostFrequentSymbol}`,
          subtitle: `Most of your executions today are in ${mostFrequentSymbol}. Keep managing risk per position.`,
          time: 'Today',
          icon: 'target'
        });
      }

      return insights.slice(0, 4); // Keep at most 4 items
    }

    // Map actual risk breach logs
    return breachLogs.map((log: any) => {
      const timeStr = log.created_at
        ? new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : 'Just now';

      let title = 'Risk threshold warning triggered';
      let subtitle = `A risk limit rule of ${log.rule_value} was exceeded (actual: ${log.actual_value}).`;
      let icon = 'alert';
      let type = log.severity?.toLowerCase() === 'critical' ? 'critical' : 'warning';

      if (log.breach_type === 'DAILY_DRAWDOWN') {
        title = 'Daily drawdown limit approached/breached';
        subtitle = `Drawdown of ${parseFloat(log.actual_value).toFixed(2)}% exceeded the safety threshold of ${parseFloat(log.rule_value).toFixed(2)}%.`;
        icon = 'alert';
      } else if (log.breach_type === 'MAX_LOT_SIZE') {
        title = 'Maximum position sizing exceeded';
        subtitle = `Executing position of ${log.actual_value} lots exceeded your risk limit of ${log.rule_value} lots.`;
        icon = 'alert';
      } else if (log.breach_type === 'MAX_OPEN_TRADES') {
        title = 'Maximum daily trade counts exhausted';
        subtitle = `Your account reached the daily trade limit of ${log.rule_value} executions.`;
        icon = 'alert';
      }

      return {
        id: log.id,
        type,
        title,
        subtitle,
        time: timeStr,
        icon
      };
    });
  }, [isConnected, breachLogs, avgDisciplineScore, winRate, recentTrades]);

  return (
    <DashboardLayout>
      <div className="max-w-[1600px] mx-auto space-y-8">
        <style>{`
          .amazing-scrollbar::-webkit-scrollbar {
            width: 5px;
            height: 6px;
          }
          .amazing-scrollbar::-webkit-scrollbar-button {
            display: none !important;
            width: 0 !important;
            height: 0 !important;
          }
          .amazing-scrollbar::-webkit-scrollbar-track {
            background: transparent;
          }
          .amazing-scrollbar::-webkit-scrollbar-thumb {
            background: rgba(156, 163, 175, 0.3);
            border-radius: 9999px;
          }
          .amazing-scrollbar::-webkit-scrollbar-thumb:hover {
            background: rgba(156, 163, 175, 0.5);
          }
          .dark .amazing-scrollbar::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.1);
          }
          .dark .amazing-scrollbar::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.2);
          }
        `}</style>

        {/* 1. Header Area */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-4 gap-4">
          <div>
            <h1 className="text-[32px] font-bold text-slate-900 dark:text-white tracking-tight leading-none min-h-[38px] flex items-center">
              {userName === null ? (
                <span className="flex items-center">Welcome back,&nbsp;<Skeleton className="h-8 w-24 bg-slate-200 dark:bg-white/10 inline-block rounded" />.</span>
              ) : (
                `Welcome back, ${userName}.`
              )}
            </h1>
            <p className="text-[14px] text-slate-500 font-medium mt-2 flex items-center gap-2">
              Markets are open <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            </p>
          </div>
          <div className="flex items-center gap-3 pb-1 shrink-0">
            {loading ? (
              <div className="px-4 py-1.5 bg-white dark:bg-[#171717] rounded-[16px] flex items-center gap-3.5 border border-slate-200 dark:border-[#262626] shadow-sm premium-flat-card !rounded-[16px] !py-1.5 !px-4 w-[280px]">
                <Skeleton className="h-4.5 w-full bg-slate-200 dark:bg-white/10 animate-pulse" />
              </div>
            ) : (
              <div className="px-4 py-1.5 bg-white dark:bg-[#171717] rounded-[16px] flex items-center gap-3.5 border border-slate-200 dark:border-[#262626] shadow-sm premium-flat-card !rounded-[16px] !py-1.5 !px-4">
                <div className="flex items-center gap-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${isConnected ? "bg-emerald-500" : "bg-amber-500 animate-pulse"}`}></div>
                  <span className="text-[12px] font-bold text-slate-900 dark:text-white tracking-wide">
                    {isConnected ? "MT5 Connected" : "MT5 Demo Stream"}
                  </span>
                  <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider ${isConnected ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-500" : "bg-amber-500/10 text-amber-600 dark:text-amber-500"}`}>
                    {isConnected ? "Live" : "Demo"}
                  </span>
                </div>
                <div className="w-px h-3.5 bg-slate-300 dark:bg-white/10"></div>
                <span className="text-[11.5px] font-semibold text-slate-600 dark:text-slate-350 tracking-wide">
                  Account: {isConnected ? accountMetrics?.account_number : "Demo Engine"}
                </span>
                <div className="w-px h-3.5 bg-slate-300 dark:bg-white/10"></div>
                <span className="text-[11.5px] font-semibold text-slate-600 dark:text-slate-350 tracking-wide">
                  Server: {isConnected ? accountMetrics?.broker_server : "Simulated"}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* 2. Top Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {loading ? (
            <>
              {Array.from({ length: 4 }).map((_, idx) => (
                <motion.div key={idx} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="h-[120px] px-5 py-4 rounded-[22px] border-2 border-white dark:border-[#262626] bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] dark:from-[#252528] dark:to-[#1A1A1C] shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-[0_4px_7px_-5px_rgba(0,0,0,0.3),0_0_0_2px_#333336] flex flex-col justify-between transition-all duration-300">
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-3.5 w-24 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-6 w-16 bg-slate-200 dark:bg-white/10" />
                  </div>
                  <div className="space-y-2">
                    <Skeleton className="h-7 w-32 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-3 w-20 bg-slate-200 dark:bg-white/10" />
                  </div>
                </motion.div>
              ))}
            </>
          ) : (
            <>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="h-[120px] px-5 py-4 rounded-[24px] border-2 border-white dark:border-transparent bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] premium-pnl-card shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-none flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-[0_4px_20px_rgba(59,130,246,0.1)]">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-white/60 uppercase tracking-widest">Account P&L</p>
                  <div className="flex items-center gap-2">
                    <SimpleSparkline data={MOCK_SPARKLINE} color="#10B981" />
                    <Info size={14} className="text-slate-350 dark:text-white/40" />
                  </div>
                </div>
                <div>
                  <h3 className={`text-[26px] font-bold tracking-tight leading-none ${totalProfit >= 0 ? "text-slate-900 dark:text-emerald-400" : "text-rose-500"}`}>
                    {totalProfit >= 0 ? "+" : "-"}${Math.abs(totalProfit).toFixed(2)}
                  </h3>
                  <p className={`text-[11px] font-medium mt-1 ${todayProfit >= 0 ? "text-emerald-450 dark:text-emerald-400" : "text-rose-500"}`}>
                    Today: {todayProfit >= 0 ? "+" : ""}${todayProfit.toFixed(2)}
                  </p>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="h-[120px] px-5 py-4 rounded-[24px] border-2 border-white dark:border-transparent bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] premium-flat-card shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-none flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-none">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-white/60 uppercase tracking-widest">Discipline Score</p>
                  <div className="flex items-center gap-2">
                    <SimpleSparkline data={MOCK_SPARKLINE} color="#3B82F6" />
                    <Info size={14} className="text-slate-350 dark:text-white/40" />
                  </div>
                </div>
                <div className="flex items-end gap-1.5">
                  <h3 className="text-[26px] font-bold text-slate-900 dark:text-white tracking-tight leading-none">
                    {avgDisciplineScore !== null ? avgDisciplineScore : "--"}
                  </h3>
                  <span className="text-[13px] text-slate-405 dark:text-white/40 font-bold mb-0.5">/ 100</span>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="h-[120px] px-5 py-4 rounded-[24px] border-2 border-white dark:border-transparent bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] premium-flat-card shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-none flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-none">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-white/60 uppercase tracking-widest">Win Rate (7D)</p>
                  <Info size={14} className="text-slate-350 dark:text-white/40" />
                </div>
                <div className="flex items-end justify-between">
                  <h3 className="text-[26px] font-bold text-slate-900 dark:text-white tracking-tight leading-none">{winRate}%</h3>
                  <div className="w-16 h-1.5 bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden mb-1">
                    <div className="h-full bg-blue-500" style={{ width: `${winRate}%` }}></div>
                  </div>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="h-[120px] px-5 py-4 rounded-[24px] border-2 border-white dark:border-transparent bg-gradient-to-b from-[#F4F4F4] to-[#FFFFFF] premium-flat-card shadow-[0_4px_7px_-5px_rgba(0,0,0,0.12),0_0_0_2px_#E7E7E7] dark:shadow-none flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_8px_15px_-5px_rgba(0,0,0,0.15),0_0_0_2px_#D0D0D5] dark:hover:shadow-none">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-white/60 uppercase tracking-widest">Daily XP Earned</p>
                  <Info size={14} className="text-slate-350 dark:text-white/40" />
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 dark:bg-purple-500/10 rounded-xl">
                    <Flame size={18} className="text-blue-650 dark:text-purple-400" />
                  </div>
                  <h3 className="text-[26px] font-bold text-blue-650 dark:text-purple-450 tracking-tight leading-none font-mono">
                    {dailyXpEarned >= 0 ? `+${dailyXpEarned}` : dailyXpEarned} XP
                  </h3>
                </div>
              </motion.div>
            </>
          )}
        </div>

        {/* 3. Center Stage & Right Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Daily Net Cumulative P&L */}
            <GlassCard className="p-7">
              {(() => {
                const isPositive = cumulativePnL.length > 0 && cumulativePnL[cumulativePnL.length - 1].v >= 0;
                const chartColor = isPositive ? "#4EBF94" : "#F06363";
                return (
                  <>
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h3 className="text-[15px] font-bold text-slate-900 dark:text-white leading-tight">Daily Net Cumulative P&L</h3>
                        <div className="flex items-center gap-1.5 text-[12px] font-semibold text-slate-500 mt-2">
                          <span className="w-2.5 h-2.5 rounded-full shadow-sm" style={{ backgroundColor: chartColor }} />
                          Cumulative P&L
                        </div>
                      </div>
                      <div className="flex items-center bg-slate-50 dark:bg-white/5 p-1 rounded-xl border border-slate-100 dark:border-[#333333]">
                        <button className="px-3 py-1 rounded-lg text-[11px] font-bold transition-all text-slate-400 hover:text-slate-700">1W</button>
                        <button className="px-3 py-1 rounded-lg text-[11px] font-bold transition-all text-slate-400 hover:text-slate-700">1M</button>
                        <button className="text-[11px] btn-neumorphic !py-1 !px-4">All</button>
                      </div>
                    </div>

                    <div className="h-[250px] w-full">
                      {loading ? (
                        <div className="h-full w-full flex items-end gap-3 pt-6 animate-pulse">
                          {Array.from({ length: 12 }).map((_, idx) => {
                            const heights = ["h-12", "h-20", "h-16", "h-28", "h-36", "h-24", "h-40", "h-48", "h-32", "h-44", "h-28", "h-20"];
                            return (
                              <div
                                key={idx}
                                className={`flex-1 ${heights[idx % heights.length]} bg-slate-200 dark:bg-white/10 rounded-t-lg`}
                              />
                            );
                          })}
                        </div>
                      ) : (
                        <ResponsiveContainer width="100%" height="100%" className="group focus:outline-none focus-visible:outline-none">
                          <AreaChart data={cumulativePnL} margin={{ top: 5, right: 5, left: 10, bottom: 0 }} style={{ outline: 'none' }}>
                            <defs>
                              <linearGradient id="colorPnl" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor={chartColor} stopOpacity={0.2} />
                                <stop offset="95%" stopColor={chartColor} stopOpacity={0} />
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke={isDark ? "rgba(255, 255, 255, 0.02)" : "#e2e8f0"} className="opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 500 }} axisLine={false} tickLine={false} />
                            <YAxis tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 500 }} axisLine={false} tickLine={false} tickFormatter={(val) => `$${val}`} />
                            <Tooltip
                              contentStyle={dynamicTooltipStyle}
                              itemStyle={{ color: isDark ? "#fff" : "#0f172a" }}
                              labelStyle={{ color: isDark ? "#94a3b8" : "#64748b" }}
                              formatter={(value: any) => {
                                const val = Number(value);
                                return [val >= 0 ? `+$${val.toFixed(2)}` : `-$${Math.abs(val).toFixed(2)}`, "Cumulative P&L"];
                              }}
                            />
                            <ReferenceLine y={0} stroke="#94a3b8" strokeDasharray="3 3" />
                            <Area type="monotone" dataKey="v" stroke={chartColor} strokeWidth={2.5} fillOpacity={1} fill="url(#colorPnl)" />
                          </AreaChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </>
                );
              })()}
            </GlassCard>

            {/* Live Risk Monitor */}
            <GlassCard className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <BarChart2 size={20} className="text-orange-500" />
                  <h2 className="text-[14px] font-bold text-slate-900 dark:text-white tracking-widest uppercase">Live Risk Monitor</h2>
                </div>
                <div className={riskMonitorData.riskLevelClass}>
                  Risk Level: {riskMonitorData.riskLevelText}
                </div>
              </div>

              {loading ? (
                <div className="grid grid-cols-2 gap-x-8 gap-y-6 mb-6 pb-6 border-b border-slate-100 dark:border-white/10">
                  {/* Q1 Loading */}
                  <div className="flex flex-col space-y-3 pr-4">
                    <Skeleton className="h-3 w-24 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-7 w-16 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-1 w-full bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-3.5 w-28 bg-slate-200 dark:bg-white/10" />
                  </div>
                  {/* Q2 Loading */}
                  <div className="flex flex-col space-y-3 pl-4 border-l border-slate-200 dark:border-white/10">
                    <Skeleton className="h-3 w-24 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-7 w-20 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-1 w-full bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-3.5 w-24 bg-slate-200 dark:bg-white/10" />
                  </div>
                  {/* Q3 Loading */}
                  <div className="flex flex-col space-y-3 pr-4 border-t border-slate-200 dark:border-white/10 pt-6">
                    <Skeleton className="h-3 w-32 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-7 w-12 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-1 w-full bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-3.5 w-20 bg-slate-200 dark:bg-white/10" />
                  </div>
                  {/* Q4 Loading */}
                  <div className="flex flex-col space-y-3 pl-4 border-l border-t border-slate-200 dark:border-white/10 pt-6">
                    <Skeleton className="h-3 w-24 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-7 w-20 bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-1 w-full bg-slate-200 dark:bg-white/10" />
                    <Skeleton className="h-3.5 w-24 bg-slate-200 dark:bg-white/10" />
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-x-8 gap-y-6 mb-6 pb-6 border-b border-slate-100 dark:border-white/10">
                  {/* Q1: Daily Executions */}
                  <div className="flex flex-col pr-4 pb-2">
                    <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1.5">Daily Executions</span>
                    <span className="text-[26px] font-bold text-slate-900 dark:text-white leading-none mb-3 tracking-tight">
                      {riskMonitorData.executionsCount} <span className="text-slate-400 dark:text-slate-500 text-[18px]">/ {riskMonitorData.executionsLimit}</span>
                    </span>
                    <div className="h-1 bg-slate-100 dark:bg-white/5 rounded-full w-full mb-2 overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${riskMonitorData.executionsPercentage}%` }} />
                    </div>
                    <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      {riskMonitorData.executionsRemaining} trade{riskMonitorData.executionsRemaining === 1 ? '' : 's'} remaining
                    </span>
                  </div>

                  {/* Q2: Daily Drawdown */}
                  <div className="flex flex-col pl-4 pb-2 border-l border-slate-100 dark:border-white/10">
                    <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1.5">Daily Drawdown</span>
                    <span className="text-[26px] font-bold text-slate-900 dark:text-white leading-none mb-3 tracking-tight tabular-nums">
                      ${riskMonitorData.drawdownDollar.toFixed(2)}
                    </span>
                    <div className="h-1 bg-slate-100 dark:bg-white/5 rounded-full w-full mb-2 overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${riskMonitorData.drawdownProgressPercent}%` }} />
                    </div>
                    <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      <span>Limit:</span>
                      <span className="font-bold text-slate-700 dark:text-slate-300 tabular-nums">${riskMonitorData.drawdownLimitDollar.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Q3: Drawdown Progress */}
                  <div className="flex flex-col pr-4 pt-4 border-t border-slate-100 dark:border-white/10">
                    <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1.5">Drawdown Progress</span>
                    <span className="text-[26px] font-bold text-emerald-500 leading-none mb-3 tracking-tight tabular-nums">
                      {riskMonitorData.drawdownPercentage.toFixed(2)}%
                    </span>
                    <div className="h-1 bg-slate-100 dark:bg-white/5 rounded-full w-full mb-2 overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${riskMonitorData.drawdownProgressPercent}%` }} />
                    </div>
                    <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      of {riskMonitorData.drawdownLimitPercentage.toFixed(2)}% Limit
                    </span>
                  </div>

                  {/* Q4: Revenge Guard */}
                  <div className="flex flex-col pl-4 pt-4 border-l border-t border-slate-100 dark:border-white/10">
                    <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1.5">Revenge Guard</span>
                    <div className="flex items-center gap-1.5 mb-3">
                      <span className={`w-2.5 h-2.5 rounded-full ${riskMonitorData.revengeGuardColor} animate-pulse`} />
                      <span className={`text-[18px] font-bold ${riskMonitorData.revengeGuardTextClass} tracking-wide uppercase leading-none`}>
                        {riskMonitorData.revengeGuardStatus}
                      </span>
                    </div>
                    <div className="h-1 bg-slate-100 dark:bg-white/5 rounded-full w-full mb-2 overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: riskMonitorData.revengeGuardStatus === "Engaged" ? "0%" : "100%" }} />
                    </div>
                    <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      {riskMonitorData.revengeGuardStatus === "Engaged" ? "Killswitch Engaged" : "Active Protection"}
                    </span>
                  </div>
                </div>
              )}

              {/* Bottom Row: Emergency Stop */}
              <div className="mt-4">
                <div
                  className={`flex items-center justify-between p-4 rounded-2xl border transition-all duration-300 ${
                    emergencyStop
                      ? "bg-rose-500 border-rose-500 text-white shadow-lg shadow-rose-500/20"
                      : "bg-slate-50/50 dark:bg-white/[0.02] border-slate-100 dark:border-white/10"
                  }`}
                >
                  <div className="flex flex-col">
                    <span className={`text-[14px] font-bold ${emergencyStop ? "text-white" : "text-slate-900 dark:text-white"}`}>
                      Emergency Stop
                    </span>
                    <span className={`text-[12px] font-medium mt-0.5 ${emergencyStop ? "text-rose-100" : "text-slate-500 dark:text-slate-400"}`}>
                      Kill all active trades
                    </span>
                  </div>
                  
                  {/* Custom Tailwind Switch */}
                  <button
                    onClick={() => {
                      const nextState = !emergencyStop;
                      setEmergencyStop(nextState);
                      if (nextState) {
                        toast.error("EMERGENCY STOP ACTIVATED! Automations paused.", {
                          description: "All active positions have been killed.",
                          duration: 4000,
                        });
                      } else {
                        toast.success("Emergency Stop deactivated.", {
                          description: "Algos and limits are back to standby.",
                        });
                      }
                    }}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      emergencyStop ? "bg-white" : "bg-slate-200 dark:bg-slate-700"
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                        emergencyStop 
                          ? "translate-x-5 bg-rose-600" 
                          : "translate-x-0 bg-white"
                      }`}
                    />
                  </button>
                </div>
              </div>
            </GlassCard>
            <SessionIntensityGauge loading={loading} />
            <DefenseProtocols loading={loading} />
          </div>

          {/* AI Coach Insights */}
          <div className="lg:col-span-1 space-y-6">
            <GlassCard className="flex flex-col p-6">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                  <BrainCircuit size={18} className="text-purple-500" />
                  <h2 className="text-[14px] font-bold text-slate-900 dark:text-white tracking-widest uppercase">AI Coach Insights</h2>
                </div>
                <div className="bg-purple-100 dark:bg-[#2D1B69] text-purple-700 dark:text-purple-300 text-[10px] font-bold px-2.5 py-1 rounded-md uppercase tracking-wider">AI</div>
              </div>

              {loading ? (
                <div className="flex-1 space-y-6">
                  {Array.from({ length: 4 }).map((_, idx) => (
                    <div key={idx} className="space-y-2">
                      <div className="flex gap-4">
                        <Skeleton className="h-8 w-8 rounded-full bg-slate-200 dark:bg-white/10 shrink-0" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-full bg-slate-200 dark:bg-white/10" />
                          <Skeleton className="h-3.5 w-2/3 bg-slate-200 dark:bg-white/10" />
                        </div>
                      </div>
                      {idx < 3 && <div className="w-full h-px bg-slate-100 dark:bg-white/5 my-2"></div>}
                    </div>
                  ))}
                </div>
              ) : (
                <>
                  <div className="flex-1 space-y-6">
                    {aiInsights.map((insight, idx) => {
                      let iconEl = <AlertTriangle size={14} className="text-rose-500" />;
                      let bgClass = "bg-rose-500/10 border-rose-500/20";
                      
                      if (insight.type === 'success') {
                        iconEl = <ShieldCheck size={14} className="text-emerald-500" />;
                        bgClass = "bg-emerald-500/10 border-emerald-500/20";
                      } else if (insight.type === 'info') {
                        if (insight.icon === 'target') {
                          iconEl = <Target size={14} className="text-purple-500" />;
                          bgClass = "bg-purple-500/10 border-purple-500/20";
                        } else {
                          iconEl = <TrendingDown size={14} className="text-blue-500" />;
                          bgClass = "bg-blue-500/10 border-blue-500/20";
                        }
                      } else if (insight.type === 'warning') {
                        iconEl = <AlertTriangle size={14} className="text-amber-500" />;
                        bgClass = "bg-amber-500/10 border-amber-500/20";
                      } else if (insight.type === 'critical') {
                        iconEl = <AlertTriangle size={14} className="text-rose-500" />;
                        bgClass = "bg-rose-500/10 border-rose-500/20";
                      }

                      return (
                        <div key={insight.id}>
                          <div className="flex gap-4">
                            <div className={`mt-1 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border ${bgClass}`}>
                              {iconEl}
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between items-start mb-1">
                                <p className="text-[13px] font-bold text-slate-800 dark:text-indigo-200 leading-tight">
                                  {insight.title}
                                </p>
                                <span className="text-[10px] text-slate-500 font-medium whitespace-nowrap ml-2 mt-0.5">
                                  {insight.time}
                                </span>
                              </div>
                              <p className="text-[13px] text-slate-400 font-medium mt-1">
                                {insight.subtitle}
                              </p>
                            </div>
                          </div>
                          {idx < aiInsights.length - 1 && (
                            <div className="w-full h-px bg-slate-100 dark:bg-white/5 my-2"></div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <button onClick={() => navigate("/ai-coach")} className="w-full mt-8 btn-neumorphic text-[12px]">
                    Ask AI Coach <Brain size={14} className="ml-1" />
                  </button>
                </>
              )}
            </GlassCard>

            {/* Journal Preview */}
            <GlassCard className="flex flex-col p-6">
              <h2 className="text-[14px] font-bold text-slate-900 dark:text-white tracking-widest uppercase mb-4">Journal Preview</h2>

              {loading ? (
                <div className="space-y-4">
                  <div className="rounded-2xl p-5 border border-slate-100 dark:border-[#262626] bg-slate-50/50 dark:bg-white/[0.02]">
                    <Skeleton className="h-5 w-2/3 bg-slate-200 dark:bg-white/10 mb-2 animate-pulse" />
                    <Skeleton className="h-3.5 w-full bg-slate-200 dark:bg-white/10 mb-1 animate-pulse" />
                    <Skeleton className="h-3.5 w-1/2 bg-slate-200 dark:bg-white/10 animate-pulse" />
                  </div>
                  <div className="space-y-2">
                    <Skeleton className="h-12 w-full bg-slate-200 dark:bg-white/10 rounded-xl animate-pulse" />
                    <Skeleton className="h-12 w-full bg-slate-200 dark:bg-white/10 rounded-xl animate-pulse" />
                  </div>
                </div>
              ) : (
                <>
                  <div className="mb-4">
                    <h3 className="text-[12px] font-bold text-purple-400 mb-2">Latest Insight</h3>
                    <div className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-[#1E1240] dark:to-[#120A28] rounded-2xl p-5 border border-purple-200 dark:border-purple-500/20 relative overflow-hidden">
                      <div className="absolute right-[-20px] top-[-20px] opacity-40 blur-xl">
                        <div className="w-32 h-32 bg-purple-500 rounded-full mix-blend-screen dark:mix-blend-screen mix-blend-multiply"></div>
                      </div>
                      <div className="relative z-10 pr-16">
                        <p className="text-[16px] font-bold text-slate-900 dark:text-white leading-snug mb-2">
                          "{journalPreviewData.bestSymbolInsight.title}"
                        </p>
                        <p className="text-[12px] text-slate-600 dark:text-slate-300 font-medium mb-3">
                          {journalPreviewData.bestSymbolInsight.subtitle}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                          – AI Coach
                        </p>
                      </div>
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 z-10 text-purple-400">
                        <Trophy size={48} className="drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    {journalPreviewData.trades.length === 0 ? (
                      <div className="p-4 rounded-xl border border-dashed border-slate-200 dark:border-white/10 text-center text-slate-400 text-[12px] py-8">
                        Waiting for completed trades to populate preview ledger.
                      </div>
                    ) : (
                      journalPreviewData.trades.map((trade: any) => (
                        <div key={trade.id} className="bg-slate-50 dark:bg-white/5 rounded-xl p-3 border border-slate-100 dark:border-[#262626] flex gap-3 items-start">
                          <div className="mt-0.5 text-emerald-500">
                            <Focus size={14} />
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5 text-[11px] mb-1">
                              <span className="text-slate-400">{trade.time}</span>
                              <span className="text-slate-600">•</span>
                              <span className="text-slate-800 dark:text-slate-300 font-bold">{trade.symbol}</span>
                              <span className="text-slate-600">•</span>
                              <span className={`${trade.profit >= 0 ? "text-emerald-600 dark:text-emerald-500" : "text-rose-600 dark:text-rose-500"} font-bold`}>
                                {trade.profit >= 0 ? '+' : ''}${trade.profit.toFixed(2)}
                              </span>
                            </div>
                            <p className="text-[12px] text-slate-600 dark:text-slate-300 font-medium">{trade.note}</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  <button onClick={() => navigate("/journal")} className="w-full btn-neumorphic text-[12px]">
                    Open Full Journal <ChevronRight size={14} />
                  </button>
                </>
              )}
            </GlassCard>
            {/* Live News Feed */}
            <LiveNewsFeed />

            {/* Alert Center */}
            <GlassCard className="flex flex-col p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <h2 className="text-[14px] font-bold text-slate-900 dark:text-white tracking-widest uppercase">Alert Center</h2>
                  {!loading && alertCenterAlerts.length > 0 && (
                    <div className="bg-rose-500/20 text-rose-500 text-[10px] font-bold px-2 py-0.5 rounded-full border border-rose-500/30">
                      {alertCenterAlerts.length}
                    </div>
                  )}
                </div>
                {!loading && (
                  <button className="text-[12px] font-bold text-slate-400 hover:text-slate-300 transition-colors flex items-center gap-1">
                    View All <ChevronRight size={14} />
                  </button>
                )}
              </div>

              {loading ? (
                <div className="space-y-4 pt-4">
                  {Array.from({ length: 4 }).map((_, idx) => (
                    <div key={idx} className="flex items-center gap-4 py-2 border-b border-slate-100 dark:border-[#262626] last:border-0">
                      <Skeleton className="w-8 h-8 rounded-full bg-slate-200 dark:bg-white/10 shrink-0" />
                      <div className="flex-1 space-y-1.5">
                        <Skeleton className="h-4 w-1/2 bg-slate-200 dark:bg-white/10" />
                        <Skeleton className="h-3 w-1/3 bg-slate-200 dark:bg-white/10" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-0">
                  {alertCenterAlerts.map((alert: any) => {
                    let iconEl = <Zap size={13} className="text-amber-500" strokeWidth={2.5} />;
                    let bgClass = "border-amber-500/50 bg-amber-500/10 shadow-[0_0_12px_rgba(245,158,11,0.2)]";

                    if (alert.type === 'danger') {
                      iconEl = <Plus size={14} className="text-rose-500" strokeWidth={2.5} />;
                      bgClass = "border-rose-500/50 bg-rose-500/10 shadow-[0_0_12px_rgba(244,63,94,0.3)]";
                    } else if (alert.type === 'info') {
                      iconEl = <Zap size={13} className="text-amber-500" strokeWidth={2.5} />;
                      bgClass = "border-amber-500/50 bg-amber-500/10 shadow-[0_0_12px_rgba(245,158,11,0.2)]";
                    } else if (alert.type === 'success') {
                      iconEl = <ShieldCheck size={13} className="text-emerald-500" strokeWidth={2.5} />;
                      bgClass = "border-emerald-500/50 bg-emerald-500/10 shadow-[0_0_12px_rgba(16,185,129,0.2)]";
                    } else if (alert.type === 'purple') {
                      iconEl = <BrainCircuit size={13} className="text-purple-500" strokeWidth={2.5} />;
                      bgClass = "border-purple-500/50 bg-purple-500/10 shadow-[0_0_12px_rgba(168,85,247,0.2)]";
                    }

                    return (
                      <div key={alert.id} className="flex items-center gap-4 py-4 border-b border-slate-100 dark:border-[#262626] last:border-0">
                        <div className={`flex-shrink-0 w-8 h-8 rounded-full border-[1.5px] flex items-center justify-center ${bgClass}`}>
                          {iconEl}
                        </div>
                        <div className="flex-1">
                          <p className="text-[13px] font-bold text-slate-900 dark:text-white leading-tight mb-1">{alert.title}</p>
                          <p className="text-[12px] text-slate-500 font-medium">{alert.subtitle}</p>
                        </div>
                        <span className="text-[11px] font-medium text-slate-500 whitespace-nowrap ml-2">{alert.time}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </GlassCard>
          </div>
        </div>



      </div>

      <AnimatePresence>
        {shareTrade && <ShareModal trade={shareTrade} onClose={() => setShareTrade(null)} />}
      </AnimatePresence>
    </DashboardLayout>
  );
}











