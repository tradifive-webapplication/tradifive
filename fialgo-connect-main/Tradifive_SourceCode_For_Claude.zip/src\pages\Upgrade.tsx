import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Shield,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useTrading } from "@/contexts/TradingContext";
import { supabase } from "@/lib/supabase";
import { PricingCards } from "@/components/PricingCards";
import { loadRazorpayScript } from "@/utils/razorpay";

export default function Upgrade() {
  const navigate = useNavigate();
  const { setSubscription } = useTrading();

  const [selectedPlan, setSelectedPlan] = useState<"starter" | "pro" | "elite">(() => {
    const params = new URLSearchParams(window.location.search);
    const planParam = params.get('plan');
    if (planParam && ["starter", "pro", "elite"].includes(planParam)) {
      return planParam as "starter" | "pro" | "elite";
    }
    return "pro";
  });
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const finalizeConnection = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase
        .from('profiles')
        .update({ subscription_status: selectedPlan })
        .eq('id', user.id);
    }

    setSubscription(selectedPlan as any, selectedPlan === "starter" ? "demo" : "real");
    navigate("/journal");
  };

  const handlePayment = async () => {
    if (selectedPlan === 'starter') {
      await finalizeConnection();
      return;
    }

    setIsProcessing(true);
    const isLoaded = await loadRazorpayScript();
    
    if (!isLoaded) {
      alert("Razorpay SDK failed to load. Please check your connection.");
      setIsProcessing(false);
      return;
    }

    const planPrices = {
      pro: 99900, // ₹999.00
      elite: 499900 // ₹4999.00
    };

    const options = {
      // TODO: Replace with your actual Razorpay Test Key from dashboard
      key: "rzp_test_YOUR_KEY_HERE", 
      amount: planPrices[selectedPlan as "pro" | "elite"],
      currency: "INR",
      name: "Tradifive",
      description: `Upgrade to ${selectedPlan.toUpperCase()} Plan`,
      handler: async function (response: any) {
        // Payment successful
        await finalizeConnection();
        setIsProcessing(false);
      },
      prefill: {
        name: "Tradifive Trader",
        email: "trader@example.com",
        contact: "9999999999",
      },
      theme: {
        color: "#2563eb",
      },
    };

    try {
      const rzp = new (window as any).Razorpay(options);
      rzp.on("payment.failed", function (response: any) {
        alert("Payment failed: " + response.error.description);
        setIsProcessing(false);
      });
      rzp.open();
      setShowPaymentModal(false);
    } catch (error) {
      console.error("Razorpay error:", error);
      alert("Failed to initialize Razorpay. Please make sure you added a valid Test Key in the code.");
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] font-sans overflow-x-hidden relative flex flex-col items-center pt-24 pb-20">
      {/* Background gradients similar to Landing page */}
      <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-purple-900/20 blur-[120px] rounded-full pointer-events-none z-0" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-blue-900/10 blur-[120px] rounded-full pointer-events-none z-0" />

      {/* BACK BUTTON */}
      <div className="absolute top-8 right-8 z-[50]">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-slate-300 hover:text-white transition-all text-[12px] font-bold shadow-md"
        >
          <X size={16} />
          Back
        </button>
      </div>

      <div className="text-center mb-16 relative z-10">
        <h1 className="text-[32px] md:text-5xl font-black text-white tracking-tight mb-4">
          Choose Your Edge
        </h1>
        <p className="text-slate-400 font-medium text-lg max-w-lg mx-auto">
          Scale your trading with professional tools. Upgrade your plan to unlock more intelligence.
        </p>
      </div>

      <div className="relative z-10 w-full px-6">
        <PricingCards 
          selectedPlan={selectedPlan} 
          onSelectPlan={setSelectedPlan} 
          onUpgradeClick={(plan) => {
            setSelectedPlan(plan);
            setShowPaymentModal(true);
          }}
          isStandalone={true} 
        />
      </div>

      {/* Payment modal */}
      <AnimatePresence>
        {showPaymentModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isProcessing && setShowPaymentModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-[#121214] border border-[#2B2B2F] rounded-3xl p-8 shadow-2xl overflow-hidden"
            >
              <button
                onClick={() => !isProcessing && setShowPaymentModal(false)}
                className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-white/10 rounded-full text-white/50 hover:text-white transition-colors disabled:opacity-50"
                disabled={isProcessing}
              >
                <X size={16} />
              </button>

              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Shield size={32} className="text-blue-500" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Initialize Connection</h3>
                <p className="text-[#B5BAC1] text-[13px]">
                  You are selecting the <span className="font-bold text-white capitalize">{selectedPlan}</span> protocol.
                </p>
              </div>

              <button
                onClick={handlePayment}
                disabled={isProcessing}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 disabled:text-white/50 text-white font-bold rounded-xl shadow-lg shadow-blue-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <span className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                    Opening Razorpay...
                  </>
                ) : (
                  selectedPlan === 'starter' ? 'Start Free Tier' : 'Proceed to Payment'
                )}
              </button>
              <p className="text-[10px] text-gray-400 text-center mt-4 leading-relaxed">
                Secure checkout via Razorpay Test Mode
              </p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
