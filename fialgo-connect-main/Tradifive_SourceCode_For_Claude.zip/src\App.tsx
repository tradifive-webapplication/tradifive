import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TradingProvider } from "@/contexts/TradingContext";
import { AuthGuard } from "@/components/AuthGuard";
import { MaintenanceGuard } from "@/components/MaintenanceGuard";
import { ProtectedLayout } from "./components/ProtectedLayout";
import Landing from "./pages/Landing";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Settings from "./pages/Settings";

import Profile from "./pages/Profile";
import Channel from "./pages/Channel";
import Inbox from "./pages/Inbox";
import NotFound from "./pages/NotFound";
import RiskGuard from "./pages/RiskGuard";
import Journal from "./pages/Journal";
import Rewards from "./pages/Rewards";
import VerifyEmail from "./pages/VerifyEmail";
import Support from "./pages/Support";
import Feedback from "./pages/Feedback";
import Upgrade from "./pages/Upgrade";
import Notifications from "./pages/Notifications";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import CompetitionsDashboard from "./pages/CompetitionsDashboard";
import CompetitionsLeaderboard from "./pages/CompetitionsLeaderboard";
import CompetitionsRewards from "./pages/CompetitionsRewards";
import TradifiveAI from "./pages/TradifiveAI";
import ChallengeConsole from "./pages/ChallengeConsole";
import Payouts from "./pages/Payouts";
import Transactions from "./pages/Transactions";
import RiskGuardPublic from "./pages/RiskGuardPublic";
import AutomatedJournalPublic from "./pages/AutomatedJournalPublic";
import Home from "./pages/Home";
import DownloadAppPublic from "./pages/DownloadAppPublic";
import DiscoverPublic from "./pages/DiscoverPublic";
import ChannelsPublic from "./pages/ChannelsPublic";
import PulseFeedsPublic from "./pages/PulseFeedsPublic";
import Discover from "./pages/Discover";
import UserProfilePublic from "./pages/UserProfilePublic";
import { NetworkNotifier } from "@/components/NetworkNotifier";

import { AdminRoute } from "./components/AdminRoute";
import AdminOverview from "./pages/admin/AdminOverview";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminTrading from "./pages/admin/AdminTrading";
import AdminFinance from "./pages/admin/AdminFinance";
import AdminSupport from "./pages/admin/AdminSupport";
import AdminLogs from "./pages/admin/AdminLogs";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <NetworkNotifier />
      <TradingProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/download" element={<DownloadAppPublic />} />
            <Route path="/features/discover" element={<DiscoverPublic />} />
            <Route path="/features/channels" element={<ChannelsPublic />} />
            <Route path="/features/pulse-feeds" element={<PulseFeedsPublic />} />
            <Route path="/login" element={<Login />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/verify-email" element={<VerifyEmail />} />
            <Route path="/features/risk-guard" element={<RiskGuardPublic />} />
            <Route path="/features/automated-journal" element={<AutomatedJournalPublic />} />
            
            {/* Protected Routes Wrapper */}
            <Route element={<ProtectedLayout />}>
              <Route path="/home" element={<Home />} />
              <Route path="/discover" element={<Discover />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/journal" element={<Journal />} />
              <Route path="/risk-guard" element={<RiskGuard />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/ai-coach" element={<TradifiveAI />} />
              <Route path="/rewards" element={<Rewards />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/user/:username" element={<UserProfilePublic />} />
              <Route path="/channel" element={<Channel />} />
              <Route path="/inbox" element={<Inbox />} />
              <Route path="/support" element={<Support />} />
              <Route path="/feedback" element={<Feedback />} />
              <Route path="/upgrade" element={<Upgrade />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/competitions/dashboard" element={<CompetitionsDashboard />} />
              <Route path="/competitions/leaderboard" element={<CompetitionsLeaderboard />} />
              <Route path="/competitions/challenge/:id" element={<ChallengeConsole />} />
              <Route path="/competitions/payouts" element={<Payouts />} />
              <Route path="/competitions/transaction" element={<Transactions />} />
              <Route path="/competitions/rewards" element={<CompetitionsRewards />} />
            </Route>

            {/* Admin Routes */}
            <Route path="/admin" element={<AdminRoute><AdminOverview /></AdminRoute>} />
            <Route path="/admin/users" element={<AdminRoute><AdminUsers /></AdminRoute>} />
            <Route path="/admin/trading" element={<AdminRoute><AdminTrading /></AdminRoute>} />
            <Route path="/admin/finance" element={<AdminRoute><AdminFinance /></AdminRoute>} />
            <Route path="/admin/support" element={<AdminRoute><AdminSupport /></AdminRoute>} />
            <Route path="/admin/logs" element={<AdminRoute><AdminLogs /></AdminRoute>} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TradingProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
